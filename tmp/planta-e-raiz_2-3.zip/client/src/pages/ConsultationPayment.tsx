import React, { useState, useEffect } from "react";
import { Copy, Check, Clock, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";



export default function ConsultationPayment() {
  const [location, setLocation] = useLocation();
  const [copied, setCopied] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<"pending" | "confirmed" | "failed">("pending");
  const [qrCode, setQrCode] = useState("");
  const [pixCode, setPixCode] = useState("");
  const [orderId, setOrderId] = useState("");

  // Get query params
  const params = new URLSearchParams(window.location.search);
  const specialistId = params.get("specialist");
  const strainId = params.get("strain");

  // Mock specialist and strain data
  const specialist = {
    id: specialistId,
    name: "Dr. João Silva",
    specialty: "Epilepsy & Seizures",
    price: 150
  };

  const strain = {
    id: strainId,
    name: "Charlotte's Web"
  };

  // Create payment preference
  const createPaymentMutation = trpc.consultation.createConsultationPreference.useMutation({
    onSuccess: (response) => {
      if (response.qrCode && response.pixCode) {
        setQrCode(response.qrCode);
        setPixCode(response.pixCode);
        setOrderId(response.orderId);
        pollPaymentStatus(response.orderId);
      }
    },
    onError: (error) => {
      console.error("Error creating payment:", error);
      setPaymentStatus("failed");
    }
  });

  useEffect(() => {
    if (specialistId && strainId) {
      createPaymentMutation.mutate({
        specialistId: parseInt(specialistId),
        strainId: parseInt(strainId),
        amount: specialist.price
      });
    }
  }, [specialistId, strainId]);

  // Poll for payment status
  const pollPaymentStatus = (orderId: string) => {
    let pollCount = 0;
    const maxPolls = 300; // 15 minutes at 3-second intervals

    const checkPayment = async () => {
      pollCount++;
      if (pollCount > maxPolls) return;

      try {
        // Simulate payment check
        // In production, this would call the actual API
        if (Math.random() > 0.7 || pollCount > 5) {
          setPaymentStatus("confirmed");
          
          // Redirect to interview after 2 seconds
          setTimeout(() => {
            setLocation(`/consultation/interview?specialist=${specialistId}&strain=${strainId}&order=${orderId}`);
          }, 2000);
          return;
        }
      } catch (error) {
        console.error("Error checking payment status:", error);
      }
    };

    const interval = setInterval(checkPayment, 3000); // Check every 3 seconds
    checkPayment(); // Check immediately

    // Stop polling after 15 minutes
    setTimeout(() => clearInterval(interval), 15 * 60 * 1000);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(pixCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0e27] to-[#1a1f3a] text-white">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#0a0e27]/95 backdrop-blur border-b border-yellow-400/20 py-4">
        <div className="max-w-2xl mx-auto px-4">
          <h1 className="text-2xl font-bold text-yellow-400">Consulta Médica</h1>
          <p className="text-gray-400 text-sm">Pagamento via PIX - Mercado Pago</p>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-8">
        {/* Order Summary */}
        <div className="bg-[#1a1f3a] border border-yellow-400/20 rounded-lg p-6 mb-6">
          <h2 className="text-lg font-semibold text-yellow-400 mb-4">Resumo da Consulta</h2>
          
          <div className="space-y-3 mb-6 pb-6 border-b border-gray-700">
            <div className="flex justify-between">
              <span className="text-gray-400">Especialista:</span>
              <span className="text-white font-semibold">{specialist.name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Especialidade:</span>
              <span className="text-white font-semibold">{specialist.specialty}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Espécie de Cannabis:</span>
              <span className="text-white font-semibold">{strain.name}</span>
            </div>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-lg text-gray-400">Valor Total:</span>
            <span className="text-3xl font-bold text-yellow-400">R$ {specialist.price.toFixed(2)}</span>
          </div>
        </div>

        {/* Payment Status */}
        {paymentStatus === "pending" && (
          <>
            {/* QR Code Section */}
            <div className="bg-[#1a1f3a] border border-yellow-400/20 rounded-lg p-6 mb-6">
              <h2 className="text-lg font-semibold text-yellow-400 mb-4">Escanear QR Code</h2>
              
              {qrCode ? (
                <div className="flex justify-center mb-6">
                  <img
                    src={qrCode}
                    alt="QR Code PIX"
                    className="w-64 h-64 bg-white p-4 rounded-lg"
                  />
                </div>
              ) : (
                <div className="flex justify-center mb-6">
                  <div className="w-64 h-64 bg-gray-700 rounded-lg animate-pulse flex items-center justify-center">
                    <span className="text-gray-400">Gerando QR Code...</span>
                  </div>
                </div>
              )}

              <p className="text-center text-gray-400 text-sm mb-4">
                Abra seu app de banco ou Mercado Pago e escaneie o QR Code acima
              </p>
            </div>

            {/* PIX Code Section */}
            <div className="bg-[#1a1f3a] border border-yellow-400/20 rounded-lg p-6 mb-6">
              <h2 className="text-lg font-semibold text-yellow-400 mb-4">Ou copie o código PIX</h2>
              
              <div className="bg-[#0a0e27] border border-yellow-400/30 rounded-lg p-4 mb-4">
                <p className="text-xs text-gray-400 mb-2">Código PIX (Copia e Cola):</p>
                <div className="flex items-center gap-2">
                  <code className="flex-1 text-xs text-yellow-400 break-all font-mono">
                    {pixCode || "Gerando código..."}
                  </code>
                  <button
                    onClick={copyToClipboard}
                    className="p-2 hover:bg-yellow-400/20 rounded transition"
                  >
                    {copied ? (
                      <Check className="w-5 h-5 text-green-400" />
                    ) : (
                      <Copy className="w-5 h-5 text-yellow-400" />
                    )}
                  </button>
                </div>
              </div>

              <p className="text-center text-gray-400 text-sm">
                {copied ? "✓ Código copiado!" : "Clique no ícone para copiar"}
              </p>
            </div>

            {/* Payment Instructions */}
            <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4 mb-6 flex gap-3">
              <AlertCircle className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-blue-200">
                <p className="font-semibold mb-1">Instruções de Pagamento:</p>
                <ol className="list-decimal list-inside space-y-1 text-xs">
                  <li>Abra seu app de banco ou Mercado Pago</li>
                  <li>Selecione "Transferência PIX"</li>
                  <li>Escaneie o QR Code ou copie o código</li>
                  <li>Confirme o pagamento de R$ {specialist.price.toFixed(2)}</li>
                  <li>Aguarde a confirmação (pode levar alguns segundos)</li>
                </ol>
              </div>
            </div>

            {/* Waiting for Payment */}
            <div className="bg-[#1a1f3a] border border-yellow-400/20 rounded-lg p-6 flex items-center justify-center gap-3">
              <Clock className="w-5 h-5 text-yellow-400 animate-spin" />
              <p className="text-gray-300">Aguardando confirmação do pagamento...</p>
            </div>
          </>
        )}

        {/* Payment Confirmed */}
        {paymentStatus === "confirmed" && (
          <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-8 text-center">
            <div className="text-5xl mb-4">✓</div>
            <h2 className="text-2xl font-bold text-green-400 mb-2">Pagamento Confirmado!</h2>
            <p className="text-gray-300 mb-6">
              Redirecionando para a entrevista com IA...
            </p>
            <div className="flex justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-yellow-400"></div>
            </div>
          </div>
        )}

        {/* Payment Failed */}
        {paymentStatus === "failed" && (
          <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-8 text-center">
            <div className="text-5xl mb-4">✗</div>
            <h2 className="text-2xl font-bold text-red-400 mb-2">Erro no Pagamento</h2>
            <p className="text-gray-300 mb-6">
              Ocorreu um erro ao processar seu pagamento. Por favor, tente novamente.
            </p>
            <Button
              onClick={() => setLocation("/cannabis-library")}
              className="bg-yellow-400 hover:bg-yellow-500 text-black font-semibold"
            >
              Voltar
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
