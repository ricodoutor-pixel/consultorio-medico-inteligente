import { router, publicProcedure, protectedProcedure } from '../_core/trpc';
import { z } from 'zod';
import { cacheGet, cacheSet, cacheDel, cacheInvalidatePattern } from '../_core/cache';
import { UserCreateSchema, UserUpdateSchema, PaginationSchema } from '../_core/validation';

/**
 * Example router demonstrating:
 * - Zod validation
 * - Redis caching
 * - Error handling
 */
export const exampleValidatedRouter = router({
  // Get all users with caching
  getAllUsers: publicProcedure
    .input(PaginationSchema)
    .query(async ({ input }) => {
      const cacheKey = `users:all:${input.page}:${input.limit}`;

      // Try to get from cache
      const cached = await cacheGet<any>(cacheKey);
      if (cached) {
        return {
          data: cached,
          fromCache: true,
        };
      }

      // Simulate database query
      const users = Array.from({ length: input.limit }, (_, i) => ({
        id: `user-${(input.page - 1) * input.limit + i + 1}`,
        name: `User ${(input.page - 1) * input.limit + i + 1}`,
        email: `user${(input.page - 1) * input.limit + i + 1}@example.com`,
      }));

      // Cache for 1 hour
      await cacheSet(cacheKey, users, 3600);

      return {
        data: users,
        fromCache: false,
      };
    }),

  // Get user by ID with caching
  getUserById: publicProcedure
    .input(z.object({ id: z.string() }))
    .query(async ({ input }) => {
      const cacheKey = `user:${input.id}`;

      // Try cache first
      const cached = await cacheGet<any>(cacheKey);
      if (cached) {
        return cached;
      }

      // Simulate database query
      const user = {
        id: input.id,
        name: 'John Doe',
        email: 'john@example.com',
      };

      // Cache for 30 minutes
      await cacheSet(cacheKey, user, 1800);

      return user;
    }),

  // Create user with validation
  createUser: protectedProcedure
    .input(UserCreateSchema)
    .mutation(async ({ input, ctx }) => {
      // Validate input (already done by Zod)
      const newUser = {
        id: `user-${Date.now()}`,
        ...input,
        createdAt: new Date(),
      };

      // Invalidate users list cache
      await cacheInvalidatePattern('users:all:*');

      return {
        success: true,
        data: newUser,
      };
    }),

  // Update user with validation
  updateUser: protectedProcedure
    .input(
      z.object({
        id: z.string(),
        data: UserUpdateSchema,
      })
    )
    .mutation(async ({ input }) => {
      // Delete user cache
      await cacheDel(`user:${input.id}`);
      // Invalidate users list cache
      await cacheInvalidatePattern('users:all:*');

      return {
        success: true,
        message: 'User updated',
      };
    }),

  // Delete user
  deleteUser: protectedProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ input }) => {
      // Delete user cache
      await cacheDel(`user:${input.id}`);
      // Invalidate users list cache
      await cacheInvalidatePattern('users:all:*');

      return {
        success: true,
        message: 'User deleted',
      };
    }),

  // Search users with validation
  searchUsers: publicProcedure
    .input(
      z.object({
        query: z.string().min(2).max(100),
        limit: z.number().int().positive().max(50).default(10),
      })
    )
    .query(async ({ input }) => {
      const cacheKey = `users:search:${input.query}:${input.limit}`;

      // Try cache
      const cached = await cacheGet<any>(cacheKey);
      if (cached) {
        return cached;
      }

      // Simulate search
      const results = [
        {
          id: 'user-1',
          name: `User matching ${input.query}`,
          email: `user@example.com`,
        },
      ];

      // Cache for 10 minutes
      await cacheSet(cacheKey, results, 600);

      return results;
    }),
});
