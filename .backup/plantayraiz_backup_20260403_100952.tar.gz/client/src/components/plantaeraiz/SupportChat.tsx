import { MessageCircle, X } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';

export function SupportChat() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Chat Window */}
      {isOpen && (
        <div className="absolute bottom-16 right-0 w-80 rounded-2xl border border-border/70 bg-card/95 shadow-xl backdrop-blur-xl animate-in fade-in slide-in-from-bottom-4">
          <div className="border-b border-border/50 p-4 flex justify-between items-center">
            <h3 className="font-semibold text-foreground">Suporte Planta & Raiz</h3>
            <button
              onClick={() => setIsOpen(false)}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
          
          <div className="p-4 space-y-4">
            <div className="space-y-3 max-h-64 overflow-y-auto">
              <div className="flex gap-3">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center">
                  <span className="text-xs font-bold text-accent">PR</span>
                </div>
                <div className="flex-1">
                  <p className="text-sm text-foreground bg-background/50 rounded-lg p-2">
                    Olá! Como podemos ajudar você?
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">09:30</p>
                </div>
              </div>
            </div>

            <div className="border-t border-border/50 pt-3">
              <p className="text-xs text-muted-foreground mb-2">Horário de atendimento:</p>
              <p className="text-sm font-medium text-foreground">Segunda a Sexta, 9h às 17h</p>
            </div>

            <Button 
              className="w-full bg-accent text-accent-foreground hover:bg-accent/90 rounded-lg"
              onClick={() => setIsOpen(false)}
            >
              Enviar Mensagem
            </Button>
          </div>
        </div>
      )}

      {/* Floating Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="inline-flex h-14 w-14 items-center justify-center rounded-full bg-accent text-accent-foreground shadow-lg ring-1 ring-border/50 transition-all hover:scale-110 hover:shadow-xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
        aria-label="Atendimento"
      >
        {isOpen ? (
          <X className="h-6 w-6" />
        ) : (
          <MessageCircle className="h-6 w-6" />
        )}
      </button>
    </div>
  );
}
