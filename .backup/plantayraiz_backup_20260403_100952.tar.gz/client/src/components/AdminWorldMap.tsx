import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { trpc } from '@/lib/trpc';

interface UserMarker {
  id: string;
  lat: number;
  lng: number;
  title: string;
  deposits: number;
  earnings: number;
  consultations: number;
  platform: string;
  status: string;
}

interface MapData {
  totalOnline: number;
  totalToday: number;
  markers: UserMarker[];
  topCountries: Array<{ country: string; count: number }>;
}

export const AdminWorldMap: React.FC = () => {
  const [mapData, setMapData] = useState<MapData>({
    totalOnline: 0,
    totalToday: 0,
    markers: [],
    topCountries: [],
  });

  const [selectedUser, setSelectedUser] = useState<UserMarker | null>(null);
  const [showDetails, setShowDetails] = useState(false);
  const [loading, setLoading] = useState(true);

  // Carregar dados do tRPC
  const { data: worldMapData } = trpc.ceoAutonomous.monitoring.getWorldMapData.useQuery();
  const { data: monitoringStats } = trpc.ceoAutonomous.monitoring.getMonitoringStats.useQuery();
  const { data: mapMarkers } = trpc.ceoAutonomous.monitoring.getMapMarkers.useQuery();

  useEffect(() => {
    if (worldMapData && monitoringStats && mapMarkers) {
      setMapData({
        totalOnline: worldMapData.totalOnline,
        totalToday: worldMapData.totalToday,
        markers: mapMarkers.markers.map((m) => ({
          id: m.id,
          lat: m.lat,
          lng: m.lng,
          title: m.title,
          deposits: m.deposits,
          earnings: m.earnings,
          consultations: m.consultations,
          platform: m.platform,
          status: 'online',
        })),
        topCountries: monitoringStats.topCountries,
      });
      setLoading(false);
    }
  }, [worldMapData, monitoringStats, mapMarkers]);

  const handleMarkerClick = (marker: UserMarker) => {
    setSelectedUser(marker);
    setShowDetails(true);
  };

  if (loading) {
    return (
      <div className="w-full h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500 mx-auto mb-4" />
          <p className="text-slate-400">Carregando Mapa Mundi...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full space-y-6 p-6 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 min-h-screen">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-white">🌍 Monitoramento Global em Tempo Real</h1>
        <p className="text-slate-400">Rastreamento de usuários conectados por geolocalização</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <div className="space-y-2">
              <p className="text-sm text-slate-400">Usuários Online Agora</p>
              <p className="text-3xl font-bold text-green-500">{mapData.totalOnline}</p>
              <p className="text-xs text-slate-500">Em tempo real</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <div className="space-y-2">
              <p className="text-sm text-slate-400">Usuários Hoje</p>
              <p className="text-3xl font-bold text-blue-500">{mapData.totalToday}</p>
              <p className="text-xs text-slate-500">Desde 00:00</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <div className="space-y-2">
              <p className="text-sm text-slate-400">Países Ativos</p>
              <p className="text-3xl font-bold text-purple-500">{mapData.topCountries.length}</p>
              <p className="text-xs text-slate-500">Distribuição global</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* World Map Visualization */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Mapa Mundi — Usuários Online</CardTitle>
          <CardDescription>Clique em um ponto para ver detalhes do usuário</CardDescription>
        </CardHeader>
        <CardContent>
          {/* Simulated Map Container */}
          <div className="relative w-full h-96 bg-slate-900 rounded-lg border border-slate-700 overflow-hidden">
            {/* SVG World Map Background */}
            <svg className="w-full h-full" viewBox="0 0 1000 600" preserveAspectRatio="xMidYMid meet">
              {/* Simple world map outline */}
              <rect width="1000" height="600" fill="#0f172a" />
              <circle cx="500" cy="300" r="290" fill="none" stroke="#1e293b" strokeWidth="2" opacity="0.3" />

              {/* Grid lines */}
              <line x1="500" y1="0" x2="500" y2="600" stroke="#1e293b" strokeWidth="1" opacity="0.2" />
              <line x1="0" y1="300" x2="1000" y2="300" stroke="#1e293b" strokeWidth="1" opacity="0.2" />

              {/* Markers */}
              {mapData.markers.map((marker) => {
                // Convert lat/lng to SVG coordinates (simplified)
                const x = ((marker.lng + 180) / 360) * 1000;
                const y = ((90 - marker.lat) / 180) * 600;

                return (
                  <g key={marker.id} onClick={() => handleMarkerClick(marker)} style={{ cursor: 'pointer' }}>
                    {/* Outer glow */}
                    <circle cx={x} cy={y} r="12" fill="#10b981" opacity="0.2" />
                    {/* Marker circle */}
                    <circle cx={x} cy={y} r="8" fill="#10b981" stroke="#ffffff" strokeWidth="2" />
                    {/* Pulse animation */}
                    <circle cx={x} cy={y} r="8" fill="none" stroke="#10b981" strokeWidth="1" opacity="0.5">
                      <animate attributeName="r" from="8" to="16" dur="2s" repeatCount="indefinite" />
                      <animate attributeName="opacity" from="0.8" to="0" dur="2s" repeatCount="indefinite" />
                    </circle>
                  </g>
                );
              })}
            </svg>

            {/* Overlay info */}
            <div className="absolute top-4 right-4 text-xs text-slate-400 bg-slate-900 bg-opacity-80 p-2 rounded">
              <p>🟢 Online • 🟡 Idle • ⚫ Offline</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Top Countries */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Principais Países</CardTitle>
          <CardDescription>Distribuição de usuários por país</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {mapData.topCountries.map((country, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-xl">🌍</span>
                  <span className="text-slate-300">{country.country}</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-48 h-2 bg-slate-700 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-green-500 to-blue-500"
                      style={{ width: `${mapData.totalOnline > 0 ? (country.count / mapData.totalOnline) * 100 : 0}%` }}
                    />
                  </div>
                  <span className="text-green-500 font-bold w-12 text-right">{country.count}</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* User Details Dialog */}
      <Dialog open={showDetails} onOpenChange={setShowDetails}>
        <DialogContent className="bg-slate-800 border-slate-700">
          <DialogHeader>
            <DialogTitle className="text-white">Detalhes do Usuário</DialogTitle>
            <DialogDescription>{selectedUser?.title}</DialogDescription>
          </DialogHeader>

          {selectedUser && (
            <div className="space-y-4">
              {/* User Info */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <p className="text-xs text-slate-400">ID do Usuário</p>
                  <p className="text-sm text-white font-mono">{selectedUser.id}</p>
                </div>
                <div className="space-y-2">
                  <p className="text-xs text-slate-400">Plataforma</p>
                  <Badge variant="outline">{selectedUser.platform}</Badge>
                </div>
              </div>

              {/* Location */}
              <div className="space-y-2">
                <p className="text-xs text-slate-400">Localização</p>
                <p className="text-sm text-white">{selectedUser.title}</p>
                <p className="text-xs text-slate-500">
                  Coordenadas: {selectedUser.lat.toFixed(4)}, {selectedUser.lng.toFixed(4)}
                </p>
              </div>

              {/* Financial Info */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <p className="text-xs text-slate-400">Depósitos</p>
                  <p className="text-lg text-green-500 font-bold">R$ {selectedUser.deposits.toFixed(2)}</p>
                </div>
                <div className="space-y-2">
                  <p className="text-xs text-slate-400">Ganhos</p>
                  <p className="text-lg text-blue-500 font-bold">R$ {selectedUser.earnings.toFixed(2)}</p>
                </div>
              </div>

              {/* Activity */}
              <div className="space-y-2">
                <p className="text-xs text-slate-400">Consultas Realizadas</p>
                <p className="text-sm text-white">{selectedUser.consultations} consultas</p>
              </div>

              {/* Status */}
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-green-500" />
                <span className="text-sm text-slate-300">Usuário online agora</span>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Footer */}
      <div className="text-center text-slate-500 text-sm pt-6 border-t border-slate-700">
        <p>Atualização em tempo real a cada 30 segundos | Última atualização: {new Date().toLocaleTimeString('pt-BR')}</p>
      </div>
    </div>
  );
};
