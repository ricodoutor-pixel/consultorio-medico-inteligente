import rateLimit from 'express-rate-limit';
import RedisStore from 'rate-limit-redis';
import { getRedisClient } from './cache';

// Global rate limiter - 100 requests per 15 minutes
export const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100,
  message: 'Too many requests from this IP, please try again later.',
  standardHeaders: true,
  legacyHeaders: false,
});

// Strict rate limiter for auth endpoints - 5 requests per 15 minutes
export const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  skipSuccessfulRequests: true,
  message: 'Too many login attempts, please try again later.',
});

// API rate limiter - 1000 requests per hour
export const apiLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 1000,
  message: 'API rate limit exceeded.',
});

// Payment rate limiter - 10 requests per hour
export const paymentLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 10,
  message: 'Too many payment requests, please try again later.',
});

// Webhook rate limiter - 100 requests per minute
export const webhookLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 100,
  message: 'Webhook rate limit exceeded.',
});

// Redis-backed rate limiters (for distributed systems)
export function createRedisLimiter(
  windowMs: number,
  max: number,
  keyPrefix: string = 'rate-limit'
) {
  try {
    const redis = getRedisClient();
    return rateLimit({
      store: new RedisStore({
        client: redis as any,
        prefix: keyPrefix,
      }),
      windowMs,
      max,
      standardHeaders: true,
      legacyHeaders: false,
    });
  } catch (error) {
    console.error('Failed to create Redis limiter, falling back to memory:', error);
    // Fallback to memory-based limiter
    return rateLimit({
      windowMs,
      max,
      standardHeaders: true,
      legacyHeaders: false,
    });
  }
}

// Create specific limiters
export const consultationLimiter = createRedisLimiter(
  60 * 60 * 1000, // 1 hour
  50, // 50 requests per hour
  'rate-limit:consultation'
);

export const shoppingLimiter = createRedisLimiter(
  60 * 60 * 1000, // 1 hour
  200, // 200 requests per hour
  'rate-limit:shopping'
);

export const communityLimiter = createRedisLimiter(
  60 * 60 * 1000, // 1 hour
  100, // 100 requests per hour
  'rate-limit:community'
);
