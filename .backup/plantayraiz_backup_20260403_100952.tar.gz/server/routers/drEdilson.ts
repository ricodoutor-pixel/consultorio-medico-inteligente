/**
 * Dr. Edilson Bezerra Authority Router
 * 
 * Endpoints para operações de autoridade máxima
 * Apenas Dr. Edilson pode acessar
 */

import { protectedProcedure, publicProcedure, router } from '../_core/trpc';
import { z } from 'zod';
import { drEdilsonAuthorityService } from '../services/DrEdilsonAuthorityService';

export const drEdilsonRouter = router({
  /**
   * Obter perfil de autoridade
   */
  getProfile: publicProcedure.query(() => {
    const profile = drEdilsonAuthorityService.getProfile();
    return {
      id: profile.id,
      name: profile.name,
      crm: profile.crm,
      specialty: profile.specialty,
      status: profile.status,
      role: profile.role,
      compliance: profile.compliance,
      authority: profile.authority,
    };
  }),

  /**
   * Autorizar prescrição digital
   */
  authorizePrescription: protectedProcedure
    .input(
      z.object({
        patientId: z.string(),
        patientName: z.string(),
        medications: z.array(z.string()),
        dosage: z.string(),
        duration: z.string(),
        indication: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Validar se é Dr. Edilson
      if (!drEdilsonAuthorityService.isDrEdilson(ctx.user.id)) {
        throw new Error('Apenas Dr. Edilson pode autorizar prescrições');
      }

      const result = await drEdilsonAuthorityService.authorizePrescription({
        patientId: input.patientId,
        patientName: input.patientName,
        medications: input.medications,
        dosage: input.dosage,
        duration: input.duration,
        indication: input.indication,
      });

      return result;
    }),

  /**
   * Aprovar novo médico
   */
  approveDoctorRegistration: protectedProcedure
    .input(
      z.object({
        name: z.string(),
        crm: z.string(),
        specialty: z.string(),
        email: z.string(),
        phone: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Validar se é Dr. Edilson
      if (!drEdilsonAuthorityService.isDrEdilson(ctx.user.id)) {
        throw new Error('Apenas Dr. Edilson pode aprovar médicos');
      }

      const result = await drEdilsonAuthorityService.approveDoctorRegistration({
        name: input.name,
        crm: input.crm,
        specialty: input.specialty,
        email: input.email,
        phone: input.phone,
      });

      return result;
    }),

  /**
   * Gerar relatório de conformidade
   */
  generateComplianceReport: protectedProcedure.query(({ ctx }) => {
    // Validar se é Dr. Edilson
    if (!drEdilsonAuthorityService.isDrEdilson(ctx.user.id)) {
      throw new Error('Apenas Dr. Edilson pode acessar relatórios de conformidade');
    }

    const report = drEdilsonAuthorityService.generateComplianceReport();
    return { report };
  }),

  /**
   * Validar certificado ICP-Brasil
   */
  validateICPBrasilCertificate: publicProcedure.query(() => {
    const validation = drEdilsonAuthorityService.validateICPBrasilCertificate();
    return validation;
  }),

  /**
   * Obter estatísticas de operações
   */
  getOperationStats: protectedProcedure.query(({ ctx }) => {
    // Validar se é Dr. Edilson
    if (!drEdilsonAuthorityService.isDrEdilson(ctx.user.id)) {
      throw new Error('Apenas Dr. Edilson pode acessar estatísticas');
    }

    const stats = drEdilsonAuthorityService.getOperationStats();
    return stats;
  }),

  /**
   * Validar autoridade para operação
   */
  validateAuthority: protectedProcedure
    .input(z.object({ permission: z.string() }))
    .query(({ ctx, input }) => {
      const hasAuthority = drEdilsonAuthorityService.validateAuthority(
        ctx.user.id,
        input.permission
      );

      return {
        hasAuthority,
        userId: ctx.user.id,
        permission: input.permission,
        isDrEdilson: drEdilsonAuthorityService.isDrEdilson(ctx.user.id),
      };
    }),
});
