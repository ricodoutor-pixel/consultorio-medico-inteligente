// ============================================================================
// JITSI VIDEO SERVICE — Integração de Videochamadas com Gravação
// Planta & Raiz 3.0 — Consultas por Vídeo
// ============================================================================

import crypto from 'crypto';

interface VideoSessionConfig {
  consultationId: string;
  doctorName: string;
  patientName: string;
  startTime: number;
  duration: number; // em minutos
  recordingEnabled: boolean;
}

interface VideoSession {
  sessionId: string;
  roomName: string;
  jitsiUrl: string;
  recordingUrl?: string;
  transcriptionUrl?: string;
  status: 'pending' | 'active' | 'completed' | 'recorded';
  createdAt: number;
  startedAt?: number;
  endedAt?: number;
}

// Configurações Jitsi
const JITSI_DOMAIN = process.env.JITSI_DOMAIN || 'meet.jit.si';
const JITSI_APP_ID = process.env.JITSI_APP_ID || 'planta-e-raiz';
const JITSI_SECRET = process.env.JITSI_SECRET || '';

// Armazenamento em memória de sessões (em produção usar banco de dados)
const activeSessions = new Map<string, VideoSession>();
const sessionHistory: VideoSession[] = [];

/**
 * Gerar JWT para Jitsi (se usando Jitsi Secure Domain)
 */
function generateJitsiJWT(roomName: string, userName: string, isDoctor: boolean): string {
  if (!JITSI_SECRET) {
    return ''; // Sem JWT se não configurado
  }

  const payload = {
    iss: JITSI_APP_ID,
    sub: JITSI_DOMAIN,
    aud: 'jitsi',
    room: roomName,
    exp: Math.floor(Date.now() / 1000) + 3600, // 1 hora
    user: {
      name: userName,
      email: `${userName.toLowerCase().replace(/\s+/g, '.')}@plantayraiz.com.br`,
      id: crypto.randomUUID(),
    },
    context: {
      user: {
        avatar: isDoctor ? 'doctor' : 'patient',
        name: userName,
        email: `${userName.toLowerCase().replace(/\s+/g, '.')}@plantayraiz.com.br`,
      },
    },
    features: {
      recording: true,
      transcription: true,
    },
  };

  // Simplificado - em produção usar biblioteca JWT apropriada
  return Buffer.from(JSON.stringify(payload)).toString('base64');
}

/**
 * Criar nova sessão de videochamada
 */
export function createVideoSession(config: VideoSessionConfig): VideoSession {
  const sessionId = crypto.randomUUID();
  const roomName = `${config.consultationId}-${Date.now()}`.replace(/[^a-zA-Z0-9-]/g, '-');

  const session: VideoSession = {
    sessionId,
    roomName,
    jitsiUrl: `https://${JITSI_DOMAIN}/${roomName}`,
    status: 'pending',
    createdAt: Date.now(),
    recordingEnabled: config.recordingEnabled,
  };

  activeSessions.set(sessionId, session);
  return session;
}

/**
 * Obter URL de acesso para médico
 */
export function getDoctorAccessUrl(sessionId: string, doctorName: string): string | null {
  const session = activeSessions.get(sessionId);
  if (!session) return null;

  const jwt = generateJitsiJWT(session.roomName, doctorName, true);
  const params = new URLSearchParams({
    jwt: jwt,
    name: doctorName,
    email: `${doctorName.toLowerCase().replace(/\s+/g, '.')}@plantayraiz.com.br`,
    avatar: 'doctor',
  });

  return `${session.jitsiUrl}?${params.toString()}`;
}

/**
 * Obter URL de acesso para paciente
 */
export function getPatientAccessUrl(sessionId: string, patientName: string): string | null {
  const session = activeSessions.get(sessionId);
  if (!session) return null;

  const jwt = generateJitsiJWT(session.roomName, patientName, false);
  const params = new URLSearchParams({
    jwt: jwt,
    name: patientName,
    email: `${patientName.toLowerCase().replace(/\s+/g, '.')}@plantayraiz.com.br`,
    avatar: 'patient',
  });

  return `${session.jitsiUrl}?${params.toString()}`;
}

/**
 * Iniciar gravação de sessão
 */
export function startRecording(sessionId: string): boolean {
  const session = activeSessions.get(sessionId);
  if (!session) return false;

  session.status = 'active';
  session.startedAt = Date.now();
  return true;
}

/**
 * Finalizar sessão e gerar URL de gravação
 */
export function endSession(sessionId: string): VideoSession | null {
  const session = activeSessions.get(sessionId);
  if (!session) return null;

  session.status = 'completed';
  session.endedAt = Date.now();

  // Simular URL de gravação (em produção, integrar com Jitsi Recording API)
  if (session.recordingEnabled) {
    session.recordingUrl = `https://recordings.plantayraiz.com.br/${session.roomName}-${session.endedAt}.mp4`;
    session.transcriptionUrl = `https://transcriptions.plantayraiz.com.br/${session.roomName}-${session.endedAt}.json`;
    session.status = 'recorded';
  }

  // Adicionar ao histórico
  sessionHistory.push(session);
  if (sessionHistory.length > 1000) {
    sessionHistory.shift();
  }

  // Remover de sessões ativas após 1 hora
  setTimeout(() => {
    activeSessions.delete(sessionId);
  }, 3600000);

  return session;
}

/**
 * Obter informações da sessão
 */
export function getSessionInfo(sessionId: string): VideoSession | null {
  return activeSessions.get(sessionId) || null;
}

/**
 * Obter histórico de sessões
 */
export function getSessionHistory(limit: number = 50): VideoSession[] {
  return sessionHistory.slice(-limit).reverse();
}

/**
 * Obter estatísticas de sessões
 */
export function getSessionStats() {
  const stats = {
    activeSessions: activeSessions.size,
    totalSessions: sessionHistory.length,
    totalRecordings: sessionHistory.filter(s => s.recordingEnabled).length,
    totalDuration: sessionHistory.reduce((acc, s) => {
      if (s.startedAt && s.endedAt) {
        return acc + (s.endedAt - s.startedAt);
      }
      return acc;
    }, 0),
    averageDuration: 0,
  };

  if (sessionHistory.length > 0) {
    stats.averageDuration = stats.totalDuration / sessionHistory.length;
  }

  return stats;
}

/**
 * Obter URL de transcrição (webhook da Jitsi)
 */
export function getTranscriptionUrl(sessionId: string): string | null {
  const session = activeSessions.get(sessionId);
  if (!session || !session.transcriptionUrl) return null;
  return session.transcriptionUrl;
}

/**
 * Webhook para receber notificações de gravação concluída
 */
export function handleRecordingWebhook(data: any): boolean {
  try {
    const { sessionId, recordingUrl, transcriptionUrl, status } = data;

    const session = activeSessions.get(sessionId);
    if (!session) return false;

    if (recordingUrl) session.recordingUrl = recordingUrl;
    if (transcriptionUrl) session.transcriptionUrl = transcriptionUrl;
    if (status) session.status = status;

    return true;
  } catch (error) {
    console.error('[JitsiVideoService] Webhook error:', error);
    return false;
  }
}

export const JitsiVideoService = {
  createVideoSession,
  getDoctorAccessUrl,
  getPatientAccessUrl,
  startRecording,
  endSession,
  getSessionInfo,
  getSessionHistory,
  getSessionStats,
  getTranscriptionUrl,
  handleRecordingWebhook,
};
