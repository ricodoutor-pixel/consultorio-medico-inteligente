# 🏛️ Conformidade Legal - Planta & Raiz (Brasil)

## 1. REGULAMENTAÇÕES APLICÁVEIS

### 1.1 Prescrição de Cannabis Medicinal no Brasil

**Lei de Referência:**
- **Lei nº 13.123/2015** - Acesso ao Patrimônio Genético
- **RDC ANVISA nº 327/2019** - Canabidiol (CBD) - Medicamento
- **RDC ANVISA nº 660/2022** - Canabinoides em geral
- **Resolução CFM nº 1.931/2009** - Código de Ética Médica
- **Resolução CREMESP nº 196/2018** - Prescrição de Cannabis Medicinal (SP)
- **Resolução CFM nº 2.113/2021** - Telemedicina

**Status Legal:**
- ✅ Cannabis medicinal (CBD, THC) é LEGAL no Brasil
- ✅ Prescrição médica é OBRIGATÓRIA
- ✅ Telemedicina para prescrição é PERMITIDA (Resolução CFM 2.113/2021)
- ✅ Receituário eletrônico é VÁLIDO (e-Receita)
- ⚠️ Venda sem prescrição é ILEGAL

### 1.2 Profissionais Autorizados

**Podem prescrever cannabis medicinal:**
1. **Médicos** (com registro ativo no CRM)
2. **Dentistas** (com registro ativo no CRO) - apenas para uso odontológico
3. **Veterinários** (com registro ativo no CRMV) - apenas para animais

**Validação obrigatória:**
- Verificar CRM/CRO/CRMV ativo no conselho respectivo
- Validar especialização (recomendado: Medicina Canábica, Neurologia, Psiquiatria)
- Confirmar inscrição estadual (CREMESP, CROSP, etc.)

### 1.3 Telemedicina - Regulamentação

**Resolução CFM nº 2.113/2021:**
- ✅ Teleconsulta é permitida para prescrição de cannabis medicinal
- ✅ Requer consentimento informado do paciente
- ✅ Requer registro em prontuário eletrônico
- ✅ Requer assinatura digital (ICP-Brasil)
- ⚠️ Primeira consulta pode ser telemedicina (sem necessidade de presencial prévia)
- ⚠️ Profissional deve estar inscrito no conselho da UF do paciente

### 1.4 Receituário Eletrônico (e-Receita)

**Regulamentação:**
- **RDC ANVISA nº 20/2011** - Receituário eletrônico
- **Resolução CFM nº 1.821/2007** - Prontuário eletrônico
- **Medida Provisória nº 2.200-2/2001** - ICP-Brasil (assinatura digital)

**Requisitos técnicos:**
- Assinatura digital com certificado ICP-Brasil (e-CPF ou e-CNPJ)
- Criptografia AES-256 para dados sensíveis
- Registro em banco de dados auditável
- Retenção por mínimo 5 anos
- Acesso controlado por RBAC

**Fluxo de e-Receita:**
1. Profissional prescreve no sistema
2. Sistema gera PDF com dados da prescrição
3. Profissional assina digitalmente (ICP-Brasil)
4. Sistema registra timestamp e hash
5. Paciente recebe link seguro para download
6. Farmácia valida assinatura digital
7. Farmácia dispensa medicamento

---

## 2. FLUXO EXECUTÁVEL - PRESCRIÇÃO CONFORME LEI

### 2.1 Fluxo Completo (Paciente → Profissional → Prescrição → Medicamento)

```
┌─────────────────────────────────────────────────────────────┐
│ ETAPA 1: PRÉ-ATENDIMENTO (IA Autônoma)                      │
├─────────────────────────────────────────────────────────────┤
│ 1. Paciente preenche questionário de sintomas               │
│ 2. IA valida dados (idade, alergias, medicações)            │
│ 3. IA recomenda especialidades (Neurologia, Psiquiatria)    │
│ 4. Sistema verifica CRM do profissional selecionado         │
│ 5. Gera termo de consentimento informado (TCLE)             │
│ 6. Paciente assina TCLE digitalmente                        │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ ETAPA 2: TELECONSULTA (Videoconferência Jitsi)              │
├─────────────────────────────────────────────────────────────┤
│ 1. Profissional acessa dados do paciente (prontuário)       │
│ 2. Videoconferência criptografada (E2E)                     │
│ 3. Profissional realiza avaliação clínica                   │
│ 4. Profissional documenta diagnóstico no prontuário          │
│ 5. Sessão é gravada (com consentimento)                     │
│ 6. Duração mínima: 15 minutos (recomendado)                 │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ ETAPA 3: PRESCRIÇÃO DIGITAL (e-Receita)                     │
├─────────────────────────────────────────────────────────────┤
│ 1. Profissional prescreve no sistema:                       │
│    - Variedade (Charlotte's Web, Harlequin, etc.)           │
│    - Dosagem (mg/dia)                                       │
│    - Via de administração (inalação, ingestão, tópica)      │
│    - Duração (dias)                                         │
│    - Indicação médica (CID-10)                              │
│                                                              │
│ 2. Sistema gera e-Receita com:                              │
│    - Dados do profissional (CRM, especialidade)             │
│    - Dados do paciente (CPF, data nascimento)               │
│    - Dados da prescrição (variedade, dosagem, CID-10)       │
│    - Timestamp (data/hora)                                  │
│    - Número único (NRx)                                     │
│                                                              │
│ 3. Profissional assina digitalmente:                        │
│    - Certificado ICP-Brasil (e-CPF)                         │
│    - Algoritmo: SHA-256 + RSA-2048                          │
│    - Timestamp de assinatura                                │
│                                                              │
│ 4. Sistema registra em banco de dados:                      │
│    - Hash da e-Receita                                      │
│    - Assinatura digital                                     │
│    - Timestamp                                              │
│    - Status: "Ativa"                                        │
│                                                              │
│ 5. Paciente recebe:                                         │
│    - PDF da e-Receita (assinado)                            │
│    - Link seguro (válido por 30 dias)                       │
│    - QR Code com dados da prescrição                        │
│    - Instruções de uso                                      │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ ETAPA 4: VALIDAÇÃO NA FARMÁCIA                              │
├─────────────────────────────────────────────────────────────┤
│ 1. Farmacêutico escaneia QR Code                            │
│ 2. Sistema valida:                                          │
│    - Assinatura digital (ICP-Brasil)                        │
│    - Profissional autorizado (CRM ativo)                    │
│    - Prescrição não expirada (30 dias)                      │
│    - Prescrição não foi dispensada antes                    │
│                                                              │
│ 3. Farmacêutico verifica:                                   │
│    - Identidade do paciente (RG/CPF)                        │
│    - Alergias e interações medicamentosas                   │
│    - Contraindicações                                       │
│                                                              │
│ 4. Dispensa medicamento:                                    │
│    - Variedade conforme prescrição                          │
│    - Quantidade: 30 dias (padrão)                           │
│    - Rótulo com dados da prescrição                         │
│    - Instruções de armazenamento                            │
│                                                              │
│ 5. Sistema registra:                                        │
│    - Data/hora da dispensação                               │
│    - Farmácia (CNPJ)                                        │
│    - Farmacêutico (CRF)                                     │
│    - Lote do medicamento                                    │
│    - Marca do medicamento                                   │
│    - Muda status para "Dispensada"                          │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ ETAPA 5: PÓS-VENDA E ACOMPANHAMENTO                          │
├─────────────────────────────────────────────────────────────┤
│ 1. Sistema envia:                                           │
│    - Lembretes de medicação (SMS/Email)                     │
│    - Formulário de resposta ao tratamento                   │
│    - Agendamento de retorno (30 dias)                       │
│                                                              │
│ 2. Paciente reporta:                                        │
│    - Eficácia (escala 1-10)                                 │
│    - Efeitos colaterais                                     │
│    - Adesão ao tratamento                                   │
│                                                              │
│ 3. Profissional avalia:                                     │
│    - Resposta ao tratamento                                 │
│    - Necessidade de ajuste de dosagem                       │
│    - Renovação de prescrição (se necessário)                │
│                                                              │
│ 4. Sistema registra:                                        │
│    - Dados de acompanhamento no prontuário                  │
│    - Histórico de prescrições                               │
│    - Histórico de dispensações                              │
└─────────────────────────────────────────────────────────────┘
```

### 2.2 Validações Obrigatórias em Cada Etapa

| Etapa | Validação | Fonte Legal | Implementação |
|-------|-----------|-------------|----------------|
| Pré-atendimento | Maioridade (≥18 anos) | Lei 13.123/2015 | Validar data nascimento |
| Pré-atendimento | Consentimento informado | CFM 1.931/2009 | TCLE assinado digitalmente |
| Teleconsulta | Profissional CRM ativo | CFM 2.113/2021 | API de validação CRM |
| Teleconsulta | Especialidade adequada | Resolução estadual | Validar especialização |
| Prescrição | Indicação médica válida (CID-10) | RDC ANVISA 660/2022 | Validar CID-10 |
| Prescrição | Dosagem dentro dos limites | RDC ANVISA 660/2022 | Validar mg/dia |
| Prescrição | Assinatura digital ICP-Brasil | MP 2.200-2/2001 | Certificado e-CPF |
| Farmácia | Identidade do paciente | Lei 11.343/2006 | RG/CPF |
| Farmácia | Validade da prescrição (30 dias) | RDC ANVISA 20/2011 | Timestamp |
| Farmácia | Profissional autorizado | CRM/COREN | API de validação |

---

## 3. RBAC (Role-Based Access Control)

### 3.1 Papéis e Permissões

```
┌─────────────────────────────────────────────────────────────┐
│ PACIENTE (patient)                                          │
├─────────────────────────────────────────────────────────────┤
│ ✓ Preencher questionário de sintomas                        │
│ ✓ Agendar teleconsulta                                      │
│ ✓ Participar de videoconferência                            │
│ ✓ Visualizar prescrições próprias                           │
│ ✓ Visualizar prontuário próprio                             │
│ ✓ Reportar resposta ao tratamento                           │
│ ✗ Prescrever medicamentos                                   │
│ ✗ Acessar dados de outros pacientes                         │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ PROFISSIONAL (professional)                                 │
├─────────────────────────────────────────────────────────────┤
│ ✓ Visualizar agenda de consultas                            │
│ ✓ Participar de videoconferência                            │
│ ✓ Acessar prontuário do paciente (própria consulta)         │
│ ✓ Prescrever medicamentos (com assinatura digital)          │
│ ✓ Visualizar histórico de prescrições próprias              │
│ ✓ Acompanhar resposta ao tratamento                         │
│ ✗ Prescrever para outros profissionais                      │
│ ✗ Acessar dados de outros profissionais                     │
│ ✗ Acessar dados de pacientes de outros profissionais        │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ FARMACÊUTICO (pharmacist)                                   │
├─────────────────────────────────────────────────────────────┤
│ ✓ Validar prescrições digitais                              │
│ ✓ Dispensar medicamentos                                    │
│ ✓ Registrar dispensação no sistema                          │
│ ✓ Acessar histórico de prescrições do paciente              │
│ ✓ Verificar interações medicamentosas                       │
│ ✗ Prescrever medicamentos                                   │
│ ✗ Acessar dados de pacientes de outras farmácias            │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ ADMINISTRADOR (admin)                                       │
├─────────────────────────────────────────────────────────────┤
│ ✓ Gerenciar usuários (criar, editar, desativar)             │
│ ✓ Validar profissionais (verificar CRM/CRO/CRMV)            │
│ ✓ Acessar logs de auditoria                                 │
│ ✓ Gerar relatórios de conformidade                          │
│ ✓ Configurar integrações com órgãos reguladores             │
│ ✓ Acessar dados agregados (sem PII)                         │
│ ✗ Prescrever medicamentos                                   │
│ ✗ Dispensar medicamentos                                    │
└─────────────────────────────────────────────────────────────┘
```

### 3.2 Implementação em TypeScript

```typescript
// server/types/roles.ts
export enum Role {
  PATIENT = 'patient',
  PROFESSIONAL = 'professional',
  PHARMACIST = 'pharmacist',
  ADMIN = 'admin',
}

export const rolePermissions: Record<Role, string[]> = {
  [Role.PATIENT]: [
    'patient:read:own',
    'consultation:create',
    'consultation:read:own',
    'prescription:read:own',
    'treatment-response:create:own',
  ],
  [Role.PROFESSIONAL]: [
    'professional:read:own',
    'consultation:read:own',
    'consultation:update:own',
    'prescription:create',
    'prescription:sign',
    'patient:read:own-consultations',
  ],
  [Role.PHARMACIST]: [
    'pharmacist:read:own',
    'prescription:validate',
    'prescription:dispense',
    'patient:read:for-dispensation',
  ],
  [Role.ADMIN]: [
    'user:create',
    'user:read',
    'user:update',
    'user:delete',
    'professional:validate',
    'audit:read',
    'report:generate',
  ],
};

// server/middleware/authorize.ts
export function requireRole(...roles: Role[]) {
  return async (ctx: Context, next: () => Promise<void>) => {
    if (!roles.includes(ctx.user.role)) {
      throw new TRPCError({
        code: 'FORBIDDEN',
        message: `Acesso negado. Papéis permitidos: ${roles.join(', ')}`,
      });
    }
    await next();
  };
}
```

---

## 4. INTEGRAÇÕES COM ÓRGÃOS REGULADORES

### 4.1 Validação de CRM/CRO/CRMV

**Integração com Conselho de Medicina (CFM):**

```typescript
// server/services/crmValidation.ts
import axios from 'axios';

export async function validateCRM(crm: string, state: string): Promise<boolean> {
  try {
    // Integração com API do Conselho Regional de Medicina
    // Exemplo: CREMESP (São Paulo)
    const response = await axios.get(
      `https://api.cremesp.org.br/v1/profissional/${crm}/${state}`,
      {
        headers: {
          'Authorization': `Bearer ${process.env.CREMESP_API_KEY}`,
        },
      }
    );

    return response.data.status === 'ativo' && response.data.especialidade === 'Medicina Canábica';
  } catch (error) {
    console.error('Erro ao validar CRM:', error);
    return false;
  }
}

// Integração com CFM (Conselho Federal de Medicina)
export async function validateCRMNational(crm: string): Promise<boolean> {
  try {
    const response = await axios.get(
      `https://www.portalmedico.org.br/api/v1/medico/${crm}`,
      {
        headers: {
          'Authorization': `Bearer ${process.env.CFM_API_KEY}`,
        },
      }
    );

    return response.data.ativo === true;
  } catch (error) {
    console.error('Erro ao validar CRM no CFM:', error);
    return false;
  }
}
```

### 4.2 Integração com ANVISA

**Validação de medicamentos autorizados:**

```typescript
// server/services/anvisaValidation.ts
export async function validateMedicationANVISA(
  medicationName: string
): Promise<boolean> {
  try {
    // Integração com banco de dados de medicamentos da ANVISA
    const response = await axios.get(
      `https://api.anvisa.gov.br/v1/medicamentos`,
      {
        params: {
          nome: medicationName,
          status: 'ativo',
        },
        headers: {
          'Authorization': `Bearer ${process.env.ANVISA_API_KEY}`,
        },
      }
    );

    return response.data.total > 0;
  } catch (error) {
    console.error('Erro ao validar medicamento na ANVISA:', error);
    return false;
  }
}
```

### 4.3 Integração com ICP-Brasil (Assinatura Digital)

```typescript
// server/services/digitalSignature.ts
import { createSign, createVerify } from 'crypto';
import * as fs from 'fs';

export interface DigitalSignatureConfig {
  certificatePath: string; // Caminho do certificado e-CPF
  keyPath: string; // Caminho da chave privada
  password: string; // Senha do certificado
}

export async function signPrescription(
  prescriptionData: object,
  config: DigitalSignatureConfig
): Promise<string> {
  try {
    // Carregar certificado ICP-Brasil
    const certificate = fs.readFileSync(config.certificatePath, 'utf-8');
    const key = fs.readFileSync(config.keyPath, 'utf-8');

    // Criar assinatura
    const sign = createSign('sha256');
    sign.update(JSON.stringify(prescriptionData));
    const signature = sign.sign(
      {
        key: key,
        passphrase: config.password,
      },
      'base64'
    );

    return signature;
  } catch (error) {
    console.error('Erro ao assinar prescrição:', error);
    throw error;
  }
}

export async function verifySignature(
  prescriptionData: object,
  signature: string,
  certificatePath: string
): Promise<boolean> {
  try {
    const certificate = fs.readFileSync(certificatePath, 'utf-8');

    const verify = createVerify('sha256');
    verify.update(JSON.stringify(prescriptionData));

    return verify.verify(certificate, signature, 'base64');
  } catch (error) {
    console.error('Erro ao verificar assinatura:', error);
    return false;
  }
}
```

---

## 5. DADOS SEED (Inicialização)

### 5.1 Usuários de Teste

```sql
-- Paciente
INSERT INTO users (id, email, name, role, cpf, date_of_birth, created_at)
VALUES (
  'patient-001',
  'joao@example.com',
  'João Silva',
  'patient',
  '12345678901',
  '1990-05-15',
  NOW()
);

-- Profissional (Médico)
INSERT INTO users (id, email, name, role, crm, specialty, created_at)
VALUES (
  'prof-001',
  'dr.carlos@example.com',
  'Dr. Carlos Silva',
  'professional',
  '123456/SP',
  'Neurologia',
  NOW()
);

-- Farmacêutico
INSERT INTO users (id, email, name, role, crf, pharmacy_id, created_at)
VALUES (
  'pharmacist-001',
  'farmaceutico@example.com',
  'Ana Costa',
  'pharmacist',
  '654321/SP',
  'pharmacy-001',
  NOW()
);

-- Administrador
INSERT INTO users (id, email, name, role, created_at)
VALUES (
  'admin-001',
  'admin@example.com',
  'Administrador',
  'admin',
  NOW()
);
```

### 5.2 Variedades de Cannabis

```sql
INSERT INTO cannabis_strains (id, name, thc_percentage, cbd_percentage, medical_indications, created_at)
VALUES
  ('strain-001', 'Charlotte\'s Web', 0.3, 17, 'Epilepsia, Ansiedade, Inflamação', NOW()),
  ('strain-002', 'Harlequin', 5, 10, 'Dor, Ansiedade, Depressão', NOW()),
  ('strain-003', 'AC/DC', 1, 15, 'Dor Crônica, Inflamação, Insônia', NOW()),
  ('strain-004', 'Pennywise', 6, 6, 'Ansiedade, PTSD, Dor', NOW()),
  ('strain-005', 'Remedy', 0.2, 13, 'Insônia, Ansiedade, Dor', NOW());
```

---

## 6. CRITÉRIOS DE ACEITE

### 6.1 Testes Funcionais

- [ ] Paciente consegue preencher questionário de sintomas
- [ ] Sistema valida maioridade do paciente
- [ ] Paciente consegue assinar TCLE digitalmente
- [ ] Profissional consegue agendar teleconsulta
- [ ] Videoconferência funciona com criptografia E2E
- [ ] Profissional consegue prescrever medicamento
- [ ] Sistema gera e-Receita com assinatura digital
- [ ] Farmacêutico consegue validar e-Receita
- [ ] Farmacêutico consegue registrar dispensação
- [ ] Paciente recebe notificações de acompanhamento

### 6.2 Testes de Segurança

- [ ] Dados sensíveis criptografados (AES-256)
- [ ] Assinatura digital validada (ICP-Brasil)
- [ ] RBAC implementado e testado
- [ ] Logs de auditoria registrados
- [ ] Acesso a dados respeitando privacidade
- [ ] Senhas com hash bcrypt (mínimo 12 rounds)
- [ ] HTTPS em produção
- [ ] CORS configurado corretamente

### 6.3 Testes de Conformidade

- [ ] CRM/CRO/CRMV validado antes de prescrever
- [ ] Prescrição contém todos os dados obrigatórios
- [ ] e-Receita assinada digitalmente
- [ ] Validade de prescrição respeitada (30 dias)
- [ ] Histórico de prescrições mantido por 5 anos
- [ ] Consentimento informado (TCLE) obtido
- [ ] Relatórios de conformidade geráveis

---

## 7. REFERÊNCIAS LEGAIS

1. **Lei nº 13.123/2015** - Acesso ao Patrimônio Genético
   - https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2015/lei/l13123.htm

2. **RDC ANVISA nº 327/2019** - Canabidiol (CBD)
   - https://www.in.gov.br/en/web/dou/-/resolucao-da-diretoria-colegiada-rdc-n-327-de-9-de-dezembro-de-2019-232669395

3. **RDC ANVISA nº 660/2022** - Canabinoides
   - https://www.in.gov.br/en/web/dou/-/resolucao-da-diretoria-colegiada-rdc-n-660-de-30-de-setembro-de-2022-432833156

4. **Resolução CFM nº 1.931/2009** - Código de Ética Médica
   - https://www.in.gov.br/en/web/dou/-/resolucao-cfm-n-1-931-de-17-de-setembro-de-2009-92146903

5. **Resolução CFM nº 2.113/2021** - Telemedicina
   - https://www.in.gov.br/en/web/dou/-/resolucao-cfm-n-2-113-de-20-de-dezembro-de-2021-366610586

6. **Medida Provisória nº 2.200-2/2001** - ICP-Brasil
   - https://www.planalto.gov.br/ccivil_03/mpv/antigas_mp/2200-2.htm

7. **Lei nº 11.343/2006** - Lei de Drogas
   - https://www.planalto.gov.br/ccivil_03/_ato2004-2006/2006/lei/l11343.htm

---

## 8. AVISOS IMPORTANTES

⚠️ **ESTE DOCUMENTO NÃO SUBSTITUI CONSULTORIA JURÍDICA ESPECIALIZADA**

Recomenda-se:
1. Consultar advogado especializado em direito médico e regulatório
2. Validar integrações com órgãos reguladores (CFM, ANVISA, CREMESP, etc.)
3. Implementar seguro de responsabilidade civil profissional
4. Manter conformidade com LGPD (Lei Geral de Proteção de Dados)
5. Realizar auditorias de segurança periódicas
6. Manter documentação de todas as decisões regulatórias

---

**Última atualização:** Fevereiro 2026
**Versão:** 1.0
**Status:** Ativo
