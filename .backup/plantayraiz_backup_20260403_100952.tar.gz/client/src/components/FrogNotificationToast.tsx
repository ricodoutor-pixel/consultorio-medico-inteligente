import React, { useState, useEffect } from 'react';
import { X, CheckCircle, AlertCircle, Info, Clock } from 'lucide-react';

export interface ToastNotification {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  message: string;
  duration?: number;
}

interface FrogNotificationToastProps {
  notifications: ToastNotification[];
  onRemove: (id: string) => void;
}

const FrogNotificationToast: React.FC<FrogNotificationToastProps> = ({ notifications, onRemove }) => {
  const getIcon = (type: string) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="w-5 h-5 text-green-400" />;
      case 'error':
        return <AlertCircle className="w-5 h-5 text-red-400" />;
      case 'warning':
        return <Clock className="w-5 h-5 text-yellow-400" />;
      case 'info':
      default:
        return <Info className="w-5 h-5 text-blue-400" />;
    }
  };

  const getBgColor = (type: string) => {
    switch (type) {
      case 'success':
        return 'bg-green-500/20 border-green-500/50';
      case 'error':
        return 'bg-red-500/20 border-red-500/50';
      case 'warning':
        return 'bg-yellow-500/20 border-yellow-500/50';
      case 'info':
      default:
        return 'bg-blue-500/20 border-blue-500/50';
    }
  };

  return (
    <div className="fixed bottom-4 right-4 z-50 space-y-3 max-w-sm">
      {notifications.map((notification, index) => (
        <div
          key={notification.id}
          className={`flex items-start gap-3 p-4 rounded-lg border backdrop-blur-sm ${getBgColor(
            notification.type
          )} animate-in slide-in-from-right-full duration-300`}
          style={{
            animation: `slideIn 0.3s ease-out ${index * 0.1}s both`,
          }}
        >
          {/* Sapo Pequeno */}
          <div className="flex-shrink-0 mt-1">
            <div className="relative w-8 h-8">
              {/* Corpo do sapo mini */}
              <div className="absolute inset-0 bg-gradient-to-b from-green-300 to-green-500 rounded-full flex items-center justify-center">
                {/* Olhos */}
                <div className="flex gap-1 absolute top-1">
                  <div className="w-1.5 h-1.5 bg-white rounded-full">
                    <div className="w-0.5 h-0.5 bg-black rounded-full absolute top-0.5 left-0.5"></div>
                  </div>
                  <div className="w-1.5 h-1.5 bg-white rounded-full">
                    <div className="w-0.5 h-0.5 bg-black rounded-full absolute top-0.5 right-0.5"></div>
                  </div>
                </div>
                {/* Boca */}
                <div className="absolute bottom-1 w-2 h-1 border-b-2 border-green-700 rounded-b-full"></div>
              </div>
            </div>
          </div>

          {/* Conteúdo */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1">
                <h3 className="font-semibold text-white text-sm">{notification.title}</h3>
                <p className="text-gray-300 text-xs mt-1">{notification.message}</p>
              </div>
              <button
                onClick={() => onRemove(notification.id)}
                className="text-gray-400 hover:text-white transition-colors flex-shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Barra de progresso */}
          <div
            className="absolute bottom-0 left-0 h-1 bg-gradient-to-r from-green-400 to-emerald-400 rounded-b-lg"
            style={{
              animation: `shrink ${notification.duration || 5}s linear forwards`,
            }}
          ></div>
        </div>
      ))}

      <style>{`
        @keyframes slideIn {
          from {
            opacity: 0;
            transform: translateX(100%);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        @keyframes shrink {
          from {
            width: 100%;
          }
          to {
            width: 0%;
          }
        }
      `}</style>
    </div>
  );
};

export default FrogNotificationToast;
