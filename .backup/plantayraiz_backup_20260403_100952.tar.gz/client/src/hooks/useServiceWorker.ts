// ============================================================================
// useServiceWorker — Hook para Registrar e Gerenciar Service Worker
// ============================================================================

import { useEffect, useState } from 'react';

interface ServiceWorkerState {
  isSupported: boolean;
  isRegistered: boolean;
  isUpdating: boolean;
  hasUpdate: boolean;
  error: Error | null;
}

export const useServiceWorker = (): ServiceWorkerState => {
  const [state, setState] = useState<ServiceWorkerState>({
    isSupported: false,
    isRegistered: false,
    isUpdating: false,
    hasUpdate: false,
    error: null,
  });

  useEffect(() => {
    // Check if Service Workers are supported
    if (!('serviceWorker' in navigator)) {
      console.log('[useServiceWorker] Service Workers not supported');
      return;
    }

    setState((prev) => ({ ...prev, isSupported: true }));

    // Register Service Worker
    const registerServiceWorker = async () => {
      try {
        console.log('[useServiceWorker] Registering Service Worker...');

        const registration = await navigator.serviceWorker.register(
          '/service-worker.js',
          { scope: '/' }
        );

        console.log('[useServiceWorker] Service Worker registered successfully');
        setState((prev) => ({ ...prev, isRegistered: true }));

        // Listen for updates
        registration.addEventListener('updatefound', () => {
          console.log('[useServiceWorker] Service Worker update found');
          const newWorker = registration.installing;

          if (newWorker) {
            newWorker.addEventListener('statechange', () => {
              if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                console.log('[useServiceWorker] New Service Worker available');
                setState((prev) => ({ ...prev, hasUpdate: true }));

                // Notify user about update
                if (window.confirm('Uma nova versão está disponível. Deseja atualizar?')) {
                  newWorker.postMessage({ type: 'SKIP_WAITING' });
                  window.location.reload();
                }
              }
            });
          }
        });

        // Handle controller change
        navigator.serviceWorker.addEventListener('controllerchange', () => {
          console.log('[useServiceWorker] Service Worker controller changed');
          window.location.reload();
        });
      } catch (error) {
        console.error('[useServiceWorker] Registration failed:', error);
        setState((prev) => ({
          ...prev,
          error: error instanceof Error ? error : new Error('Unknown error'),
        }));
      }
    };

    registerServiceWorker();
  }, []);

  return state;
};

// ============================================================================
// useBackgroundSync — Hook para Sincronizar Dados em Background
// ============================================================================

export const useBackgroundSync = (tag: string) => {
  const [isSyncing, setIsSyncing] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const requestSync = async () => {
    if (!('serviceWorker' in navigator) || !('SyncManager' in window)) {
      console.log('[useBackgroundSync] Background Sync not supported');
      return false;
    }

    try {
      setIsSyncing(true);
      const registration = await navigator.serviceWorker.ready;

      if (registration.sync) {
        await registration.sync.register(tag);
        console.log('[useBackgroundSync] Sync registered:', tag);
        return true;
      }
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Unknown error');
      console.error('[useBackgroundSync] Sync failed:', error);
      setError(error);
      return false;
    } finally {
      setIsSyncing(false);
    }
  };

  return { requestSync, isSyncing, error };
};

// ============================================================================
// usePushNotifications — Hook para Gerenciar Push Notifications
// ============================================================================

export const usePushNotifications = () => {
  const [isSupported, setIsSupported] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
      console.log('[usePushNotifications] Push Notifications not supported');
      return;
    }

    setIsSupported(true);

    // Check if already subscribed
    const checkSubscription = async () => {
      try {
        const registration = await navigator.serviceWorker.ready;
        const subscription = await registration.pushManager.getSubscription();
        setIsSubscribed(!!subscription);
      } catch (err) {
        const error = err instanceof Error ? err : new Error('Unknown error');
        console.error('[usePushNotifications] Check failed:', error);
        setError(error);
      }
    };

    checkSubscription();
  }, []);

  const subscribe = async (vapidPublicKey: string) => {
    if (!isSupported) {
      console.log('[usePushNotifications] Push Notifications not supported');
      return false;
    }

    try {
      const registration = await navigator.serviceWorker.ready;
      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(vapidPublicKey),
      });

      console.log('[usePushNotifications] Subscribed successfully');
      setIsSubscribed(true);
      return subscription;
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Unknown error');
      console.error('[usePushNotifications] Subscription failed:', error);
      setError(error);
      return null;
    }
  };

  const unsubscribe = async () => {
    try {
      const registration = await navigator.serviceWorker.ready;
      const subscription = await registration.pushManager.getSubscription();

      if (subscription) {
        await subscription.unsubscribe();
        console.log('[usePushNotifications] Unsubscribed successfully');
        setIsSubscribed(false);
        return true;
      }
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Unknown error');
      console.error('[usePushNotifications] Unsubscription failed:', error);
      setError(error);
      return false;
    }
  };

  return { isSupported, isSubscribed, subscribe, unsubscribe, error };
};

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/\-/g, '+').replace(/_/g, '/');

  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }

  return outputArray;
}

// ============================================================================
// useOnline — Hook para Monitorar Status de Conexão
// ============================================================================

export const useOnline = () => {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  useEffect(() => {
    const handleOnline = () => {
      console.log('[useOnline] Online');
      setIsOnline(true);
    };

    const handleOffline = () => {
      console.log('[useOnline] Offline');
      setIsOnline(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return isOnline;
};
