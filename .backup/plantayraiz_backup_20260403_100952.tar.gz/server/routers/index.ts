import { router } from '../_core/trpc';
import { videocallRouter, paymentRouter } from './videocall';

/**
 * Routers principais da aplicação
 */
export const appRouter = router({
  videocall: videocallRouter,
  payment: paymentRouter,
  // ... outros routers
});

export type AppRouter = typeof appRouter;
