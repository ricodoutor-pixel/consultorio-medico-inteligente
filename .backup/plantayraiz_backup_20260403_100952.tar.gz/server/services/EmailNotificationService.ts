/**
 * EmailNotificationService - Sistema de Notificações por Email
 * Alertas para administradores sobre falhas, atividades suspeitas e eventos críticos
 */

export type AlertLevel = "critical" | "warning" | "info";
export type AlertCategory =
  | "payout_failure"
  | "suspicious_activity"
  | "compliance_issue"
  | "fraud_detection"
  | "system_error"
  | "high_value_transaction";

interface EmailAlert {
  id: string;
  level: AlertLevel;
  category: AlertCategory;
  title: string;
  message: string;
  details: Record<string, any>;
  recipients: string[];
  sentAt: Date;
  status: "pending" | "sent" | "failed";
  retries: number;
}

interface AnomalyDetection {
  id: string;
  type: "unusual_amount" | "rapid_transactions" | "geographic_anomaly" | "time_anomaly";
  severity: number; // 0-100
  description: string;
  detectedAt: Date;
  entityId: string;
  entityType: "doctor" | "shopkeeper" | "patient";
}

export class EmailNotificationService {
  private static alerts: Map<string, EmailAlert> = new Map();
  private static anomalies: Map<string, AnomalyDetection> = new Map();
  private static adminEmails = [
    "admin@plantayraiz.com.br",
    "contato@plantayraiz.com.br",
  ];

  /**
   * Enviar alerta de falha de Payout
   */
  static async alertPayoutFailure(
    payoutId: string,
    recipientId: string,
    amount: number,
    reason: string,
    bankAccount: string
  ): Promise<EmailAlert> {
    const alert: EmailAlert = {
      id: `alert-payout-${payoutId}`,
      level: "critical",
      category: "payout_failure",
      title: `❌ FALHA NO PAYOUT - ID: ${payoutId}`,
      message: `Falha ao processar transferência de R$ ${amount.toFixed(2)} para ${recipientId}`,
      details: {
        payoutId,
        recipientId,
        amount,
        reason,
        bankAccount,
        timestamp: new Date().toISOString(),
      },
      recipients: this.adminEmails,
      sentAt: new Date(),
      status: "pending",
      retries: 0,
    };

    this.alerts.set(alert.id, alert);
    await this.sendEmailAlert(alert);
    return alert;
  }

  /**
   * Detectar e alertar atividade suspeita
   */
  static async detectSuspiciousActivity(
    entityId: string,
    entityType: "doctor" | "shopkeeper" | "patient",
    activityType: string,
    details: Record<string, any>
  ): Promise<EmailAlert | null> {
    // Analisar atividade
    const anomaly = this.analyzeActivity(entityId, entityType, activityType, details);

    if (anomaly && anomaly.severity > 60) {
      const alert: EmailAlert = {
        id: `alert-suspicious-${entityId}-${Date.now()}`,
        level: anomaly.severity > 80 ? "critical" : "warning",
        category: "suspicious_activity",
        title: `⚠️ ATIVIDADE SUSPEITA DETECTADA - ${entityType.toUpperCase()}`,
        message: `${anomaly.description}`,
        details: {
          entityId,
          entityType,
          activityType,
          anomalySeverity: anomaly.severity,
          ...details,
          timestamp: new Date().toISOString(),
        },
        recipients: this.adminEmails,
        sentAt: new Date(),
        status: "pending",
        retries: 0,
      };

      this.alerts.set(alert.id, alert);
      this.anomalies.set(anomaly.id, anomaly);
      await this.sendEmailAlert(alert);
      return alert;
    }

    return null;
  }

  /**
   * Alertar sobre problema de conformidade
   */
  static async alertComplianceIssue(
    entityId: string,
    entityType: "doctor" | "shopkeeper",
    issue: string,
    affectedRecords: string[]
  ): Promise<EmailAlert> {
    const alert: EmailAlert = {
      id: `alert-compliance-${entityId}-${Date.now()}`,
      level: "warning",
      category: "compliance_issue",
      title: `⚠️ PROBLEMA DE CONFORMIDADE DETECTADO`,
      message: `Problema de conformidade identificado para ${entityType}: ${issue}`,
      details: {
        entityId,
        entityType,
        issue,
        affectedRecords,
        timestamp: new Date().toISOString(),
      },
      recipients: this.adminEmails,
      sentAt: new Date(),
      status: "pending",
      retries: 0,
    };

    this.alerts.set(alert.id, alert);
    await this.sendEmailAlert(alert);
    return alert;
  }

  /**
   * Alertar sobre possível fraude
   */
  static async alertFraudDetection(
    transactionId: string,
    entityId: string,
    fraudScore: number,
    indicators: string[]
  ): Promise<EmailAlert> {
    const alert: EmailAlert = {
      id: `alert-fraud-${transactionId}`,
      level: fraudScore > 80 ? "critical" : "warning",
      category: "fraud_detection",
      title: `🚨 POSSÍVEL FRAUDE DETECTADA - Score: ${fraudScore}%`,
      message: `Transação ${transactionId} apresenta indicadores de fraude`,
      details: {
        transactionId,
        entityId,
        fraudScore,
        indicators,
        timestamp: new Date().toISOString(),
      },
      recipients: this.adminEmails,
      sentAt: new Date(),
      status: "pending",
      retries: 0,
    };

    this.alerts.set(alert.id, alert);
    await this.sendEmailAlert(alert);
    return alert;
  }

  /**
   * Alertar sobre transação de alto valor
   */
  static async alertHighValueTransaction(
    transactionId: string,
    entityId: string,
    amount: number,
    threshold: number
  ): Promise<EmailAlert> {
    if (amount > threshold) {
      const alert: EmailAlert = {
        id: `alert-high-value-${transactionId}`,
        level: "info",
        category: "high_value_transaction",
        title: `ℹ️ TRANSAÇÃO DE ALTO VALOR PROCESSADA`,
        message: `Transação de R$ ${amount.toFixed(2)} excede o limite de R$ ${threshold.toFixed(2)}`,
        details: {
          transactionId,
          entityId,
          amount,
          threshold,
          timestamp: new Date().toISOString(),
        },
        recipients: this.adminEmails,
        sentAt: new Date(),
        status: "pending",
        retries: 0,
      };

      this.alerts.set(alert.id, alert);
      await this.sendEmailAlert(alert);
      return alert;
    }

    return null as any;
  }

  /**
   * Enviar email de alerta
   */
  private static async sendEmailAlert(alert: EmailAlert): Promise<void> {
    try {
      const emailContent = this.generateEmailTemplate(alert);

      // Simular envio de email
      console.log(`[EMAIL] Enviando alerta para: ${alert.recipients.join(", ")}`);
      console.log(`[EMAIL] Assunto: ${alert.title}`);
      console.log(`[EMAIL] Nível: ${alert.level}`);
      console.log(`[EMAIL] Categoria: ${alert.category}`);
      console.log(`[EMAIL] Mensagem: ${alert.message}`);
      console.log(`[EMAIL] Detalhes:`, JSON.stringify(alert.details, null, 2));

      // Em produção, usar SendGrid, AWS SES ou similar
      alert.status = "sent";
    } catch (error) {
      console.error(`[EMAIL] Erro ao enviar alerta: ${error}`);
      alert.status = "failed";
      alert.retries++;

      // Retry logic
      if (alert.retries < 3) {
        setTimeout(() => this.sendEmailAlert(alert), 5000 * alert.retries);
      }
    }
  }

  /**
   * Gerar template de email
   */
  private static generateEmailTemplate(alert: EmailAlert): string {
    const levelEmoji = {
      critical: "🚨",
      warning: "⚠️",
      info: "ℹ️",
    };

    return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: Arial, sans-serif; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background-color: ${alert.level === "critical" ? "#ff4444" : alert.level === "warning" ? "#ffaa00" : "#0066cc"}; color: white; padding: 20px; border-radius: 5px; }
    .content { margin: 20px 0; }
    .details { background-color: #f5f5f5; padding: 15px; border-radius: 5px; font-family: monospace; font-size: 12px; }
    .footer { color: #666; font-size: 12px; margin-top: 20px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h2>${levelEmoji[alert.level]} ${alert.title}</h2>
    </div>
    <div class="content">
      <p><strong>Mensagem:</strong> ${alert.message}</p>
      <p><strong>Categoria:</strong> ${alert.category}</p>
      <p><strong>Nível de Alerta:</strong> ${alert.level.toUpperCase()}</p>
      <div class="details">
        <strong>Detalhes:</strong><br>
        ${JSON.stringify(alert.details, null, 2)}
      </div>
    </div>
    <div class="footer">
      <p>Planta & Raiz - Sistema de Alertas Automáticos</p>
      <p>Email enviado em: ${new Date().toLocaleString("pt-BR")}</p>
    </div>
  </div>
</body>
</html>
    `;
  }

  /**
   * Analisar atividade para detectar anomalias
   */
  private static analyzeActivity(
    entityId: string,
    entityType: string,
    activityType: string,
    details: Record<string, any>
  ): AnomalyDetection | null {
    let severity = 0;
    let type: AnomalyDetection["type"] = "unusual_amount";
    let description = "";

    // Verificar valor incomum
    if (details.amount && details.amount > 50000) {
      severity += 40;
      type = "unusual_amount";
      description = `Valor incomum detectado: R$ ${details.amount.toFixed(2)}`;
    }

    // Verificar múltiplas transações rápidas
    if (details.transactionCount && details.transactionCount > 10) {
      severity += 30;
      type = "rapid_transactions";
      description = `${details.transactionCount} transações em curto período`;
    }

    // Verificar anomalia geográfica
    if (details.previousCountry && details.currentCountry && details.previousCountry !== details.currentCountry) {
      severity += 25;
      type = "geographic_anomaly";
      description = `Mudança geográfica detectada: ${details.previousCountry} → ${details.currentCountry}`;
    }

    // Verificar anomalia de horário
    const hour = new Date().getHours();
    if (hour >= 2 && hour <= 5 && details.amount && details.amount > 10000) {
      severity += 20;
      type = "time_anomaly";
      description = `Transação de alto valor em horário incomum`;
    }

    if (severity > 0) {
      return {
        id: `anomaly-${entityId}-${Date.now()}`,
        type,
        severity: Math.min(severity, 100),
        description,
        detectedAt: new Date(),
        entityId,
        entityType: entityType as "doctor" | "shopkeeper" | "patient",
      };
    }

    return null;
  }

  /**
   * Obter histórico de alertas
   */
  static async getAlertHistory(limit: number = 100): Promise<EmailAlert[]> {
    return Array.from(this.alerts.values())
      .sort((a, b) => b.sentAt.getTime() - a.sentAt.getTime())
      .slice(0, limit);
  }

  /**
   * Obter alertas por nível
   */
  static async getAlertsByLevel(level: AlertLevel): Promise<EmailAlert[]> {
    return Array.from(this.alerts.values()).filter((a) => a.level === level);
  }

  /**
   * Obter estatísticas de alertas
   */
  static async getAlertStats(): Promise<{
    total: number;
    critical: number;
    warning: number;
    info: number;
    sent: number;
    failed: number;
    pending: number;
  }> {
    const alerts = Array.from(this.alerts.values());
    return {
      total: alerts.length,
      critical: alerts.filter((a) => a.level === "critical").length,
      warning: alerts.filter((a) => a.level === "warning").length,
      info: alerts.filter((a) => a.level === "info").length,
      sent: alerts.filter((a) => a.status === "sent").length,
      failed: alerts.filter((a) => a.status === "failed").length,
      pending: alerts.filter((a) => a.status === "pending").length,
    };
  }

  /**
   * Obter anomalias detectadas
   */
  static async getDetectedAnomalies(): Promise<AnomalyDetection[]> {
    return Array.from(this.anomalies.values()).sort(
      (a, b) => b.severity - a.severity
    );
  }
}
