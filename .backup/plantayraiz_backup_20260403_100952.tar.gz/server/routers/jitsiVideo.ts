import { router, protectedProcedure, publicProcedure } from '../_core/trpc';
import { z } from 'zod';
import { JitsiVideoService } from '../services/JitsiVideoService';

export const jitsiVideoRouter = router({
  createSession: protectedProcedure
    .input(
      z.object({
        consultationId: z.string(),
        doctorName: z.string(),
        patientName: z.string(),
        duration: z.number().default(30),
        recordingEnabled: z.boolean().default(true),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const session = JitsiVideoService.createVideoSession({
          consultationId: input.consultationId,
          doctorName: input.doctorName,
          patientName: input.patientName,
          startTime: Date.now(),
          duration: input.duration,
          recordingEnabled: input.recordingEnabled,
        });

        return {
          success: true,
          session,
          message: 'Sessão de vídeo criada com sucesso',
        };
      } catch (error) {
        console.error('[jitsiVideo] createSession error:', error);
        return {
          success: false,
          message: 'Erro ao criar sessão',
        };
      }
    }),

  getDoctorUrl: protectedProcedure
    .input(
      z.object({
        sessionId: z.string(),
        doctorName: z.string(),
      })
    )
    .query(async ({ input }) => {
      try {
        const url = JitsiVideoService.getDoctorAccessUrl(input.sessionId, input.doctorName);
        return {
          success: !!url,
          url,
          message: url ? 'URL gerada com sucesso' : 'Sessão não encontrada',
        };
      } catch (error) {
        console.error('[jitsiVideo] getDoctorUrl error:', error);
        return {
          success: false,
          message: 'Erro ao gerar URL',
        };
      }
    }),

  getPatientUrl: protectedProcedure
    .input(
      z.object({
        sessionId: z.string(),
        patientName: z.string(),
      })
    )
    .query(async ({ input }) => {
      try {
        const url = JitsiVideoService.getPatientAccessUrl(input.sessionId, input.patientName);
        return {
          success: !!url,
          url,
          message: url ? 'URL gerada com sucesso' : 'Sessão não encontrada',
        };
      } catch (error) {
        console.error('[jitsiVideo] getPatientUrl error:', error);
        return {
          success: false,
          message: 'Erro ao gerar URL',
        };
      }
    }),

  startRecording: protectedProcedure
    .input(z.object({ sessionId: z.string() }))
    .mutation(async ({ input }) => {
      try {
        const success = JitsiVideoService.startRecording(input.sessionId);
        return {
          success,
          message: success ? 'Gravação iniciada' : 'Sessão não encontrada',
        };
      } catch (error) {
        console.error('[jitsiVideo] startRecording error:', error);
        return {
          success: false,
          message: 'Erro ao iniciar gravação',
        };
      }
    }),

  endSession: protectedProcedure
    .input(z.object({ sessionId: z.string() }))
    .mutation(async ({ input }) => {
      try {
        const session = JitsiVideoService.endSession(input.sessionId);
        return {
          success: !!session,
          session,
          message: session ? 'Sessão finalizada' : 'Sessão não encontrada',
        };
      } catch (error) {
        console.error('[jitsiVideo] endSession error:', error);
        return {
          success: false,
          message: 'Erro ao finalizar sessão',
        };
      }
    }),

  getSessionInfo: publicProcedure
    .input(z.object({ sessionId: z.string() }))
    .query(async ({ input }) => {
      try {
        const session = JitsiVideoService.getSessionInfo(input.sessionId);
        return {
          success: !!session,
          session,
        };
      } catch (error) {
        console.error('[jitsiVideo] getSessionInfo error:', error);
        return {
          success: false,
          session: null,
        };
      }
    }),

  getHistory: publicProcedure
    .input(z.object({ limit: z.number().default(50) }))
    .query(async ({ input }) => {
      try {
        const history = JitsiVideoService.getSessionHistory(input.limit);
        return {
          success: true,
          data: history,
          count: history.length,
        };
      } catch (error) {
        console.error('[jitsiVideo] getHistory error:', error);
        return {
          success: false,
          data: [],
          count: 0,
        };
      }
    }),

  getStats: publicProcedure.query(async () => {
    try {
      const stats = JitsiVideoService.getSessionStats();
      return {
        success: true,
        data: stats,
      };
    } catch (error) {
      console.error('[jitsiVideo] getStats error:', error);
      return {
        success: false,
        data: null,
      };
    }
  }),
});
