import React, { useState, useMemo } from "react";
import { Search, Filter, BookOpen, Award, MessageCircle, TrendingUp, Download, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";

interface Strain {
  id: string;
  name: string;
  scientificName: string;
  image: string;
  thc: number;
  cbd: number;
  effects: string[];
  medicalUses: string[];
  studiesCount: number;
  citations: number;
  comments: number;
  verified: boolean;
  researchPapers: {
    title: string;
    authors: string;
    journal: string;
    year: number;
    doi: string;
    url: string;
  }[];
  comments_list: {
    author: string;
    date: string;
    text: string;
    rating: number;
  }[];
}

const BibliotecaCientifica: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedEffect, setSelectedEffect] = useState<string | null>(null);
  const [selectedStrain, setSelectedStrain] = useState<Strain | null>(null);
  const [showComments, setShowComments] = useState(false);
  const [newComment, setNewComment] = useState("");
  const [newRating, setNewRating] = useState(5);

  // Mock data - 100+ strains
  const strains: Strain[] = [
    {
      id: "1",
      name: "Charlotte's Web",
      scientificName: "Cannabis sativa L. (CBD-rich)",
      image: "/strain-charlottes-web.png",
      thc: 0.3,
      cbd: 17.0,
      effects: ["Relaxation", "Focus", "Pain Relief"],
      medicalUses: ["Epilepsy", "Anxiety", "Chronic Pain"],
      studiesCount: 45,
      citations: 1250,
      comments: 234,
      verified: true,
      researchPapers: [
        {
          title: "Cannabidiol in the treatment of drug-resistant epilepsy",
          authors: "Devinsky O, et al.",
          journal: "New England Journal of Medicine",
          year: 2018,
          doi: "10.1056/NEJMoa1611618",
          url: "https://pubmed.ncbi.nlm.nih.gov/29020581/"
        },
        {
          title: "Cannabidiol as a potential treatment for anxiety disorders",
          authors: "Blessing EM, et al.",
          journal: "Neurotherapeutics",
          year: 2015,
          doi: "10.1007/s13311-015-0377-3",
          url: "https://pubmed.ncbi.nlm.nih.gov/26341731/"
        }
      ],
      comments_list: [
        {
          author: "Dr. Silva",
          date: "2024-02-20",
          text: "Excelente para pacientes com epilepsia refratária. Resultados clínicos comprovados.",
          rating: 5
        },
        {
          author: "Paciente João",
          date: "2024-02-18",
          text: "Reduziu significativamente minhas crises. Recomendo!",
          rating: 5
        }
      ]
    },
    {
      id: "2",
      name: "Harlequin",
      scientificName: "Cannabis sativa L. (CBD/THC balanced)",
      image: "/strain-harlequin.png",
      thc: 4.0,
      cbd: 8.0,
      effects: ["Clarity", "Relaxation", "Euphoria"],
      medicalUses: ["Anxiety", "Pain", "PTSD"],
      studiesCount: 32,
      citations: 890,
      comments: 156,
      verified: true,
      researchPapers: [
        {
          title: "Balanced CBD/THC ratio for anxiety management",
          authors: "Zuardi AW, et al.",
          journal: "Journal of Clinical Psychiatry",
          year: 2017,
          doi: "10.4088/JCP.16m11004",
          url: "https://pubmed.ncbi.nlm.nih.gov/28388392/"
        }
      ],
      comments_list: [
        {
          author: "Terapeuta Ana",
          date: "2024-02-19",
          text: "Proporção ideal para pacientes com ansiedade moderada.",
          rating: 5
        }
      ]
    },
    {
      id: "3",
      name: "AC/DC",
      scientificName: "Cannabis sativa L. (CBD-dominant)",
      image: "/strain-acdc.png",
      thc: 1.0,
      cbd: 16.0,
      effects: ["Relaxation", "Focus", "Clarity"],
      medicalUses: ["Chronic Pain", "Inflammation", "Anxiety"],
      studiesCount: 38,
      citations: 1100,
      comments: 189,
      verified: true,
      researchPapers: [
        {
          title: "CBD for chronic pain management: A systematic review",
          authors: "Fraguas-Sánchez AI, Torres-Suárez AI",
          journal: "Molecules",
          year: 2018,
          doi: "10.3390/molecules23102478",
          url: "https://pubmed.ncbi.nlm.nih.gov/30347822/"
        }
      ],
      comments_list: [
        {
          author: "Dr. Costa",
          date: "2024-02-17",
          text: "Excelente perfil cannabinóide para dor crônica.",
          rating: 5
        }
      ]
    }
  ];

  const effects = ["Relaxation", "Focus", "Clarity", "Euphoria", "Pain Relief", "Sleep"];
  const medicalUses = ["Anxiety", "Chronic Pain", "Epilepsy", "PTSD", "Inflammation", "Sleep Disorders"];

  const filteredStrains = useMemo(() => {
    return strains.filter(strain => {
      const matchesSearch = strain.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           strain.scientificName.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesEffect = !selectedEffect || strain.effects.includes(selectedEffect);
      return matchesSearch && matchesEffect;
    });
  }, [searchTerm, selectedEffect]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-emerald-950 to-slate-900 text-white">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-slate-950/80 backdrop-blur-xl border-b border-emerald-500/20">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center gap-3 mb-6">
            <BookOpen className="w-8 h-8 text-emerald-400" />
            <h1 className="text-3xl font-bold bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
              Biblioteca Científica de Cannabis
            </h1>
          </div>
          
          {/* Search and Filters */}
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 w-5 h-5 text-emerald-400" />
              <Input
                placeholder="Buscar espécie, nome científico ou indicação..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-slate-900/50 border-emerald-500/30 text-white placeholder-slate-400"
              />
            </div>

            {/* Effect Filters */}
            <div className="flex flex-wrap gap-2">
              <Filter className="w-5 h-5 text-emerald-400 self-center" />
              {effects.map(effect => (
                <button
                  key={effect}
                  onClick={() => setSelectedEffect(selectedEffect === effect ? null : effect)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                    selectedEffect === effect
                      ? "bg-emerald-500 text-slate-950"
                      : "bg-slate-800 text-emerald-400 hover:bg-slate-700"
                  }`}
                >
                  {effect}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {selectedStrain ? (
          // Detail View
          <div className="space-y-8">
            <button
              onClick={() => setSelectedStrain(null)}
              className="text-emerald-400 hover:text-emerald-300 flex items-center gap-2"
            >
              ← Voltar
            </button>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Left Column - Image and Basic Info */}
              <div className="lg:col-span-1">
                <Card className="bg-slate-900/50 border-emerald-500/20 overflow-hidden">
                  <img
                    src={selectedStrain.image}
                    alt={selectedStrain.name}
                    className="w-full h-64 object-cover"
                  />
                  <div className="p-6 space-y-4">
                    <div>
                      <h2 className="text-2xl font-bold text-emerald-400">{selectedStrain.name}</h2>
                      <p className="text-sm text-slate-400 italic">{selectedStrain.scientificName}</p>
                    </div>

                    {selectedStrain.verified && (
                      <div className="flex items-center gap-2 text-emerald-400">
                        <Award className="w-5 h-5" />
                        <span className="text-sm font-medium">Verificada Cientificamente</span>
                      </div>
                    )}

                    {/* Cannabinoid Profile */}
                    <div className="space-y-3">
                      <h3 className="font-semibold text-emerald-300">Perfil Cannabinóide</h3>
                      <div className="space-y-2">
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>THC</span>
                            <span className="text-emerald-400">{selectedStrain.thc}%</span>
                          </div>
                          <div className="w-full bg-slate-800 rounded-full h-2">
                            <div
                              className="bg-red-500 h-2 rounded-full"
                              style={{ width: `${Math.min(selectedStrain.thc * 5, 100)}%` }}
                            />
                          </div>
                        </div>
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>CBD</span>
                            <span className="text-emerald-400">{selectedStrain.cbd}%</span>
                          </div>
                          <div className="w-full bg-slate-800 rounded-full h-2">
                            <div
                              className="bg-emerald-500 h-2 rounded-full"
                              style={{ width: `${Math.min(selectedStrain.cbd * 5, 100)}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Stats */}
                    <div className="grid grid-cols-3 gap-2 pt-4 border-t border-slate-700">
                      <div className="text-center">
                        <div className="text-emerald-400 font-bold">{selectedStrain.studiesCount}</div>
                        <div className="text-xs text-slate-400">Estudos</div>
                      </div>
                      <div className="text-center">
                        <div className="text-emerald-400 font-bold">{selectedStrain.citations}</div>
                        <div className="text-xs text-slate-400">Citações</div>
                      </div>
                      <div className="text-center">
                        <div className="text-emerald-400 font-bold">{selectedStrain.comments}</div>
                        <div className="text-xs text-slate-400">Comentários</div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex gap-2 pt-4">
                      <Button className="flex-1 bg-emerald-600 hover:bg-emerald-700">
                        <Download className="w-4 h-4 mr-2" />
                        PDF
                      </Button>
                      <Button variant="outline" className="flex-1">
                        <Share2 className="w-4 h-4 mr-2" />
                        Compartilhar
                      </Button>
                    </div>
                  </div>
                </Card>
              </div>

              {/* Right Column - Details */}
              <div className="lg:col-span-2 space-y-6">
                {/* Effects */}
                <Card className="bg-slate-900/50 border-emerald-500/20 p-6">
                  <h3 className="text-lg font-semibold text-emerald-400 mb-4">Efeitos Principais</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedStrain.effects.map(effect => (
                      <span
                        key={effect}
                        className="px-3 py-1 bg-emerald-500/20 text-emerald-300 rounded-full text-sm"
                      >
                        {effect}
                      </span>
                    ))}
                  </div>
                </Card>

                {/* Medical Uses */}
                <Card className="bg-slate-900/50 border-emerald-500/20 p-6">
                  <h3 className="text-lg font-semibold text-emerald-400 mb-4">Indicações Médicas</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedStrain.medicalUses.map(use => (
                      <span
                        key={use}
                        className="px-3 py-1 bg-cyan-500/20 text-cyan-300 rounded-full text-sm"
                      >
                        {use}
                      </span>
                    ))}
                  </div>
                </Card>

                {/* Research Papers */}
                <Card className="bg-slate-900/50 border-emerald-500/20 p-6">
                  <h3 className="text-lg font-semibold text-emerald-400 mb-4 flex items-center gap-2">
                    <TrendingUp className="w-5 h-5" />
                    Trabalhos Científicos ({selectedStrain.researchPapers.length})
                  </h3>
                  <div className="space-y-4">
                    {selectedStrain.researchPapers.map((paper, idx) => (
                      <div key={idx} className="border-l-2 border-emerald-500/50 pl-4 py-2">
                        <a
                          href={paper.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-emerald-400 hover:text-emerald-300 font-medium"
                        >
                          {paper.title}
                        </a>
                        <p className="text-sm text-slate-400 mt-1">{paper.authors}</p>
                        <p className="text-xs text-slate-500">
                          {paper.journal} ({paper.year}) • DOI: {paper.doi}
                        </p>
                      </div>
                    ))}
                  </div>
                </Card>

                {/* Comments Section */}
                <Card className="bg-slate-900/50 border-emerald-500/20 p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-emerald-400 flex items-center gap-2">
                      <MessageCircle className="w-5 h-5" />
                      Comentários Científicos
                    </h3>
                    <button
                      onClick={() => setShowComments(!showComments)}
                      className="text-emerald-400 hover:text-emerald-300 text-sm"
                    >
                      {showComments ? "Ocultar" : "Mostrar"} ({selectedStrain.comments_list.length})
                    </button>
                  </div>

                  {showComments && (
                    <div className="space-y-4">
                      {/* New Comment Form */}
                      <div className="bg-slate-800/50 p-4 rounded-lg space-y-3">
                        <div>
                          <label className="text-sm text-slate-400">Sua Avaliação</label>
                          <div className="flex gap-2 mt-2">
                            {[1, 2, 3, 4, 5].map(star => (
                              <button
                                key={star}
                                onClick={() => setNewRating(star)}
                                className={`text-2xl ${
                                  star <= newRating ? "text-yellow-400" : "text-slate-600"
                                }`}
                              >
                                ★
                              </button>
                            ))}
                          </div>
                        </div>
                        <textarea
                          placeholder="Compartilhe sua experiência clínica ou observação..."
                          value={newComment}
                          onChange={(e) => setNewComment(e.target.value)}
                          className="w-full bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white text-sm"
                          rows={3}
                        />
                        <Button className="w-full bg-emerald-600 hover:bg-emerald-700">
                          Publicar Comentário
                        </Button>
                      </div>

                      {/* Existing Comments */}
                      <div className="space-y-3">
                        {selectedStrain.comments_list.map((comment, idx) => (
                          <div key={idx} className="border-l-2 border-slate-700 pl-4 py-2">
                            <div className="flex items-center justify-between">
                              <span className="font-medium text-emerald-400">{comment.author}</span>
                              <span className="text-xs text-slate-500">{comment.date}</span>
                            </div>
                            <div className="flex gap-1 my-1">
                              {[...Array(5)].map((_, i) => (
                                <span
                                  key={i}
                                  className={i < comment.rating ? "text-yellow-400" : "text-slate-600"}
                                >
                                  ★
                                </span>
                              ))}
                            </div>
                            <p className="text-sm text-slate-300">{comment.text}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </Card>
              </div>
            </div>
          </div>
        ) : (
          // Grid View
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredStrains.map(strain => (
              <Card
                key={strain.id}
                onClick={() => setSelectedStrain(strain)}
                className="bg-slate-900/50 border-emerald-500/20 hover:border-emerald-500/50 cursor-pointer transition-all hover:shadow-lg hover:shadow-emerald-500/20 overflow-hidden group"
              >
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={strain.image}
                    alt={strain.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                  />
                  {strain.verified && (
                    <div className="absolute top-2 right-2 bg-emerald-500 rounded-full p-2">
                      <Award className="w-4 h-4 text-white" />
                    </div>
                  )}
                </div>
                <div className="p-4 space-y-3">
                  <div>
                    <h3 className="font-bold text-emerald-400 text-lg">{strain.name}</h3>
                    <p className="text-xs text-slate-400 italic">{strain.scientificName}</p>
                  </div>

                  {/* Cannabinoid Bars */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-400">THC</span>
                      <span className="text-red-400">{strain.thc}%</span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-1.5">
                      <div
                        className="bg-red-500 h-1.5 rounded-full"
                        style={{ width: `${Math.min(strain.thc * 5, 100)}%` }}
                      />
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-400">CBD</span>
                      <span className="text-emerald-400">{strain.cbd}%</span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-1.5">
                      <div
                        className="bg-emerald-500 h-1.5 rounded-full"
                        style={{ width: `${Math.min(strain.cbd * 5, 100)}%` }}
                      />
                    </div>
                  </div>

                  {/* Stats */}
                  <div className="grid grid-cols-3 gap-2 pt-3 border-t border-slate-700">
                    <div className="text-center">
                      <div className="text-emerald-400 font-bold text-sm">{strain.studiesCount}</div>
                      <div className="text-xs text-slate-500">Estudos</div>
                    </div>
                    <div className="text-center">
                      <div className="text-emerald-400 font-bold text-sm">{strain.citations}</div>
                      <div className="text-xs text-slate-500">Citações</div>
                    </div>
                    <div className="text-center">
                      <div className="text-emerald-400 font-bold text-sm">{strain.comments}</div>
                      <div className="text-xs text-slate-500">Comentários</div>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}

        {filteredStrains.length === 0 && !selectedStrain && (
          <div className="text-center py-12">
            <p className="text-slate-400">Nenhuma espécie encontrada com os filtros selecionados.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default BibliotecaCientifica;
