// ============================================================================
// REFERRAL PROGRAM COMPONENT — PROGRAMA DE REFERÊNCIA PARA MÉDICOS
// Planta & Raiz 3.0 — Recompensas Automáticas
// ============================================================================

import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Copy, Share2, TrendingUp, Award, DollarSign, Users } from 'lucide-react';
import { trpc } from '@/lib/trpc';
// Contexto de autenticação será implementado conforme necessário

// ============================================================================
// TIPOS E INTERFACES
// ============================================================================

interface ReferralStats {
  doctorId: string;
  totalReferrals: number;
  successfulReferrals: number;
  totalRewards: number;
  pendingRewards: number;
  paidRewards: number;
  conversionRate: number;
}

interface ReferralTier {
  tier: 'bronze' | 'silver' | 'gold' | 'platinum';
  minReferrals: number;
  maxReferrals: number;
  rewardPercentage: number;
  bonusPercentage: number;
  features: string[];
}

// ============================================================================
// REFERRAL PROGRAM COMPONENT
// ============================================================================

export const ReferralProgramComponent: React.FC = () => {
  // Usar dados mockados para demonstração
  // Em produção, integrar com useAuth() para obter dados reais do usuário
  const [referralLink, setReferralLink] = useState<string>('');
  const [referralCode, setReferralCode] = useState<string>('');
  const [stats, setStats] = useState<ReferralStats | null>(null);
  const [tier, setTier] = useState<ReferralTier | null>(null);
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(true);

  // Buscar dados de referência
  useEffect(() => {
    const fetchReferralData = async () => {
      try {
        setLoading(true);

        // Simular dados para demonstração
        const mockStats: ReferralStats = {
          doctorId: 'doc-' + Math.random().toString(36).substr(2, 9),
          totalReferrals: 12,
          successfulReferrals: 10,
          totalRewards: 1200,
          pendingRewards: 200,
          paidRewards: 1000,
          conversionRate: 83.33,
        };

        const mockTier: ReferralTier = {
          tier: 'silver',
          minReferrals: 5,
          maxReferrals: 14,
          rewardPercentage: 7,
          bonusPercentage: 2,
          features: ['Link de referência avançado', 'Dashboard de referências'],
        };

        setStats(mockStats);
        setTier(mockTier);
        setReferralLink('https://plantayraizmed.manus.space/register?ref=ABC12345');
        setReferralCode('ABC12345');
      } catch (error) {
        console.error('Erro ao buscar dados de referência:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchReferralData();
  }, []);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(referralLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShareLink = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Programa de Referência Planta & Raiz',
        text: 'Ganhe recompensas indicando colegas médicos!',
        url: referralLink,
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-500 mx-auto mb-2"></div>
          <p className="text-gray-400">Carregando programa de referência...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full space-y-6">
      {/* HEADER */}
      <div>
        <h2 className="text-3xl font-bold text-white mb-2">Programa de Referência</h2>
        <p className="text-gray-400">Ganhe recompensas indicando novos médicos e profissionais</p>
      </div>

      {/* TIER ATUAL */}
      {tier && (
        <Card className="bg-gradient-to-r from-purple-900/20 to-blue-900/20 border-purple-500/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="w-5 h-5 text-yellow-500" />
              Seu Tier: {tier.tier.toUpperCase()}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-400">Recompensa por Referência</p>
                <p className="text-2xl font-bold text-green-500">{tier.rewardPercentage}%</p>
              </div>
              <div>
                <p className="text-sm text-gray-400">Bônus de Tier</p>
                <p className="text-2xl font-bold text-blue-500">+{tier.bonusPercentage}%</p>
              </div>
            </div>
            <div className="mt-4 pt-4 border-t border-gray-700">
              <p className="text-sm text-gray-400 mb-2">Benefícios:</p>
              <ul className="space-y-1">
                {tier.features.map((feature, idx) => (
                  <li key={idx} className="text-sm text-gray-300 flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          </CardContent>
        </Card>
      )}

      {/* LINK DE REFERÊNCIA */}
      <Card className="bg-gray-900 border-gray-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Share2 className="w-5 h-5" />
            Seu Link de Referência
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="bg-gray-800 rounded-lg p-4 flex items-center justify-between">
              <div className="flex-1">
                <p className="text-sm text-gray-400 mb-1">Código</p>
                <p className="text-lg font-mono font-bold text-green-500">{referralCode}</p>
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={handleCopyLink}
                className="ml-2"
              >
                <Copy className="w-4 h-4 mr-1" />
                {copied ? 'Copiado!' : 'Copiar'}
              </Button>
            </div>

            <div className="bg-gray-800 rounded-lg p-4">
              <p className="text-sm text-gray-400 mb-2">Link Completo</p>
              <p className="text-sm text-gray-300 break-all font-mono">{referralLink}</p>
            </div>

            <Button
              onClick={handleShareLink}
              className="w-full bg-green-600 hover:bg-green-700"
            >
              <Share2 className="w-4 h-4 mr-2" />
              Compartilhar Link
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* ESTATÍSTICAS */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="bg-gray-900 border-gray-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-400 flex items-center gap-2">
                <Users className="w-4 h-4" />
                Total de Referências
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-500">{stats.totalReferrals}</div>
              <p className="text-xs text-gray-500 mt-1">{stats.successfulReferrals} bem-sucedidas</p>
            </CardContent>
          </Card>

          <Card className="bg-gray-900 border-gray-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-400 flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Taxa de Conversão
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-500">{stats.conversionRate.toFixed(1)}%</div>
              <p className="text-xs text-gray-500 mt-1">Cliques convertidos</p>
            </CardContent>
          </Card>

          <Card className="bg-gray-900 border-gray-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-400 flex items-center gap-2">
                <DollarSign className="w-4 h-4" />
                Recompensas Pagas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-500">R$ {stats.paidRewards.toLocaleString('pt-BR')}</div>
              <p className="text-xs text-gray-500 mt-1">Já recebidas</p>
            </CardContent>
          </Card>

          <Card className="bg-gray-900 border-gray-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-400 flex items-center gap-2">
                <DollarSign className="w-4 h-4" />
                Recompensas Pendentes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-yellow-500">R$ {stats.pendingRewards.toLocaleString('pt-BR')}</div>
              <p className="text-xs text-gray-500 mt-1">Aguardando aprovação</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* COMO FUNCIONA */}
      <Card className="bg-gray-900 border-gray-700">
        <CardHeader>
          <CardTitle>Como Funciona</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-8 w-8 rounded-full bg-green-500 text-white font-bold">
                  1
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-white">Compartilhe seu link</h4>
                <p className="text-sm text-gray-400">Envie seu código de referência para colegas médicos</p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-8 w-8 rounded-full bg-green-500 text-white font-bold">
                  2
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-white">Eles se registram</h4>
                <p className="text-sm text-gray-400">Novos médicos usam seu código ao se cadastrar</p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-8 w-8 rounded-full bg-green-500 text-white font-bold">
                  3
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-white">Receba recompensas</h4>
                <p className="text-sm text-gray-400">Ganhe R$ 100 + bônus por cada referência bem-sucedida</p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-8 w-8 rounded-full bg-green-500 text-white font-bold">
                  4
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-white">Suba de tier</h4>
                <p className="text-sm text-gray-400">Quanto mais referências, maiores as recompensas</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* TIERS DISPONÍVEIS */}
      <Card className="bg-gray-900 border-gray-700">
        <CardHeader>
          <CardTitle>Tiers de Referência</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[
              { tier: 'bronze', min: 0, max: 4, reward: 5, bonus: 0 },
              { tier: 'silver', min: 5, max: 14, reward: 7, bonus: 2 },
              { tier: 'gold', min: 15, max: 49, reward: 10, bonus: 5 },
              { tier: 'platinum', min: 50, max: '∞', reward: 15, bonus: 10 },
            ].map((t) => (
              <div
                key={t.tier}
                className={`p-4 rounded-lg border ${
                  tier?.tier === t.tier
                    ? 'bg-green-900/20 border-green-500'
                    : 'bg-gray-800 border-gray-700'
                }`}
              >
                <h4 className="font-bold text-white capitalize mb-2">{t.tier}</h4>
                <p className="text-xs text-gray-400 mb-3">
                  {t.min} - {t.max} referências
                </p>
                <div className="space-y-1">
                  <p className="text-sm text-gray-300">
                    <span className="text-green-500 font-bold">{t.reward}%</span> recompensa
                  </p>
                  <p className="text-sm text-gray-300">
                    <span className="text-blue-500 font-bold">+{t.bonus}%</span> bônus
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ReferralProgramComponent;
