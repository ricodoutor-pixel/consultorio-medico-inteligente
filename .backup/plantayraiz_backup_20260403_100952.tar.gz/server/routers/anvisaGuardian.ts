import { router, protectedProcedure } from "../_core/trpc";
import { z } from "zod";
import { AnvisaGuardianService } from "../services/AnvisaGuardianService";

export const anvisaGuardianRouter = router({
  /**
   * Validar prescrição
   */
  validatePrescription: protectedProcedure
    .input(
      z.object({
        prescriptionId: z.string(),
        doctorCRM: z.string(),
        patientCPF: z.string(),
        medicineANVISA: z.string(),
        dosage: z.string(),
        duration: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      return await AnvisaGuardianService.validatePrescription(
        input.prescriptionId,
        input.doctorCRM,
        input.patientCPF,
        input.medicineANVISA,
        input.dosage,
        input.duration
      );
    }),

  /**
   * Gerar relatório de conformidade para médico
   */
  generateDoctorReport: protectedProcedure
    .input(
      z.object({
        doctorId: z.string(),
        doctorCRM: z.string(),
        icpBrasilCertificate: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      return await AnvisaGuardianService.generateDoctorComplianceReport(
        input.doctorId,
        input.doctorCRM,
        input.icpBrasilCertificate
      );
    }),

  /**
   * Gerar relatório de conformidade para lojista
   */
  generateShopkeeperReport: protectedProcedure
    .input(
      z.object({
        shopkeeperId: z.string(),
        cnpj: z.string(),
        registrationNumber: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      return await AnvisaGuardianService.generateShopkeeperComplianceReport(
        input.shopkeeperId,
        input.cnpj,
        input.registrationNumber
      );
    }),

  /**
   * Obter histórico de prescrições
   */
  getPrescriptionHistory: protectedProcedure
    .input(z.object({ doctorCRM: z.string() }))
    .query(async ({ input }) => {
      return await AnvisaGuardianService.getPrescriptionHistory(input.doctorCRM);
    }),

  /**
   * Obter relatórios de conformidade
   */
  getComplianceReports: protectedProcedure
    .input(z.object({ entityId: z.string() }))
    .query(async ({ input }) => {
      return await AnvisaGuardianService.getComplianceReports(input.entityId);
    }),

  /**
   * Obter estatísticas de conformidade
   */
  getStats: protectedProcedure.query(async () => {
    return await AnvisaGuardianService.getComplianceStats();
  }),
});
