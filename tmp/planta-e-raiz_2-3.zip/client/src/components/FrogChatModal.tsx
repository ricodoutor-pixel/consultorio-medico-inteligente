import React, { useState, useRef, useEffect } from 'react';
import { X, Send, MessageCircle } from 'lucide-react';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

interface FrogChatModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const FrogChatModal: React.FC<FrogChatModalProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'Olá! 🐸 Sou o Sapo Verde, assistente de IA da Planta & Raiz. Como posso ajudar você hoje?',
      sender: 'ai',
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const aiResponses: { [key: string]: string } = {
    agendamento: 'Para agendar uma consulta, clique em "Agendar Consulta" na página inicial. Você passará por uma pré-entrevista com IA que leva cerca de 5 minutos.',
    prescrição: 'Nossas prescrições digitais são certificadas ICP-Brasil e conformes com a ANVISA. Você recebe um código de validação para usar na farmácia.',
    medicamentos: 'Após sua consulta, você pode comprar medicamentos diretamente em nosso marketplace integrado com pagamento via PIX ou cartão.',
    profissionais: 'Temos 500+ profissionais verificados especializados em cannabis medicinal. Você pode filtrar por especialidade, idioma e preço.',
    segurança: 'Operamos com conformidade LGPD, ANVISA, CFM e ICP-Brasil. Todos os dados são criptografados e sua privacidade é garantida.',
    default: 'Ótima pergunta! 🤔 Você pode explorar nossos serviços de telemedicina, marketplace e prescrições digitais. Qual desses temas te interessa?',
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    // Simular delay de resposta da IA
    setTimeout(() => {
      const lowerInput = inputValue.toLowerCase();
      let aiResponse = aiResponses.default;

      if (lowerInput.includes('agend')) aiResponse = aiResponses.agendamento;
      else if (lowerInput.includes('prescr')) aiResponse = aiResponses.prescrição;
      else if (lowerInput.includes('medicam')) aiResponse = aiResponses.medicamentos;
      else if (lowerInput.includes('profissional')) aiResponse = aiResponses.profissionais;
      else if (lowerInput.includes('segur') || lowerInput.includes('privac')) aiResponse = aiResponses.segurança;

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: aiResponse,
        sender: 'ai',
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, aiMessage]);
      setIsLoading(false);
    }, 800);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="w-full max-w-md h-96 bg-gradient-to-b from-slate-900 to-slate-950 rounded-2xl shadow-2xl border border-green-500/30 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 border-b border-green-500/30 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="text-2xl">🐸</div>
            <div>
              <h3 className="font-bold text-white">Sapo Verde</h3>
              <p className="text-xs text-green-400">Assistente de IA</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-xs px-4 py-2 rounded-lg ${
                  message.sender === 'user'
                    ? 'bg-green-500/30 border border-green-500/50 text-white'
                    : 'bg-slate-800 border border-green-500/20 text-gray-200'
                }`}
              >
                <p className="text-sm leading-relaxed">{message.text}</p>
                <p className="text-xs text-gray-400 mt-1">
                  {message.timestamp.toLocaleTimeString('pt-BR', {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </p>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-slate-800 border border-green-500/20 px-4 py-2 rounded-lg">
                <div className="flex gap-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="border-t border-green-500/20 bg-slate-900/50 p-4">
          <div className="flex gap-2">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Digite sua pergunta..."
              className="flex-1 bg-slate-800 border border-green-500/30 rounded-lg px-3 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-green-500/60 transition-colors text-sm"
            />
            <button
              onClick={handleSendMessage}
              disabled={!inputValue.trim() || isLoading}
              className="bg-gradient-to-r from-green-500 to-emerald-500 text-white p-2 rounded-lg hover:from-green-600 hover:to-emerald-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FrogChatModal;
