import { ExpoConfig, ConfigContext } from "@expo/config";

export default ({ config }: ConfigContext): ExpoConfig => ({
  ...config,
  name: "Planta & Raiz",
  slug: "planta-raiz",
  version: "1.0.0",
  orientation: "portrait",
  icon: "./assets/icon.png",
  userInterfaceStyle: "dark",
  splash: {
    image: "./assets/splash.png",
    resizeMode: "contain",
    backgroundColor: "#1a1a1a",
  },
  assetBundlePatterns: ["**/*"],
  ios: {
    supportsTabletMode: true,
    bundleIdentifier: "com.plantaraiz.app",
    buildNumber: "1",
    infoPlist: {
      NSFaceIDUsageDescription: "Usamos Face ID para autenticação segura",
      NSBiometricsUsageDescription: "Usamos biometria para sua segurança",
      NSCameraUsageDescription: "Câmera para receitas digitais",
      NSPhotoLibraryUsageDescription: "Fotos para receitas digitais",
    },
  },
  android: {
    adaptiveIcon: {
      foregroundImage: "./assets/adaptive-icon.png",
      backgroundColor: "#1a1a1a",
    },
    package: "com.plantaraiz.app",
    versionCode: 1,
    permissions: [
      "android.permission.CAMERA",
      "android.permission.READ_EXTERNAL_STORAGE",
      "android.permission.WRITE_EXTERNAL_STORAGE",
      "android.permission.BIOMETRIC",
      "android.permission.USE_BIOMETRIC",
    ],
  },
  web: {
    favicon: "./assets/favicon.png",
  },
  plugins: [
    [
      "expo-notifications",
      {
        icon: "./assets/notification-icon.png",
        color: "#00B050",
      },
    ],
    [
      "expo-local-authentication",
      {
        faceIDPermission: "Usamos Face ID para autenticação segura",
      },
    ],
    [
      "expo-camera",
      {
        cameraPermission: "Câmera para receitas digitais",
        microphonePermission: "Microfone para vídeo consultas",
      },
    ],
  ],
  extra: {
    apiUrl: process.env.EXPO_PUBLIC_API_URL || "https://api.plantaraiz.com.br",
    appId: process.env.EXPO_PUBLIC_APP_ID,
    oauthUrl: process.env.EXPO_PUBLIC_OAUTH_URL,
  },
});
