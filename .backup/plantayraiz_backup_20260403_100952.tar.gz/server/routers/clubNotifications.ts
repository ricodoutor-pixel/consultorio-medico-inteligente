import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import { db } from "../db";
import { clubNotifications, users } from "../../drizzle/schema";
import { eq, and, desc, sql } from "drizzle-orm";

export const clubNotificationsRouter = router({
  // Get unread notifications count
  getUnreadCount: protectedProcedure.query(async ({ ctx }) => {
    const userId = ctx.user?.id;
    if (!userId) return 0;

    const result = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(clubNotifications)
      .where(and(eq(clubNotifications.userId, userId), eq(clubNotifications.isRead, 0)));

    return result[0]?.count || 0;
  }),

  // Get all notifications for current user
  getNotifications: protectedProcedure
    .input(z.object({ limit: z.number().default(20), offset: z.number().default(0) }).optional())
    .query(async ({ input, ctx }) => {
      const userId = ctx.user?.id;
      if (!userId) return [];

      const limit = input?.limit || 20;
      const offset = input?.offset || 0;

      const notifications = await db
        .select({
          id: clubNotifications.id,
          userId: clubNotifications.userId,
          postId: clubNotifications.postId,
          type: clubNotifications.type,
          title: clubNotifications.title,
          message: clubNotifications.message,
          isRead: clubNotifications.isRead,
          actionUrl: clubNotifications.actionUrl,
          createdAt: clubNotifications.createdAt,
          triggeredByUserName: users.name,
          triggeredByUserEmail: users.email,
        })
        .from(clubNotifications)
        .leftJoin(users, eq(clubNotifications.triggeredByUserId, users.id))
        .where(eq(clubNotifications.userId, userId))
        .orderBy(desc(clubNotifications.createdAt))
        .limit(limit)
        .offset(offset);

      return notifications;
    }),

  // Mark notification as read
  markAsRead: protectedProcedure
    .input(z.object({ notificationId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const userId = ctx.user?.id;
      if (!userId) throw new Error("User not authenticated");

      const notification = await db
        .select()
        .from(clubNotifications)
        .where(eq(clubNotifications.id, input.notificationId));

      if (notification.length === 0 || notification[0].userId !== userId) {
        throw new Error("Notification not found or not authorized");
      }

      await db
        .update(clubNotifications)
        .set({ isRead: 1 })
        .where(eq(clubNotifications.id, input.notificationId));

      return { success: true };
    }),

  // Mark all notifications as read
  markAllAsRead: protectedProcedure.mutation(async ({ ctx }) => {
    const userId = ctx.user?.id;
    if (!userId) throw new Error("User not authenticated");

    await db
      .update(clubNotifications)
      .set({ isRead: 1 })
      .where(and(eq(clubNotifications.userId, userId), eq(clubNotifications.isRead, 0)));

    return { success: true };
  }),

  // Delete notification
  deleteNotification: protectedProcedure
    .input(z.object({ notificationId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const userId = ctx.user?.id;
      if (!userId) throw new Error("User not authenticated");

      const notification = await db
        .select()
        .from(clubNotifications)
        .where(eq(clubNotifications.id, input.notificationId));

      if (notification.length === 0 || notification[0].userId !== userId) {
        throw new Error("Notification not found or not authorized");
      }

      await db.delete(clubNotifications).where(eq(clubNotifications.id, input.notificationId));

      return { success: true };
    }),

  // Create notification (internal use)
  createNotification: protectedProcedure
    .input(
      z.object({
        userId: z.number(),
        postId: z.number(),
        triggeredByUserId: z.number(),
        type: z.enum(["comment", "like", "reply"]),
        title: z.string(),
        message: z.string(),
        actionUrl: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const result = await db.insert(clubNotifications).values({
        userId: input.userId,
        postId: input.postId,
        triggeredByUserId: input.triggeredByUserId,
        type: input.type,
        title: input.title,
        message: input.message,
        actionUrl: input.actionUrl,
        isRead: 0,
      });

      return { success: true, notificationId: result.insertId };
    }),
});
