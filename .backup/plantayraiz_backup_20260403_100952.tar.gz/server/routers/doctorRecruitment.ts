import { router, protectedProcedure, adminProcedure } from '../_core/trpc';
import { z } from 'zod';
import { doctorRecruitmentService } from '../services/DoctorRecruitmentService';

export const doctorRecruitmentRouter = router({
  /**
   * Submit doctor application
   */
  submitApplication: protectedProcedure
    .input(
      z.object({
        fullName: z.string().min(3),
        crm: z.string().min(5),
        crmState: z.string().length(2),
        specialty: z.string(),
        yearsOfExperience: z.number().min(0),
        icpBrasilCertificate: z.string(),
        icpBrasilCertificateExpiry: z.string(),
        bankAccount: z.object({
          bank: z.string(),
          accountType: z.string(),
          accountNumber: z.string(),
        }),
        documents: z.object({
          crmCertificate: z.string(),
          identityDocument: z.string(),
          addressProof: z.string(),
          icpBrasilCertificate: z.string(),
        }),
      })
    )
    .mutation(({ input, ctx }) => {
      const application = doctorRecruitmentService.submitApplication(
        ctx.user.email || '',
        input.fullName,
        input.crm,
        input.crmState,
        input.specialty,
        input.yearsOfExperience,
        input.icpBrasilCertificate,
        input.icpBrasilCertificateExpiry,
        input.bankAccount,
        input.documents
      );

      return {
        success: true,
        data: application,
      };
    }),

  /**
   * Get application by ID
   */
  getApplication: protectedProcedure
    .input(
      z.object({
        applicationId: z.string(),
      })
    )
    .query(({ input }) => {
      const application = doctorRecruitmentService.getApplication(input.applicationId);

      return {
        success: !!application,
        data: application,
      };
    }),

  /**
   * Get all applications (admin only)
   */
  getAllApplications: adminProcedure
    .input(
      z.object({
        status: z.string().optional(),
      })
    )
    .query(({ input }) => {
      const applications = doctorRecruitmentService.getAllApplications(input.status);

      return {
        success: true,
        data: applications,
      };
    }),

  /**
   * Review application (admin only)
   */
  reviewApplication: adminProcedure
    .input(
      z.object({
        applicationId: z.string(),
        approved: z.boolean(),
        notes: z.string().optional(),
      })
    )
    .mutation(({ input, ctx }) => {
      const application = doctorRecruitmentService.reviewApplication(
        input.applicationId,
        input.approved,
        ctx.user.id,
        input.notes
      );

      return {
        success: !!application,
        data: application,
      };
    }),

  /**
   * Get pending applications (admin only)
   */
  getPendingApplications: adminProcedure.query(() => {
    const applications = doctorRecruitmentService.getPendingApplications();

    return {
      success: true,
      data: applications,
    };
  }),

  /**
   * Get approved applications
   */
  getApprovedApplications: protectedProcedure.query(() => {
    const applications = doctorRecruitmentService.getApprovedApplications();

    return {
      success: true,
      data: applications,
    };
  }),

  /**
   * Get recruitment statistics (admin only)
   */
  getStats: adminProcedure.query(() => {
    const stats = doctorRecruitmentService.getStats();

    return {
      success: true,
      data: stats,
    };
  }),

  /**
   * Get applications by specialty
   */
  getApplicationsBySpecialty: adminProcedure
    .input(
      z.object({
        specialty: z.string(),
      })
    )
    .query(({ input }) => {
      const applications = doctorRecruitmentService.getApplicationsBySpecialty(input.specialty);

      return {
        success: true,
        data: applications,
      };
    }),

  /**
   * Get applications by state
   */
  getApplicationsByState: adminProcedure
    .input(
      z.object({
        state: z.string(),
      })
    )
    .query(({ input }) => {
      const applications = doctorRecruitmentService.getApplicationsByState(input.state);

      return {
        success: true,
        data: applications,
      };
    }),

  /**
   * Export approved doctors list (admin only)
   */
  exportApprovedDoctors: adminProcedure.query(() => {
    const doctors = doctorRecruitmentService.exportApprovedDoctors();

    return {
      success: true,
      data: doctors,
    };
  }),
});
