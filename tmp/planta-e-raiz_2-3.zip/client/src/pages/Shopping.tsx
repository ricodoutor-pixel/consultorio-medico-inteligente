import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ShoppingCart, Star, Truck, Shield, Search } from 'lucide-react';

const products = [
  {
    id: 1,
    name: 'Óleo CBD 10ml',
    category: 'Óleos',
    price: 89.90,
    originalPrice: 129.90,
    rating: 4.8,
    reviews: 234,
    image: '💧',
    seller: 'Farmácia Medicinal Plus',
    shipping: 'Frete Grátis',
    stock: 45,
    description: 'Óleo de CBD puro, 500mg, certificado ANVISA',
    benefits: ['Ansiedade', 'Insônia', 'Dor Crônica'],
  },
  {
    id: 2,
    name: 'Creme Cannabis 50g',
    category: 'Tópicos',
    price: 59.90,
    originalPrice: 89.90,
    rating: 4.7,
    reviews: 156,
    image: '🧴',
    seller: 'Produtor Autorizado ANVISA',
    shipping: 'Frete Grátis',
    stock: 28,
    description: 'Creme tópico com cannabis medicinal',
    benefits: ['Dor Muscular', 'Inflamação', 'Dermatite'],
  },
  {
    id: 3,
    name: 'Jujuba Cannabis 30un',
    category: 'Comestíveis',
    price: 45.90,
    originalPrice: 65.90,
    rating: 4.6,
    reviews: 89,
    image: '🍬',
    seller: 'Produtor Artesanal',
    shipping: 'Frete Grátis',
    stock: 67,
    description: 'Jujubas de cannabis medicinal, sabor natural',
    benefits: ['Ansiedade', 'Relaxamento', 'Sono'],
  },
  {
    id: 4,
    name: 'Softgel THC+CBD 30caps',
    category: 'Cápsulas',
    price: 79.90,
    originalPrice: 119.90,
    rating: 4.9,
    reviews: 312,
    image: '💊',
    seller: 'Laboratório Certificado',
    shipping: 'Frete Grátis',
    stock: 52,
    description: 'Cápsulas com proporção balanceada de THC e CBD',
    benefits: ['Dor', 'Epilepsia', 'TDAH'],
  },
  {
    id: 5,
    name: 'Chá Cannabis Premium 50g',
    category: 'Bebidas',
    price: 34.90,
    originalPrice: 49.90,
    rating: 4.5,
    reviews: 78,
    image: '🍵',
    seller: 'Produtor Orgânico',
    shipping: 'Frete Grátis',
    stock: 91,
    description: 'Chá de cannabis medicinal, 100% orgânico',
    benefits: ['Relaxamento', 'Digestão', 'Sono'],
  },
  {
    id: 6,
    name: 'Tintura Cannabis 30ml',
    category: 'Tinturas',
    price: 69.90,
    originalPrice: 99.90,
    rating: 4.7,
    reviews: 145,
    image: '🧪',
    seller: 'Farmácia Especializada',
    shipping: 'Frete Grátis',
    stock: 38,
    description: 'Tintura alcoólica de cannabis medicinal',
    benefits: ['Ansiedade', 'Inflamação', 'Dor'],
  },
];

export default function Shopping() {
  const [cart, setCart] = useState<number[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const categories = ['Óleos', 'Tópicos', 'Comestíveis', 'Cápsulas', 'Bebidas', 'Tinturas'];

  const filteredProducts = products.filter((product) => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = !selectedCategory || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const addToCart = (productId: number) => {
    setCart([...cart, productId]);
  };

  const cartTotal = cart.reduce((sum, productId) => {
    const product = products.find((p) => p.id === productId);
    return sum + (product?.price || 0);
  }, 0);

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-background/80 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="space-y-2">
            <h1 className="text-4xl font-black text-yellow-400">Shopping Cannabis</h1>
            <p className="text-muted-foreground">Produtos autorizados ANVISA com frete grátis</p>
          </div>
          <div className="relative">
            <ShoppingCart className="h-8 w-8 text-yellow-400" />
            {cart.length > 0 && (
              <Badge className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full">
                {cart.length}
              </Badge>
            )}
          </div>
        </div>

        {/* Search and Filter */}
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
            <input
              type="text"
              placeholder="Buscar produtos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-background/50 border border-yellow-500/20 rounded-lg text-white placeholder-muted-foreground focus:outline-none focus:border-yellow-500"
            />
          </div>

          <div className="flex flex-wrap gap-2">
            <Button
              onClick={() => setSelectedCategory(null)}
              className={`${
                selectedCategory === null
                  ? 'bg-yellow-500 text-black hover:bg-yellow-600'
                  : 'bg-background/50 text-yellow-400 hover:bg-background/70'
              }`}
            >
              Todos
            </Button>
            {categories.map((category) => (
              <Button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`${
                  selectedCategory === category
                    ? 'bg-yellow-500 text-black hover:bg-yellow-600'
                    : 'bg-background/50 text-yellow-400 hover:bg-background/70'
                }`}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid md:grid-cols-3 gap-4">
          {filteredProducts.map((product) => (
            <Card key={product.id} className="bg-card/50 border-yellow-500/20 rounded-2xl overflow-hidden hover:border-yellow-500/50 transition-all">
              <CardContent className="p-4">
                <div className="text-5xl mb-3">{product.image}</div>

                <div className="space-y-2 mb-3">
                  <p className="font-bold text-yellow-400">{product.name}</p>
                  <p className="text-xs text-muted-foreground">{product.seller}</p>

                  <div className="flex items-center gap-2">
                    <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                    <span className="text-sm font-semibold">{product.rating}</span>
                    <span className="text-xs text-muted-foreground">({product.reviews})</span>
                  </div>
                </div>

                <div className="space-y-2 mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl font-black text-green-400">R$ {product.price.toFixed(2)}</span>
                    <span className="text-sm text-muted-foreground line-through">R$ {product.originalPrice.toFixed(2)}</span>
                  </div>

                  <div className="flex items-center gap-2 text-xs text-green-400">
                    <Truck className="h-4 w-4" />
                    {product.shipping}
                  </div>

                  <div className="flex items-center gap-2 text-xs text-yellow-400">
                    <Shield className="h-4 w-4" />
                    ANVISA Certificado
                  </div>
                </div>

                <div className="mb-3">
                  <p className="text-xs text-muted-foreground mb-2">Benefícios:</p>
                  <div className="flex flex-wrap gap-1">
                    {product.benefits.map((benefit) => (
                      <Badge key={benefit} className="bg-yellow-500/20 text-yellow-400 text-xs">
                        {benefit}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={() => addToCart(product.id)}
                    className="flex-1 bg-yellow-500 hover:bg-yellow-600 text-black font-bold"
                  >
                    <ShoppingCart className="h-4 w-4 mr-2" />
                    Adicionar
                  </Button>
                </div>

                <p className="text-xs text-muted-foreground mt-2">{product.stock} em estoque</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Cart Summary */}
        {cart.length > 0 && (
          <Card className="bg-card/50 border-yellow-500/20 rounded-2xl sticky bottom-6">
            <CardContent className="p-6 flex items-center justify-between">
              <div>
                <p className="text-muted-foreground">Total do Carrinho</p>
                <p className="text-3xl font-black text-green-400">R$ {cartTotal.toFixed(2)}</p>
              </div>
              <div className="flex gap-3">
                <Button className="bg-background/50 text-yellow-400 hover:bg-background/70">
                  Continuar Comprando
                </Button>
                <Button className="bg-green-500 hover:bg-green-600 text-white font-bold">
                  Ir para Checkout
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
