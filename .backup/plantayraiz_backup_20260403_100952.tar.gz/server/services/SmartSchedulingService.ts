import crypto from 'crypto';

interface Doctor {
  id: string;
  name: string;
  specialty: string;
  maxConsultationsPerDay: number;
  workingHours: {
    start: number; // hora em formato 24h
    end: number;
  };
  breakTimes: Array<{ start: number; end: number }>;
  consultationDuration: number; // em minutos
  unavailableDates: string[]; // datas em formato YYYY-MM-DD
}

interface Appointment {
  id: string;
  consultationId: string;
  doctorId: string;
  patientId: string;
  patientName: string;
  patientPhone: string;
  specialty: string;
  scheduledTime: number;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  createdAt: number;
  notificationsSent: number;
}

// Armazenamento em memória (em produção usar banco de dados)
const doctors = new Map<string, Doctor>();
const appointments: Appointment[] = [];
const appointmentHistory: Appointment[] = [];

/**
 * Registrar médico no sistema de agendamento
 */
export function registerDoctor(doctor: Doctor): boolean {
  try {
    doctors.set(doctor.id, doctor);
    console.log(`[SmartScheduling] Doctor registered: ${doctor.name}`);
    return true;
  } catch (error) {
    console.error('[SmartScheduling] Error registering doctor:', error);
    return false;
  }
}

/**
 * Obter horários disponíveis para um médico em uma data
 */
export function getAvailableSlots(
  doctorId: string,
  date: string, // YYYY-MM-DD
  specialty?: string
): number[] {
  const doctor = doctors.get(doctorId);
  if (!doctor) return [];

  // Verificar se médico tem essa especialidade
  if (specialty && doctor.specialty !== specialty) return [];

  // Verificar se data está indisponível
  if (doctor.unavailableDates.includes(date)) return [];

  const slots: number[] = [];
  const dateObj = new Date(`${date}T${doctor.workingHours.start.toString().padStart(2, '0')}:00:00`);
  const endTime = new Date(`${date}T${doctor.workingHours.end.toString().padStart(2, '0')}:00:00`);

  // Gerar slots de 30 minutos
  while (dateObj < endTime) {
    const slotTime = dateObj.getTime();
    const slotHour = dateObj.getHours();
    const slotMinute = dateObj.getMinutes();

    // Verificar se está em horário de pausa
    const inBreak = doctor.breakTimes.some(
      (breakTime) =>
        slotHour >= breakTime.start && slotHour < breakTime.end
    );

    // Verificar se slot já está ocupado
    const slotOccupied = appointments.some(
      (apt) =>
        apt.doctorId === doctorId &&
        apt.status !== 'cancelled' &&
        apt.scheduledTime === slotTime
    );

    if (!inBreak && !slotOccupied) {
      slots.push(slotTime);
    }

    dateObj.setMinutes(dateObj.getMinutes() + 30);
  }

  return slots;
}

/**
 * Encontrar melhor médico disponível para uma especialidade
 */
export function findBestAvailableDoctor(
  specialty: string,
  preferredDate: string
): { doctorId: string; availableSlots: number[] } | null {
  let bestDoctor: { doctorId: string; availableSlots: number[] } | null = null;
  let maxSlots = 0;

  for (const [doctorId, doctor] of doctors.entries()) {
    if (doctor.specialty === specialty) {
      const slots = getAvailableSlots(doctorId, preferredDate, specialty);
      if (slots.length > maxSlots) {
        maxSlots = slots.length;
        bestDoctor = { doctorId, availableSlots: slots };
      }
    }
  }

  return bestDoctor;
}

/**
 * Agendar consulta
 */
export function scheduleAppointment(
  doctorId: string,
  patientId: string,
  patientName: string,
  patientPhone: string,
  specialty: string,
  scheduledTime: number
): Appointment | null {
  try {
    const doctor = doctors.get(doctorId);
    if (!doctor) return null;

    // Verificar se horário está disponível
    const slots = getAvailableSlots(doctorId, new Date(scheduledTime).toISOString().split('T')[0]);
    if (!slots.includes(scheduledTime)) return null;

    const appointment: Appointment = {
      id: crypto.randomUUID(),
      consultationId: `CONS-${Date.now()}`,
      doctorId,
      patientId,
      patientName,
      patientPhone,
      specialty,
      scheduledTime,
      status: 'pending',
      createdAt: Date.now(),
      notificationsSent: 0,
    };

    appointments.push(appointment);
    return appointment;
  } catch (error) {
    console.error('[SmartScheduling] Error scheduling appointment:', error);
    return null;
  }
}

/**
 * Confirmar agendamento
 */
export function confirmAppointment(appointmentId: string): boolean {
  const appointment = appointments.find((a) => a.id === appointmentId);
  if (!appointment) return false;

  appointment.status = 'confirmed';
  return true;
}

/**
 * Cancelar agendamento
 */
export function cancelAppointment(appointmentId: string): boolean {
  const appointment = appointments.find((a) => a.id === appointmentId);
  if (!appointment) return false;

  appointment.status = 'cancelled';
  appointmentHistory.push(appointment);
  appointments.splice(appointments.indexOf(appointment), 1);

  return true;
}

/**
 * Obter agendamentos pendentes
 */
export function getPendingAppointments(doctorId?: string): Appointment[] {
  return appointments.filter(
    (a) =>
      a.status === 'pending' &&
      (!doctorId || a.doctorId === doctorId)
  );
}

/**
 * Obter histórico de agendamentos
 */
export function getAppointmentHistory(limit: number = 100): Appointment[] {
  return appointmentHistory.slice(-limit).reverse();
}

/**
 * Obter estatísticas de agendamentos
 */
export function getSchedulingStats() {
  const stats = {
    totalDoctors: doctors.size,
    totalAppointments: appointments.length + appointmentHistory.length,
    pendingAppointments: appointments.filter((a) => a.status === 'pending').length,
    confirmedAppointments: appointments.filter((a) => a.status === 'confirmed').length,
    completedAppointments: appointmentHistory.filter((a) => a.status === 'completed').length,
    cancelledAppointments: appointmentHistory.filter((a) => a.status === 'cancelled').length,
    averageNotificationsPerAppointment: 0,
  };

  if (appointments.length + appointmentHistory.length > 0) {
    const totalNotifications = [...appointments, ...appointmentHistory].reduce(
      (sum, a) => sum + a.notificationsSent,
      0
    );
    stats.averageNotificationsPerAppointment =
      totalNotifications / (appointments.length + appointmentHistory.length);
  }

  return stats;
}

/**
 * Enviar notificação de lembrete
 */
export function sendReminderNotification(appointmentId: string): boolean {
  const appointment = appointments.find((a) => a.id === appointmentId);
  if (!appointment) return false;

  appointment.notificationsSent++;
  console.log(
    `[SmartScheduling] Reminder sent to ${appointment.patientName} for appointment ${appointmentId}`
  );

  return true;
}

export const SmartSchedulingService = {
  registerDoctor,
  getAvailableSlots,
  findBestAvailableDoctor,
  scheduleAppointment,
  confirmAppointment,
  cancelAppointment,
  getPendingAppointments,
  getAppointmentHistory,
  getSchedulingStats,
  sendReminderNotification,
};
