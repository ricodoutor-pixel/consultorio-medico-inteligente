import React, { useState, useRef, useEffect } from 'react';
import { X, Send } from 'lucide-react';

interface Message {
  id: string;
  type: 'user' | 'assistant';
  text: string;
  timestamp: Date;
}

const AIFrogAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'assistant',
      text: 'Olá! 🐸 Sou o Sapo Verde, seu assistente de IA. Posso ajudar?',
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const generateAIResponse = (userInput: string): string => {
    const responses: Record<string, string> = {
      agendamento:
        'Para agendar uma consulta, clique em "Ver Profissionais" e selecione um especialista. Você será guiado através de um processo simples de 3 cliques!',
      medicamento:
        'Temos uma biblioteca de 100+ variedades de cannabis. Cada uma tem análise detalhada de THC/CBD e indicações médicas. Visite nossa Biblioteca!',
      preco:
        'Nossas consultas começam a partir de R$ 49,90. Oferecemos diferentes planos e pacotes para se adequar ao seu orçamento.',
      pagamento:
        'Aceitamos PIX, cartão de crédito e débito. Todos os pagamentos são processados de forma segura através do Mercado Pago.',
      farmacia:
        'Após sua consulta e prescrição, você pode comprar medicamentos direto em nossa plataforma ou em farmácias parceiras.',
      default:
        'Ótima pergunta! Você pode explorar nossa plataforma, agendar uma consulta com um profissional ou conhecer nossas variedades de cannabis. Como posso ajudá-lo especificamente?',
    };

    const lowerInput = userInput.toLowerCase();
    for (const [key, response] of Object.entries(responses)) {
      if (lowerInput.includes(key)) {
        return response;
      }
    }
    return responses.default;
  };

  const handleSendMessage = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      text: inputValue,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        text: generateAIResponse(inputValue),
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, aiResponse]);
      setIsLoading(false);
    }, 1000);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Botão do Sapo */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`
          w-16 h-16 rounded-full flex items-center justify-center
          transition-all duration-300 transform hover:scale-110
          ${
            isOpen
              ? 'bg-gradient-to-br from-green-400 to-green-600 shadow-lg'
              : 'bg-gradient-to-br from-green-500 to-green-700 shadow-lg hover:shadow-xl'
          }
        `}
        title="Assistente de IA - Sapo Verde"
      >
        {isOpen ? (
          <X className="w-8 h-8 text-white" />
        ) : (
          <div className="text-2xl animate-bounce">🐸</div>
        )}
      </button>

      {/* Chat Box */}
      {isOpen && (
        <div
          className={`
            absolute bottom-20 right-0 w-96 h-96 rounded-2xl
            bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900
            border-2 border-green-500 shadow-2xl
            flex flex-col overflow-hidden
            animate-in fade-in slide-in-from-bottom-4 duration-300
          `}
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-green-500 to-green-600 p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-2xl">🐸</span>
              <div>
                <h3 className="text-white font-bold">Sapo Verde</h3>
                <p className="text-green-100 text-xs">Assistente de IA</p>
              </div>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-800">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`
                    max-w-xs px-4 py-2 rounded-lg
                    ${
                      message.type === 'user'
                        ? 'bg-green-600 text-white rounded-br-none'
                        : 'bg-slate-700 text-gray-100 rounded-bl-none border border-green-500'
                    }
                  `}
                >
                  <p className="text-sm">{message.text}</p>
                  <span className="text-xs opacity-70 mt-1 block">
                    {message.timestamp.toLocaleTimeString('pt-BR', {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-slate-700 text-gray-100 px-4 py-2 rounded-lg rounded-bl-none border border-green-500">
                  <div className="flex gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <form onSubmit={handleSendMessage} className="p-4 border-t border-green-500 bg-slate-800">
            <div className="flex gap-2">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Digite sua pergunta..."
                className="
                  flex-1 px-4 py-2 rounded-lg
                  bg-slate-700 text-white placeholder-gray-400
                  border border-green-500 focus:border-green-400
                  focus:outline-none focus:ring-2 focus:ring-green-500/50
                  transition-all
                "
                disabled={isLoading}
              />
              <button
                type="submit"
                disabled={isLoading || !inputValue.trim()}
                className="
                  px-4 py-2 rounded-lg
                  bg-gradient-to-r from-green-500 to-green-600
                  text-white font-semibold
                  hover:from-green-600 hover:to-green-700
                  disabled:opacity-50 disabled:cursor-not-allowed
                  transition-all
                  flex items-center gap-2
                "
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default AIFrogAssistant;
