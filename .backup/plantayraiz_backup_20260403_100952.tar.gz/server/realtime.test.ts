/**
 * Testes Vitest - Sincronização em Tempo Real
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { realtimeSyncService } from './services/RealtimeSync';
import { digitalPrescriptionService } from './services/DigitalPrescriptionService';
import { mercadoPagoWebhookService } from './services/MercadoPagoWebhook';

describe('Realtime Sync Service', () => {
  beforeEach(() => {
    realtimeSyncService.clearHistory();
  });

  it('deve emitir evento de triagem iniciada', (done) => {
    const unsubscribe = realtimeSyncService.subscribe('triage', (event) => {
      expect(event.type).toBe('triage');
      expect(event.data.status).toBe('started');
      unsubscribe();
      done();
    });

    realtimeSyncService.emitTriageStarted({
      patientName: 'João Silva',
      triageId: 'TRIAGE-001',
    });
  });

  it('deve emitir evento de prescrição criada', (done) => {
    const unsubscribe = realtimeSyncService.subscribe('prescription', (event) => {
      expect(event.type).toBe('prescription');
      expect(event.data.status).toBe('created');
      unsubscribe();
      done();
    });

    realtimeSyncService.emitPrescriptionCreated({
      prescriptionId: 'PRESC-001',
      patientName: 'Maria Santos',
    });
  });

  it('deve emitir evento de pagamento aprovado', (done) => {
    const unsubscribe = realtimeSyncService.subscribe('payment', (event) => {
      expect(event.type).toBe('payment');
      expect(event.data.status).toBe('approved');
      unsubscribe();
      done();
    });

    realtimeSyncService.emitPaymentApproved({
      paymentId: 'PAY-001',
      amount: 13000,
    });
  });

  it('deve manter histórico de eventos', () => {
    realtimeSyncService.emitTriageStarted({ patientName: 'João' });
    realtimeSyncService.emitPrescriptionCreated({ prescriptionId: 'PRESC-001' });
    realtimeSyncService.emitPaymentApproved({ paymentId: 'PAY-001' });

    const history = realtimeSyncService.getEventHistory();
    expect(history.length).toBe(3);
    expect(history[0].type).toBe('triage');
    expect(history[1].type).toBe('prescription');
    expect(history[2].type).toBe('payment');
  });

  it('deve retornar estatísticas corretas', () => {
    realtimeSyncService.emitTriageStarted({ patientName: 'João' });
    realtimeSyncService.emitTriageCompleted({ patientName: 'João' });
    realtimeSyncService.emitPaymentApproved({ paymentId: 'PAY-001' });

    const stats = realtimeSyncService.getStats();
    expect(stats.totalEvents).toBe(3);
    expect(stats.eventTypes['triage']).toBe(2);
    expect(stats.eventTypes['payment']).toBe(1);
  });
});

describe('Digital Prescription Service', () => {
  it('deve criar prescrição digital', async () => {
    const prescription = await digitalPrescriptionService.createPrescription({
      patientId: 'PAT-001',
      patientName: 'João Silva',
      patientCPF: '123.456.789-00',
      doctorId: 'DR-001',
      doctorName: 'Dr. Edilson Bezerra',
      doctorCRM: '10963',
      medications: [
        {
          name: 'Óleo CBD 10%',
          dosage: '10mg',
          quantity: 1,
          unit: 'frasco',
          frequency: '2x ao dia',
          duration: '30 dias',
        },
      ],
      indication: 'Insônia e ansiedade',
      contraindications: ['Gravidez'],
    });

    expect(prescription.prescriptionId).toBeDefined();
    expect(prescription.anvisaCode).toBeDefined();
    expect(prescription.qrCode).toBeDefined();
    expect(prescription.status).toBe('draft');
    expect(prescription.medications.length).toBe(1);
  });

  it('deve validar prescrição autorizada', async () => {
    const prescription = await digitalPrescriptionService.createPrescription({
      patientId: 'PAT-001',
      patientName: 'João Silva',
      patientCPF: '123.456.789-00',
      doctorId: 'DR-001',
      doctorName: 'Dr. Edilson Bezerra',
      doctorCRM: '10963',
      medications: [
        {
          name: 'Óleo CBD 10%',
          dosage: '10mg',
          quantity: 1,
          unit: 'frasco',
          frequency: '2x ao dia',
          duration: '30 dias',
        },
      ],
      indication: 'Insônia e ansiedade',
      contraindications: [],
    });

    // Assinar prescrição
    const signed = await digitalPrescriptionService.signPrescription(prescription, 'DR-001');
    expect(signed.status).toBe('signed');
    expect(signed.digitalSignature.signature).toBeDefined();

    // Autorizar prescrição
    const authorized = await digitalPrescriptionService.authorizePrescription(signed);
    expect(authorized.status).toBe('authorized');
    expect(authorized.authorizedAt).toBeDefined();

    // Validar prescrição
    const validation = digitalPrescriptionService.validatePrescription(authorized);
    expect(validation.isValid).toBe(true);
    expect(validation.errors.length).toBe(0);
  });

  it('deve gerar relatório de prescrição', async () => {
    const prescription = await digitalPrescriptionService.createPrescription({
      patientId: 'PAT-001',
      patientName: 'João Silva',
      patientCPF: '123.456.789-00',
      doctorId: 'DR-001',
      doctorName: 'Dr. Edilson Bezerra',
      doctorCRM: '10963',
      medications: [
        {
          name: 'Óleo CBD 10%',
          dosage: '10mg',
          quantity: 1,
          unit: 'frasco',
          frequency: '2x ao dia',
          duration: '30 dias',
        },
      ],
      indication: 'Insônia e ansiedade',
      contraindications: ['Gravidez'],
    });

    const report = digitalPrescriptionService.generateReport(prescription);
    expect(report).toContain('PRESCRIÇÃO DIGITAL');
    expect(report).toContain('João Silva');
    expect(report).toContain('Óleo CBD 10%');
    expect(report).toContain(prescription.anvisaCode);
  });
});

describe('Mercado Pago Webhook Service', () => {
  it('deve processar webhook de pagamento aprovado', async () => {
    const payload = {
      id: 'webhook-001',
      type: 'payment' as const,
      action: 'payment.approved' as const,
      data: { id: 'PAY-001' },
    };

    await mercadoPagoWebhookService.processWebhook(payload);

    const payment = mercadoPagoWebhookService.getPayment('PAY-001');
    expect(payment).toBeDefined();
    expect(payment?.status).toBe('approved');
  });

  it('deve processar webhook de pagamento falhado', async () => {
    const payload = {
      id: 'webhook-002',
      type: 'payment' as const,
      action: 'payment.failed' as const,
      data: { id: 'PAY-002' },
    };

    await mercadoPagoWebhookService.processWebhook(payload);

    const payment = mercadoPagoWebhookService.getPayment('PAY-002');
    expect(payment).toBeDefined();
    expect(payment?.status).toBe('failed');
  });

  it('deve listar pagamentos recentes', async () => {
    const payload1 = {
      id: 'webhook-001',
      type: 'payment' as const,
      action: 'payment.approved' as const,
      data: { id: 'PAY-001' },
    };

    const payload2 = {
      id: 'webhook-002',
      type: 'payment' as const,
      action: 'payment.approved' as const,
      data: { id: 'PAY-002' },
    };

    await mercadoPagoWebhookService.processWebhook(payload1);
    await mercadoPagoWebhookService.processWebhook(payload2);

    const payments = mercadoPagoWebhookService.listPayments(10);
    expect(payments.length).toBeGreaterThanOrEqual(2);
  });

  it('deve gerar relatório de pagamentos', async () => {
    const payload = {
      id: 'webhook-001',
      type: 'payment' as const,
      action: 'payment.approved' as const,
      data: { id: 'PAY-001' },
    };

    await mercadoPagoWebhookService.processWebhook(payload);

    const report = mercadoPagoWebhookService.generateReport();
    expect(report).toContain('RELATÓRIO DE PAGAMENTOS');
    expect(report).toContain('Mercado Pago');
  });
});
