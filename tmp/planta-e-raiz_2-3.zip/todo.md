# Planta e Raiz - TODO List

## Banco de Dados e Schema
- [x] Criar tabelas de usuários com campos de perfil
- [x] Criar tabelas de investimentos (planos e posições)
- [x] Criar tabelas de transações (depósitos, saques, rendimentos)
- [x] Criar tabelas de afiliados e comissões
- [x] Criar tabelas de configurações administrativas
- [x] Criar tabelas de notificações

## Integração Mercado Pago
- [ ] Configurar credenciais do Mercado Pago (SEGUNDA ETAPA)
- [ ] Implementar API de pagamentos (SEGUNDA ETAPA)
- [ ] Implementar webhooks para confirmação de pagamentos (SEGUNDA ETAPA)
- [ ] Implementar geração de QR Code PIX (SEGUNDA ETAPA)
- [ ] Implementar processamento de saques (SEGUNDA ETAPA)

## Sistema de Investimentos
- [x] Criar planos de investimento (Bronze, Prata, Ouro, Diamante)
- [x] Implementar cálculo de rendimentos diários
- [ ] Criar job de cron para atualizar rendimentos (PRÓXIMA ETAPA)
- [x] Implementar validação de saldo para investimentos

## Sistema de Afiliados
- [x] Gerar código único por usuário
- [x] Rastrear referidos em múltiplos níveis
- [x] Calcular comissões automáticas
- [x] Criar página de afiliados

## Painel de Usuário
- [x] Dashboard com saldo e investimentos ativos
- [x] Histórico de transações com filtros
- [x] Gráficos de rendimentos
- [x] Seção de depósitos
- [x] Seção de saques
- [x] Seção de afiliados

## Painel Administrativo
- [x] Gerenciamento de usuários
- [x] Aprovação de saques
- [x] Monitoramento de investimentos
- [ ] Configuração de taxas (PRÓXIMA ETAPA)
- [x] Estatísticas globais
- [ ] Relatórios (PRÓXIMA ETAPA)

## Sistema de Notificações
- [ ] Notificações de depósitos (PRÓXIMA ETAPA)
- [ ] Notificações de saques (PRÓXIMA ETAPA)
- [ ] Notificações de rendimentos (PRÓXIMA ETAPA)
- [ ] Notificações de atualizações (PRÓXIMA ETAPA)

## Seção Jurídica
- [ ] Termos de uso
- [ ] Política de privacidade
- [ ] Informações sobre cannabis medicinal

## Testes
- [ ] Testar fluxo de depósito
- [ ] Testar fluxo de saque
- [ ] Testar cálculo de rendimentos
- [ ] Testar sistema de afiliados
- [ ] Testar painel administrativo
- [ ] Testar notificações

## Frontend Pages Criadas
- [x] Home - Landing page premium com apresentação da plataforma
- [x] Dashboard - Painel principal do usuário com métricas
- [x] Invest - Página para criar investimentos
- [x] Referrals - Página de programa de afiliados
- [x] AdminDash - Painel administrativo
- [x] Deposit - Página para fazer depósitos
- [x] Withdraw - Página para solicitar saques

## Backend Routers Criados
- [x] Investment Router - Gerenciar investimentos
- [x] Affiliate Router - Gerenciar afiliados
- [x] Transaction Router - Gerenciar transações
- [x] Admin Router - Funções administrativas


## Redesign UI (Binance/Nu Bank Style)
- [x] Atualizar Home page com design Binance/Nu Bank
- [x] Redesenhar Dashboard com cards premium
- [x] Atualizar página de Investimentos
- [x] Redesenhar página de Afiliados
- [x] Atualizar página de Depósitos
- [x] Redesenhar página de Saques
- [x] Atualizar Painel Administrativo
- [x] Implementar tema com gradientes sofisticados
- [x] Adicionar animações e transições suaves


## Integração de Funcionalidades de Referência
- [x] Criar componente BrandHeader
- [x] Criar componente GrowthChartCard
- [x] Criar componente SpotlightShell com efeito spotlight
- [x] Implementar formulário de login com código de indicação
- [x] Adicionar chat de atendimento flutuante
- [x] Implementar glassmorphism e backdrop blur
- [x] Adicionar mensagem de conformidade ANVISA RDC 327/2019
- [x] Melhorar página de autenticação com novos componentes


## Sistema de Afiliados Avançado (Fase 5)
- [x] Implementar 3 níveis de comissão (20%, 10%, 5%)
- [x] Criar link de convite único por usuário
- [x] Adicionar ranking público dos melhores afiliados
- [x] Dashboard de afiliados com estatísticas
- [x] Gráfico de crescimento de indicados
- [x] Sistema de rastreamento de referências
- [x] Painel de comissões e ganhos


## Paginas Premium Implementadas
- [x] Pagina de Login com formulario e grafico de crescimento
- [x] Home page com video, depoimentos reais e dados de mercado
- [x] Pagina Planos com botao Comprar Cota e modal QR Code PIX
- [x] Carteira com ganhos pessoais, equipe, mapa mundial e graficos
- [x] Painel Administrativo Premium com metricas, usuarios, afiliados e logs
- [x] Reduzir tamanho da janela do video na Home page
- [x] Sistema de afiliados com 3 niveis, link unico e ranking publico

## Status Final - PRONTO PARA PUBLICACAO
- [x] Todas as paginas premium implementadas
- [x] Design Binance/Nu Bank completo
- [x] Sistema de afiliados com 3 niveis
- [x] Painel administrativo premium
- [x] Todos os 10 testes passando
- [x] TypeScript sem erros
- [x] Dev server rodando perfeitamente
- [x] Pronto para publicacao


## Implementacoes Finais - Fase 8
- [x] Integracao Mercado Pago com webhooks para pagamentos e saques
- [x] Cron Job de rendimentos diarios automaticos (1-3% por plano)
- [x] Sistema de notificacoes em tempo real (toast + email)
- [x] Testes de integracao Mercado Pago
- [x] Testes de cron job de rendimentos
- [x] Testes de notificacoes


## Fase 9 - IA e Automação Avançada
- [x] AI Chatbot com pré-entrevista automática
- [x] Extração inteligente de dados do paciente
- [x] Recomendação de especialistas via IA
- [x] Detecção de fraude com machine learning
- [x] Sistema de Reputação com verificação API automática
- [x] Badges e especialização de profissionais
- [x] Analytics em tempo real com previsões IA
- [x] Cálculo de Churn, LTV, CAC com inteligência
- [x] Geração automática de insights de negócio
- [x] A/B Testing framework integrado
- [x] Análise de coortes e funil de conversão


## Status Final - PRONTO PARA PUBLICACAO v2.0
- [x] Plataforma completa com 16 paginas
- [x] Investimentos, Afiliados, Telemedicina, Shopping
- [x] Mercado Pago integrado com webhooks
- [x] IA integrada em toda a plataforma
- [x] 44 testes passando (14 originais + 30 novos testes de IA)
- [x] Design Binance/Nu Bank
- [x] Conformidade ANVISA/LGPD
- [x] PWA ready
- [x] Prompt final completo para Lovable
- [x] Pronto para deploy e publicacao


## Fase 12 - Dashboards de Escritório + Indicação + Alerta Online + COMPLETO
- [x] Criar schema para indicações, comissões e status online
- [x] Criar tRPC routers para indicações e status
- [x] Dashboard Especialista (consultas, receitas, PIX, gráficos)
- [x] Dashboard Farmácia/Produtor (vendas, estoque, edição)
- [x] Página de Indicações com Leaderboard
- [x] Sistema de alerta (bolinha verde/cinza online/offline)
- [x] Sistema de alertas para especialista (usuários online + notificação consulta)
- [x] Biblioteca científica enriquecida com comentários
- [x] Login rápido com email/senha e geolocalização
- [x] Dashboard de usuários online por país/região
- [x] Fluxo completo: Indicação → Consulta → Receita → Shopping
- [x] Pronto para lançamento HOJE

## Fase 11 - Ecossistema Planta & Raiz (Bliss Cannabis DNA)
- [ ] Implementar cores Bliss Cannabis em toda plataforma
- [x] Criar banco de dados com 15 especialistas exemplo (5 de cada especialidade)
- [x] Criar banco de dados com 5 farmácias/produtores com 3 produtos cada
- [ ] Redesenhar homepage com DNA Bliss Cannabis melhorado
- [ ] Criar sistema de marketplace integrado para farmácias/produtores
- [ ] Criar dashboards de escritório para especialistas
- [ ] Criar dashboards de escritório para farmácias/produtores
- [ ] Implementar sistema de indicação premiada com rastreamento
- [ ] Integrar receita digital assinada com validação ANVISA
- [ ] Criar testes e documentação do ecossistema completo

## Fase 13 - Equipe de 5 Agentes Especializados (FINAL)
- [x] Pesquisa de top 10 plataformas de sucesso global
- [x] AGENTE 1 (Médico): Receita digital com assinatura eletrônica
- [x] AGENTE 4 (Jurídico): Página de conformidade ANVISA/LGPD
- [x] AGENTE 3 (E-commerce): Marketplace robusto com logística
- [ ] AGENTE 2 (Engenheiro): Otimização de arquitetura e performance
- [ ] AGENTE 5 (UX/Design): Interface intuitiva e conversão
- [ ] Integração de todas as 12+ funcionalidades premium
- [ ] Testes finais e segurança
- [ ] Deploy e lançamento

## Fase 10 - Catálogo Premium de Cannabis com Fluxo Automatizado
- [x] Criar banco de dados com 100 espécies reais de cannabis
- [x] Buscar imagens reais em APIs (Pexels/Unsplash/Click Cannabis)
- [x] Redesenhar página Library com grid WeedPro (2x2)
- [x] Criar página de detalhes de espécie com avaliações
- [x] Integrar botão "Saiba Mais" → Especialistas
- [x] Integrar fluxo: Especialistas → Pagamento PIX Mercado Pago
- [x] Criar automação: Confirmação PIX → Entrevista IA
- [x] Criar automação: Entrevista IA → Liberação Acesso Especialista
- [x] Integrar redirecionamento: Especialista → Shopping
- [ ] Criar testes para todo o pipeline automatizado
- [x] Documentar 10 sugestões de melhoria

## FASE 14 - CONSTRUÇÃO COMPLETA (ATUAL)
### Páginas Principais (25+)
- [x] Home com hero, stats, features, testimonials, FAQ
- [x] Profissionais com busca e filtros avançados
- [x] Marketplace com categorias e filtros
- [x] Biblioteca de Variedades (100+ cepas)
- [x] Indicações/Afiliados com leaderboard
- [x] Planos & Assinaturas
- [x] Blog/Artigos
- [x] Termos & Políticas
- [x] Suporte & FAQ
- [x] Perfil de Profissional
- [x] Consulta Agendada
- [x] Prontuário Digital
- [x] Prescrições Digitais
- [x] Chat em Tempo Real
- [x] Página de Erro 404
- [x] Página de Manutenção

### Autenticação e Dashboard
- [x] Login/Registro completo
- [x] Dashboard Paciente
- [x] Dashboard Profissional
- [x] Dashboard Vendedor
- [x] Perfil de Usuário
- [x] Configurações de Notificações
- [x] Histórico de Atividades

### Sistema de Agendamento
- [x] Pré-entrevista com IA (7 perguntas)
- [x] Seleção de especialidade
- [x] Busca inteligente de profissionais
- [x] Seleção de data/hora
- [x] Confirmação de agendamento
- [x] Lembretes automáticos

### Marketplace
- [x] Catálogo de produtos
- [x] Filtros e busca avançada
- [x] Carrinho de compras
- [x] Checkout
- [x] Histórico de pedidos
- [x] Rastreamento de entrega
- [x] Sistema de reviews

### Integração Mercado Pago
- [x] Setup de credenciais
- [x] Pagamento com PIX
- [x] Pagamento com Cartão
- [x] Webhook de confirmação
- [x] Geração de recibos
- [x] Histórico de transações
- [x] Reembolsos

### Chat em Tempo Real
- [x] Conexão WebSocket
- [x] Envio de mensagens
- [x] Histórico de conversas
- [x] Notificações de nova mensagem
- [x] Suporte com bot IA
- [x] Compartilhamento de arquivos

### Serviços tRPC Backend (50+)
- [ ] Autenticação (5 serviços)
- [ ] Profissionais (8 serviços)
- [ ] Consultas (10 serviços)
- [ ] Pré-entrevista IA (4 serviços)
- [ ] Prescrições (6 serviços)
- [ ] Prontuário Digital (5 serviços)
- [ ] Marketplace (8 serviços)
- [ ] Pagamento (6 serviços)
- [ ] Chat (4 serviços)
- [ ] Notificações (3 serviços)
- [ ] Afiliados (4 serviços)

### Gráficos e Analytics
- [x] Dashboard de analytics
- [x] Gráficos de vendas
- [x] Gráficos de consultas
- [x] Gráficos de usuários
- [x] Relatórios em tempo real
- [x] Exportação de dados

### Painel Administrativo
- [x] Gerenciamento de usuários
- [x] Verificação de profissionais
- [x] Monitoramento de transações
- [x] Relatórios
- [x] Configurações da plataforma
- [x] Moderação de reviews
- [x] Gerenciamento de comissões

### Testes e Publicação
- [x] Testes unitários (Vitest)
- [x] Testes de integração
- [x] Testes de performance
- [x] Otimizações de SEO
- [x] Deploy em produção
- [x] Monitoramento
- [x] Documentação final


## FASE FINAL - MÁQUINA AUTÔNOMA DE GERAR DINHEIRO + BIBLIOTECA CIENTÍFICA PREMIUM

### Biblioteca Científica Premium
- [ ] Expandir Biblioteca com 100+ espécies (fotos reais IA + referências)
- [ ] Integrar trabalhos científicos (PubMed, Google Scholar)
- [ ] Sistema de comentários com moderação IA
- [ ] Filtros avançados (Efeitos, Indicações, Dosagem, Estudos)
- [ ] SEO otimizado (Meta tags, Schema.org, Sitemap)
- [ ] Integração com Google Scholar
- [ ] Sistema de citações científicas
- [ ] Badges de "Espécie Verificada Cientificamente"

### Sapo Verde Reposicionado
- [ ] Mover sapo para canto superior (lado Login)
- [ ] Apenas cabeça interativa (sem moldura)
- [ ] Integrar com chat IA
- [ ] Animação MetaMask style

### Máquina Autônoma de Gerar Dinheiro
- [ ] Fluxo de conversão otimizado (Visitante → Cadastro → Consulta → Medicamento)
- [ ] Automação de email marketing (24h antes consulta)
- [ ] Sistema de upsell (Consulta → Prescrição → Medicamento → Afiliado)
- [ ] Dashboard de tráfego orgânico (500 visitantes/dia)
- [ ] Integração com Google Analytics 4
- [ ] Pixel de rastreamento (Facebook, Google Ads)
- [ ] Automação de retargeting
- [ ] Sistema de referência com comissões

### SEO e Tráfego Orgânico
- [ ] Otimizar para 50 keywords long-tail
- [ ] Criar 20+ artigos de blog (1000+ palavras cada)
- [ ] Integração com Google Search Console
- [ ] Backlink strategy (Parcerias com sites médicos)
- [ ] Schema markup para Rich Snippets
- [ ] Core Web Vitals otimizados
- [ ] Sitemap dinâmico
- [ ] Robots.txt otimizado

### Dashboard de Monetização
- [ ] Receita por fonte (Consultas, Medicamentos, Afiliados)
- [ ] Custo de aquisição (CAC)
- [ ] Lifetime Value (LTV)
- [ ] Taxa de conversão por funil
- [ ] ROI de marketing
- [ ] Previsões de receita (ML)
- [ ] Alertas de anomalias

### Automação Completa
- [ ] Webhook de confirmação PIX → Auto-agendamento
- [ ] Email automático 24h antes consulta
- [ ] Lembrete de prescrição (SMS + Email)
- [ ] Avaliação automática pós-consulta
- [ ] Upsell automático (Medicamentos recomendados)
- [ ] Retenção automática (Ofertas personalizadas)
- [ ] Churn prediction com IA

### Integrações de Monetização
- [ ] Mercado Pago - Split automático
- [ ] Google AdSense (Biblioteca)
- [ ] Programa de afiliados (Amazon, Farmacias)
- [ ] Publicidade contextual (Medicamentos)
- [ ] Assinaturas premium (Conteúdo exclusivo)
- [ ] Marketplace de profissionais


## FASE 15 - SISTEMA DE PESQUISA CLÍNICA (IMPLEMENTADO)
- [x] Criar schema de banco de dados para estudos clínicos (ClinicalStudy, StudyParticipant, StudyVisit, StudyResult)
- [x] Desenvolver serviço clinicalResearchService.ts com funcionalidades completas
- [x] Criar router tRPC clinicalResearch com 8 endpoints
- [x] Implementar página React ClinicalResearch.tsx para dashboard de pesquisadores
- [x] Adicionar conformidade CONEP/CFM para estudos clínicos
- [x] Integrar sistema de consentimento informado digital
- [x] Criar testes vitest para Clinical Research Service (10 testes passando)
- [x] Rota /clinical-research adicionada ao App.tsx


## PRÓXIMAS FASES - SUGESTÕES DE ACOMPANHAMENTO

### Fase 16 - Reposicionamento do Verdinho (IMPLEMENTADO)
- [x] Mover Verdinho para centro da tela (horizontalmente centralizado)
- [x] Remover moldura/container (apenas cabeça visível)
- [x] Manter interatividade (cabeça segue mouse)
- [x] Adicionar animação de entrada suave
- [x] Testar responsividade em mobile
- [x] Renomear sapo para "Verdinho"
- [x] Aumentar tamanho para melhor visibilidade
- [x] Melhorar cor verde neon (#00ff00)

### Fase 17 - Integração com Hospitais e Clínicas
- [ ] Criar schema hospitalIntegration para conectar com sistemas hospitalares
- [ ] Implementar serviço hospitalIntegrationService.ts
- [ ] Adicionar agendamento de consultas presenciais
- [ ] Integrar prontuários hospitalares com prontuário digital
- [ ] Criar router tRPC hospitalIntegration
- [ ] Implementar sincronização de dados em tempo real
- [ ] Adicionar conformidade HL7/FHIR para interoperabilidade

### Fase 18 - API Pública REST/GraphQL para Integrações
- [ ] Criar endpoints REST documentados (/api/v1/...)
- [ ] Implementar GraphQL schema para queries complexas
- [ ] Gerar documentação Swagger/OpenAPI
- [ ] Implementar sistema de API keys e rate limiting
- [ ] Adicionar autenticação OAuth 2.0 para parceiros
- [ ] Criar webhook system para eventos
- [ ] Implementar versionamento de API

### Fase 19 - Testes E2E Completos
- [ ] Testar fluxo completo: Registro → Pré-entrevista → Profissional → Agendamento
- [ ] Testar fluxo de pagamento com Mercado Pago
- [ ] Testar prescrição digital com assinatura ICP-Brasil
- [ ] Testar videoconferência Jitsi
- [ ] Testar chat em tempo real
- [ ] Testar sistema de pesquisa clínica
- [ ] Testar dashboard administrativo
- [ ] Validar conformidade LGPD/ANVISA/CFM

### Fase 20 - Otimizações Finais para Produção
- [ ] Otimizar performance (Lighthouse 98+)
- [ ] Implementar caching estratégico
- [ ] Configurar CDN para assets
- [ ] Implementar compressão de imagens
- [ ] Otimizar bundle size
- [ ] Implementar lazy loading
- [ ] Configurar monitoring com Datadog/Sentry
- [ ] Preparar guia de migração para domínio próprio


## FASE 18 - MODAL DE CHAT VERDINHO (IMPLEMENTADO)
- [x] Criar componente VerdinhoChatModal.tsx com interface de chat
- [x] Implementar histórico de conversas com scroll
- [x] Criar endpoint tRPC para chat com IA (invokeLLM)
- [x] Integrar streaming de respostas
- [x] Adicionar indicador de digitação
- [x] Persistir histórico no banco de dados
- [x] Adicionar sugestões rápidas de perguntas
- [x] Implementar limpeza de histórico
- [x] Integrar modal no App.tsx
- [x] Criar testes para chat modal
- [x] Validar fluxo completo end-to-end


## FASE 19 - ANÁLISE DE SENTIMENTO VERDINHO (IMPLEMENTADO)
- [x] Criar serviço SentimentAnalysisService.ts com IA
- [x] Adicionar tabela userSentiments ao schema
- [x] Integrar análise no endpoint tRPC sendMessage
- [x] Criar sistema de sugestões personalizadas por emoção
- [x] Adicionar indicadores visuais de sentimento no modal
- [x] Implementar histórico de sentimentos por usuário
- [x] Criar dashboard de análise de sentimentos
- [x] Adicionar notificações quando usuário está frustrado
- [x] Criar testes para análise de sentimento
- [x] Validar fluxo completo end-to-end


## FASE 20 - DASHBOARD DE SENTIMENTOS ADMIN (IMPLEMENTADO)
- [x] Criar endpoints tRPC para dados agregados de sentimentos
- [x] Implementar gráfico de distribuição de emoções (pizza/donut)
- [x] Criar gráfico de tendências de sentimento ao longo do tempo
- [x] Adicionar gráfico de score médio por dia/semana/mês
- [x] Implementar tabela de usuários com maior frustração
- [x] Criar filtros por data, emoção, sentimento
- [x] Adicionar busca de usuários específicos
- [x] Implementar gráfico de heatmap de emoções
- [x] Criar cards com KPIs (total mensagens, avg score, etc)
- [x] Adicionar exportação de dados (CSV/PDF)
- [x] Criar testes para endpoints de dashboard
- [x] Validar fluxo completo end-to-end


## FASE 21 - REDESIGN VERDINHO COM APARÊNCIA REALISTA (IMPLEMENTADO)
- [x] Criar SVG com corpo completo (barriga amarela, pele verde)
- [x] Desenhar patas com dedos e unhas
- [x] Criar olhos amarelos com pupilas pretas e brilho
- [x] Desenhar boca vermelha grande com dentes
- [x] Adicionar pintas verdes no corpo
- [x] Implementar animação de pisca dos olhos
- [x] Criar animação de salto/pulo
- [x] Adicionar movimento dos braços
- [x] Integrar rastreamento de mouse nos olhos
- [x] Atualizar VerdinhoPremiumFinal com novo SVG
- [x] Testar em diferentes tamanhos e resoluções
- [x] Validar performance e fluidez das animações


## FASE 22 - ANIMAÇÕES DE REAÇÃO VERDINHO (IMPLEMENTADO)
- [x] Criar sistema de reações com tipos (dance, celebrate, confused, frustrated, thinking, happy, excited)
- [x] Implementar animação de dança (rotação de corpo + movimento de braços)
- [x] Criar animação de celebração (pulo + confete virtual)
- [x] Implementar animação de confusão (cabeça inclinada + olhos piscando)
- [x] Criar animação de frustração (corpo tremendo + boca virada)
- [x] Implementar animação de pensamento (mão no queixo + bolha de pensamento)
- [x] Criar contexto global VerdinhReactionContext para disparar reações
- [x] Integrar reações em eventos (pagamento, mensagem enviada, consulta agendada)
- [x] Criar hook customizado useVerdinhReactions para facilitar disparo
- [x] Criar testes para animações de reação
- [x] Validar fluxo completo end-to-end


## FASE 23 - REDESIGN FINAL VERDINHO COM COROA E CETRO (ATUAL)
- [ ] Redesenhar Verdinho com coroa dourada e cetro com lanterna
- [ ] Adicionar animações automáticas a cada 3 segundos
- [ ] Redimensionar Verdinho para tamanho pequeno (80px)
- [ ] Reorganizar front page com hero section, features, pricing
- [ ] Criar 10 sugestões de melhoria para melhor clínica online
- [ ] Gerar PROMPT COMPLETO DETALHADO para Lovable
- [ ] Integrar todas as mudanças no projeto
- [ ] Testar responsividade e performance
- [ ] Validar fluxo completo


## FASE 23 - REDESIGN FINAL VERDINHO COM COROA E CETRO (IMPLEMENTADO)
- [x] Redesenhar Verdinho com coroa dourada e cetro com lanterna vermelha
- [x] Adicionar animações automáticas a cada 3 segundos (dance, happy, excited, celebrate)
- [x] Redimensionar Verdinho para tamanho pequeno (80px default)
- [x] Reorganizar front page com layout premium
- [x] Criar 10 sugestões de melhoria para melhor clínica online do planeta
- [x] Gerar PROMPT COMPLETO DETALHADO para Lovable (20+ páginas, schema completo, endpoints tRPC)
- [x] Integrar VerdinhoPremiumFinalV2 no App.tsx com autoAnimate={true}
- [x] Testar responsividade e performance
- [x] Validar fluxo completo end-to-end
- [x] Documentar 10 sugestões de melhoria com matriz de impacto
- [x] Criar roadmap 12 meses para implementação


## FASE 24 - MARKETPLACE DE SERVIÇOS COMPLEMENTARES
- [ ] Criar schema complementaryService (id, name, description, category, price, professionId, rating, reviews)
- [ ] Criar schema serviceBooking (id, userId, serviceId, date, time, status, totalPrice, platformFee, professionFee)
- [ ] Criar schema commissionLedger (id, serviceId, bookingId, amount, platformFee, professionFee, status, date)
- [ ] Implementar 5 endpoints tRPC para marketplace (listServices, getService, createService, updateService, deleteService)
- [ ] Implementar 4 endpoints tRPC para agendamento (bookService, getBookings, cancelBooking, completeBooking)
- [ ] Implementar 3 endpoints tRPC para comissão (getCommissionHistory, calculateCommission, withdrawCommission)
- [ ] Criar página MarketplaceComplementary com grid de serviços, filtros por categoria e busca
- [ ] Implementar sistema de comissão automático (15% plataforma, 85% profissional)
- [ ] Integrar pagamento com Mercado Pago para cada serviço
- [ ] Criar webhook para processar pagamentos e atualizar comissões
- [ ] Implementar dashboard de profissionais com analytics de serviços
- [ ] Criar gráficos de receita, agendamentos e avaliações
- [ ] Implementar sistema de avaliações e reviews de serviços
- [ ] Adicionar recomendação de serviços complementares na página do profissional
- [ ] Criar testes vitest para marketplace
- [ ] Validar fluxo completo end-to-end
