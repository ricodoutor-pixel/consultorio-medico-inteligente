import { router, protectedProcedure } from '../_core/trpc';
import { z } from 'zod';
import { googleMapsProximityService } from '../services/GoogleMapsProximityService';

export const googleMapsProximityRouter = router({
  /**
   * Update doctor location
   */
  updateDoctorLocation: protectedProcedure
    .input(
      z.object({
        doctorId: z.string(),
        doctorName: z.string(),
        specialty: z.string(),
        latitude: z.number(),
        longitude: z.number(),
        address: z.string().optional(),
        available: z.boolean().default(true),
        score: z.number().default(50),
      })
    )
    .mutation(({ input }) => {
      const location = googleMapsProximityService.updateDoctorLocation(
        input.doctorId,
        input.doctorName,
        input.specialty,
        input.latitude,
        input.longitude,
        input.address,
        input.available,
        input.score
      );

      return {
        success: true,
        data: location,
      };
    }),

  /**
   * Update patient location
   */
  updatePatientLocation: protectedProcedure
    .input(
      z.object({
        patientId: z.string(),
        patientName: z.string(),
        latitude: z.number(),
        longitude: z.number(),
        address: z.string().optional(),
      })
    )
    .mutation(({ input }) => {
      const location = googleMapsProximityService.updatePatientLocation(
        input.patientId,
        input.patientName,
        input.latitude,
        input.longitude,
        input.address
      );

      return {
        success: true,
        data: location,
      };
    }),

  /**
   * Find nearby doctors for a patient
   */
  findNearbyDoctors: protectedProcedure
    .input(
      z.object({
        patientId: z.string(),
        radiusKm: z.number().default(10),
        specialty: z.string().optional(),
      })
    )
    .query(({ input }) => {
      const matches = googleMapsProximityService.findNearbyDoctors(
        input.patientId,
        input.radiusKm,
        input.specialty
      );

      return {
        success: true,
        data: matches,
      };
    }),

  /**
   * Find best doctor match for patient
   */
  findBestDoctorMatch: protectedProcedure
    .input(
      z.object({
        patientId: z.string(),
        specialty: z.string().optional(),
      })
    )
    .query(({ input }) => {
      const match = googleMapsProximityService.findBestDoctorMatch(
        input.patientId,
        input.specialty
      );

      return {
        success: !!match,
        data: match,
      };
    }),

  /**
   * Get all doctor locations
   */
  getAllDoctorLocations: protectedProcedure.query(() => {
    const locations = googleMapsProximityService.getAllDoctorLocations();

    return {
      success: true,
      data: locations,
    };
  }),

  /**
   * Get doctor location
   */
  getDoctorLocation: protectedProcedure
    .input(
      z.object({
        doctorId: z.string(),
      })
    )
    .query(({ input }) => {
      const location = googleMapsProximityService.getDoctorLocation(input.doctorId);

      return {
        success: !!location,
        data: location,
      };
    }),

  /**
   * Get patient location
   */
  getPatientLocation: protectedProcedure
    .input(
      z.object({
        patientId: z.string(),
      })
    )
    .query(({ input }) => {
      const location = googleMapsProximityService.getPatientLocation(input.patientId);

      return {
        success: !!location,
        data: location,
      };
    }),

  /**
   * Get doctors by region
   */
  getDoctorsByRegion: protectedProcedure
    .input(
      z.object({
        latitude: z.number(),
        longitude: z.number(),
        radiusKm: z.number().default(50),
      })
    )
    .query(({ input }) => {
      const doctors = googleMapsProximityService.getDoctorsByRegion(
        input.latitude,
        input.longitude,
        input.radiusKm
      );

      return {
        success: true,
        data: doctors,
      };
    }),

  /**
   * Get proximity statistics
   */
  getStats: protectedProcedure.query(() => {
    const stats = googleMapsProximityService.getStats();

    return {
      success: true,
      data: stats,
    };
  }),
});
