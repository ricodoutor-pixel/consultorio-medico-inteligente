import React, { useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ShoppingCart, Award } from 'lucide-react';

interface Product {
  id: number;
  name: string;
  price: string;
  images: string[];
  description?: string;
}

interface ClubSectionProps {
  products?: Product[];
  title?: string;
}

const ProductCard: React.FC<{ product: Product }> = ({ product }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const handleNextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % product.images.length);
  };

  const handlePrevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + product.images.length) % product.images.length);
  };

  return (
    <Card className="bg-zinc-950 border-zinc-800 overflow-hidden group hover:border-green-500/50 transition-all duration-300">
      <div className="relative h-48 bg-zinc-900">
        <img 
          src={product.images[currentImageIndex] || "/api/placeholder/300/300"} 
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
          alt={product.name}
        />
        
        {/* Image Indicators */}
        <div className="absolute bottom-2 left-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          {product.images.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentImageIndex(idx)}
              className={`w-2 h-2 rounded-full transition-colors ${
                idx === currentImageIndex ? 'bg-green-500' : 'bg-zinc-400'
              }`}
              aria-label={`Image ${idx + 1}`}
            />
          ))}
        </div>

        {/* Navigation Arrows */}
        {product.images.length > 1 && (
          <>
            <button
              onClick={handlePrevImage}
              className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-green-600 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-300"
              aria-label="Previous image"
            >
              ←
            </button>
            <button
              onClick={handleNextImage}
              className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-green-600 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-300"
              aria-label="Next image"
            >
              →
            </button>
          </>
        )}
      </div>

      <CardContent className="p-3">
        <h4 className="text-white text-sm font-bold truncate">{product.name}</h4>
        {product.description && (
          <p className="text-zinc-400 text-xs mt-1 line-clamp-2">{product.description}</p>
        )}
        <div className="flex justify-between items-center mt-3">
          <span className="text-green-500 font-bold text-lg">{product.price}</span>
          <Button 
            size="sm" 
            className="bg-zinc-800 hover:bg-green-600 text-white p-2 transition-colors"
            aria-label="Add to cart"
          >
            <ShoppingCart size={16} />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export const ClubSection: React.FC<ClubSectionProps> = ({ 
  title = "Club Planta y Raiz (Ofertas Exclusivas)",
  products
}) => {
  const defaultProducts: Product[] = Array.from({ length: 10 }).map((_, i) => ({
    id: i,
    name: `Produto Premium Club #${i + 1}`,
    price: `R$ ${(149.90 + i * 10).toFixed(2)}`,
    images: [
      "/api/placeholder/300/300",
      "/api/placeholder/300/300",
      "/api/placeholder/300/300"
    ],
    description: `Produto exclusivo do clube com benefícios especiais`
  }));

  const displayProducts = products || defaultProducts;

  return (
    <section className="bg-zinc-900/50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-3 mb-8">
          <Award className="text-green-500" size={28} />
          <h2 className="text-2xl sm:text-3xl font-bold text-green-500">
            {title}
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
          {displayProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ClubSection;
