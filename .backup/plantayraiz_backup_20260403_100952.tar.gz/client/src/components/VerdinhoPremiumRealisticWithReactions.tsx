/**
 * 🐸 VERDINHO PREMIUM REALISTIC WITH REACTIONS
 * 
 * Adiciona sistema de reações animadas ao Verdinho:
 * - Dance: Rotação de corpo + movimento de braços
 * - Celebrate: Pulos + confete
 * - Confused: Cabeça inclinada + olhos piscando
 * - Frustrated: Tremor + boca virada
 * - Thinking: Mão no queixo + bolha
 * - Happy: Pulos pequenos
 * - Excited: Movimento frenético
 */

import React, { useState, useEffect, useRef } from 'react';
import { useVerdinhReaction } from '@/contexts/VerdinhReactionContext';

interface VerdinhoPremiumRealisticWithReactionsProps {
  size?: 'small' | 'medium' | 'large';
  position?: 'header' | 'center' | 'floating';
  onChat?: () => void;
  interactive?: boolean;
}

const VerdinhoPremiumRealisticWithReactions: React.FC<VerdinhoPremiumRealisticWithReactionsProps> = ({
  size = 'medium',
  position = 'floating',
  onChat,
  interactive = true
}) => {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isBlinking, setIsBlinking] = useState(false);
  const [isJumping, setIsJumping] = useState(false);
  const [armRotation, setArmRotation] = useState(0);
  const [confetti, setConfetti] = useState<Array<{ id: number; x: number; y: number; delay: number }>>([]);
  const svgRef = useRef<SVGSVGElement>(null);
  const { currentReaction, isReacting } = useVerdinhReaction();

  // Tamanhos
  const sizeMap = {
    small: 120,
    medium: 180,
    large: 240
  };

  const viewBoxSize = 200;
  const size_px = sizeMap[size];

  // Rastrear movimento do mouse
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!interactive || !svgRef.current) return;

      const rect = svgRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      setMousePos({ x, y });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [interactive]);

  // Piscar dos olhos
  useEffect(() => {
    const blinkInterval = setInterval(() => {
      setIsBlinking(true);
      setTimeout(() => setIsBlinking(false), 150);
    }, 3000 + Math.random() * 2000);

    return () => clearInterval(blinkInterval);
  }, []);

  // Saltar ocasionalmente (exceto durante reações)
  useEffect(() => {
    if (isReacting) return;

    const jumpInterval = setInterval(() => {
      setIsJumping(true);
      setTimeout(() => setIsJumping(false), 600);
    }, 5000 + Math.random() * 3000);

    return () => clearInterval(jumpInterval);
  }, [isReacting]);

  // Movimento dos braços
  useEffect(() => {
    const armInterval = setInterval(() => {
      setArmRotation((prev) => (prev + 5) % 360);
    }, 50);

    return () => clearInterval(armInterval);
  }, []);

  // Gerar confete para celebração
  useEffect(() => {
    if (currentReaction?.type === 'celebrate') {
      const newConfetti = Array.from({ length: 15 }, (_, i) => ({
        id: i,
        x: Math.random() * 100,
        y: Math.random() * 50,
        delay: Math.random() * 0.3
      }));
      setConfetti(newConfetti);

      const timer = setTimeout(() => setConfetti([]), 2000);
      return () => clearTimeout(timer);
    }
  }, [currentReaction?.type]);

  // Calcular posição dos olhos seguindo o mouse
  const calculateEyePosition = (eyeCenterX: number, eyeCenterY: number) => {
    if (!interactive || isReacting) return { x: eyeCenterX, y: eyeCenterY };

    const rect = svgRef.current?.getBoundingClientRect();
    if (!rect) return { x: eyeCenterX, y: eyeCenterY };

    const angle = Math.atan2(mousePos.y - rect.height / 2, mousePos.x - rect.width / 2);
    const distance = 8;

    return {
      x: eyeCenterX + Math.cos(angle) * distance,
      y: eyeCenterY + Math.sin(angle) * distance
    };
  };

  // Aplicar transformações baseadas em reação
  const getTransform = () => {
    if (!isReacting || !currentReaction) return 'translate(0, 0) rotate(0deg)';

    switch (currentReaction.type) {
      case 'dance':
        return `translate(${Math.sin(armRotation * 0.1) * 15}px, 0) rotate(${Math.sin(armRotation * 0.05) * 10}deg)`;
      case 'celebrate':
        return `translate(0, ${isJumping ? -40 : 0}px) scale(1.05)`;
      case 'confused':
        return `rotate(-15deg)`;
      case 'frustrated':
        return `translate(${Math.sin(armRotation * 0.2) * 5}px, ${Math.cos(armRotation * 0.2) * 5}px)`;
      case 'thinking':
        return `translate(0, -5px)`;
      case 'happy':
        return `scale(1.1)`;
      case 'excited':
        return `translate(${Math.sin(armRotation * 0.15) * 20}px, ${Math.cos(armRotation * 0.15) * 20}px) scale(1.1)`;
      default:
        return 'translate(0, 0) rotate(0deg)';
    }
  };

  const leftPupil = calculateEyePosition(65, 70);
  const rightPupil = calculateEyePosition(135, 70);

  // Determinar expressão facial baseada em reação
  const getMouthExpression = () => {
    if (currentReaction?.type === 'frustrated') {
      return 'frustrated'; // Boca virada para baixo
    }
    if (currentReaction?.type === 'confused') {
      return 'confused'; // Boca em ponto de interrogação
    }
    if (currentReaction?.type === 'happy' || currentReaction?.type === 'celebrate' || currentReaction?.type === 'excited') {
      return 'big_smile'; // Sorriso grande
    }
    return 'normal';
  };

  const mouthExpression = getMouthExpression();

  return (
    <div
      className={`flex items-center justify-center cursor-pointer transition-transform hover:scale-110 ${
        position === 'header' ? 'fixed top-4 right-4 z-40' : position === 'center' ? 'flex justify-center' : ''
      }`}
      onClick={onChat}
      title="Clique para conversar com Verdinho"
    >
      {/* Confete */}
      {confetti.map((piece) => (
        <div
          key={piece.id}
          className="fixed pointer-events-none"
          style={{
            left: `${piece.x}%`,
            top: `${piece.y}%`,
            animation: `fall 2s ease-in forwards`,
            animationDelay: `${piece.delay}s`,
            opacity: 0.8
          }}
        >
          {piece.id % 3 === 0 ? '🎉' : piece.id % 3 === 1 ? '✨' : '🎊'}
        </div>
      ))}

      <svg
        ref={svgRef}
        viewBox={`0 0 ${viewBoxSize} ${viewBoxSize}`}
        width={size_px}
        height={size_px}
        className="filter drop-shadow-lg transition-transform"
        style={{
          transform: getTransform(),
          transition: isReacting ? 'transform 0.1s ease-out' : 'transform 0.3s ease-out'
        }}
      >
        {/* Definições de gradientes */}
        <defs>
          <radialGradient id="bodyGradient" cx="40%" cy="40%">
            <stop offset="0%" stopColor="#7FFF00" />
            <stop offset="100%" stopColor="#32CD32" />
          </radialGradient>

          <radialGradient id="bellyGradient" cx="50%" cy="50%">
            <stop offset="0%" stopColor="#FFFF99" />
            <stop offset="100%" stopColor="#FFFF00" />
          </radialGradient>

          <radialGradient id="eyeGradient" cx="35%" cy="35%">
            <stop offset="0%" stopColor="#FFFF99" />
            <stop offset="100%" stopColor="#FFD700" />
          </radialGradient>

          <filter id="shadow" x="-50%" y="-50%" width="200%" height="200%">
            <feDropShadow dx="2" dy="2" stdDeviation="3" floodOpacity="0.3" />
          </filter>

          <style>{`
            @keyframes fall {
              to {
                transform: translateY(200px) rotate(360deg);
                opacity: 0;
              }
            }
            @keyframes thinking-bounce {
              0%, 100% { transform: translateY(0); }
              50% { transform: translateY(-5px); }
            }
          `}</style>
        </defs>

        {/* Corpo principal */}
        <ellipse cx="100" cy="110" rx="55" ry="65" fill="url(#bodyGradient)" filter="url(#shadow)" />

        {/* Barriga */}
        <ellipse cx="100" cy="120" rx="35" ry="45" fill="url(#bellyGradient)" />

        {/* Pintas verdes */}
        <circle cx="75" cy="85" r="4" fill="#228B22" opacity="0.7" />
        <circle cx="125" cy="95" r="3" fill="#228B22" opacity="0.7" />
        <circle cx="85" cy="140" r="3.5" fill="#228B22" opacity="0.7" />
        <circle cx="115" cy="145" r="3" fill="#228B22" opacity="0.7" />
        <circle cx="70" cy="120" r="2.5" fill="#228B22" opacity="0.7" />
        <circle cx="130" cy="130" r="2.5" fill="#228B22" opacity="0.7" />

        {/* Patas traseiras */}
        <g transform="translate(60, 165)">
          <ellipse cx="0" cy="0" rx="18" ry="22" fill="url(#bodyGradient)" />
          <circle cx="-12" cy="15" r="5" fill="#32CD32" />
          <circle cx="-5" cy="18" r="5" fill="#32CD32" />
          <circle cx="5" cy="18" r="5" fill="#32CD32" />
          <circle cx="12" cy="15" r="5" fill="#32CD32" />
          <circle cx="-12" cy="18" r="2" fill="#1a1a1a" />
          <circle cx="-5" cy="21" r="2" fill="#1a1a1a" />
          <circle cx="5" cy="21" r="2" fill="#1a1a1a" />
          <circle cx="12" cy="18" r="2" fill="#1a1a1a" />
        </g>

        <g transform="translate(140, 165)">
          <ellipse cx="0" cy="0" rx="18" ry="22" fill="url(#bodyGradient)" />
          <circle cx="-12" cy="15" r="5" fill="#32CD32" />
          <circle cx="-5" cy="18" r="5" fill="#32CD32" />
          <circle cx="5" cy="18" r="5" fill="#32CD32" />
          <circle cx="12" cy="15" r="5" fill="#32CD32" />
          <circle cx="-12" cy="18" r="2" fill="#1a1a1a" />
          <circle cx="-5" cy="21" r="2" fill="#1a1a1a" />
          <circle cx="5" cy="21" r="2" fill="#1a1a1a" />
          <circle cx="12" cy="18" r="2" fill="#1a1a1a" />
        </g>

        {/* Braços com animação de dança */}
        <g transform={`translate(55, 100) rotate(${currentReaction?.type === 'dance' ? Math.sin(armRotation * 0.1) * 30 : armRotation * 0.5})`}>
          <ellipse cx="0" cy="0" rx="12" ry="35" fill="url(#bodyGradient)" />
          <circle cx="0" cy="-35" r="14" fill="#32CD32" />
          <circle cx="-8" cy="-42" r="4" fill="#32CD32" />
          <circle cx="0" cy="-46" r="4" fill="#32CD32" />
          <circle cx="8" cy="-42" r="4" fill="#32CD32" />
        </g>

        <g transform={`translate(145, 100) rotate(${currentReaction?.type === 'dance' ? -Math.sin(armRotation * 0.1) * 30 : -armRotation * 0.5})`}>
          <ellipse cx="0" cy="0" rx="12" ry="35" fill="url(#bodyGradient)" />
          <circle cx="0" cy="-35" r="14" fill="#32CD32" />
          <circle cx="-8" cy="-42" r="4" fill="#32CD32" />
          <circle cx="0" cy="-46" r="4" fill="#32CD32" />
          <circle cx="8" cy="-42" r="4" fill="#32CD32" />
        </g>

        {/* Mão no queixo para pensamento */}
        {currentReaction?.type === 'thinking' && (
          <g transform="translate(50, 110)">
            <circle cx="0" cy="0" r="8" fill="#32CD32" />
          </g>
        )}

        {/* Olho esquerdo */}
        <g>
          <circle cx="65" cy="70" r="18" fill="url(#eyeGradient)" />
          <circle cx="60" cy="60" r="6" fill="white" opacity="0.6" />
          {!isBlinking ? (
            <>
              <circle cx={leftPupil.x} cy={leftPupil.y} r="10" fill="#000000" />
              <circle cx={leftPupil.x - 3} cy={leftPupil.y - 3} r="3" fill="white" opacity="0.8" />
            </>
          ) : (
            <line x1="55" y1="70" x2="75" y2="70" stroke="#000000" strokeWidth="2" />
          )}
        </g>

        {/* Olho direito */}
        <g>
          <circle cx="135" cy="70" r="18" fill="url(#eyeGradient)" />
          <circle cx="140" cy="60" r="6" fill="white" opacity="0.6" />
          {!isBlinking ? (
            <>
              <circle cx={rightPupil.x} cy={rightPupil.y} r="10" fill="#000000" />
              <circle cx={rightPupil.x - 3} cy={rightPupil.y - 3} r="3" fill="white" opacity="0.8" />
            </>
          ) : (
            <line x1="125" y1="70" x2="145" y2="70" stroke="#000000" strokeWidth="2" />
          )}
        </g>

        {/* Boca com expressões */}
        <g>
          {mouthExpression === 'big_smile' ? (
            <>
              <path d="M 85 95 Q 100 115 115 95" fill="#FF1744" opacity="0.8" />
              <ellipse cx="100" cy="110" rx="10" ry="8" fill="#FF69B4" />
              <line x1="90" y1="95" x2="90" y2="105" stroke="white" strokeWidth="1.5" />
              <line x1="100" y1="95" x2="100" y2="108" stroke="white" strokeWidth="1.5" />
              <line x1="110" y1="95" x2="110" y2="105" stroke="white" strokeWidth="1.5" />
            </>
          ) : mouthExpression === 'frustrated' ? (
            <>
              <path d="M 85 105 Q 100 95 115 105" fill="#FF1744" opacity="0.8" />
              <ellipse cx="100" cy="100" rx="8" ry="5" fill="#FF69B4" />
            </>
          ) : mouthExpression === 'confused' ? (
            <>
              <path d="M 85 100 Q 100 105 115 100" fill="#FF1744" opacity="0.8" />
              <text x="100" y="115" textAnchor="middle" fontSize="20" fill="#DC143C">?</text>
            </>
          ) : (
            <>
              <path d="M 85 95 Q 100 105 115 95" fill="none" stroke="#DC143C" strokeWidth="3" strokeLinecap="round" />
              <path d="M 85 95 Q 100 110 115 95" fill="#FF1744" opacity="0.8" />
              <ellipse cx="100" cy="108" rx="8" ry="6" fill="#FF69B4" />
              <line x1="90" y1="95" x2="90" y2="102" stroke="white" strokeWidth="1.5" />
              <line x1="100" y1="95" x2="100" y2="103" stroke="white" strokeWidth="1.5" />
              <line x1="110" y1="95" x2="110" y2="102" stroke="white" strokeWidth="1.5" />
            </>
          )}
        </g>

        {/* Narinas */}
        <circle cx="92" cy="85" r="2" fill="#1a1a1a" />
        <circle cx="108" cy="85" r="2" fill="#1a1a1a" />

        {/* Bolha de pensamento */}
        {currentReaction?.type === 'thinking' && (
          <g>
            <circle cx="130" cy="40" r="20" fill="white" stroke="#DC143C" strokeWidth="2" opacity="0.9" />
            <circle cx="120" cy="55" r="8" fill="white" stroke="#DC143C" strokeWidth="1.5" opacity="0.9" />
            <circle cx="115" cy="65" r="5" fill="white" stroke="#DC143C" strokeWidth="1" opacity="0.9" />
            <text x="130" y="48" textAnchor="middle" fontSize="16">💭</text>
          </g>
        )}
      </svg>
    </div>
  );
};

export default VerdinhoPremiumRealisticWithReactions;
