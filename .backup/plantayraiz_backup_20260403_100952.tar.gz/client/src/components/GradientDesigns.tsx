import React from 'react';

/**
 * Gradient Design Patterns Library
 * Implements modern gradient designs from reference platforms
 */

// Hero Section with Animated Gradient
export const HeroGradient = ({ children }: { children: React.ReactNode }) => (
  <div className="relative overflow-hidden bg-gradient-to-br from-green-500 via-emerald-500 to-teal-600">
    <div className="absolute inset-0 opacity-30">
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-green-400 rounded-full mix-blend-multiply filter blur-3xl animate-pulse" />
      <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-blue-400 rounded-full mix-blend-multiply filter blur-3xl animate-pulse delay-2000" />
      <div className="absolute bottom-0 left-1/2 w-96 h-96 bg-purple-400 rounded-full mix-blend-multiply filter blur-3xl animate-pulse delay-4000" />
    </div>
    <div className="relative z-10">
      {children}
    </div>
  </div>
);

// Card with Gradient Border
export const GradientBorderCard = ({
  children,
  className = ''
}: {
  children: React.ReactNode;
  className?: string;
}) => (
  <div className={`relative p-0.5 rounded-xl bg-gradient-to-r from-green-500 via-emerald-500 to-blue-500 ${className}`}>
    <div className="bg-white rounded-xl p-6">
      {children}
    </div>
  </div>
);

// Gradient Text
export const GradientText = ({
  children,
  className = ''
}: {
  children: React.ReactNode;
  className?: string;
}) => (
  <span className={`bg-gradient-to-r from-green-600 via-emerald-600 to-blue-600 bg-clip-text text-transparent ${className}`}>
    {children}
  </span>
);

// Gradient Button
export const GradientButton = ({
  children,
  onClick,
  className = ''
}: {
  children: React.ReactNode;
  onClick?: () => void;
  className?: string;
}) => (
  <button
    onClick={onClick}
    className={`px-6 py-3 rounded-lg font-semibold text-white bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 transition-all duration-300 shadow-lg hover:shadow-xl ${className}`}
  >
    {children}
  </button>
);

// Gradient Section Background
export const GradientSection = ({
  children,
  variant = 'light'
}: {
  children: React.ReactNode;
  variant?: 'light' | 'dark' | 'vibrant';
}) => {
  const backgrounds = {
    light: 'bg-gradient-to-br from-green-50 via-white to-blue-50',
    dark: 'bg-gradient-to-br from-gray-900 via-green-900 to-blue-900',
    vibrant: 'bg-gradient-to-br from-green-400 via-emerald-500 to-blue-600'
  };

  return (
    <div className={backgrounds[variant]}>
      {children}
    </div>
  );
};

// Animated Gradient Background
export const AnimatedGradientBg = ({ children }: { children: React.ReactNode }) => (
  <div className="relative overflow-hidden">
    <style>{`
      @keyframes gradient-shift {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
      }
      .animated-gradient {
        background: linear-gradient(-45deg, #00B050, #00D084, #00F0B8, #00B050);
        background-size: 400% 400%;
        animation: gradient-shift 15s ease infinite;
      }
    `}</style>
    <div className="animated-gradient absolute inset-0" />
    <div className="relative z-10">
      {children}
    </div>
  </div>
);

// Gradient Mesh Background (Premium effect)
export const GradientMesh = ({ children }: { children: React.ReactNode }) => (
  <div className="relative overflow-hidden bg-gradient-to-br from-green-50 to-blue-50">
    <div className="absolute inset-0 opacity-40">
      <svg className="w-full h-full" viewBox="0 0 1200 600">
        <defs>
          <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style={{ stopColor: '#00B050', stopOpacity: 0.3 }} />
            <stop offset="100%" style={{ stopColor: '#00D084', stopOpacity: 0.1 }} />
          </linearGradient>
          <linearGradient id="grad2" x1="100%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" style={{ stopColor: '#0066FF', stopOpacity: 0.2 }} />
            <stop offset="100%" style={{ stopColor: '#00B050', stopOpacity: 0.1 }} />
          </linearGradient>
        </defs>
        <rect width="1200" height="600" fill="url(#grad1)" />
        <circle cx="200" cy="100" r="300" fill="url(#grad2)" opacity="0.5" />
        <circle cx="1000" cy="500" r="250" fill="url(#grad1)" opacity="0.4" />
      </svg>
    </div>
    <div className="relative z-10">
      {children}
    </div>
  </div>
);

// Gradient Overlay Card
export const GradientOverlayCard = ({
  title,
  description,
  image,
  cta
}: {
  title: string;
  description: string;
  image?: string;
  cta?: string;
}) => (
  <div className="relative rounded-xl overflow-hidden h-64 group">
    <div
      className="absolute inset-0 bg-cover bg-center transition-transform duration-300 group-hover:scale-110"
      style={{
        backgroundImage: image ? `url(${image})` : 'linear-gradient(135deg, #00B050, #00D084)'
      }}
    />
    <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80" />
    <div className="absolute inset-0 flex flex-col justify-end p-6 text-white">
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-sm text-gray-200 mb-4">{description}</p>
      {cta && (
        <button className="w-fit px-4 py-2 bg-white text-green-600 rounded-lg font-semibold hover:bg-green-50 transition-colors">
          {cta}
        </button>
      )}
    </div>
  </div>
);

// Gradient Divider
export const GradientDivider = ({ className = '' }: { className?: string }) => (
  <div className={`h-1 bg-gradient-to-r from-transparent via-green-500 to-transparent ${className}`} />
);

// Gradient Stats Card
export const GradientStatsCard = ({
  value,
  label,
  icon,
  trend
}: {
  value: string | number;
  label: string;
  icon?: React.ReactNode;
  trend?: { value: number; positive: boolean };
}) => (
  <div className="relative p-6 rounded-xl overflow-hidden bg-white border border-green-100">
    <div className="absolute inset-0 bg-gradient-to-br from-green-50 to-transparent opacity-50" />
    <div className="relative z-10">
      <div className="flex items-center justify-between mb-4">
        <div className="text-3xl font-bold text-gray-900">{value}</div>
        {icon && <div className="text-3xl opacity-50">{icon}</div>}
      </div>
      <div className="text-sm text-gray-600 mb-3">{label}</div>
      {trend && (
        <div className={`text-sm font-semibold ${trend.positive ? 'text-green-600' : 'text-red-600'}`}>
          {trend.positive ? '↑' : '↓'} {Math.abs(trend.value)}%
        </div>
      )}
    </div>
  </div>
);

// Gradient Progress Bar
export const GradientProgressBar = ({
  value,
  max = 100,
  label
}: {
  value: number;
  max?: number;
  label?: string;
}) => {
  const percentage = (value / max) * 100;

  return (
    <div>
      {label && <p className="text-sm font-semibold text-gray-700 mb-2">{label}</p>}
      <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-green-500 to-emerald-500 transition-all duration-300"
          style={{ width: `${percentage}%` }}
        />
      </div>
      <p className="text-xs text-gray-600 mt-1">{percentage.toFixed(0)}%</p>
    </div>
  );
};

// Gradient Badge
export const GradientBadge = ({
  children,
  variant = 'primary'
}: {
  children: React.ReactNode;
  variant?: 'primary' | 'success' | 'warning' | 'danger';
}) => {
  const variants = {
    primary: 'bg-gradient-to-r from-green-500 to-emerald-500 text-white',
    success: 'bg-gradient-to-r from-green-400 to-green-600 text-white',
    warning: 'bg-gradient-to-r from-yellow-400 to-orange-500 text-white',
    danger: 'bg-gradient-to-r from-red-400 to-red-600 text-white'
  };

  return (
    <span className={`px-3 py-1 rounded-full text-sm font-semibold ${variants[variant]}`}>
      {children}
    </span>
  );
};

// Gradient Timeline Item
export const GradientTimelineItem = ({
  title,
  description,
  date,
  completed
}: {
  title: string;
  description: string;
  date: string;
  completed: boolean;
}) => (
  <div className="flex gap-4 pb-8">
    <div className="flex flex-col items-center">
      <div
        className={`w-4 h-4 rounded-full ${
          completed ? 'bg-gradient-to-br from-green-500 to-emerald-500' : 'bg-gray-300'
        }`}
      />
      <div className="w-1 h-16 bg-gradient-to-b from-green-500 to-transparent mt-2" />
    </div>
    <div className="flex-1 pt-1">
      <h4 className="font-semibold text-gray-900">{title}</h4>
      <p className="text-sm text-gray-600 mt-1">{description}</p>
      <p className="text-xs text-gray-500 mt-2">{date}</p>
    </div>
  </div>
);

export default {
  HeroGradient,
  GradientBorderCard,
  GradientText,
  GradientButton,
  GradientSection,
  AnimatedGradientBg,
  GradientMesh,
  GradientOverlayCard,
  GradientDivider,
  GradientStatsCard,
  GradientProgressBar,
  GradientBadge,
  GradientTimelineItem
};
