import React, { useEffect, useState } from "react";

interface FrogHeadTopNavProps {
  onChat?: () => void;
}

const FrogHeadTopNav: React.FC<FrogHeadTopNavProps> = ({ onChat }) => {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      // Posição fixa do sapo no centro da tela
      const frogX = window.innerWidth / 2;
      const frogY = window.innerHeight / 2;
      const centerX = frogX;
      const centerY = frogY;

      const angle = Math.atan2(e.clientY - centerY, e.clientX - centerX);
      setMousePos({
        x: Math.cos(angle) * 8,
        y: Math.sin(angle) * 8,
      });
    };

    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  return (
    <div
      className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-20 h-20 cursor-pointer group z-50"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={onChat}
      title="Posso ajudar?"
    >
      {/* SVG Sapo Verdinho - Apenas Cabeça MetaMask Style */}
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full"
        xmlns="http://www.w3.org/2000/svg"
        style={{
          filter: "drop-shadow(0 0 12px rgba(16, 185, 129, 0.6))",
          transition: "all 0.2s ease-out",
          transform: isHovered ? "scale(1.15)" : "scale(1)",
        }}
      >
        {/* Cabeça Principal - Verde Neon */}
        <ellipse cx="50" cy="50" rx="42" ry="40" fill="#00ff00" opacity="0.95" />

        {/* Olhos - Seguem o mouse */}
        <g>
          {/* Olho Esquerdo */}
          <circle cx="35" cy="38" r="9" fill="white" />
          <circle
            cx={35 + mousePos.x * 0.4}
            cy={38 + mousePos.y * 0.4}
            r="6"
            fill="#1f2937"
          />
          <circle
            cx={35 + mousePos.x * 0.4 + 2}
            cy={38 + mousePos.y * 0.4 - 2}
            r="2.5"
            fill="white"
          />

          {/* Olho Direito */}
          <circle cx="65" cy="38" r="9" fill="white" />
          <circle
            cx={65 + mousePos.x * 0.4}
            cy={38 + mousePos.y * 0.4}
            r="6"
            fill="#1f2937"
          />
          <circle
            cx={65 + mousePos.x * 0.4 + 2}
            cy={38 + mousePos.y * 0.4 - 2}
            r="2.5"
            fill="white"
          />
        </g>

        {/* Boca - Sorriso Feliz */}
        <path
          d="M 38 62 Q 50 72 62 62"
          stroke="#ff4444"
          strokeWidth="3"
          fill="none"
          strokeLinecap="round"
        />

        {/* Língua */}
        <ellipse cx="50" cy="68" rx="7" ry="5" fill="#ff4444" opacity="0.8" />

        {/* Manchinhas Verdes */}
        <circle cx="28" cy="52" r="2.5" fill="#00cc00" opacity="0.7" />
        <circle cx="72" cy="56" r="3" fill="#00cc00" opacity="0.7" />
        <circle cx="50" cy="75" r="2" fill="#00cc00" opacity="0.7" />
      </svg>

      {/* Tooltip - Posso ajudar? */}
      <div className="absolute -bottom-14 left-1/2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
        <div className="bg-emerald-600 text-white text-sm px-4 py-2 rounded-full font-semibold shadow-lg">
          Posso ajudar?
        </div>
      </div>

      {/* Animação de Pulso quando Hover */}
      {isHovered && (
        <div
          className="absolute inset-0 rounded-full"
          style={{
            animation: "pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite",
            boxShadow: "0 0 0 8px rgba(16, 185, 129, 0.2)",
          }}
        />
      )}
    </div>
  );
};

export default FrogHeadTopNav;
