import twilio from 'twilio';

/**
 * TwilioWhatsAppService - Serviço para envio de alertas via WhatsApp
 * 
 * Funcionalidades:
 * - Enviar alertas de consulta para médicos
 * - Enviar confirmações para pacientes
 * - Rastrear entrega de mensagens
 * - Criar logs de comunicação
 */

interface WhatsAppMessage {
  to: string;
  body: string;
  mediaUrl?: string;
}

interface MessageResponse {
  success: boolean;
  sid?: string;
  error?: string;
  timestamp: string;
}

export class TwilioWhatsAppService {
  private client: any;
  private fromNumber: string;

  constructor() {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    const fromNumber = process.env.TWILIO_WHATSAPP_FROM;

    if (!accountSid || !authToken || !fromNumber) {
      throw new Error('Twilio credentials not configured');
    }

    this.client = twilio(accountSid, authToken);
    this.fromNumber = fromNumber;
  }

  /**
   * Enviar alerta de nova consulta para médico
   */
  async sendDoctorAlert(
    doctorPhone: string,
    doctorName: string,
    patientName: string,
    consultationDate: string,
    consultationTime: string,
    consultationValue: number,
    consultationLink: string
  ): Promise<MessageResponse> {
    try {
      const body = `
👨‍⚕️ *NOVA CONSULTA - PLANTA Y RAIZ*

Olá Dr(a) ${doctorName}! 👋

Você tem uma nova consulta agendada:

👤 *Paciente:* ${patientName}
📅 *Data:* ${consultationDate}
🕐 *Horário:* ${consultationTime}
💰 *Valor:* R$ ${consultationValue.toFixed(2)}

🔗 *Entrar na consulta:*
${consultationLink}

Status: ✅ Confirmada
Plataforma: Planta y Raiz - Mega Clínica Digital
`.trim();

      const message = await this.client.messages.create({
        from: `whatsapp:${this.fromNumber}`,
        to: `whatsapp:${doctorPhone}`,
        body: body
      });

      console.log(`✅ Alerta enviado para médico ${doctorName}: ${message.sid}`);

      return {
        success: true,
        sid: message.sid,
        timestamp: new Date().toISOString()
      };
    } catch (error: any) {
      console.error(`❌ Erro ao enviar alerta para médico: ${error.message}`);
      return {
        success: false,
        error: error.message,
        timestamp: new Date().toISOString()
      };
    }
  }

  /**
   * Enviar confirmação de consulta para paciente
   */
  async sendPatientConfirmation(
    patientPhone: string,
    patientName: string,
    doctorName: string,
    consultationDate: string,
    consultationTime: string,
    consultationLink: string
  ): Promise<MessageResponse> {
    try {
      const body = `
✅ *CONSULTA CONFIRMADA - PLANTA Y RAIZ*

Olá ${patientName}! 👋

Sua consulta foi confirmada com sucesso!

👨‍⚕️ *Médico:* Dr(a) ${doctorName}
📅 *Data:* ${consultationDate}
🕐 *Horário:* ${consultationTime}

🔗 *Entrar na consulta:*
${consultationLink}

⏰ *Dica:* Entre 5 minutos antes do horário agendado

Plataforma: Planta y Raiz - Mega Clínica Digital
CFM-LGPD Certificado ✅
`.trim();

      const message = await this.client.messages.create({
        from: `whatsapp:${this.fromNumber}`,
        to: `whatsapp:${patientPhone}`,
        body: body
      });

      console.log(`✅ Confirmação enviada para paciente ${patientName}: ${message.sid}`);

      return {
        success: true,
        sid: message.sid,
        timestamp: new Date().toISOString()
      };
    } catch (error: any) {
      console.error(`❌ Erro ao enviar confirmação para paciente: ${error.message}`);
      return {
        success: false,
        error: error.message,
        timestamp: new Date().toISOString()
      };
    }
  }

  /**
   * Enviar lembrete 1 hora antes da consulta
   */
  async sendReminderAlert(
    recipientPhone: string,
    recipientName: string,
    recipientType: 'doctor' | 'patient',
    doctorName: string,
    patientName: string,
    consultationTime: string,
    consultationLink: string
  ): Promise<MessageResponse> {
    try {
      let body: string;

      if (recipientType === 'doctor') {
        body = `
⏰ *LEMBRETE DE CONSULTA - PLANTA Y RAIZ*

Dr(a) ${recipientName}, sua consulta começa em 1 HORA!

👤 *Paciente:* ${patientName}
🕐 *Horário:* ${consultationTime}

🔗 *Entrar na consulta:*
${consultationLink}

Plataforma: Planta y Raiz - Mega Clínica Digital
`.trim();
      } else {
        body = `
⏰ *LEMBRETE DE CONSULTA - PLANTA Y RAIZ*

Olá ${recipientName}, sua consulta começa em 1 HORA!

👨‍⚕️ *Médico:* Dr(a) ${doctorName}
🕐 *Horário:* ${consultationTime}

🔗 *Entrar na consulta:*
${consultationLink}

Plataforma: Planta y Raiz - Mega Clínica Digital
`.trim();
      }

      const message = await this.client.messages.create({
        from: `whatsapp:${this.fromNumber}`,
        to: `whatsapp:${recipientPhone}`,
        body: body
      });

      console.log(`✅ Lembrete enviado para ${recipientType} ${recipientName}: ${message.sid}`);

      return {
        success: true,
        sid: message.sid,
        timestamp: new Date().toISOString()
      };
    } catch (error: any) {
      console.error(`❌ Erro ao enviar lembrete: ${error.message}`);
      return {
        success: false,
        error: error.message,
        timestamp: new Date().toISOString()
      };
    }
  }

  /**
   * Enviar notificação de conclusão de consulta
   */
  async sendCompletionNotification(
    recipientPhone: string,
    recipientName: string,
    recipientType: 'doctor' | 'patient',
    otherPartyName: string,
    prescriptionLink?: string
  ): Promise<MessageResponse> {
    try {
      let body: string;

      if (recipientType === 'doctor') {
        body = `
✅ *CONSULTA FINALIZADA - PLANTA Y RAIZ*

Dr(a) ${recipientName}, a consulta com ${otherPartyName} foi finalizada!

${prescriptionLink ? `📄 *Prescrição Digital:*\n${prescriptionLink}\n` : ''}
Obrigado por usar Planta y Raiz!

Plataforma: Planta y Raiz - Mega Clínica Digital
`.trim();
      } else {
        body = `
✅ *CONSULTA FINALIZADA - PLANTA Y RAIZ*

Olá ${recipientName}, sua consulta com Dr(a) ${otherPartyName} foi finalizada!

${prescriptionLink ? `📄 *Sua Prescrição:*\n${prescriptionLink}\n` : ''}
Obrigado por usar Planta y Raiz!

Plataforma: Planta y Raiz - Mega Clínica Digital
`.trim();
      }

      const message = await this.client.messages.create({
        from: `whatsapp:${this.fromNumber}`,
        to: `whatsapp:${recipientPhone}`,
        body: body
      });

      console.log(`✅ Notificação de conclusão enviada para ${recipientType} ${recipientName}: ${message.sid}`);

      return {
        success: true,
        sid: message.sid,
        timestamp: new Date().toISOString()
      };
    } catch (error: any) {
      console.error(`❌ Erro ao enviar notificação de conclusão: ${error.message}`);
      return {
        success: false,
        error: error.message,
        timestamp: new Date().toISOString()
      };
    }
  }

  /**
   * Enviar mensagem genérica
   */
  async sendMessage(message: WhatsAppMessage): Promise<MessageResponse> {
    try {
      const response = await this.client.messages.create({
        from: `whatsapp:${this.fromNumber}`,
        to: `whatsapp:${message.to}`,
        body: message.body,
        ...(message.mediaUrl && { mediaUrl: [message.mediaUrl] })
      });

      console.log(`✅ Mensagem enviada para ${message.to}: ${response.sid}`);

      return {
        success: true,
        sid: response.sid,
        timestamp: new Date().toISOString()
      };
    } catch (error: any) {
      console.error(`❌ Erro ao enviar mensagem: ${error.message}`);
      return {
        success: false,
        error: error.message,
        timestamp: new Date().toISOString()
      };
    }
  }

  /**
   * Testar conexão com Twilio
   */
  async testConnection(): Promise<{ success: boolean; message: string }> {
    try {
      const account = await this.client.api.accounts.list({ limit: 1 });
      return {
        success: true,
        message: `✅ Conexão com Twilio estabelecida. Account: ${account[0].sid}`
      };
    } catch (error: any) {
      return {
        success: false,
        message: `❌ Erro ao conectar com Twilio: ${error.message}`
      };
    }
  }
}

// Exportar instância singleton
export const twilioService = new TwilioWhatsAppService();
