import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface DoctorCardProps {
  name: string;
  crm: string;
  specialty: string;
  countries: string[];
  image?: string;
  rating?: number;
  consultationPrice?: string;
}

export const DoctorCard: React.FC<DoctorCardProps> = ({
  name,
  crm,
  specialty,
  countries,
  image = "/api/placeholder/80/80",
  rating = 4.8,
  consultationPrice = "R$ 30"
}) => (
  <Card className="bg-zinc-900 border-green-500/30 hover:border-green-500 transition-all duration-300 hover:shadow-lg hover:shadow-green-500/20">
    <CardContent className="p-5">
      <div className="flex justify-between items-start mb-4">
        <div className="relative">
          <img 
            src={image} 
            className="rounded-full border-2 border-green-500 w-20 h-20 object-cover" 
            alt={name} 
          />
          {/* DUAS BANDEIRAS DE ATUAÇÃO */}
          <div className="absolute -bottom-2 -right-2 flex gap-1">
            {countries.map((flag) => (
              <span key={flag} className="text-xl drop-shadow-md">{flag}</span>
            ))}
          </div>
        </div>
        <Badge className="bg-green-600 text-white">Online</Badge>
      </div>
      
      <h3 className="text-white font-bold text-lg">{name}</h3>
      <p className="text-green-400 text-sm font-medium">{specialty}</p>
      <p className="text-zinc-400 text-xs mt-1">CRM: {crm}</p>
      
      {/* Rating */}
      <div className="flex items-center gap-1 mt-2 mb-4">
        <span className="text-yellow-500">★</span>
        <span className="text-zinc-300 text-sm">{rating}</span>
      </div>
      
      <Button className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 transition-colors">
        Consultar {consultationPrice}
      </Button>
    </CardContent>
  </Card>
);

export default DoctorCard;
