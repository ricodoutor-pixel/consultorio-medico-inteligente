interface ConversionMetrics {
  totalVisitors: number;
  totalSignups: number;
  conversionRate: number;
  avgTimeOnSite: number;
  bounceRate: number;
}

interface RevenueMetrics {
  totalRevenue: number;
  totalTransactions: number;
  avgTransactionValue: number;
  monthlyRevenue: number;
  dailyRevenue: number;
}

interface SatisfactionMetrics {
  averageRating: number;
  totalReviews: number;
  satisfiedPatients: number;
  satisfactionRate: number;
  npsScore: number;
}

interface AnalyticsData {
  timestamp: number;
  conversion: ConversionMetrics;
  revenue: RevenueMetrics;
  satisfaction: SatisfactionMetrics;
}

// Armazenamento em memória
const analyticsHistory: AnalyticsData[] = [];
const MAX_HISTORY = 10000;

// Dados simulados para demonstração
let currentMetrics: AnalyticsData = {
  timestamp: Date.now(),
  conversion: {
    totalVisitors: 45000,
    totalSignups: 2250,
    conversionRate: 5.0,
    avgTimeOnSite: 4.5,
    bounceRate: 32.5,
  },
  revenue: {
    totalRevenue: 6300000,
    totalTransactions: 12600,
    avgTransactionValue: 500,
    monthlyRevenue: 525000,
    dailyRevenue: 17500,
  },
  satisfaction: {
    averageRating: 4.9,
    totalReviews: 2250,
    satisfiedPatients: 2205,
    satisfactionRate: 98.0,
    npsScore: 72,
  },
};

/**
 * Registrar evento de conversão
 */
export function recordConversion(type: 'signup' | 'consultation' | 'purchase'): void {
  currentMetrics.conversion.totalSignups++;
  currentMetrics.conversion.conversionRate =
    (currentMetrics.conversion.totalSignups / currentMetrics.conversion.totalVisitors) * 100;

  if (type === 'consultation') {
    currentMetrics.revenue.totalTransactions++;
    currentMetrics.revenue.totalRevenue += 500;
    currentMetrics.revenue.avgTransactionValue =
      currentMetrics.revenue.totalRevenue / currentMetrics.revenue.totalTransactions;
  }

  saveSnapshot();
}

/**
 * Registrar visita
 */
export function recordVisit(): void {
  currentMetrics.conversion.totalVisitors++;
  currentMetrics.conversion.conversionRate =
    (currentMetrics.conversion.totalSignups / currentMetrics.conversion.totalVisitors) * 100;
  saveSnapshot();
}

/**
 * Registrar avaliação de paciente
 */
export function recordReview(rating: number, satisfied: boolean): void {
  currentMetrics.satisfaction.totalReviews++;
  const totalRating =
    currentMetrics.satisfaction.averageRating * (currentMetrics.satisfaction.totalReviews - 1) +
    rating;
  currentMetrics.satisfaction.averageRating =
    totalRating / currentMetrics.satisfaction.totalReviews;

  if (satisfied) {
    currentMetrics.satisfaction.satisfiedPatients++;
  }

  currentMetrics.satisfaction.satisfactionRate =
    (currentMetrics.satisfaction.satisfiedPatients / currentMetrics.satisfaction.totalReviews) *
    100;

  saveSnapshot();
}

/**
 * Registrar transação de receita
 */
export function recordTransaction(amount: number): void {
  currentMetrics.revenue.totalRevenue += amount;
  currentMetrics.revenue.totalTransactions++;
  currentMetrics.revenue.avgTransactionValue =
    currentMetrics.revenue.totalRevenue / currentMetrics.revenue.totalTransactions;
  currentMetrics.revenue.dailyRevenue += amount;

  saveSnapshot();
}

/**
 * Obter métricas atuais
 */
export function getCurrentMetrics(): AnalyticsData {
  return {
    ...currentMetrics,
    timestamp: Date.now(),
  };
}

/**
 * Obter histórico de métricas
 */
export function getMetricsHistory(limit: number = 100): AnalyticsData[] {
  return analyticsHistory.slice(-limit).reverse();
}

/**
 * Obter tendências
 */
export function getTrends(period: 'daily' | 'weekly' | 'monthly' = 'daily') {
  const metrics = getCurrentMetrics();

  return {
    conversionTrend: {
      current: metrics.conversion.conversionRate,
      previous: analyticsHistory.length > 0 ? analyticsHistory[analyticsHistory.length - 1].conversion.conversionRate : 0,
      change: metrics.conversion.conversionRate - (analyticsHistory.length > 0 ? analyticsHistory[analyticsHistory.length - 1].conversion.conversionRate : 0),
    },
    revenueTrend: {
      current: metrics.revenue.totalRevenue,
      previous: analyticsHistory.length > 0 ? analyticsHistory[analyticsHistory.length - 1].revenue.totalRevenue : 0,
      change: metrics.revenue.totalRevenue - (analyticsHistory.length > 0 ? analyticsHistory[analyticsHistory.length - 1].revenue.totalRevenue : 0),
    },
    satisfactionTrend: {
      current: metrics.satisfaction.satisfactionRate,
      previous: analyticsHistory.length > 0 ? analyticsHistory[analyticsHistory.length - 1].satisfaction.satisfactionRate : 0,
      change: metrics.satisfaction.satisfactionRate - (analyticsHistory.length > 0 ? analyticsHistory[analyticsHistory.length - 1].satisfaction.satisfactionRate : 0),
    },
  };
}

/**
 * Obter resumo executivo
 */
export function getExecutiveSummary() {
  const metrics = getCurrentMetrics();
  const trends = getTrends();

  return {
    overview: {
      totalVisitors: metrics.conversion.totalVisitors,
      totalSignups: metrics.conversion.totalSignups,
      totalRevenue: metrics.revenue.totalRevenue,
      totalPatients: metrics.satisfaction.totalReviews,
    },
    performance: {
      conversionRate: metrics.conversion.conversionRate,
      avgTransactionValue: metrics.revenue.avgTransactionValue,
      satisfactionRate: metrics.satisfaction.satisfactionRate,
      npsScore: metrics.satisfaction.npsScore,
    },
    trends,
    timestamp: Date.now(),
  };
}

/**
 * Salvar snapshot de métricas
 */
function saveSnapshot(): void {
  analyticsHistory.push({
    ...currentMetrics,
    timestamp: Date.now(),
  });

  if (analyticsHistory.length > MAX_HISTORY) {
    analyticsHistory.shift();
  }
}

/**
 * Resetar métricas diárias
 */
export function resetDailyMetrics(): void {
  currentMetrics.revenue.dailyRevenue = 0;
  currentMetrics.conversion.totalVisitors = 0;
  saveSnapshot();
}

export const AnalyticsService = {
  recordConversion,
  recordVisit,
  recordReview,
  recordTransaction,
  getCurrentMetrics,
  getMetricsHistory,
  getTrends,
  getExecutiveSummary,
  resetDailyMetrics,
};
