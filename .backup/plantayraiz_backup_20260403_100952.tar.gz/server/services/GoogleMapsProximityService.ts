import { EventEmitter } from 'events';

interface Location {
  latitude: number;
  longitude: number;
  address?: string;
}

interface DoctorLocation extends Location {
  doctorId: string;
  doctorName: string;
  specialty: string;
  available: boolean;
  score: number;
}

interface PatientLocation extends Location {
  patientId: string;
  patientName: string;
}

interface ProximityMatch {
  doctorId: string;
  doctorName: string;
  specialty: string;
  distance: number; // in kilometers
  estimatedTime: number; // in minutes
  score: number;
  available: boolean;
}

export class GoogleMapsProximityService extends EventEmitter {
  private static instance: GoogleMapsProximityService;
  private doctorLocations: Map<string, DoctorLocation> = new Map();
  private patientLocations: Map<string, PatientLocation> = new Map();

  private constructor() {
    super();
    this.setMaxListeners(100);
    this.initializeMockLocations();
  }

  static getInstance(): GoogleMapsProximityService {
    if (!GoogleMapsProximityService.instance) {
      GoogleMapsProximityService.instance = new GoogleMapsProximityService();
    }
    return GoogleMapsProximityService.instance;
  }

  /**
   * Initialize mock locations for testing
   */
  private initializeMockLocations(): void {
    // Dr. Edilson Bezerra - São Paulo
    this.doctorLocations.set('doc-001', {
      doctorId: 'doc-001',
      doctorName: 'Dr. Edilson Bezerra',
      specialty: 'Clínica Geral',
      latitude: -23.5505,
      longitude: -46.6333,
      address: 'São Paulo, SP',
      available: true,
      score: 98,
    });

    // Mock patient in São Paulo
    this.patientLocations.set('pat-001', {
      patientId: 'pat-001',
      patientName: 'João Silva',
      latitude: -23.5521,
      longitude: -46.6333,
      address: 'São Paulo, SP',
    });

    // Mock patient in Rio de Janeiro
    this.patientLocations.set('pat-002', {
      patientId: 'pat-002',
      patientName: 'Maria Santos',
      latitude: -22.9068,
      longitude: -43.1729,
      address: 'Rio de Janeiro, RJ',
    });
  }

  /**
   * Update doctor location
   */
  updateDoctorLocation(
    doctorId: string,
    doctorName: string,
    specialty: string,
    latitude: number,
    longitude: number,
    address?: string,
    available: boolean = true,
    score: number = 50
  ): DoctorLocation {
    const location: DoctorLocation = {
      doctorId,
      doctorName,
      specialty,
      latitude,
      longitude,
      address,
      available,
      score,
    };

    this.doctorLocations.set(doctorId, location);
    this.emit('doctor:location-updated', { doctorId, location });

    return location;
  }

  /**
   * Update patient location
   */
  updatePatientLocation(
    patientId: string,
    patientName: string,
    latitude: number,
    longitude: number,
    address?: string
  ): PatientLocation {
    const location: PatientLocation = {
      patientId,
      patientName,
      latitude,
      longitude,
      address,
    };

    this.patientLocations.set(patientId, location);
    this.emit('patient:location-updated', { patientId, location });

    return location;
  }

  /**
   * Calculate distance between two points using Haversine formula
   */
  private calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371; // Earth's radius in kilometers
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  /**
   * Estimate travel time (simplified: 1 km = 2 minutes)
   */
  private estimateTravelTime(distanceKm: number): number {
    return Math.ceil(distanceKm * 2);
  }

  /**
   * Find nearby doctors for a patient
   */
  findNearbyDoctors(
    patientId: string,
    radiusKm: number = 10,
    specialty?: string
  ): ProximityMatch[] {
    const patientLocation = this.patientLocations.get(patientId);
    if (!patientLocation) {
      return [];
    }

    const matches: ProximityMatch[] = [];

    for (const doctor of this.doctorLocations.values()) {
      // Filter by specialty if provided
      if (specialty && doctor.specialty.toLowerCase() !== specialty.toLowerCase()) {
        continue;
      }

      // Calculate distance
      const distance = this.calculateDistance(
        patientLocation.latitude,
        patientLocation.longitude,
        doctor.latitude,
        doctor.longitude
      );

      // Check if within radius
      if (distance > radiusKm) {
        continue;
      }

      // Calculate estimated time
      const estimatedTime = this.estimateTravelTime(distance);

      matches.push({
        doctorId: doctor.doctorId,
        doctorName: doctor.doctorName,
        specialty: doctor.specialty,
        distance: Math.round(distance * 100) / 100,
        estimatedTime,
        score: doctor.score,
        available: doctor.available,
      });
    }

    // Sort by distance
    matches.sort((a, b) => a.distance - b.distance);

    this.emit('doctors:found', { patientId, count: matches.length, radiusKm });

    return matches;
  }

  /**
   * Find best doctor match for patient (considering distance, score, availability)
   */
  findBestDoctorMatch(patientId: string, specialty?: string): ProximityMatch | null {
    const nearbyDoctors = this.findNearbyDoctors(patientId, 50, specialty);

    if (nearbyDoctors.length === 0) {
      return null;
    }

    // Score calculation: 40% distance, 40% doctor score, 20% availability
    const scoredDoctors = nearbyDoctors.map((doctor) => {
      const distanceScore = Math.max(0, 100 - doctor.distance * 2); // Closer = higher score
      const availabilityScore = doctor.available ? 100 : 0;
      const finalScore =
        distanceScore * 0.4 + doctor.score * 0.4 + availabilityScore * 0.2;

      return { ...doctor, finalScore };
    });

    // Sort by final score
    scoredDoctors.sort((a, b) => b.finalScore - a.finalScore);

    const bestMatch = scoredDoctors[0];

    this.emit('best-match:found', { patientId, doctorId: bestMatch.doctorId });

    return {
      doctorId: bestMatch.doctorId,
      doctorName: bestMatch.doctorName,
      specialty: bestMatch.specialty,
      distance: bestMatch.distance,
      estimatedTime: bestMatch.estimatedTime,
      score: bestMatch.score,
      available: bestMatch.available,
    };
  }

  /**
   * Get all doctor locations
   */
  getAllDoctorLocations(): DoctorLocation[] {
    return Array.from(this.doctorLocations.values());
  }

  /**
   * Get doctor location
   */
  getDoctorLocation(doctorId: string): DoctorLocation | null {
    return this.doctorLocations.get(doctorId) || null;
  }

  /**
   * Get patient location
   */
  getPatientLocation(patientId: string): PatientLocation | null {
    return this.patientLocations.get(patientId) || null;
  }

  /**
   * Get doctors by region/state
   */
  getDoctorsByRegion(latitude: number, longitude: number, radiusKm: number = 50): DoctorLocation[] {
    const doctors: DoctorLocation[] = [];

    for (const doctor of this.doctorLocations.values()) {
      const distance = this.calculateDistance(latitude, longitude, doctor.latitude, doctor.longitude);
      if (distance <= radiusKm) {
        doctors.push(doctor);
      }
    }

    return doctors.sort((a, b) => {
      const distA = this.calculateDistance(latitude, longitude, a.latitude, a.longitude);
      const distB = this.calculateDistance(latitude, longitude, b.latitude, b.longitude);
      return distA - distB;
    });
  }

  /**
   * Get statistics
   */
  getStats(): {
    totalDoctors: number;
    totalPatients: number;
    averageDoctorScore: number;
    availableDoctors: number;
  } {
    const doctors = Array.from(this.doctorLocations.values());
    const patients = Array.from(this.patientLocations.values());

    const totalScore = doctors.reduce((sum, d) => sum + d.score, 0);
    const averageScore = doctors.length > 0 ? totalScore / doctors.length : 0;
    const availableCount = doctors.filter((d) => d.available).length;

    return {
      totalDoctors: doctors.length,
      totalPatients: patients.length,
      averageDoctorScore: Math.round(averageScore * 100) / 100,
      availableDoctors: availableCount,
    };
  }
}

export const googleMapsProximityService = GoogleMapsProximityService.getInstance();
