// ============================================================================
// CHANGE TRACKING DASHBOARD — Dashboard de Rastreamento de Mudanças
// Planta & Raiz 3.0 — Gerenciamento Autônomo
// ============================================================================

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import {
  GitBranch,
  GitCommit,
  AlertCircle,
  CheckCircle,
  Clock,
  TrendingUp,
  Users,
  FileText,
} from 'lucide-react';

interface ChangeLog {
  id: string;
  timestamp: number;
  type: 'feat' | 'fix' | 'docs' | 'chore' | 'test';
  message: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  filesChanged: number;
  linesAdded: number;
  linesRemoved: number;
}

interface DashboardMetrics {
  totalCommits: number;
  filesModified: number;
  linesAdded: number;
  linesRemoved: number;
  uptime: number;
  errorRate: number;
  avgResponseTime: number;
  activeUsers: number;
}

export const ChangeTrackingDashboard: React.FC = () => {
  const [metrics, setMetrics] = useState<DashboardMetrics>({
    totalCommits: 0,
    filesModified: 0,
    linesAdded: 0,
    linesRemoved: 0,
    uptime: 99.8,
    errorRate: 0.02,
    avgResponseTime: 245,
    activeUsers: 1245,
  });

  const [changeLogs, setChangeLogs] = useState<ChangeLog[]>([
    {
      id: '1',
      timestamp: Date.now() - 15 * 60000,
      type: 'feat',
      message: 'ErrorMonitoringService implementado',
      severity: 'high',
      filesChanged: 3,
      linesAdded: 245,
      linesRemoved: 0,
    },
    {
      id: '2',
      timestamp: Date.now() - 30 * 60000,
      type: 'fix',
      message: 'ReferralProgramComponent import corrigido',
      severity: 'medium',
      filesChanged: 1,
      linesAdded: 5,
      linesRemoved: 2,
    },
    {
      id: '3',
      timestamp: Date.now() - 45 * 60000,
      type: 'chore',
      message: 'Aumentar limite de memória Node.js',
      severity: 'low',
      filesChanged: 1,
      linesAdded: 1,
      linesRemoved: 1,
    },
  ]);

  const [commitsByType, setCommitsByType] = useState([
    { name: 'feat', value: 45 },
    { name: 'fix', value: 30 },
    { name: 'docs', value: 10 },
    { name: 'chore', value: 8 },
    { name: 'test', value: 7 },
  ]);

  const [performanceData, setPerformanceData] = useState([
    { time: '00:00', uptime: 99.9, errorRate: 0.01 },
    { time: '04:00', uptime: 99.8, errorRate: 0.02 },
    { time: '08:00', uptime: 99.7, errorRate: 0.03 },
    { time: '12:00', uptime: 99.8, errorRate: 0.02 },
    { time: '16:00', uptime: 99.9, errorRate: 0.01 },
    { time: '20:00', uptime: 99.8, errorRate: 0.02 },
  ]);

  const COLORS = ['#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#3b82f6'];

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'bg-red-500';
      case 'high':
        return 'bg-orange-500';
      case 'medium':
        return 'bg-yellow-500';
      case 'low':
        return 'bg-green-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'feat':
        return '✨';
      case 'fix':
        return '🐛';
      case 'docs':
        return '📚';
      case 'chore':
        return '⚙️';
      case 'test':
        return '🧪';
      default:
        return '📝';
    }
  };

  return (
    <div className="w-full space-y-6 p-6 bg-background">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-foreground">
          📊 Painel de Rastreamento de Mudanças
        </h1>
        <Badge variant="outline" className="text-green-500">
          🟢 Sistema Operacional
        </Badge>
      </div>

      {/* Métricas Principais */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total de Commits
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold">{metrics.totalCommits}</div>
              <GitCommit className="w-8 h-8 text-blue-500" />
            </div>
            <p className="text-xs text-muted-foreground mt-2">+5 hoje</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Arquivos Modificados
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold">{metrics.filesModified}</div>
              <FileText className="w-8 h-8 text-purple-500" />
            </div>
            <p className="text-xs text-muted-foreground mt-2">+12 hoje</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Uptime
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold">{metrics.uptime}%</div>
              <CheckCircle className="w-8 h-8 text-green-500" />
            </div>
            <p className="text-xs text-muted-foreground mt-2">Excelente</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Taxa de Erro
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold">{metrics.errorRate}%</div>
              <AlertCircle className="w-8 h-8 text-green-500" />
            </div>
            <p className="text-xs text-muted-foreground mt-2">Normal</p>
          </CardContent>
        </Card>
      </div>

      {/* Gráficos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Commits por Tipo */}
        <Card>
          <CardHeader>
            <CardTitle>Commits por Tipo</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={commitsByType}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {commitsByType.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Performance ao Longo do Tempo */}
        <Card>
          <CardHeader>
            <CardTitle>Performance (Últimas 24h)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="uptime"
                  stroke="#10b981"
                  name="Uptime (%)"
                />
                <Line
                  type="monotone"
                  dataKey="errorRate"
                  stroke="#ef4444"
                  name="Taxa Erro (%)"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Últimas Mudanças */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Últimas Mudanças
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {changeLogs.map((log) => (
              <div
                key={log.id}
                className="flex items-start gap-4 p-3 rounded-lg border border-border hover:bg-accent transition"
              >
                <div className="text-2xl">{getTypeIcon(log.type)}</div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-medium text-foreground">{log.message}</span>
                    <Badge
                      variant="outline"
                      className={`text-xs ${getSeverityColor(log.severity)}`}
                    >
                      {log.severity}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span>
                      📁 {log.filesChanged} arquivo{log.filesChanged !== 1 ? 's' : ''}
                    </span>
                    <span className="text-green-600">+{log.linesAdded} linhas</span>
                    <span className="text-red-600">-{log.linesRemoved} linhas</span>
                    <span>
                      {new Date(log.timestamp).toLocaleTimeString('pt-BR')}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Status de Sincronização */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <GitBranch className="w-5 h-5" />
            Status de Sincronização
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-lg bg-green-50 border border-green-200">
              <h3 className="font-medium text-green-900 mb-2">Local</h3>
              <p className="text-sm text-green-700">✅ Sincronizado</p>
              <p className="text-xs text-green-600 mt-1">Última atualização: agora</p>
            </div>
            <div className="p-4 rounded-lg bg-blue-50 border border-blue-200">
              <h3 className="font-medium text-blue-900 mb-2">GitHub</h3>
              <p className="text-sm text-blue-700">✅ Atualizado</p>
              <p className="text-xs text-blue-600 mt-1">Branch: main</p>
            </div>
            <div className="p-4 rounded-lg bg-purple-50 border border-purple-200">
              <h3 className="font-medium text-purple-900 mb-2">Hostinger</h3>
              <p className="text-sm text-purple-700">✅ Em produção</p>
              <p className="text-xs text-purple-600 mt-1">Versão: 02500a15</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ChangeTrackingDashboard;
