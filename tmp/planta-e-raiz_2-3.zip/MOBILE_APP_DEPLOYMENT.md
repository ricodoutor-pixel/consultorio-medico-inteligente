# 📱 PLANTA & RAIZ - MOBILE APP DEPLOYMENT GUIDE

## 1. PREPARAÇÃO PARA BUILD

### 1.1 Configurar EAS CLI
```bash
npm install -g eas-cli
eas login
eas whoami
```

### 1.2 Configurar Credenciais
```bash
# iOS - Apple Developer Account
eas credentials configure --platform ios

# Android - Google Play Console
eas credentials configure --platform android
```

### 1.3 Configurar app.json
```json
{
  "expo": {
    "name": "Planta & Raiz",
    "slug": "planta-raiz",
    "version": "1.0.0",
    "orientation": "portrait",
    "icon": "./assets/icon.png",
    "userInterfaceStyle": "dark",
    "splash": {
      "image": "./assets/splash.png",
      "resizeMode": "contain",
      "backgroundColor": "#000000"
    },
    "assetBundlePatterns": ["**/*"],
    "ios": {
      "supportsTabletMode": true,
      "bundleIdentifier": "com.plantaraiz.app"
    },
    "android": {
      "adaptiveIcon": {
        "foregroundImage": "./assets/adaptive-icon.png",
        "backgroundColor": "#000000"
      },
      "package": "com.plantaraiz.app"
    },
    "plugins": [
      "expo-notifications",
      "expo-local-authentication"
    ]
  }
}
```

## 2. BUILD PARA PRODUÇÃO

### 2.1 Build iOS
```bash
# Gerar build para App Store
eas build --platform ios --auto-submit

# Ou build manual
eas build --platform ios
```

### 2.2 Build Android
```bash
# Gerar build para Google Play
eas build --platform android --auto-submit

# Ou build manual
eas build --platform android
```

### 2.3 Build Universal
```bash
# Build para iOS + Android simultaneamente
eas build --platform all
```

## 3. SUBMISSÃO PARA LOJAS

### 3.1 App Store (iOS)

1. **Preparar Metadados**
   - Nome do app: "Planta & Raiz"
   - Descrição: "Democratizando o acesso a medicamentos à base de cannabis"
   - Categoria: Medical
   - Rating: 17+

2. **Submeter Build**
   ```bash
   eas submit --platform ios
   ```

3. **Aguardar Aprovação**
   - Tempo médio: 24-48 horas
   - Apple revisa conformidade, segurança e conteúdo

### 3.2 Google Play (Android)

1. **Preparar Metadados**
   - Nome: "Planta & Raiz"
   - Descrição: "Telemedicina + Cannabis Medicinal"
   - Categoria: Medical
   - Conteúdo: +18 anos

2. **Submeter Build**
   ```bash
   eas submit --platform android
   ```

3. **Aguardar Aprovação**
   - Tempo médio: 2-4 horas
   - Google revisa automaticamente

## 4. CONFIGURAÇÃO DE NOTIFICAÇÕES PUSH

### 4.1 Expo Push Notifications
```bash
npm install expo-notifications
```

### 4.2 Configurar Credenciais
```bash
eas credentials configure --platform ios --service apns
eas credentials configure --platform android --service fcm
```

### 4.3 Implementar no App
```typescript
import * as Notifications from 'expo-notifications';

// Registrar para notificações
const token = await Notifications.getExpoPushTokenAsync();

// Enviar notificação
await Notifications.scheduleNotificationAsync({
  content: {
    title: "Nova Consulta Disponível",
    body: "Dr. Silva está online agora",
    data: { consultationId: '123' }
  },
  trigger: { seconds: 60 }
});
```

## 5. MONITORAMENTO E ANALYTICS

### 5.1 Integrar Sentry
```bash
npm install @sentry/react-native
```

### 5.2 Configurar Analytics
```typescript
import * as Analytics from 'expo-firebase-analytics';

Analytics.logEvent('consultation_started', {
  specialistId: '123',
  duration: 30
});
```

## 6. DISTRIBUIÇÃO BETA

### 6.1 TestFlight (iOS)
```bash
eas build --platform ios
# Submeter para TestFlight automaticamente
eas submit --platform ios --latest
```

### 6.2 Google Play Beta
```bash
eas build --platform android
# Criar track beta em Google Play Console
# Submeter build para beta testing
```

## 7. VERSIONING E UPDATES

### 7.1 Atualizar Versão
```bash
# Atualizar app.json
{
  "expo": {
    "version": "1.0.1"
  }
}

# Criar novo build
eas build --platform all
```

### 7.2 Over-the-Air Updates
```bash
npm install expo-updates

# Publicar update
eas update --branch production
```

## 8. CHECKLIST PRÉ-LANÇAMENTO

- [ ] Testar em iOS 14+ e Android 10+
- [ ] Verificar permissões (câmera, microfone, localização)
- [ ] Testar notificações push
- [ ] Verificar autenticação biométrica
- [ ] Testar offline-first sync
- [ ] Verificar conformidade LGPD/ANVISA
- [ ] Testar fluxo de pagamento PIX
- [ ] Testar integração com especialistas
- [ ] Verificar performance em conexão 3G
- [ ] Testar com 10+ dispositivos reais
- [ ] Preparar screenshots para lojas
- [ ] Preparar descrição e keywords
- [ ] Configurar política de privacidade
- [ ] Configurar termos de serviço

## 9. PÓS-LANÇAMENTO

### 9.1 Monitorar Crashes
```bash
# Verificar logs no Sentry
# Alertas automáticos para crashes críticos
```

### 9.2 Coletar Feedback
- In-app ratings
- Feedback form
- Support email

### 9.3 Otimizar Conversão
- A/B testing de onboarding
- Analytics de retenção
- Otimizar funnel de consultas

## 10. COMANDOS RÁPIDOS

```bash
# Verificar status de builds
eas build:list

# Cancelar build
eas build:cancel <build-id>

# Verificar credenciais
eas credentials show --platform ios

# Limpar cache
eas build:cache:list
eas build:cache:delete

# Logs de build
eas build:view <build-id>
```

## 11. TROUBLESHOOTING

### Build falha no iOS
```bash
# Limpar cache e tentar novamente
eas build --platform ios --clear-cache
```

### Build falha no Android
```bash
# Verificar versão do Android SDK
eas build --platform android --clear-cache
```

### Notificações não funcionam
```bash
# Verificar token de push
console.log(await Notifications.getExpoPushTokenAsync());

# Verificar permissões
Notifications.requestPermissionsAsync()
```

---

**Próximos Passos:**
1. Executar `eas build --platform all` para gerar builds
2. Submeter para App Store e Google Play
3. Monitorar aprovação e lançamento
4. Coletar feedback de usuários beta
5. Otimizar baseado em analytics
