/**
 * Shared Cannabis Types
 */

export interface CannabisStrain {
  id: number;
  name: string;
  type: "Sativa" | "Indica" | "Hybrid";
  thcPercentage: number;
  cbdPercentage: number;
  effects: string[];
  medicalBenefits: string[];
  flavors: string[];
  origin: string;
  growthDifficulty: "Easy" | "Medium" | "Hard";
  floweringTime: number;
  yield: string;
  indoorHeight: string;
  outdoorYield: string;
  description: string;
  scientificBenefits: string;
  imageUrl?: string;
  rating: number;
  reviews: number;
}

export const strainTypes = ["Sativa", "Indica", "Hybrid"];

export const medicalConditions = [
  "Pain",
  "Anxiety",
  "Insomnia",
  "Depression",
  "Inflammation",
  "Epilepsy",
  "Nausea",
  "PTSD",
  "ADHD",
  "Migraines",
  "Stress",
  "Fatigue",
  "Cancer symptoms",
  "Arthritis",
  "Muscle spasms"
];

export const effects = [
  "Relaxing",
  "Uplifting",
  "Creative",
  "Focused",
  "Happy",
  "Energetic",
  "Calm",
  "Euphoric",
  "Clear-headed",
  "Sleepy",
  "Meditative",
  "Talkative"
];

export const flavors = [
  "Earthy",
  "Citrus",
  "Sweet",
  "Pine",
  "Herbal",
  "Spicy",
  "Fruity",
  "Floral",
  "Diesel",
  "Minty"
];
