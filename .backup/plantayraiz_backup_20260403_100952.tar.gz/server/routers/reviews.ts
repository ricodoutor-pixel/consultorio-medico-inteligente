import { router, protectedProcedure } from '../_core/trpc';
import { z } from 'zod';
import { reviewsService } from '../services/ReviewsService';

export const reviewsRouter = router({
  /**
   * Submit a review for a consultation
   */
  submitReview: protectedProcedure
    .input(
      z.object({
        consultationId: z.string(),
        doctorId: z.string(),
        rating: z.number().min(1).max(5),
        title: z.string().min(5).max(100),
        comment: z.string().min(10).max(1000),
        tags: z.array(z.string()).optional(),
      })
    )
    .mutation(({ input, ctx }) => {
      const review = reviewsService.submitReview(
        input.consultationId,
        ctx.user.id,
        input.doctorId,
        input.rating,
        input.title,
        input.comment,
        input.tags || []
      );

      return {
        success: true,
        data: review,
      };
    }),

  /**
   * Get reviews for a doctor
   */
  getDoctorReviews: protectedProcedure
    .input(
      z.object({
        doctorId: z.string(),
        limit: z.number().default(50),
      })
    )
    .query(({ input }) => {
      const reviews = reviewsService.getDoctorReviews(input.doctorId, input.limit);

      return {
        success: true,
        data: reviews,
      };
    }),

  /**
   * Get doctor rating summary
   */
  getDoctorRating: protectedProcedure
    .input(
      z.object({
        doctorId: z.string(),
      })
    )
    .query(({ input }) => {
      const rating = reviewsService.getDoctorRating(input.doctorId);

      return {
        success: true,
        data: rating,
      };
    }),

  /**
   * Mark review as helpful
   */
  markHelpful: protectedProcedure
    .input(
      z.object({
        reviewId: z.string(),
        doctorId: z.string(),
      })
    )
    .mutation(({ input }) => {
      const success = reviewsService.markHelpful(input.reviewId, input.doctorId);

      return {
        success,
        message: success ? 'Review marked as helpful' : 'Review not found',
      };
    }),

  /**
   * Mark review as not helpful
   */
  markNotHelpful: protectedProcedure
    .input(
      z.object({
        reviewId: z.string(),
        doctorId: z.string(),
      })
    )
    .mutation(({ input }) => {
      const success = reviewsService.markNotHelpful(input.reviewId, input.doctorId);

      return {
        success,
        message: success ? 'Review marked as not helpful' : 'Review not found',
      };
    }),

  /**
   * Get reviews by rating
   */
  getReviewsByRating: protectedProcedure
    .input(
      z.object({
        doctorId: z.string(),
        rating: z.number().min(1).max(5),
      })
    )
    .query(({ input }) => {
      const reviews = reviewsService.getReviewsByRating(input.doctorId, input.rating);

      return {
        success: true,
        data: reviews,
      };
    }),

  /**
   * Search reviews by keyword
   */
  searchReviews: protectedProcedure
    .input(
      z.object({
        doctorId: z.string(),
        keyword: z.string(),
      })
    )
    .query(({ input }) => {
      const reviews = reviewsService.searchReviews(input.doctorId, input.keyword);

      return {
        success: true,
        data: reviews,
      };
    }),

  /**
   * Get reviews by tag
   */
  getReviewsByTag: protectedProcedure
    .input(
      z.object({
        doctorId: z.string(),
        tag: z.string(),
      })
    )
    .query(({ input }) => {
      const reviews = reviewsService.getReviewsByTag(input.doctorId, input.tag);

      return {
        success: true,
        data: reviews,
      };
    }),

  /**
   * Get top doctors by rating
   */
  getTopDoctors: protectedProcedure
    .input(
      z.object({
        limit: z.number().default(10),
      })
    )
    .query(({ input }) => {
      const doctors = reviewsService.getTopDoctors(input.limit);

      return {
        success: true,
        data: doctors,
      };
    }),

  /**
   * Get doctors by minimum rating
   */
  getDoctorsByMinRating: protectedProcedure
    .input(
      z.object({
        minRating: z.number().min(1).max(5),
      })
    )
    .query(({ input }) => {
      const doctors = reviewsService.getDoctorsByMinRating(input.minRating);

      return {
        success: true,
        data: doctors,
      };
    }),

  /**
   * Get review statistics
   */
  getStats: protectedProcedure.query(() => {
    const stats = reviewsService.getStats();

    return {
      success: true,
      data: stats,
    };
  }),
});
