import { z } from 'zod';

// Common schemas
export const IdSchema = z.string().uuid().or(z.string().min(1));
export const EmailSchema = z.string().email();
export const PhoneSchema = z.string().regex(/^\+?[1-9]\d{1,14}$/);
export const UrlSchema = z.string().url();
export const DateSchema = z.date().or(z.string().datetime());

// User schemas
export const UserCreateSchema = z.object({
  email: EmailSchema,
  name: z.string().min(2).max(255),
  phone: PhoneSchema.optional(),
  role: z.enum(['user', 'admin', 'doctor']).default('user'),
});

export const UserUpdateSchema = z.object({
  name: z.string().min(2).max(255).optional(),
  phone: PhoneSchema.optional(),
  avatar: UrlSchema.optional(),
});

// Doctor schemas
export const DoctorCreateSchema = z.object({
  userId: IdSchema,
  crm: z.string().min(5).max(20),
  specialty: z.string().min(2).max(100),
  bio: z.string().max(1000).optional(),
  languages: z.array(z.string()).optional(),
  hourlyRate: z.number().positive(),
});

// Consultation schemas
export const ConsultationCreateSchema = z.object({
  doctorId: IdSchema,
  patientId: IdSchema,
  scheduledAt: DateSchema,
  type: z.enum(['video', 'audio', 'chat']).default('video'),
  reason: z.string().min(10).max(500),
});

export const ConsultationUpdateSchema = z.object({
  status: z.enum(['scheduled', 'in_progress', 'completed', 'cancelled']).optional(),
  notes: z.string().max(1000).optional(),
});

// Payment schemas
export const PaymentCreateSchema = z.object({
  consultationId: IdSchema.optional(),
  productId: IdSchema.optional(),
  amount: z.number().positive(),
  currency: z.string().length(3).default('BRL'),
  method: z.enum(['mercadopago', 'pix', 'credit_card', 'bank_transfer']),
  description: z.string().max(255),
});

export const PaymentWebhookSchema = z.object({
  id: z.string(),
  type: z.string(),
  data: z.record(z.unknown()),
});

// Product schemas
export const ProductCreateSchema = z.object({
  name: z.string().min(2).max(255),
  description: z.string().max(1000),
  price: z.number().positive(),
  category: z.string().min(2).max(100),
  images: z.array(UrlSchema).optional(),
  stock: z.number().int().nonnegative().default(0),
});

export const ProductUpdateSchema = z.object({
  name: z.string().min(2).max(255).optional(),
  description: z.string().max(1000).optional(),
  price: z.number().positive().optional(),
  stock: z.number().int().nonnegative().optional(),
});

// Pagination schemas
export const PaginationSchema = z.object({
  page: z.number().int().positive().default(1),
  limit: z.number().int().positive().max(100).default(10),
  sort: z.string().optional(),
  order: z.enum(['asc', 'desc']).default('asc'),
});

// Query parameter schemas
export const QueryParamsSchema = z.object({
  search: z.string().optional(),
  filter: z.record(z.unknown()).optional(),
  ...PaginationSchema.shape,
});

// Error response schema
export const ErrorResponseSchema = z.object({
  error: z.string(),
  code: z.string(),
  details: z.unknown().optional(),
});

// Success response schema
export const SuccessResponseSchema = z.object({
  success: z.literal(true),
  data: z.unknown().optional(),
  message: z.string().optional(),
});

// Type exports
export type User = z.infer<typeof UserCreateSchema>;
export type Doctor = z.infer<typeof DoctorCreateSchema>;
export type Consultation = z.infer<typeof ConsultationCreateSchema>;
export type Payment = z.infer<typeof PaymentCreateSchema>;
export type Product = z.infer<typeof ProductCreateSchema>;
export type PaginationParams = z.infer<typeof PaginationSchema>;
export type QueryParams = z.infer<typeof QueryParamsSchema>;
