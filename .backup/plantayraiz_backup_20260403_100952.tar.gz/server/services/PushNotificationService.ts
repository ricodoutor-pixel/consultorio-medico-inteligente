import webpush from 'web-push';

interface PushSubscription {
  endpoint: string;
  keys: {
    p256dh: string;
    auth: string;
  };
}

interface NotificationPayload {
  title: string;
  body: string;
  icon?: string;
  badge?: string;
  tag?: string;
  url?: string;
  type?: 'consultation' | 'payment' | 'prescription' | 'general';
  image?: string;
  requireInteraction?: boolean;
  actions?: Array<{
    action: string;
    title: string;
  }>;
}

export class PushNotificationService {
  private vapidPublicKey: string;
  private vapidPrivateKey: string;

  constructor() {
    this.vapidPublicKey = process.env.VITE_VAPID_PUBLIC_KEY || '';
    this.vapidPrivateKey = process.env.VAPID_PRIVATE_KEY || '';

    if (!this.vapidPublicKey || !this.vapidPrivateKey) {
      console.warn('[Push] VAPID keys not configured. Push notifications disabled.');
    } else {
      webpush.setVapidDetails(
        'mailto:contato@plantayraiz.com.br',
        this.vapidPublicKey,
        this.vapidPrivateKey
      );
    }
  }

  /**
   * Enviar notificação de consulta
   */
  async sendConsultationNotification(
    subscription: PushSubscription,
    data: {
      patientName: string;
      doctorName: string;
      date: string;
      time: string;
      value: number;
      consultationId: string;
    }
  ): Promise<boolean> {
    const payload: NotificationPayload = {
      title: '🏥 Nova Consulta - Planta y Raiz',
      body: `${data.patientName} agendou uma consulta com você em ${data.date} às ${data.time}`,
      icon: '/logo.png',
      badge: '/logo.png',
      tag: `consultation-${data.consultationId}`,
      url: `/consultation/${data.consultationId}`,
      type: 'consultation',
      requireInteraction: true,
      actions: [
        {
          action: 'accept',
          title: 'Aceitar',
        },
        {
          action: 'decline',
          title: 'Recusar',
        },
      ],
    };

    return this.sendNotification(subscription, payload);
  }

  /**
   * Enviar notificação de pagamento
   */
  async sendPaymentNotification(
    subscription: PushSubscription,
    data: {
      userName: string;
      amount: number;
      status: 'approved' | 'pending' | 'failed';
      paymentId: string;
    }
  ): Promise<boolean> {
    const statusEmoji = {
      approved: '✅',
      pending: '⏳',
      failed: '❌',
    }[data.status];

    const statusText = {
      approved: 'aprovado',
      pending: 'pendente',
      failed: 'falhou',
    }[data.status];

    const payload: NotificationPayload = {
      title: `${statusEmoji} Pagamento ${statusText}`,
      body: `Seu pagamento de R$ ${data.amount.toFixed(2)} foi ${statusText}`,
      icon: '/logo.png',
      badge: '/logo.png',
      tag: `payment-${data.paymentId}`,
      url: `/payments/${data.paymentId}`,
      type: 'payment',
    };

    return this.sendNotification(subscription, payload);
  }

  /**
   * Enviar notificação de prescrição
   */
  async sendPrescriptionNotification(
    subscription: PushSubscription,
    data: {
      userName: string;
      doctorName: string;
      medications: string[];
      prescriptionId: string;
    }
  ): Promise<boolean> {
    const payload: NotificationPayload = {
      title: '💊 Prescrição Disponível',
      body: `Dr. ${data.doctorName} enviou uma prescrição com ${data.medications.length} medicamento(s)`,
      icon: '/logo.png',
      badge: '/logo.png',
      tag: `prescription-${data.prescriptionId}`,
      url: `/prescription/${data.prescriptionId}`,
      type: 'prescription',
      requireInteraction: true,
    };

    return this.sendNotification(subscription, payload);
  }

  /**
   * Enviar notificação de lembrete
   */
  async sendReminderNotification(
    subscription: PushSubscription,
    data: {
      consultationDate: string;
      consultationTime: string;
      doctorName: string;
      consultationId: string;
    }
  ): Promise<boolean> {
    const payload: NotificationPayload = {
      title: '⏰ Lembrete de Consulta',
      body: `Sua consulta com Dr. ${data.doctorName} é em 1 hora (${data.consultationTime})`,
      icon: '/logo.png',
      badge: '/logo.png',
      tag: `reminder-${data.consultationId}`,
      url: `/consultation/${data.consultationId}`,
      type: 'general',
      requireInteraction: true,
    };

    return this.sendNotification(subscription, payload);
  }

  /**
   * Enviar notificação genérica
   */
  async sendNotification(
    subscription: PushSubscription,
    payload: NotificationPayload
  ): Promise<boolean> {
    if (!this.vapidPrivateKey) {
      console.warn('[Push] VAPID keys not configured. Cannot send notification.');
      return false;
    }

    try {
      const message = {
        title: payload.title,
        body: payload.body,
        icon: payload.icon || '/logo.png',
        badge: payload.badge || '/logo.png',
        tag: payload.tag || 'notification',
        url: payload.url || '/',
        type: payload.type || 'general',
        image: payload.image,
        requireInteraction: payload.requireInteraction || false,
        actions: payload.actions,
      };

      await webpush.sendNotification(subscription, JSON.stringify(message));

      console.log('[Push] Notification sent successfully:', {
        title: payload.title,
        endpoint: subscription.endpoint.substring(0, 50) + '...',
      });

      return true;
    } catch (error: any) {
      if (error.statusCode === 410) {
        // Subscription expirou
        console.warn('[Push] Subscription expired:', error.message);
        return false;
      }

      console.error('[Push] Failed to send notification:', error.message);
      return false;
    }
  }

  /**
   * Enviar notificação para múltiplas subscrições
   */
  async sendBulkNotification(
    subscriptions: PushSubscription[],
    payload: NotificationPayload
  ): Promise<{ success: number; failed: number }> {
    let success = 0;
    let failed = 0;

    for (const subscription of subscriptions) {
      const result = await this.sendNotification(subscription, payload);
      if (result) {
        success++;
      } else {
        failed++;
      }
    }

    return { success, failed };
  }

  /**
   * Obter VAPID public key para o cliente
   */
  getVapidPublicKey(): string {
    return this.vapidPublicKey;
  }
}

export const pushNotificationService = new PushNotificationService();
