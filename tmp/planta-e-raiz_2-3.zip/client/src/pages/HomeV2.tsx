import React from 'react';
import { ArrowRight, Check, Star, Users, Zap, Shield } from 'lucide-react';
import AIFrogAssistant from '../components/AIFrogAssistant';

const HomeV2: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
      {/* Navbar */}
      <nav className="bg-slate-900/80 backdrop-blur border-b border-green-500/20 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-3xl">🌿</span>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">
              Planta & Raiz
            </h1>
          </div>
          <div className="flex gap-4">
            <button className="px-6 py-2 text-green-400 hover:text-green-300 transition">
              Login
            </button>
            <button className="px-6 py-2 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-lg hover:from-green-600 hover:to-emerald-600 transition">
              Cadastro
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative py-20 px-4 overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-20 left-10 w-72 h-72 bg-green-500 rounded-full mix-blend-multiply filter blur-3xl animate-blob"></div>
          <div className="absolute top-40 right-10 w-72 h-72 bg-emerald-500 rounded-full mix-blend-multiply filter blur-3xl animate-blob animation-delay-2000"></div>
          <div className="absolute -bottom-8 left-1/2 w-72 h-72 bg-teal-500 rounded-full mix-blend-multiply filter blur-3xl animate-blob animation-delay-4000"></div>
        </div>

        <div className="relative max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <div className="space-y-4">
                <div className="inline-block px-4 py-2 bg-green-500/20 border border-green-500/50 rounded-full">
                  <span className="text-green-400 text-sm font-semibold">🚀 Revolução em Saúde Digital</span>
                </div>

                <h2 className="text-5xl lg:text-6xl font-bold leading-tight">
                  <span className="bg-gradient-to-r from-green-400 via-emerald-400 to-teal-400 bg-clip-text text-transparent">
                    Democratizando o acesso à tele-medicina e ao uso de medicamentos e suprimentos à base de cannabis
                  </span>
                  <span className="text-white"> no mundo</span>
                </h2>

                <p className="text-xl text-gray-300 leading-relaxed">
                  Conectamos pacientes a profissionais especializados, oferecemos prescrições digitais certificadas e acesso a um marketplace completo - tudo em uma plataforma integrada e segura.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <button className="px-8 py-4 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold rounded-lg hover:from-green-600 hover:to-emerald-600 transition-all transform hover:scale-105 flex items-center justify-center gap-2 shadow-lg">
                  Agendar Consulta
                  <ArrowRight className="w-5 h-5" />
                </button>
                <button className="px-8 py-4 border-2 border-green-500 text-green-400 font-bold rounded-lg hover:bg-green-500/10 transition-all">
                  Conhecer Plataforma
                </button>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 pt-8">
                <div className="space-y-2">
                  <p className="text-3xl font-bold text-green-400">500+</p>
                  <p className="text-gray-400 text-sm">Profissionais Verificados</p>
                </div>
                <div className="space-y-2">
                  <p className="text-3xl font-bold text-emerald-400">100+</p>
                  <p className="text-gray-400 text-sm">Variedades Disponíveis</p>
                </div>
                <div className="space-y-2">
                  <p className="text-3xl font-bold text-teal-400">24/7</p>
                  <p className="text-gray-400 text-sm">Atendimento Automático</p>
                </div>
              </div>
            </div>

            {/* Right Visual */}
            <div className="relative h-96 lg:h-full min-h-96">
              <div className="absolute inset-0 bg-gradient-to-br from-green-500/20 to-emerald-500/20 rounded-2xl border border-green-500/30 backdrop-blur-sm flex items-center justify-center">
                <div className="text-center">
                  <div className="text-9xl animate-bounce mb-4">🐸</div>
                  <p className="text-2xl font-bold text-green-400">Sapo Verde</p>
                  <p className="text-gray-400">Seu Assistente de IA</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 bg-slate-900/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold mb-4">
              <span className="bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">
                Funcionalidades Completas
              </span>
            </h3>
            <p className="text-xl text-gray-400">Tudo que você precisa em uma plataforma</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: <Zap className="w-8 h-8" />,
                title: 'Agendamento em 3 Cliques',
                description: 'Processo simplificado de agendamento com IA pré-entrevista',
              },
              {
                icon: <Shield className="w-8 h-8" />,
                title: 'Prescrição Digital ICP-Brasil',
                description: 'Receituário eletrônico certificado e conforme ANVISA',
              },
              {
                icon: <Users className="w-8 h-8" />,
                title: 'Profissionais Verificados',
                description: '500+ especialistas em cannabis medicinal',
              },
              {
                icon: <Star className="w-8 h-8" />,
                title: 'Marketplace Integrado',
                description: 'Compre medicamentos direto após consulta',
              },
              {
                icon: <Check className="w-8 h-8" />,
                title: 'IA Autônoma 24/7',
                description: 'Diagnóstico e recomendações personalizadas',
              },
              {
                icon: <Zap className="w-8 h-8" />,
                title: 'Videoconferência Criptografada',
                description: 'Teleconsultas seguras com Jitsi E2E',
              },
            ].map((feature, idx) => (
              <div
                key={idx}
                className="p-6 bg-gradient-to-br from-slate-800 to-slate-900 border border-green-500/30 rounded-xl hover:border-green-500/60 transition-all group"
              >
                <div className="text-green-400 mb-4 group-hover:scale-110 transition-transform">
                  {feature.icon}
                </div>
                <h4 className="text-xl font-bold text-white mb-2">{feature.title}</h4>
                <p className="text-gray-400">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 border-2 border-green-500/50 rounded-2xl p-12 text-center">
            <h3 className="text-4xl font-bold text-white mb-4">
              Pronto para revolucionar sua saúde?
            </h3>
            <p className="text-xl text-gray-300 mb-8">
              Junte-se a milhares de pacientes que já estão acessando tele-medicina de qualidade
            </p>
            <button className="px-10 py-4 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold rounded-lg hover:from-green-600 hover:to-emerald-600 transition-all transform hover:scale-105 text-lg">
              Começar Agora
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-green-500/20 py-12 px-4 bg-slate-950">
        <div className="max-w-7xl mx-auto text-center text-gray-400">
          <p>&copy; 2026 Planta & Raiz. Todos os direitos reservados.</p>
          <p className="mt-2 text-sm">Conformidade: LGPD | ANVISA | CFM | ICP-Brasil</p>
        </div>
      </footer>

      {/* AI Frog Assistant */}
      <AIFrogAssistant />

      {/* Animations */}
      <style>{`
        @keyframes blob {
          0%, 100% { transform: translate(0, 0) scale(1); }
          33% { transform: translate(30px, -50px) scale(1.1); }
          66% { transform: translate(-20px, 20px) scale(0.9); }
        }
        .animate-blob {
          animation: blob 7s infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
        .animation-delay-4000 {
          animation-delay: 4s;
        }
      `}</style>
    </div>
  );
};

export default HomeV2;
