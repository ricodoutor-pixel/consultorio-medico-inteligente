import { EventEmitter } from 'events';

interface Review {
  id: string;
  consultationId: string;
  patientId: string;
  doctorId: string;
  rating: number; // 1-5 stars
  title: string;
  comment: string;
  verified: boolean;
  helpful: number;
  notHelpful: number;
  timestamp: number;
  status: 'pending' | 'approved' | 'rejected';
  tags: string[];
}

interface DoctorRating {
  doctorId: string;
  averageRating: number;
  totalReviews: number;
  ratingDistribution: {
    1: number;
    2: number;
    3: number;
    4: number;
    5: number;
  };
  topTags: Array<{ tag: string; count: number }>;
  recentReviews: Review[];
}

export class ReviewsService extends EventEmitter {
  private static instance: ReviewsService;
  private reviews: Map<string, Review[]> = new Map();
  private doctorRatings: Map<string, DoctorRating> = new Map();
  private maxReviewsPerDoctor = 1000;

  private constructor() {
    super();
    this.setMaxListeners(100);
  }

  static getInstance(): ReviewsService {
    if (!ReviewsService.instance) {
      ReviewsService.instance = new ReviewsService();
    }
    return ReviewsService.instance;
  }

  /**
   * Submit a review for a consultation
   */
  submitReview(
    consultationId: string,
    patientId: string,
    doctorId: string,
    rating: number,
    title: string,
    comment: string,
    tags: string[] = []
  ): Review {
    // Validate rating
    if (rating < 1 || rating > 5) {
      throw new Error('Rating must be between 1 and 5');
    }

    const review: Review = {
      id: `review-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      consultationId,
      patientId,
      doctorId,
      rating,
      title,
      comment,
      verified: true, // Mark as verified since it's from a real consultation
      helpful: 0,
      notHelpful: 0,
      timestamp: Date.now(),
      status: 'approved', // Auto-approve for now
      tags,
    };

    // Store review
    if (!this.reviews.has(doctorId)) {
      this.reviews.set(doctorId, []);
    }

    const doctorReviews = this.reviews.get(doctorId)!;
    doctorReviews.unshift(review);

    // Keep only last N reviews
    if (doctorReviews.length > this.maxReviewsPerDoctor) {
      doctorReviews.pop();
    }

    // Update doctor rating
    this.updateDoctorRating(doctorId);

    // Emit event
    this.emit('review:submitted', { review });

    return review;
  }

  /**
   * Get reviews for a doctor
   */
  getDoctorReviews(doctorId: string, limit: number = 50): Review[] {
    const reviews = this.reviews.get(doctorId) || [];
    return reviews
      .filter((r) => r.status === 'approved')
      .slice(0, limit);
  }

  /**
   * Get doctor rating summary
   */
  getDoctorRating(doctorId: string): DoctorRating | null {
    return this.doctorRatings.get(doctorId) || null;
  }

  /**
   * Mark review as helpful
   */
  markHelpful(reviewId: string, doctorId: string): boolean {
    const reviews = this.reviews.get(doctorId);
    if (!reviews) return false;

    const review = reviews.find((r) => r.id === reviewId);
    if (review) {
      review.helpful++;
      this.emit('review:marked-helpful', { reviewId, doctorId });
      return true;
    }

    return false;
  }

  /**
   * Mark review as not helpful
   */
  markNotHelpful(reviewId: string, doctorId: string): boolean {
    const reviews = this.reviews.get(doctorId);
    if (!reviews) return false;

    const review = reviews.find((r) => r.id === reviewId);
    if (review) {
      review.notHelpful++;
      this.emit('review:marked-not-helpful', { reviewId, doctorId });
      return true;
    }

    return false;
  }

  /**
   * Delete review (admin only)
   */
  deleteReview(reviewId: string, doctorId: string): boolean {
    const reviews = this.reviews.get(doctorId);
    if (!reviews) return false;

    const index = reviews.findIndex((r) => r.id === reviewId);
    if (index > -1) {
      reviews.splice(index, 1);
      this.updateDoctorRating(doctorId);
      this.emit('review:deleted', { reviewId, doctorId });
      return true;
    }

    return false;
  }

  /**
   * Update doctor rating statistics
   */
  private updateDoctorRating(doctorId: string): void {
    const reviews = this.reviews.get(doctorId) || [];
    const approvedReviews = reviews.filter((r) => r.status === 'approved');

    if (approvedReviews.length === 0) {
      this.doctorRatings.delete(doctorId);
      return;
    }

    // Calculate average rating
    const totalRating = approvedReviews.reduce((sum, r) => sum + r.rating, 0);
    const averageRating = totalRating / approvedReviews.length;

    // Calculate rating distribution
    const ratingDistribution = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
    for (const review of approvedReviews) {
      ratingDistribution[review.rating as keyof typeof ratingDistribution]++;
    }

    // Get top tags
    const tagCounts: Record<string, number> = {};
    for (const review of approvedReviews) {
      for (const tag of review.tags) {
        tagCounts[tag] = (tagCounts[tag] || 0) + 1;
      }
    }

    const topTags = Object.entries(tagCounts)
      .map(([tag, count]) => ({ tag, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    // Get recent reviews
    const recentReviews = approvedReviews.slice(0, 5);

    const rating: DoctorRating = {
      doctorId,
      averageRating,
      totalReviews: approvedReviews.length,
      ratingDistribution,
      topTags,
      recentReviews,
    };

    this.doctorRatings.set(doctorId, rating);
    this.emit('rating:updated', { doctorId, rating });
  }

  /**
   * Get reviews by rating
   */
  getReviewsByRating(doctorId: string, rating: number): Review[] {
    const reviews = this.reviews.get(doctorId) || [];
    return reviews
      .filter((r) => r.status === 'approved' && r.rating === rating)
      .slice(0, 50);
  }

  /**
   * Search reviews by keyword
   */
  searchReviews(doctorId: string, keyword: string): Review[] {
    const reviews = this.reviews.get(doctorId) || [];
    const lowerKeyword = keyword.toLowerCase();

    return reviews
      .filter(
        (r) =>
          r.status === 'approved' &&
          (r.title.toLowerCase().includes(lowerKeyword) ||
            r.comment.toLowerCase().includes(lowerKeyword))
      )
      .slice(0, 50);
  }

  /**
   * Get reviews by tag
   */
  getReviewsByTag(doctorId: string, tag: string): Review[] {
    const reviews = this.reviews.get(doctorId) || [];
    return reviews
      .filter((r) => r.status === 'approved' && r.tags.includes(tag))
      .slice(0, 50);
  }

  /**
   * Get all doctors sorted by rating
   */
  getTopDoctors(limit: number = 10): DoctorRating[] {
    return Array.from(this.doctorRatings.values())
      .sort((a, b) => b.averageRating - a.averageRating)
      .slice(0, limit);
  }

  /**
   * Get doctors by minimum rating
   */
  getDoctorsByMinRating(minRating: number): DoctorRating[] {
    return Array.from(this.doctorRatings.values())
      .filter((r) => r.averageRating >= minRating)
      .sort((a, b) => b.averageRating - a.averageRating);
  }

  /**
   * Get review statistics
   */
  getStats(): {
    totalReviews: number;
    totalDoctors: number;
    averageRating: number;
    topRatedDoctor: DoctorRating | null;
  } {
    const allReviews = Array.from(this.reviews.values()).flat();
    const totalReviews = allReviews.length;
    const totalDoctors = this.doctorRatings.size;
    const averageRating =
      totalReviews > 0
        ? allReviews.reduce((sum, r) => sum + r.rating, 0) / totalReviews
        : 0;

    const topRatedDoctor = this.getTopDoctors(1)[0] || null;

    return {
      totalReviews,
      totalDoctors,
      averageRating,
      topRatedDoctor,
    };
  }
}

export const reviewsService = ReviewsService.getInstance();
