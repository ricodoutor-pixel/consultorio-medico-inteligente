/**
 * BRISA IA Router
 * 
 * Endpoints para triagem centralizada de pacientes
 * Autoridade: Dr. Edilson Bezerra
 * Estatuto: Planta y Raiz 2026-2030
 */

import { protectedProcedure, publicProcedure, router } from '../_core/trpc';
import { z } from 'zod';
import { brisaAIService } from '../services/BrisaAIService';

export const brisaRouter = router({
  /**
   * Iniciar triagem de paciente
   */
  startTriage: protectedProcedure
    .input(
      z.object({
        patientName: z.string(),
        symptoms: z.array(z.string()),
        medicalHistory: z.string().optional(),
        medications: z.array(z.string()).optional(),
        allergies: z.array(z.string()).optional(),
        urgencyLevel: z.enum(['low', 'medium', 'high', 'critical']),
      })
    )
    .mutation(async ({ ctx, input }) => {
      console.log('[Brisa Router] Iniciando triagem para:', input.patientName);

      try {
        const triageResult = await brisaAIService.performTriage({
          patientId: ctx.user.id,
          patientName: input.patientName,
          symptoms: input.symptoms,
          medicalHistory: input.medicalHistory,
          medications: input.medications,
          allergies: input.allergies,
          urgencyLevel: input.urgencyLevel,
        });

        // Enviar alertas para médicos
        await brisaAIService.sendDoctorAlert(
          triageResult.triageId,
          triageResult.recommendedDoctors,
          input.patientName
        );

        return {
          success: true,
          triageId: triageResult.triageId,
          recommendedSpecialties: triageResult.recommendedSpecialties,
          estimatedWaitTime: triageResult.estimatedWaitTime,
          recommendedDoctors: triageResult.recommendedDoctors,
          anvisaCompliance: triageResult.anvisaCompliance,
          cfmCompliance: triageResult.cfmCompliance,
        };
      } catch (error) {
        console.error('[Brisa Router] Erro na triagem:', error);
        return {
          success: false,
          error: 'Erro ao processar triagem',
        };
      }
    }),

  /**
   * Obter status de triagem
   */
  getTriageStatus: protectedProcedure
    .input(z.object({ triageId: z.string() }))
    .query(async ({ input }) => {
      console.log('[Brisa Router] Obtendo status da triagem:', input.triageId);

      return {
        triageId: input.triageId,
        status: 'pending',
        estimatedWaitTime: 5,
        lastUpdate: new Date(),
      };
    }),

  /**
   * Aceitar triagem (médico confirma)
   */
  acceptTriage: protectedProcedure
    .input(z.object({ triageId: z.string(), doctorId: z.string() }))
    .mutation(async ({ input }) => {
      console.log('[Brisa Router] Triagem aceita por médico:', input.doctorId);

      return {
        success: true,
        message: 'Triagem aceita com sucesso',
        consultationId: `CONS-${Date.now()}`,
      };
    }),

  /**
   * Rejeitar triagem (médico não pode atender)
   */
  rejectTriage: protectedProcedure
    .input(z.object({ triageId: z.string(), doctorId: z.string(), reason: z.string() }))
    .mutation(async ({ input }) => {
      console.log('[Brisa Router] Triagem rejeitada por:', input.doctorId);

      return {
        success: true,
        message: 'Triagem encaminhada para próximo médico',
        nextDoctorId: 'DR-EDILSON-001', // Fallback para Dr. Edilson
      };
    }),

  /**
   * Gerar relatório de triagem
   */
  generateReport: protectedProcedure
    .input(z.object({ triageId: z.string() }))
    .query(async ({ input }) => {
      const report = await brisaAIService.generateTriageReport({
        triageId: input.triageId,
        patientId: 'PATIENT-001',
        recommendedSpecialties: [
          {
            specialty: 'Medicina Integrativa',
            confidence: 0.95,
            reasoning: 'Especialista em cannabis medicinal',
          },
        ],
        estimatedWaitTime: 5,
        urgencyLevel: 'medium',
        anvisaCompliance: true,
        cfmCompliance: true,
        recommendedDoctors: [
          {
            doctorId: 'DR-EDILSON-001',
            name: 'Dr. Edilson Bezerra',
            specialty: 'Medicina Integrativa',
            availability: '24/7',
            responseTime: 5,
          },
        ],
        notes: 'Triagem realizada por Brisa IA',
        createdAt: new Date(),
        authorizedBy: 'Dr. Edilson Bezerra',
      });

      return { report };
    }),

  /**
   * Obter informações sobre Brisa IA
   */
  getInfo: publicProcedure.query(() => {
    return {
      name: 'Brisa IA',
      role: 'Enfermeira Chefe',
      specialization: 'Triagem e Encaminhamento de Pacientes',
      authority: 'Dr. Edilson Bezerra',
      maxResponseTime: 5, // minutos
      status: 'online',
      version: '1.0.0',
      compliance: {
        anvisa: true,
        cfm: true,
        lgpd: true,
        icpBrasil: true,
      },
    };
  }),
});
