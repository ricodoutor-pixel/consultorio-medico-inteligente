import { useEffect, useState } from 'react';
import { usePushNotifications } from '../hooks/usePushNotifications';
import { Button } from './ui/button';
import { Bell, BellOff } from 'lucide-react';

export function PushNotificationManager() {
  const { isSupported, isSubscribed, subscribe, unsubscribe, sendTestNotification } =
    usePushNotifications();
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const handleSubscribe = async () => {
    setIsLoading(true);
    try {
      const success = await subscribe();
      if (success) {
        setMessage('✅ Notificações ativadas com sucesso!');
        setTimeout(() => setMessage(null), 3000);
      } else {
        setMessage('❌ Falha ao ativar notificações');
        setTimeout(() => setMessage(null), 3000);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleUnsubscribe = async () => {
    setIsLoading(true);
    try {
      const success = await unsubscribe();
      if (success) {
        setMessage('✅ Notificações desativadas');
        setTimeout(() => setMessage(null), 3000);
      } else {
        setMessage('❌ Falha ao desativar notificações');
        setTimeout(() => setMessage(null), 3000);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleTestNotification = async () => {
    setIsLoading(true);
    try {
      await sendTestNotification();
      setMessage('✅ Notificação de teste enviada!');
      setTimeout(() => setMessage(null), 3000);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isSupported) {
    return null;
  }

  return (
    <div className="flex items-center gap-2">
      {isSubscribed ? (
        <>
          <Button
            onClick={handleTestNotification}
            disabled={isLoading}
            variant="outline"
            size="sm"
            className="gap-2"
          >
            <Bell className="w-4 h-4" />
            Teste
          </Button>
          <Button
            onClick={handleUnsubscribe}
            disabled={isLoading}
            variant="outline"
            size="sm"
            className="gap-2"
          >
            <BellOff className="w-4 h-4" />
            Desativar
          </Button>
        </>
      ) : (
        <Button
          onClick={handleSubscribe}
          disabled={isLoading}
          variant="default"
          size="sm"
          className="gap-2"
        >
          <Bell className="w-4 h-4" />
          Ativar Notificações
        </Button>
      )}

      {message && (
        <span className="text-sm text-gray-600 dark:text-gray-400">{message}</span>
      )}
    </div>
  );
}
