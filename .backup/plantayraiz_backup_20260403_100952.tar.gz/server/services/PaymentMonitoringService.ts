// import { db } from "../db"; // N00e3o usar db diretamente
import { payments, monitoringAlerts } from "../../drizzle/schema-ceo-autonomous";
import { desc, eq, and, gte } from "drizzle-orm";

/**
 * PaymentMonitoringService
 * Detecta anomalias em transações e monitora saúde dos pagamentos
 * Análise a cada 30 minutos
 */

interface PaymentAnomaly {
  paymentId: number;
  doctorId: number;
  patientId: number;
  amount: number;
  anomalyType: string;
  severity: "warning" | "critical";
  reason: string;
}

interface PaymentMetrics {
  totalPayments: number;
  completedPayments: number;
  failedPayments: number;
  successRate: number;
  anomalyRate: number;
  averageAmount: number;
  totalRevenue: number;
  anomalies: PaymentAnomaly[];
}

/**
 * Detecta anomalias em um pagamento
 */
function detectAnomalies(
  payment: typeof payments.$inferSelect,
  metrics: {
    avgAmount: number;
    stdDevAmount: number;
    failureRate: number;
  }
): PaymentAnomaly | null {
  const anomalies: string[] = [];
  let severity: "warning" | "critical" = "warning";

  // Verificar se valor é muito alto (>3x a média)
  if (payment.amount > metrics.avgAmount * 3) {
    anomalies.push(
      `Valor muito alto: R$ ${(payment.amount / 100).toFixed(2)} (média: R$ ${(metrics.avgAmount / 100).toFixed(2)})`
    );
    severity = "critical";
  }

  // Verificar se valor é muito baixo (<10% da média)
  if (payment.amount < metrics.avgAmount * 0.1 && metrics.avgAmount > 0) {
    anomalies.push(
      `Valor muito baixo: R$ ${(payment.amount / 100).toFixed(2)}`
    );
  }

  // Verificar padrões suspeitos (múltiplos pagamentos em curto período)
  // TODO: Implementar detecção de padrões

  // Verificar se pagamento falhou
  if (payment.status === "failed") {
    anomalies.push("Pagamento falhou");
    if (metrics.failureRate > 0.1) {
      anomalies.push("Taxa de falha acima do normal");
      severity = "critical";
    }
  }

  if (anomalies.length === 0) {
    return null;
  }

  return {
    paymentId: payment.id,
    doctorId: payment.doctorId,
    patientId: payment.patientId,
    amount: payment.amount,
    anomalyType: anomalies[0],
    severity,
    reason: anomalies.join(" | "),
  };
}

/**
 * Calcula métricas de pagamento
 */
async function calculateMetrics(): Promise<{
  avgAmount: number;
  stdDevAmount: number;
  failureRate: number;
}> {
  const last24h = new Date(Date.now() - 24 * 60 * 60 * 1000);

  const recentPayments = await db
    .select()
    .from(payments)
    .where(gte(payments.timestamp, last24h));

  if (recentPayments.length === 0) {
    return {
      avgAmount: 0,
      stdDevAmount: 0,
      failureRate: 0,
    };
  }

  const amounts = recentPayments.map((p) => p.amount);
  const avgAmount = amounts.reduce((a, b) => a + b, 0) / amounts.length;

  // Calcular desvio padrão
  const variance =
    amounts.reduce((sum, amount) => sum + Math.pow(amount - avgAmount, 2), 0) /
    amounts.length;
  const stdDevAmount = Math.sqrt(variance);

  // Taxa de falha
  const failedCount = recentPayments.filter(
    (p) => p.status === "failed"
  ).length;
  const failureRate = failedCount / recentPayments.length;

  return {
    avgAmount: Math.round(avgAmount),
    stdDevAmount: Math.round(stdDevAmount),
    failureRate,
  };
}

/**
 * Executa monitoramento de pagamentos
 * Chamado a cada 30 minutos
 */
async function runPaymentMonitoring(): Promise<PaymentMetrics> {
  try {
    const last24h = new Date(Date.now() - 24 * 60 * 60 * 1000);

    // Buscar todos os pagamentos das últimas 24h
    const allPayments = await db
      .select()
      .from(payments)
      .where(gte(payments.timestamp, last24h));

    // Calcular métricas
    const metrics = await calculateMetrics();

    // Detectar anomalias
    const anomalies: PaymentAnomaly[] = [];
    for (const payment of allPayments) {
      const anomaly = detectAnomalies(payment, metrics);
      if (anomaly) {
        anomalies.push(anomaly);

        // Marcar pagamento como anomalia no banco de dados
        await db
          .update(payments)
          .set({
            isAnomaly: 1,
            anomalyReason: anomaly.reason,
          })
          .where(eq(payments.id, payment.id));

        // Criar alerta se crítico
        if (anomaly.severity === "critical") {
          await db.insert(monitoringAlerts).values({
            type: "payment_anomaly",
            severity: "critical",
            title: `Anomalia de Pagamento: ${anomaly.anomalyType}`,
            content: `Pagamento ID ${anomaly.paymentId}: ${anomaly.reason}`,
            relatedEntityId: anomaly.doctorId,
            resolved: 0,
            timestamp: new Date(),
          });
        }
      }
    }

    // Calcular métricas finais
    const completedPayments = allPayments.filter(
      (p) => p.status === "completed"
    ).length;
    const failedPayments = allPayments.filter(
      (p) => p.status === "failed"
    ).length;
    const totalRevenue = allPayments
      .filter((p) => p.status === "completed")
      .reduce((sum, p) => sum + p.amount, 0);

    const paymentMetrics: PaymentMetrics = {
      totalPayments: allPayments.length,
      completedPayments,
      failedPayments,
      successRate:
        allPayments.length > 0
          ? (completedPayments / allPayments.length) * 100
          : 0,
      anomalyRate:
        allPayments.length > 0 ? (anomalies.length / allPayments.length) * 100 : 0,
      averageAmount: metrics.avgAmount,
      totalRevenue,
      anomalies,
    };

    console.log(
      `[PaymentMonitoringService] Monitoramento concluído: ${paymentMetrics.totalPayments} pagamentos, ${anomalies.length} anomalias detectadas`
    );

    return paymentMetrics;
  } catch (error) {
    console.error("[PaymentMonitoringService] Erro no monitoramento:", error);
    throw error;
  }
}

/**
 * Retorna status de saúde dos pagamentos
 */
async function getHealthStatus(): Promise<{
  status: "healthy" | "warning" | "critical";
  successRate: number;
  anomalyRate: number;
  message: string;
}> {
  const metrics = await runPaymentMonitoring();

  let status: "healthy" | "warning" | "critical" = "healthy";
  let message = "Sistema de pagamentos operando normalmente";

  if (metrics.successRate < 95) {
    status = "warning";
    message = `Taxa de sucesso baixa: ${metrics.successRate.toFixed(1)}%`;
  }

  if (metrics.successRate < 90 || metrics.anomalyRate > 5) {
    status = "critical";
    message = `Sistema crítico: ${metrics.successRate.toFixed(1)}% sucesso, ${metrics.anomalyRate.toFixed(1)}% anomalias`;
  }

  return {
    status,
    successRate: metrics.successRate,
    anomalyRate: metrics.anomalyRate,
    message,
  };
}

/**
 * Retorna últimas anomalias detectadas
 */
async function getRecentAnomalies(limit: number = 10): Promise<PaymentAnomaly[]> {
  const last7d = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

  const anomalousPayments = await db
    .select()
    .from(payments)
    .where(
      and(
        eq(payments.isAnomaly, 1),
        gte(payments.timestamp, last7d)
      )
    )
    .orderBy(desc(payments.timestamp))
    .limit(limit);

  const metrics = await calculateMetrics();

  return anomalousPayments
    .map((p) => {
      const anomaly = detectAnomalies(p, metrics);
      return anomaly || null;
    })
    .filter((a) => a !== null) as PaymentAnomaly[];
}

export const paymentMonitoringService = {
  detectAnomalies,
  calculateMetrics,
  runPaymentMonitoring,
  getHealthStatus,
  getRecentAnomalies,
};
