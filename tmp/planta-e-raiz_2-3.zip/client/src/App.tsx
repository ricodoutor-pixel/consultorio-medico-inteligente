import React from "react";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import NotFound from "@/pages/NotFound";
import HomePremiumHub from "@/pages/HomePremiumHub";
import Dashboard from "@/pages/Dashboard";
import Invest from "@/pages/Invest";
import AffiliatesNew from "@/pages/AffiliatesNew";
import AdminPremium from "@/pages/AdminPremium";
import PlansNew from "@/pages/PlansNew";
import WalletNew from "@/pages/WalletNew";
import Deposit from "@/pages/Deposit";
import Withdraw from "@/pages/Withdraw";
import Auth from "@/pages/Auth";
import Telemedicine from "@/pages/Telemedicine";
import Shopping from "@/pages/Shopping";
import SellerPanel from "@/pages/SellerPanel";
import Legal from "@/pages/Legal";
import ScientificLibrary from "@/pages/ScientificLibrary";
import AdvancedSearch from "@/pages/AdvancedSearch";
import QuickBooking from "@/pages/QuickBooking";
import Professionais from "@/pages/Professionais";
import Agendar from "@/pages/Agendar";
import BibliotecaV2 from "@/pages/BibliotecaV2";
import HomeV2 from "@/pages/HomeV2";
import DashboardAnalytics from "@/pages/DashboardAnalytics";
import AdminPanel from "@/pages/AdminPanel";
import ChatRealtime from "@/pages/ChatRealtime";
import LandingPageOptimized from "@/pages/LandingPageOptimized";
import Reviews from "@/pages/Reviews";
import AffiliatesDashboard from "@/pages/AffiliatesDashboard";
import Clinic24x7 from "@/pages/Clinic24x7";
import BibliotecaCientifica from "@/pages/BibliotecaCientifica";
import ClinicalResearch from "@/pages/ClinicalResearch";
import AdminSentimentDashboard from "@/pages/AdminSentimentDashboard";
import MarketplaceComplementary from "@/pages/MarketplaceComplementary";
import BibliotecaImagensAnalytics from "@/pages/BibliotecaImagensAnalytics";
import BibliotecaDistribuicaoPizza from "@/pages/BibliotecaDistribuicaoPizza";

import VerdinhoChatModal from "@/components/VerdinhoChatModal";
import VerdinhoPremiumFinalV2 from "@/components/VerdinhoPremiumFinalV2";

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomeV2} />
      <Route path="/home-premium" component={HomePremiumHub} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/invest" component={Invest} />
      <Route path="/referrals" component={AffiliatesNew} />
      <Route path="/admin" component={AdminPremium} />
      <Route path="/plans" component={PlansNew} />
      <Route path="/wallet" component={WalletNew} />
      <Route path="/deposit" component={Deposit} />
      <Route path="/withdraw" component={Withdraw} />
      <Route path="/auth" component={Auth} />
      <Route path="/telemedicine" component={Telemedicine} />
      <Route path="/shopping" component={Shopping} />
      <Route path="/marketplace" component={Shopping} />
      <Route path="/seller" component={SellerPanel} />
      <Route path="/legal" component={Legal} />
      <Route path="/biblioteca-cientifica" component={ScientificLibrary} />
      <Route path="/search" component={AdvancedSearch} />
      <Route path="/booking" component={QuickBooking} />
      <Route path="/profissionais" component={Professionais} />
      <Route path="/agendar" component={Agendar} />
      <Route path="/biblioteca" component={BibliotecaV2} />
      <Route path="/biblioteca-cientifica-premium" component={BibliotecaCientifica} />
      <Route path="/dashboard-analytics" component={DashboardAnalytics} />
      <Route path="/admin-panel" component={AdminPanel} />
      <Route path="/chat" component={ChatRealtime} />
      <Route path="/landing" component={LandingPageOptimized} />
      <Route path="/reviews" component={Reviews} />
      <Route path="/affiliates" component={AffiliatesDashboard} />
      <Route path="/clinic" component={Clinic24x7} />
      <Route path="/clinical-research" component={ClinicalResearch} />
      <Route path="/admin/sentiment-dashboard" component={AdminSentimentDashboard} />
      <Route path="/marketplace-complementary" component={MarketplaceComplementary} />
      <Route path="/biblioteca-imagens-analytics" component={BibliotecaImagensAnalytics} />
      <Route path="/biblioteca-distribuicao-pizza" component={BibliotecaDistribuicaoPizza} />
      <Route path="/404" component={NotFound} />
      {/* Fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [showVerdinhChat, setShowVerdinhChat] = React.useState<boolean>(false);

  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
      >
        <TooltipProvider>
          <Toaster />
          {/* Verdinho Premium no header */}
          <div className="fixed top-4 right-4 z-40">
            <VerdinhoPremiumFinalV2
              position="header"
              size="small"
              onChat={() => setShowVerdinhChat(true)}
              interactive={true}
              autoAnimate={true}
            />
          </div>
          
          {/* Modal de chat do Verdinho */}
          <VerdinhoChatModal
            isOpen={showVerdinhChat}
            onClose={() => setShowVerdinhChat(false)}
          />
          
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
