/**
 * Web Push API - Configuração VAPID Keys
 * 
 * Para gerar novas VAPID keys, execute:
 * npx web-push generate-vapid-keys
 * 
 * Armazene em variáveis de ambiente:
 * VITE_VAPID_PUBLIC_KEY - Chave pública (para frontend)
 * VAPID_PRIVATE_KEY - Chave privada (para backend)
 * VAPID_SUBJECT - Email de contato (mailto:email@example.com)
 */

import webpush from 'web-push';

export class PushNotificationSetup {
  /**
   * Inicializar Web Push com VAPID keys
   */
  static initialize(): void {
    const vapidPublicKey = process.env.VITE_VAPID_PUBLIC_KEY;
    const vapidPrivateKey = process.env.VAPID_PRIVATE_KEY;
    const vapidSubject = process.env.VAPID_SUBJECT || 'mailto:contato@plantayraiz.com.br';

    if (!vapidPublicKey || !vapidPrivateKey) {
      console.warn('[Push] VAPID keys não configuradas. Gerando novas chaves...');
      this.generateNewKeys();
      return;
    }

    try {
      webpush.setVapidDetails(vapidSubject, vapidPublicKey, vapidPrivateKey);
      console.log('✅ [Push] VAPID keys configuradas com sucesso');
    } catch (error) {
      console.error('❌ [Push] Erro ao configurar VAPID keys:', error);
    }
  }

  /**
   * Gerar novas VAPID keys
   */
  static generateNewKeys(): void {
    console.log(`
╔════════════════════════════════════════════════════════════╗
║  GERANDO NOVAS VAPID KEYS PARA WEB PUSH API               ║
╚════════════════════════════════════════════════════════════╝

Para gerar VAPID keys, execute:
  npx web-push generate-vapid-keys

Depois, adicione ao arquivo .env:
  VITE_VAPID_PUBLIC_KEY=<sua-chave-publica>
  VAPID_PRIVATE_KEY=<sua-chave-privada>
  VAPID_SUBJECT=mailto:contato@plantayraiz.com.br

Ou defina como variáveis de ambiente do sistema.
    `);
  }

  /**
   * Obter VAPID public key para frontend
   */
  static getPublicKey(): string {
    return process.env.VITE_VAPID_PUBLIC_KEY || '';
  }

  /**
   * Validar configuração
   */
  static isConfigured(): boolean {
    return !!(process.env.VITE_VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY);
  }

  /**
   * Gerar exemplo de VAPID keys para documentação
   */
  static getExampleKeys(): { publicKey: string; privateKey: string } {
    return {
      publicKey: 'EXEMPLO_CHAVE_PUBLICA_BASE64',
      privateKey: 'EXEMPLO_CHAVE_PRIVADA_BASE64',
    };
  }
}

// Inicializar ao carregar o módulo
PushNotificationSetup.initialize();

export default PushNotificationSetup;
