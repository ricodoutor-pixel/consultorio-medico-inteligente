import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { AlertCircle, CheckCircle, Loader } from 'lucide-react';
import { trpc } from '@/lib/trpc';

interface PaymentCheckoutProps {
  consultationId: number;
  doctorId: number;
  doctorName: string;
  amount: number;
  isSubscriber?: boolean;
  onSuccess: () => void;
  onError: (error: string) => void;
}

/**
 * Componente de Checkout com Mercado Pago Split
 */
export const PaymentCheckout: React.FC<PaymentCheckoutProps> = ({
  consultationId,
  doctorId,
  doctorName,
  amount,
  isSubscriber = false,
  onSuccess,
  onError,
}) => {
  const [split, setSplit] = useState<any>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<
    'pending' | 'processing' | 'success' | 'error'
  >('pending');

  // Obter cálculo de split
  const { data: splitData } = trpc.payment.calculateSplit.useQuery({
    amount,
    type: 'consultation',
    isSubscriber,
  });

  useEffect(() => {
    if (splitData) {
      setSplit(splitData);
    }
  }, [splitData]);

  const createPaymentMutation = trpc.payment.createPayment.useMutation({
    onSuccess: (data) => {
      setPaymentStatus('success');
      // Redirecionar para Mercado Pago ou processar pagamento
      handlePaymentSuccess(data);
    },
    onError: (error) => {
      setPaymentStatus('error');
      onError(error.message);
    },
  });

  const handlePaymentSuccess = async (paymentData: any) => {
    // Aguardar confirmação de pagamento
    setTimeout(() => {
      onSuccess();
    }, 2000);
  };

  const handleCreatePayment = async () => {
    setIsProcessing(true);
    setPaymentStatus('processing');

    try {
      // Obter account ID do médico (simplificado)
      const doctorAccountId = `doctor-${doctorId}`;

      await createPaymentMutation.mutateAsync({
        consultationId,
        doctorId,
        doctorAccountId,
        amount,
        description: `Consulta com ${doctorName} - Planta y Raiz`,
        isSubscriber,
      });
    } catch (error) {
      setIsProcessing(false);
      setPaymentStatus('error');
    }
  };

  if (!split) {
    return (
      <Card className="p-6 bg-gray-50">
        <Loader className="animate-spin" />
        <p className="mt-2">Calculando valores...</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Resumo da Consulta */}
      <Card className="p-6 bg-white border border-gray-200">
        <h3 className="text-lg font-bold mb-4">Resumo da Consulta</h3>

        <div className="space-y-3">
          <div className="flex justify-between">
            <span className="text-gray-600">Médico:</span>
            <span className="font-semibold">{doctorName}</span>
          </div>

          <div className="flex justify-between">
            <span className="text-gray-600">Tipo:</span>
            <span className="font-semibold">Consulta Online</span>
          </div>

          <div className="flex justify-between border-t pt-3">
            <span className="text-gray-600">Valor da Consulta:</span>
            <span className="font-semibold">R$ {amount.toFixed(2)}</span>
          </div>
        </div>
      </Card>

      {/* Divisão de Pagamento */}
      <Card className="p-6 bg-blue-50 border border-blue-200">
        <h3 className="text-lg font-bold mb-4 text-blue-900">
          Divisão de Pagamento
        </h3>

        <div className="space-y-3">
          {split.splits.map((s: any, index: number) => (
            <div key={index} className="flex justify-between items-center">
              <div>
                <p className="font-semibold text-blue-900">{s.description}</p>
                <p className="text-sm text-blue-700">
                  {s.account === 'planta-raiz-account'
                    ? 'Plataforma'
                    : 'Médico'}
                </p>
              </div>
              <p className="font-bold text-blue-900">
                R$ {s.amount.toFixed(2)}
              </p>
            </div>
          ))}

          <div className="border-t border-blue-300 pt-3 flex justify-between items-center bg-white p-3 rounded">
            <span className="font-bold text-blue-900">Total:</span>
            <span className="text-2xl font-bold text-blue-900">
              R$ {split.totalAmount.toFixed(2)}
            </span>
          </div>
        </div>

        {isSubscriber && (
          <div className="mt-4 p-3 bg-green-100 border border-green-300 rounded flex gap-2">
            <CheckCircle size={20} className="text-green-600 flex-shrink-0" />
            <p className="text-sm text-green-700">
              ✓ Você é assinante! Taxa de plataforma isenta.
            </p>
          </div>
        )}
      </Card>

      {/* Status de Pagamento */}
      {paymentStatus === 'success' && (
        <Card className="p-6 bg-green-50 border border-green-200">
          <div className="flex gap-3 items-center">
            <CheckCircle size={24} className="text-green-600" />
            <div>
              <h4 className="font-bold text-green-900">Pagamento Aprovado!</h4>
              <p className="text-sm text-green-700">
                Sua consulta foi confirmada. Você será redirecionado para a
                videochamada.
              </p>
            </div>
          </div>
        </Card>
      )}

      {paymentStatus === 'error' && (
        <Card className="p-6 bg-red-50 border border-red-200">
          <div className="flex gap-3 items-center">
            <AlertCircle size={24} className="text-red-600" />
            <div>
              <h4 className="font-bold text-red-900">Erro no Pagamento</h4>
              <p className="text-sm text-red-700">
                Ocorreu um erro ao processar seu pagamento. Tente novamente.
              </p>
            </div>
          </div>
        </Card>
      )}

      {/* Botão de Pagamento */}
      <Button
        onClick={handleCreatePayment}
        disabled={isProcessing || paymentStatus === 'success'}
        className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 text-lg"
      >
        {isProcessing ? (
          <>
            <Loader size={20} className="mr-2 animate-spin" />
            Processando...
          </>
        ) : paymentStatus === 'success' ? (
          <>
            <CheckCircle size={20} className="mr-2" />
            Pagamento Confirmado
          </>
        ) : (
          `Pagar R$ ${split.totalAmount.toFixed(2)}`
        )}
      </Button>

      {/* Informações de Segurança */}
      <div className="p-4 bg-gray-100 rounded text-sm text-gray-700">
        <p className="font-semibold mb-2">🔒 Segurança Garantida</p>
        <ul className="list-disc list-inside space-y-1">
          <li>Pagamento processado pelo Mercado Pago (PCI DSS compliant)</li>
          <li>Seus dados são criptografados (SSL/TLS)</li>
          <li>Conformidade LGPD garantida</li>
          <li>Assinatura digital válida juridicamente</li>
        </ul>
      </div>
    </div>
  );
};

export default PaymentCheckout;
