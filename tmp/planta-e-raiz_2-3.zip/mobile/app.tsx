/**
 * Planta & Raiz Mobile App
 * React Native + Expo with push notifications, biometric auth, and offline sync
 */

import React, { useEffect, useState } from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import * as Notifications from "expo-notifications";
import * as SecureStore from "expo-secure-store";
import * as LocalAuthentication from "expo-local-authentication";
import { useNetInfo } from "@react-native-community/netinfo";
import AsyncStorage from "@react-native-async-storage/async-storage";

// Screens
import LoginScreen from "./screens/LoginScreen";
import BiometricAuthScreen from "./screens/BiometricAuthScreen";
import HomeScreen from "./screens/HomeScreen";
import ConsultationScreen from "./screens/ConsultationScreen";
import MarketplaceScreen from "./screens/MarketplaceScreen";
import ProfileScreen from "./screens/ProfileScreen";
import OfflineModeScreen from "./screens/OfflineModeScreen";

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

// Configure notifications
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

/**
 * Main App Component
 */
export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isBiometricAvailable, setIsBiometricAvailable] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const netInfo = useNetInfo();
  const [isOfflineMode, setIsOfflineMode] = useState(!netInfo.isConnected);

  useEffect(() => {
    // Initialize app
    initializeApp();

    // Setup notifications
    setupNotifications();

    // Setup offline sync
    setupOfflineSync();

    // Monitor network status
    const unsubscribe = netInfo.addEventListener((state) => {
      setIsOfflineMode(!state.isConnected);
      if (state.isConnected) {
        syncOfflineData();
      }
    });

    return unsubscribe;
  }, []);

  /**
   * Initialize app
   */
  const initializeApp = async () => {
    try {
      // Check if user is logged in
      const token = await SecureStore.getItemAsync("authToken");
      if (token) {
        setIsLoggedIn(true);
      }

      // Check biometric availability
      const compatible = await LocalAuthentication.hasHardwareAsync();
      const enrolled = await LocalAuthentication.isEnrolledAsync();
      setIsBiometricAvailable(compatible && enrolled);
    } catch (error) {
      console.error("Initialize app error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Setup push notifications
   */
  const setupNotifications = async () => {
    try {
      // Request permissions
      const { status } = await Notifications.requestPermissionsAsync();
      if (status !== "granted") {
        console.warn("Notification permissions not granted");
        return;
      }

      // Get push token
      const token = await Notifications.getExpoPushTokenAsync();
      console.log("Push token:", token.data);

      // Save push token to backend
      await savePushToken(token.data);

      // Listen for notifications
      const subscription = Notifications.addNotificationResponseListener((response) => {
        handleNotificationResponse(response);
      });

      return () => subscription.remove();
    } catch (error) {
      console.error("Setup notifications error:", error);
    }
  };

  /**
   * Save push token to backend
   */
  const savePushToken = async (token: string) => {
    try {
      // TODO: Send token to backend
      await AsyncStorage.setItem("pushToken", token);
      console.log("Push token saved");
    } catch (error) {
      console.error("Save push token error:", error);
    }
  };

  /**
   * Handle notification response
   */
  const handleNotificationResponse = (response: any) => {
    const { notification } = response;
    const { data } = notification.request.content;

    console.log("Notification received:", data);

    // Handle different notification types
    switch (data.type) {
      case "consultation_confirmed":
        // Navigate to consultation screen
        break;
      case "payment_received":
        // Show payment confirmation
        break;
      case "product_available":
        // Navigate to marketplace
        break;
      case "specialist_online":
        // Show specialist online alert
        break;
      default:
        break;
    }
  };

  /**
   * Setup offline sync
   */
  const setupOfflineSync = async () => {
    try {
      // Load offline queue
      const offlineQueue = await AsyncStorage.getItem("offlineQueue");
      if (offlineQueue) {
        console.log("Offline queue loaded:", JSON.parse(offlineQueue));
      }
    } catch (error) {
      console.error("Setup offline sync error:", error);
    }
  };

  /**
   * Sync offline data when online
   */
  const syncOfflineData = async () => {
    try {
      const offlineQueue = await AsyncStorage.getItem("offlineQueue");
      if (!offlineQueue) return;

      const queue = JSON.parse(offlineQueue);
      console.log("Syncing offline data:", queue);

      // TODO: Process offline queue and sync with backend

      // Clear offline queue
      await AsyncStorage.removeItem("offlineQueue");
      console.log("Offline data synced");
    } catch (error) {
      console.error("Sync offline data error:", error);
    }
  };

  /**
   * Handle login
   */
  const handleLogin = async (email: string, password: string) => {
    try {
      // TODO: Authenticate with backend
      const token = "mock-token-123";

      // Save token securely
      await SecureStore.setItemAsync("authToken", token);
      setIsLoggedIn(true);
    } catch (error) {
      console.error("Login error:", error);
    }
  };

  /**
   * Handle biometric auth
   */
  const handleBiometricAuth = async () => {
    try {
      const result = await LocalAuthentication.authenticateAsync({
        disableDeviceFallback: false,
        reason: "Authenticate to access your account",
      });

      if (result.success) {
        setIsLoggedIn(true);
      }
    } catch (error) {
      console.error("Biometric auth error:", error);
    }
  };

  /**
   * Handle logout
   */
  const handleLogout = async () => {
    try {
      await SecureStore.deleteItemAsync("authToken");
      setIsLoggedIn(false);
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  if (isLoading) {
    return null; // TODO: Show splash screen
  }

  if (isOfflineMode) {
    return <OfflineModeScreen />;
  }

  if (!isLoggedIn) {
    return (
      <NavigationContainer>
        <Stack.Navigator>
          <Stack.Screen
            name="Login"
            options={{ headerShown: false }}
            children={(props) => <LoginScreen {...props} onLogin={handleLogin} />}
          />
          {isBiometricAvailable && (
            <Stack.Screen
              name="BiometricAuth"
              options={{ headerShown: false }}
              children={(props) => (
                <BiometricAuthScreen {...props} onAuth={handleBiometricAuth} />
              )}
            />
          )}
        </Stack.Navigator>
      </NavigationContainer>
    );
  }

  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={{
          headerShown: true,
          tabBarActiveTintColor: "#00B050",
          tabBarInactiveTintColor: "#999",
        }}
      >
        <Tab.Screen
          name="Home"
          component={HomeScreen}
          options={{
            title: "Início",
            tabBarLabel: "Início",
          }}
        />
        <Tab.Screen
          name="Consultation"
          component={ConsultationScreen}
          options={{
            title: "Consultas",
            tabBarLabel: "Consultas",
          }}
        />
        <Tab.Screen
          name="Marketplace"
          component={MarketplaceScreen}
          options={{
            title: "Marketplace",
            tabBarLabel: "Compras",
          }}
        />
        <Tab.Screen
          name="Profile"
          children={(props) => <ProfileScreen {...props} onLogout={handleLogout} />}
          options={{
            title: "Perfil",
            tabBarLabel: "Perfil",
          }}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
