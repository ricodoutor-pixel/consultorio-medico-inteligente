import { router, publicProcedure, protectedProcedure } from '../_core/trpc';
import { z } from 'zod';
import { createVideocallService } from '../services/VideocallService';
import { createMercadoPagoSplitService } from '../services/MercadoPagoSplitService';

const videocallService = createVideocallService();
const mercadoPagoService = createMercadoPagoSplitService();

export const videocallRouter = router({
  /**
   * Criar sessão de videochamada
   */
  createSession: protectedProcedure
    .input(
      z.object({
        consultationId: z.number(),
        doctorId: z.number(),
        doctorName: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        // 1. Criar sessão de videochamada
        const session = await videocallService.createVideocallSession(
          input.consultationId,
          ctx.user.id,
          input.doctorId,
          ctx.user.name || 'Paciente',
          input.doctorName
        );

        // 2. Armazenar no banco de dados
        // await db.videocallSessions.create({
        //   consultationId: input.consultationId,
        //   sessionId: session.id,
        //   patientId: ctx.user.id,
        //   doctorId: input.doctorId,
        //   roomName: session.roomName,
        //   joinUrl: session.joinUrl,
        //   isRecording: session.isRecording,
        //   startTime: session.startTime
        // });

        return {
          sessionId: session.id,
          roomName: session.roomName,
          joinUrl: session.joinUrl,
          isRecording: session.isRecording,
          encryptedData: session.encryptedData,
        };
      } catch (error) {
        console.error('Erro ao criar sessão:', error);
        throw new Error('Falha ao criar sessão de videochamada');
      }
    }),

  /**
   * Finalizar sessão e obter gravação
   */
  endSession: protectedProcedure
    .input(
      z.object({
        sessionId: z.string(),
        consultationId: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        // 1. Finalizar sessão
        const result = await videocallService.endVideocallSession(
          input.sessionId
        );

        // 2. Armazenar gravação criptografada
        if (result.recordingUrl) {
          const recordingKey = await videocallService.storeEncryptedRecording(
            result.recordingUrl,
            input.consultationId,
            0 // doctorId seria obtido do banco
          );

          // 3. Atualizar banco de dados
          // await db.videocallSessions.update({
          //   where: { sessionId: input.sessionId },
          //   data: {
          //     endTime: new Date(),
          //     duration: result.duration,
          //     recordingUrl: recordingKey
          //   }
          // });
        }

        return {
          duration: result.duration,
          recordingUrl: result.recordingUrl,
        };
      } catch (error) {
        console.error('Erro ao finalizar sessão:', error);
        throw new Error('Falha ao finalizar sessão de videochamada');
      }
    }),

  /**
   * Obter status de gravação
   */
  getRecordingStatus: protectedProcedure
    .input(z.object({ sessionId: z.string() }))
    .query(async ({ input }) => {
      try {
        const status = await videocallService.getRecordingStatus(
          input.sessionId
        );
        return status;
      } catch (error) {
        console.error('Erro ao obter status de gravação:', error);
        throw new Error('Falha ao obter status de gravação');
      }
    }),
});

export const paymentRouter = router({
  /**
   * Calcular divisão de pagamento
   */
  calculateSplit: publicProcedure
    .input(
      z.object({
        amount: z.number(),
        type: z.enum(['consultation', 'product']),
        isSubscriber: z.boolean().optional(),
      })
    )
    .query(({ input }) => {
      const split = mercadoPagoService.calculateSplit(
        input.amount,
        input.type,
        input.isSubscriber
      );

      return {
        totalAmount: split.totalAmount,
        platformFee: split.platformFee,
        recipientAmount: split.recipientAmount,
        splits: split.splits,
      };
    }),

  /**
   * Criar pagamento com split
   */
  createPayment: protectedProcedure
    .input(
      z.object({
        consultationId: z.number(),
        doctorId: z.number(),
        doctorAccountId: z.string(),
        amount: z.number(),
        description: z.string(),
        isSubscriber: z.boolean().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        // 1. Criar pagamento com split
        const payment = await mercadoPagoService.createPaymentWithSplit(
          input.consultationId,
          ctx.user.email || '',
          input.doctorId,
          input.doctorAccountId,
          input.amount,
          input.description,
          input.isSubscriber
        );

        // 2. Armazenar no banco de dados
        // await db.payments.create({
        //   consultationId: input.consultationId,
        //   patientId: ctx.user.id,
        //   doctorId: input.doctorId,
        //   amount: input.amount,
        //   status: payment.status,
        //   mercadoPagoId: payment.id,
        //   createdAt: new Date()
        // });

        return {
          paymentId: payment.id,
          status: payment.status,
          statusDetail: payment.statusDetail,
          amount: payment.transactionAmount,
        };
      } catch (error) {
        console.error('Erro ao criar pagamento:', error);
        throw new Error('Falha ao processar pagamento');
      }
    }),

  /**
   * Obter informações de pagamento
   */
  getPaymentInfo: protectedProcedure
    .input(z.object({ paymentId: z.string() }))
    .query(async ({ input }) => {
      try {
        const payment = await mercadoPagoService.getPaymentInfo(
          input.paymentId
        );

        return {
          id: payment.id,
          status: payment.status,
          statusDetail: payment.statusDetail,
          amount: payment.transactionAmount,
          description: payment.description,
          dateCreated: payment.dateCreated,
          dateApproved: payment.dateApproved,
        };
      } catch (error) {
        console.error('Erro ao obter informações de pagamento:', error);
        throw new Error('Falha ao obter informações de pagamento');
      }
    }),

  /**
   * Webhook para processar notificações de pagamento
   */
  handleWebhook: publicProcedure
    .input(
      z.object({
        id: z.string(),
        type: z.string(),
        data: z.object({
          id: z.string(),
        }),
      })
    )
    .mutation(async ({ input }) => {
      try {
        if (input.type === 'payment') {
          await mercadoPagoService.handlePaymentWebhook(
            input.data.id,
            'approved' // Simplificado, seria obtido da API
          );
        }

        return { success: true };
      } catch (error) {
        console.error('Erro ao processar webhook:', error);
        return { success: false };
      }
    }),

  /**
   * Obter saldo da conta
   */
  getAccountBalance: protectedProcedure
    .input(z.object({ accountId: z.string() }))
    .query(async ({ input }) => {
      try {
        const balance = await mercadoPagoService.getAccountBalance(
          input.accountId
        );

        return { balance };
      } catch (error) {
        console.error('Erro ao obter saldo:', error);
        throw new Error('Falha ao obter saldo da conta');
      }
    }),
});
