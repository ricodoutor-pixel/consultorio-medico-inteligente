/**
 * 🐸 VERDINHO PREMIUM FINAL V2 — COROA, CETRO E ANIMAÇÕES AUTOMÁTICAS
 * 
 * Versão final com:
 * - Coroa dourada com pedras
 * - Cetro com lanterna vermelha
 * - Animações automáticas a cada 3 segundos
 * - Tamanho pequeno (80px default)
 * - Olhos que seguem mouse
 * - Expressões faciais dinâmicas
 */

import React, { useState, useEffect, useRef } from 'react';
import { useVerdinhReaction } from '@/contexts/VerdinhReactionContext';

interface VerdinhoPremiumFinalV2Props {
  size?: 'tiny' | 'small' | 'medium';
  position?: 'header' | 'center' | 'floating';
  onChat?: () => void;
  interactive?: boolean;
  autoAnimate?: boolean;
}

const VerdinhoPremiumFinalV2: React.FC<VerdinhoPremiumFinalV2Props> = ({
  size = 'small',
  position = 'floating',
  onChat,
  interactive = true,
  autoAnimate = true
}) => {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isBlinking, setIsBlinking] = useState(false);
  const [armRotation, setArmRotation] = useState(0);
  const [currentAutoAnimation, setCurrentAutoAnimation] = useState<string | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const { triggerReaction } = useVerdinhReaction();

  // Tamanhos
  const sizeMap = {
    tiny: 60,
    small: 80,
    medium: 120
  };

  const viewBoxSize = 200;
  const size_px = sizeMap[size];

  // Rastrear movimento do mouse
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!interactive || !svgRef.current) return;

      const rect = svgRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      setMousePos({ x, y });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [interactive]);

  // Piscar dos olhos
  useEffect(() => {
    const blinkInterval = setInterval(() => {
      setIsBlinking(true);
      setTimeout(() => setIsBlinking(false), 150);
    }, 3000 + Math.random() * 2000);

    return () => clearInterval(blinkInterval);
  }, []);

  // Animações automáticas a cada 3 segundos
  useEffect(() => {
    if (!autoAnimate) return;

    const animations = ['dance', 'happy', 'excited', 'celebrate'];
    let currentIndex = 0;

    const autoAnimationInterval = setInterval(() => {
      const animation = animations[currentIndex];
      setCurrentAutoAnimation(animation);

      // Disparar reação
      if (animation === 'dance') {
        triggerReaction({ type: 'dance', duration: 2800, intensity: 'high' });
      } else if (animation === 'happy') {
        triggerReaction({ type: 'happy', duration: 2800, intensity: 'medium' });
      } else if (animation === 'excited') {
        triggerReaction({ type: 'excited', duration: 2800, intensity: 'high' });
      } else if (animation === 'celebrate') {
        triggerReaction({ type: 'celebrate', duration: 2800, intensity: 'high' });
      }

      currentIndex = (currentIndex + 1) % animations.length;
    }, 3000);

    return () => clearInterval(autoAnimationInterval);
  }, [autoAnimate, triggerReaction]);

  // Movimento dos braços
  useEffect(() => {
    const armInterval = setInterval(() => {
      setArmRotation((prev) => (prev + 5) % 360);
    }, 50);

    return () => clearInterval(armInterval);
  }, []);

  // Calcular posição dos olhos seguindo o mouse
  const calculateEyePosition = (eyeCenterX: number, eyeCenterY: number) => {
    if (!interactive) return { x: eyeCenterX, y: eyeCenterY };

    const rect = svgRef.current?.getBoundingClientRect();
    if (!rect) return { x: eyeCenterX, y: eyeCenterY };

    const angle = Math.atan2(mousePos.y - rect.height / 2, mousePos.x - rect.width / 2);
    const distance = 6;

    return {
      x: eyeCenterX + Math.cos(angle) * distance,
      y: eyeCenterY + Math.sin(angle) * distance
    };
  };

  const leftPupil = calculateEyePosition(65, 70);
  const rightPupil = calculateEyePosition(135, 70);

  return (
    <div
      className={`flex items-center justify-center cursor-pointer transition-transform hover:scale-125 ${
        position === 'header' ? 'fixed top-4 right-4 z-40' : position === 'center' ? 'flex justify-center' : ''
      }`}
      onClick={onChat}
      title="Clique para conversar com Verdinho"
    >
      <svg
        ref={svgRef}
        viewBox={`0 0 ${viewBoxSize} ${viewBoxSize}`}
        width={size_px}
        height={size_px}
        className="filter drop-shadow-lg transition-transform"
        style={{
          transform: currentAutoAnimation ? 'scale(1.05)' : 'scale(1)',
          transition: 'transform 0.3s ease-out'
        }}
      >
        {/* Definições de gradientes */}
        <defs>
          <radialGradient id="bodyGradient" cx="40%" cy="40%">
            <stop offset="0%" stopColor="#7FFF00" />
            <stop offset="100%" stopColor="#32CD32" />
          </radialGradient>

          <radialGradient id="bellyGradient" cx="50%" cy="50%">
            <stop offset="0%" stopColor="#FFFF99" />
            <stop offset="100%" stopColor="#FFFF00" />
          </radialGradient>

          <radialGradient id="eyeGradient" cx="35%" cy="35%">
            <stop offset="0%" stopColor="#FFFF99" />
            <stop offset="100%" stopColor="#FFD700" />
          </radialGradient>

          <radialGradient id="crownGradient" cx="40%" cy="40%">
            <stop offset="0%" stopColor="#FFD700" />
            <stop offset="100%" stopColor="#FFA500" />
          </radialGradient>

          <filter id="shadow" x="-50%" y="-50%" width="200%" height="200%">
            <feDropShadow dx="2" dy="2" stdDeviation="3" floodOpacity="0.3" />
          </filter>
        </defs>

        {/* Corpo principal */}
        <ellipse cx="100" cy="110" rx="55" ry="65" fill="url(#bodyGradient)" filter="url(#shadow)" />

        {/* Barriga */}
        <ellipse cx="100" cy="120" rx="35" ry="45" fill="url(#bellyGradient)" />

        {/* Pintas verdes */}
        <circle cx="75" cy="85" r="4" fill="#228B22" opacity="0.7" />
        <circle cx="125" cy="95" r="3" fill="#228B22" opacity="0.7" />
        <circle cx="85" cy="140" r="3.5" fill="#228B22" opacity="0.7" />
        <circle cx="115" cy="145" r="3" fill="#228B22" opacity="0.7" />

        {/* Patas traseiras */}
        <g transform="translate(60, 165)">
          <ellipse cx="0" cy="0" rx="18" ry="22" fill="url(#bodyGradient)" />
          <circle cx="-12" cy="15" r="5" fill="#32CD32" />
          <circle cx="-5" cy="18" r="5" fill="#32CD32" />
          <circle cx="5" cy="18" r="5" fill="#32CD32" />
          <circle cx="12" cy="15" r="5" fill="#32CD32" />
        </g>

        <g transform="translate(140, 165)">
          <ellipse cx="0" cy="0" rx="18" ry="22" fill="url(#bodyGradient)" />
          <circle cx="-12" cy="15" r="5" fill="#32CD32" />
          <circle cx="-5" cy="18" r="5" fill="#32CD32" />
          <circle cx="5" cy="18" r="5" fill="#32CD32" />
          <circle cx="12" cy="15" r="5" fill="#32CD32" />
        </g>

        {/* Braço esquerdo */}
        <g transform={`translate(55, 100) rotate(${currentAutoAnimation === 'dance' ? Math.sin(armRotation * 0.1) * 30 : armRotation * 0.3})`}>
          <ellipse cx="0" cy="0" rx="12" ry="35" fill="url(#bodyGradient)" />
          <circle cx="0" cy="-35" r="14" fill="#32CD32" />
          <circle cx="-8" cy="-42" r="4" fill="#32CD32" />
          <circle cx="0" cy="-46" r="4" fill="#32CD32" />
          <circle cx="8" cy="-42" r="4" fill="#32CD32" />
        </g>

        {/* Braço direito com cetro */}
        <g transform={`translate(145, 100) rotate(${currentAutoAnimation === 'dance' ? -Math.sin(armRotation * 0.1) * 30 : -armRotation * 0.3})`}>
          <ellipse cx="0" cy="0" rx="12" ry="35" fill="url(#bodyGradient)" />
          <circle cx="0" cy="-35" r="14" fill="#32CD32" />
          {/* Cetro */}
          <line x1="0" y1="-35" x2="0" y2="-80" stroke="#FFD700" strokeWidth="4" />
          {/* Lanterna vermelha */}
          <circle cx="0" cy="-85" r="8" fill="#FF4444" />
          <circle cx="0" cy="-85" r="6" fill="#FF6666" />
          <circle cx="-2" cy="-87" r="2" fill="white" opacity="0.6" />
        </g>

        {/* COROA DOURADA */}
        <g transform="translate(100, 45)">
          {/* Base da coroa */}
          <path d="M 20 0 Q 30 -15 40 -10 Q 50 -20 60 -15 Q 70 -25 80 -10 Q 90 -15 100 0 Z" fill="url(#crownGradient)" stroke="#DAA520" strokeWidth="1.5" />
          
          {/* Picos com pedras */}
          <circle cx="30" cy="-25" r="6" fill="#FFD700" stroke="#DAA520" strokeWidth="1" />
          <circle cx="30" cy="-25" r="3" fill="#FFFF00" opacity="0.8" />
          
          <circle cx="50" cy="-35" r="7" fill="#FFD700" stroke="#DAA520" strokeWidth="1" />
          <circle cx="50" cy="-35" r="4" fill="#FFFF00" opacity="0.8" />
          
          <circle cx="70" cy="-28" r="6" fill="#FFD700" stroke="#DAA520" strokeWidth="1" />
          <circle cx="70" cy="-28" r="3" fill="#FFFF00" opacity="0.8" />
          
          <circle cx="90" cy="-20" r="6" fill="#FFD700" stroke="#DAA520" strokeWidth="1" />
          <circle cx="90" cy="-20" r="3" fill="#FFFF00" opacity="0.8" />
          
          {/* Pedras laterais menores */}
          <circle cx="25" cy="-10" r="4" fill="#FFA500" />
          <circle cx="95" cy="-10" r="4" fill="#FFA500" />
        </g>

        {/* Olho esquerdo */}
        <g>
          <circle cx="65" cy="70" r="18" fill="url(#eyeGradient)" />
          <circle cx="60" cy="60" r="6" fill="white" opacity="0.6" />
          {!isBlinking ? (
            <>
              <circle cx={leftPupil.x} cy={leftPupil.y} r="10" fill="#000000" />
              <circle cx={leftPupil.x - 3} cy={leftPupil.y - 3} r="3" fill="white" opacity="0.8" />
            </>
          ) : (
            <line x1="55" y1="70" x2="75" y2="70" stroke="#000000" strokeWidth="2" />
          )}
        </g>

        {/* Olho direito */}
        <g>
          <circle cx="135" cy="70" r="18" fill="url(#eyeGradient)" />
          <circle cx="140" cy="60" r="6" fill="white" opacity="0.6" />
          {!isBlinking ? (
            <>
              <circle cx={rightPupil.x} cy={rightPupil.y} r="10" fill="#000000" />
              <circle cx={rightPupil.x - 3} cy={rightPupil.y - 3} r="3" fill="white" opacity="0.8" />
            </>
          ) : (
            <line x1="125" y1="70" x2="145" y2="70" stroke="#000000" strokeWidth="2" />
          )}
        </g>

        {/* Boca grande e feliz */}
        <g>
          <path d="M 85 95 Q 100 115 115 95" fill="#FF1744" opacity="0.8" />
          <ellipse cx="100" cy="110" rx="10" ry="8" fill="#FF69B4" />
          <line x1="90" y1="95" x2="90" y2="105" stroke="white" strokeWidth="1.5" />
          <line x1="100" y1="95" x2="100" y2="108" stroke="white" strokeWidth="1.5" />
          <line x1="110" y1="95" x2="110" y2="105" stroke="white" strokeWidth="1.5" />
        </g>

        {/* Narinas */}
        <circle cx="92" cy="85" r="2" fill="#1a1a1a" />
        <circle cx="108" cy="85" r="2" fill="#1a1a1a" />
      </svg>
    </div>
  );
};

export default VerdinhoPremiumFinalV2;
