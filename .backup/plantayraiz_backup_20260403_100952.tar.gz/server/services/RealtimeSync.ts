/**
 * Sincronização em Tempo Real - WebSocket + SSE
 * 
 * Todas as atualizações da plataforma sincronizadas instantaneamente:
 * - Triagem Brisa IA
 * - Prescrição Digital
 * - Pagamento Mercado Pago
 * - Alertas WhatsApp
 * - Status de Consulta
 */

import { EventEmitter } from 'events';

interface RealtimeEvent {
  type: 'triage' | 'prescription' | 'payment' | 'alert' | 'consultation' | 'notification';
  data: any;
  timestamp: Date;
  userId?: string;
  triageId?: string;
  prescriptionId?: string;
  paymentId?: string;
}

interface SubscriberCallback {
  (event: RealtimeEvent): void;
}

export class RealtimeSyncService extends EventEmitter {
  private subscribers: Map<string, Set<SubscriberCallback>> = new Map();
  private eventHistory: RealtimeEvent[] = [];
  private maxHistorySize = 1000;

  constructor() {
    super();
    this.setupEventHandlers();
  }

  /**
   * Configurar handlers de eventos
   */
  private setupEventHandlers(): void {
    // Triagem Brisa
    this.on('brisa:triage:started', (data) => {
      this.broadcast({
        type: 'triage',
        data: { status: 'started', ...data },
        timestamp: new Date(),
      });
    });

    this.on('brisa:triage:analyzing', (data) => {
      this.broadcast({
        type: 'triage',
        data: { status: 'analyzing', ...data },
        timestamp: new Date(),
      });
    });

    this.on('brisa:triage:completed', (data) => {
      this.broadcast({
        type: 'triage',
        data: { status: 'completed', ...data },
        timestamp: new Date(),
      });
    });

    // Prescrição Digital
    this.on('prescription:created', (data) => {
      this.broadcast({
        type: 'prescription',
        data: { status: 'created', ...data },
        timestamp: new Date(),
      });
    });

    this.on('prescription:signed', (data) => {
      this.broadcast({
        type: 'prescription',
        data: { status: 'signed', ...data },
        timestamp: new Date(),
      });
    });

    this.on('prescription:authorized', (data) => {
      this.broadcast({
        type: 'prescription',
        data: { status: 'authorized', ...data },
        timestamp: new Date(),
      });
    });

    // Pagamento
    this.on('payment:initiated', (data) => {
      this.broadcast({
        type: 'payment',
        data: { status: 'initiated', ...data },
        timestamp: new Date(),
      });
    });

    this.on('payment:processing', (data) => {
      this.broadcast({
        type: 'payment',
        data: { status: 'processing', ...data },
        timestamp: new Date(),
      });
    });

    this.on('payment:approved', (data) => {
      this.broadcast({
        type: 'payment',
        data: { status: 'approved', ...data },
        timestamp: new Date(),
      });
    });

    this.on('payment:failed', (data) => {
      this.broadcast({
        type: 'payment',
        data: { status: 'failed', ...data },
        timestamp: new Date(),
      });
    });

    // Alertas WhatsApp
    this.on('alert:sent', (data) => {
      this.broadcast({
        type: 'alert',
        data: { status: 'sent', ...data },
        timestamp: new Date(),
      });
    });

    this.on('alert:timeout', (data) => {
      this.broadcast({
        type: 'alert',
        data: { status: 'timeout', ...data },
        timestamp: new Date(),
      });
    });

    // Consulta
    this.on('consultation:scheduled', (data) => {
      this.broadcast({
        type: 'consultation',
        data: { status: 'scheduled', ...data },
        timestamp: new Date(),
      });
    });

    this.on('consultation:started', (data) => {
      this.broadcast({
        type: 'consultation',
        data: { status: 'started', ...data },
        timestamp: new Date(),
      });
    });

    this.on('consultation:completed', (data) => {
      this.broadcast({
        type: 'consultation',
        data: { status: 'completed', ...data },
        timestamp: new Date(),
      });
    });
  }

  /**
   * Inscrever em eventos em tempo real
   */
  subscribe(eventType: string, callback: SubscriberCallback): () => void {
    if (!this.subscribers.has(eventType)) {
      this.subscribers.set(eventType, new Set());
    }

    this.subscribers.get(eventType)!.add(callback);

    // Retornar função de desinscrição
    return () => {
      this.subscribers.get(eventType)?.delete(callback);
    };
  }

  /**
   * Transmitir evento para todos os inscritos
   */
  private broadcast(event: RealtimeEvent): void {
    console.log(`[Realtime] 📡 Transmitindo evento: ${event.type}`);

    // Adicionar ao histórico
    this.eventHistory.push(event);
    if (this.eventHistory.length > this.maxHistorySize) {
      this.eventHistory.shift();
    }

    // Notificar inscritos
    const subscribers = this.subscribers.get(event.type);
    if (subscribers) {
      subscribers.forEach((callback) => {
        try {
          callback(event);
        } catch (error) {
          console.error('[Realtime] Erro ao chamar callback:', error);
        }
      });
    }

    // Notificar inscritos em todos os eventos
    const allSubscribers = this.subscribers.get('*');
    if (allSubscribers) {
      allSubscribers.forEach((callback) => {
        try {
          callback(event);
        } catch (error) {
          console.error('[Realtime] Erro ao chamar callback:', error);
        }
      });
    }
  }

  /**
   * Emitir evento de triagem Brisa
   */
  emitTriageStarted(data: any): void {
    this.emit('brisa:triage:started', data);
  }

  emitTriageAnalyzing(data: any): void {
    this.emit('brisa:triage:analyzing', data);
  }

  emitTriageCompleted(data: any): void {
    this.emit('brisa:triage:completed', data);
  }

  /**
   * Emitir evento de prescrição
   */
  emitPrescriptionCreated(data: any): void {
    this.emit('prescription:created', data);
  }

  emitPrescriptionSigned(data: any): void {
    this.emit('prescription:signed', data);
  }

  emitPrescriptionAuthorized(data: any): void {
    this.emit('prescription:authorized', data);
  }

  /**
   * Emitir evento de pagamento
   */
  emitPaymentInitiated(data: any): void {
    this.emit('payment:initiated', data);
  }

  emitPaymentProcessing(data: any): void {
    this.emit('payment:processing', data);
  }

  emitPaymentApproved(data: any): void {
    this.emit('payment:approved', data);
  }

  emitPaymentFailed(data: any): void {
    this.emit('payment:failed', data);
  }

  /**
   * Emitir evento de alerta
   */
  emitAlertSent(data: any): void {
    this.emit('alert:sent', data);
  }

  emitAlertTimeout(data: any): void {
    this.emit('alert:timeout', data);
  }

  /**
   * Emitir evento de consulta
   */
  emitConsultationScheduled(data: any): void {
    this.emit('consultation:scheduled', data);
  }

  emitConsultationStarted(data: any): void {
    this.emit('consultation:started', data);
  }

  emitConsultationCompleted(data: any): void {
    this.emit('consultation:completed', data);
  }

  /**
   * Obter histórico de eventos
   */
  getEventHistory(limit: number = 100): RealtimeEvent[] {
    return this.eventHistory.slice(-limit);
  }

  /**
   * Obter estatísticas em tempo real
   */
  getStats(): {
    totalEvents: number;
    eventTypes: Record<string, number>;
    subscribers: Record<string, number>;
  } {
    const eventTypes: Record<string, number> = {};
    this.eventHistory.forEach((event) => {
      eventTypes[event.type] = (eventTypes[event.type] || 0) + 1;
    });

    const subscribers: Record<string, number> = {};
    this.subscribers.forEach((set, key) => {
      subscribers[key] = set.size;
    });

    return {
      totalEvents: this.eventHistory.length,
      eventTypes,
      subscribers,
    };
  }

  /**
   * Limpar histórico
   */
  clearHistory(): void {
    this.eventHistory = [];
    console.log('[Realtime] Histórico de eventos limpo');
  }
}

// Exportar instância singleton
export const realtimeSyncService = new RealtimeSyncService();
