# Campanha de Marketing Agressiva - Planta & Raiz
## Estratégia de Crescimento para 20K Usuários em 30 Dias

---

## 📊 FASE 1: INFLUENCERS & CONTENT CREATORS (Dias 1-7)

### Segmentação de Influencers:

#### Tier 1 - Mega Influencers (100K-1M seguidores)
- **Categoria:** Saúde, Wellness, Cannabis Medicinal
- **Estratégia:** Parcerias de marca com comissão de 5% + bônus por conversão
- **Conteúdo:** Depoimentos, reviews de consultas, antes/depois
- **Orçamento:** R$ 50K-100K

**Influencers Alvo:**
- @dra_cannabis_br (Médica especialista em cannabis)
- @wellness_natureza (Wellness coach)
- @saude_holistica (Saúde alternativa)
- @farmacia_natural (Farmacêutico)
- @telemedicina_brasil (Telemedicina)

#### Tier 2 - Micro Influencers (10K-100K seguidores)
- **Categoria:** Saúde, Fitness, Nutrição, Lifestyle
- **Estratégia:** Código de desconto exclusivo (10% off) + comissão 3%
- **Conteúdo:** Unboxing, tutorial de uso, dia na vida
- **Orçamento:** R$ 30K-50K

**Estratégia de Recrutamento:**
1. Enviar convite personalizado com bônus de R$ 500 para primeiros 50 influencers
2. Fornecer kit completo: código promo, assets visuais, roteiros de vídeo
3. Acompanhamento semanal com relatórios de performance
4. Bônus extra para top 5 influencers (R$ 1K-5K)

### Conteúdo Recomendado:
```
Dia 1-2: "Descobri uma plataforma revolucionária para telemedicina"
Dia 3-4: "Consulta com especialista em cannabis medicinal (FÁCIL!)"
Dia 5-6: "Recebi minha receita digital em 30 minutos"
Dia 7: "Comprei medicamento no marketplace com frete grátis"
```

---

## 🏥 FASE 2: PARCERIAS COM FARMÁCIAS ANVISA (Dias 8-14)

### Estratégia B2B:

#### Farmácias Alvo:
1. **Farmácias Grandes** (Drogaria São Paulo, Farmácia do Dr. Ahorro, Farmácias Pague Menos)
   - Comissão: 8% por venda
   - Suporte: Treinamento de atendentes, materiais de marketing
   - Objetivo: 500 farmácias cadastradas em 30 dias

2. **Farmácias Independentes** (Farmácias de bairro, farmácias especializadas)
   - Comissão: 10% por venda
   - Suporte: Consultoria gratuita, sistema de gestão integrado
   - Objetivo: 2000 farmácias cadastradas em 30 dias

### Benefícios para Farmácias:
- ✅ Aumentar ticket médio (consulta + medicamento)
- ✅ Reduzir estoque parado (produtos cannabis)
- ✅ Receber pagamento em PIX em <5 minutos
- ✅ Dashboard de vendas em tempo real
- ✅ Suporte técnico 24/7

### Material de Marketing para Farmácias:
- Cartazes (A3, A4)
- Adesivos para balcão
- QR Code para consulta rápida
- Treinamento de atendentes (vídeo 10 min)
- Certificado de parceria

---

## 🔍 FASE 3: SEO & MARKETING DE CONTEÚDO (Dias 15-21)

### Keywords Alvo:
```
Primárias:
- "telemedicina cannabis brasil"
- "consulta médico cannabis online"
- "receita cannabis digital"
- "comprar medicamento cannabis legal"

Secundárias:
- "especialista em cannabis medicinal"
- "óleo de cannabis anvisa"
- "cápsulas de cannabis legal"
- "consulta online rápida"
- "receita digital assinada"
```

### Estratégia de Conteúdo:

#### Blog (2 posts/dia):
1. "Guia Completo: Como Funciona Telemedicina de Cannabis no Brasil"
2. "5 Benefícios Comprovados da Cannabis Medicinal"
3. "Receita Digital: Tudo que Você Precisa Saber"
4. "Comparativo: Telemedicina vs Consultório Tradicional"
5. "ANVISA Aprova Cannabis: Entenda as Novas Resoluções"

#### Videos (YouTube, TikTok, Instagram Reels):
- 15-30 segundos: "Consulta em 3 cliques"
- 1-2 minutos: Depoimento de paciente
- 3-5 minutos: Tutorial completo
- 10+ minutos: Entrevista com especialista

#### Podcasts:
- Episódios em podcasts de saúde/wellness
- Entrevista com especialistas
- Histórias de sucesso de pacientes

**Orçamento:** R$ 20K (conteúdo + distribuição)

---

## 📱 FASE 4: GOOGLE ADS & META ADS (Dias 22-30)

### Google Ads (Search + Display):
```
Budget: R$ 30K
CPC Alvo: R$ 2-5
CTR Alvo: 5%+
Conversão Alvo: 10%+

Campanhas:
1. "Telemedicina Cannabis" - R$ 10K
2. "Consulta Online Rápida" - R$ 10K
3. "Receita Digital" - R$ 10K
```

### Meta Ads (Facebook + Instagram):
```
Budget: R$ 40K
CPM Alvo: R$ 5-10
CTR Alvo: 3%+
Conversão Alvo: 8%+

Segmentação:
- Idade: 25-65 anos
- Interesse: Saúde, Wellness, Cannabis Medicinal
- Comportamento: Pesquisadores de saúde, compradores online
- Localização: Brasil (priorizar SP, RJ, MG, BA)

Criativos:
- Vídeo: Consulta em ação (15-30s)
- Carrossel: Passo a passo (5 imagens)
- Estático: Oferta especial (desconto 20% primeira consulta)
```

### Retargeting:
```
Pixel instalado em:
- Homepage
- Página de especialistas
- Página de checkout

Mensagem: "Volte e conclua sua consulta - 20% de desconto"
Budget: R$ 10K
Duração: 30 dias
```

---

## 📊 FASE 5: ANALYTICS & OTIMIZAÇÃO (Contínuo)

### KPIs Monitorados:
```
Aquisição:
- CAC (Custo de Aquisição): < R$ 50
- ROAS (Retorno sobre Gasto em Ads): > 5x
- Conversão por Canal: >10%

Engajamento:
- Taxa de Consulta Completada: >80%
- NPS (Net Promoter Score): >70
- Retenção 7 dias: >60%

Monetização:
- LTV (Lifetime Value): > R$ 500
- Ticket Médio: R$ 100-150
- Repeat Rate: >40%
```

### Dashboard de Acompanhamento:
- Google Analytics 4
- Meta Business Suite
- Mercado Pago Analytics
- Dashboard customizado Planta & Raiz

### Otimizações Semanais:
- Pausar campanhas com ROAS < 2x
- Aumentar budget para campanhas com ROAS > 5x
- A/B testing de criativos
- Ajuste de targeting baseado em performance

---

## 💰 ORÇAMENTO TOTAL: R$ 180K

| Fase | Descrição | Orçamento |
|------|-----------|-----------|
| 1 | Influencers | R$ 80K |
| 2 | Parcerias Farmácias | R$ 10K (suporte) |
| 3 | SEO & Conteúdo | R$ 20K |
| 4 | Google + Meta Ads | R$ 70K |
| 5 | Analytics & Tools | R$ 5K |
| **TOTAL** | | **R$ 185K** |

---

## 🎯 PROJEÇÕES DE RESULTADO

### Mês 1:
- **Usuários Adquiridos:** 20K
- **Consultas Realizadas:** 5K (25% de conversão)
- **Receita:** R$ 500K-750K
- **CAC:** R$ 37.50 (R$ 185K / 5K consultas)
- **LTV:** R$ 500-750 (estimado)
- **ROAS:** 2.7x-4x

### Mês 2-3:
- **Crescimento Viral:** Referrals + Indicação
- **Usuários Acumulados:** 100K+
- **Consultas Mensais:** 25K+
- **Receita Mensal:** R$ 2.5M-3.5M
- **CAC Reduzido:** R$ 20-25 (por referral)

### Mês 6:
- **Usuários:** 300K+
- **Consultas Mensais:** 75K+
- **Receita Mensal:** R$ 7.5M-10M
- **Margem de Lucro:** 40-50%
- **Posição:** Top 3 plataforma de telemedicina Brasil

---

## 🚀 PRÓXIMAS AÇÕES

1. **Semana 1:** Recrutar top 50 influencers + criar assets
2. **Semana 2:** Lançar campanhas Google + Meta Ads
3. **Semana 3:** Onboard 500+ farmácias
4. **Semana 4:** Otimizar baseado em dados + escalar budget

---

## ⚠️ RISCOS & MITIGAÇÃO

| Risco | Impacto | Mitigação |
|-------|---------|-----------|
| Baixa conversão de influencers | Alto | Selecionar influencers com audiência qualificada |
| Custo alto de aquisição | Alto | Otimizar ads continuamente, focar em referral |
| Problemas técnicos na plataforma | Crítico | Testes de carga, monitoramento 24/7 |
| Conformidade regulatória | Crítico | Revisar com jurídico antes de cada campanha |
| Concorrência | Médio | Diferenciação: IA + Marketplace + Preço |

---

**Status:** Pronto para implementação
**Data:** 23 de Fevereiro de 2026
**Responsável:** Equipe de Marketing Planta & Raiz
