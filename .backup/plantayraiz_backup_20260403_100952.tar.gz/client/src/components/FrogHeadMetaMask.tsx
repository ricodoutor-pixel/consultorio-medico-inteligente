import React, { useState, useEffect, useRef } from 'react';

interface MousePosition {
  x: number;
  y: number;
}

const FrogHeadMetaMask: React.FC = () => {
  const [mousePos, setMousePos] = useState<MousePosition>({ x: 0, y: 0 });
  const [headRotation, setHeadRotation] = useState({ x: 0, y: 0 });
  const frogRef = useRef<HTMLDivElement>(null);
  const [isHovered, setIsHovered] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });

      if (frogRef.current) {
        const rect = frogRef.current.getBoundingClientRect();
        const frogCenterX = rect.left + rect.width / 2;
        const frogCenterY = rect.top + rect.height / 2;

        const angle = Math.atan2(e.clientY - frogCenterY, e.clientX - frogCenterX);
        const distance = Math.sqrt(
          Math.pow(e.clientX - frogCenterX, 2) + Math.pow(e.clientY - frogCenterY, 2)
        );

        const maxDistance = 500;
        const rotation = Math.min((angle * 180) / Math.PI, 45);
        const tilt = Math.min((distance / maxDistance) * 15, 15);

        setHeadRotation({
          x: Math.sin(angle) * 20,
          y: Math.cos(angle) * 20,
        });
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <div
      ref={frogRef}
      className="fixed top-3 left-20 z-50 w-12 h-12 cursor-pointer group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      title="Pergunte ao Verdinho! 🐸"
    >
      {/* Cabeça do Sapo - MetaMask Style */}
      <div
        className="relative w-full h-full transition-transform duration-100"
        style={{
          transform: `perspective(1000px) rotateX(${headRotation.x}deg) rotateY(${headRotation.y}deg) scale(${
            isHovered ? 1.1 : 1
          })`,
        }}
      >
        {/* Cabeça Principal */}
        <div className="relative w-full h-full">
          {/* Topo da cabeça */}
          <div className="absolute inset-0 bg-gradient-to-b from-green-400 via-green-500 to-emerald-600 rounded-t-3xl rounded-b-lg shadow-lg"></div>

          {/* Olhos */}
          <div className="absolute top-3 left-1.5 w-2 h-2.5 bg-white rounded-full shadow-md">
            <div className="absolute inset-0.5 bg-black rounded-full"></div>
            <div className="absolute top-0.5 left-0.5 w-1 h-1 bg-white rounded-full opacity-60"></div>
          </div>

          <div className="absolute top-3 right-1.5 w-2 h-2.5 bg-white rounded-full shadow-md">
            <div className="absolute inset-0.5 bg-black rounded-full"></div>
            <div className="absolute top-0.5 right-0.5 w-1 h-1 bg-white rounded-full opacity-60"></div>
          </div>

          {/* Boca */}
          <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 w-3 h-1.5 border-b-2 border-green-700 rounded-b-full"></div>

          {/* Nariz */}
          <div className="absolute top-5 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-green-700 rounded-full"></div>

          {/* Brilho nos olhos (animado) */}
          <div
            className={`absolute top-2 left-2 w-1 h-1 bg-white rounded-full transition-opacity duration-300 ${
              isHovered ? 'opacity-100' : 'opacity-60'
            }`}
          ></div>

          <div
            className={`absolute top-2 right-2 w-1 h-1 bg-white rounded-full transition-opacity duration-300 ${
              isHovered ? 'opacity-100' : 'opacity-60'
            }`}
          ></div>
        </div>
      </div>

      {/* Tooltip */}
      <div className="absolute top-14 left-1/2 transform -translate-x-1/2 bg-slate-900 text-green-400 px-2 py-1 rounded-lg text-xs font-semibold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none shadow-lg border border-green-500/30">
        Pergunte ao Verdinho! 🐸
      </div>

      {/* Efeito de brilho ao hover */}
      <div
        className={`absolute inset-0 bg-gradient-to-r from-green-400/20 to-emerald-400/20 rounded-t-3xl rounded-b-lg blur-md transition-opacity duration-300 ${
          isHovered ? 'opacity-100' : 'opacity-0'
        }`}
      ></div>

      <style>{`
        @keyframes float {
          0%, 100% {
            transform: translateY(0px);
          }
          50% {
            transform: translateY(-5px);
          }
        }

        .frog-float {
          animation: float 3s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default FrogHeadMetaMask;
