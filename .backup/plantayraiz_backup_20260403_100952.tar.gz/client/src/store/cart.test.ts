import { describe, it, expect, beforeEach } from 'vitest';
import { useCart } from './cart';
import { Product } from '@/data/products';

const mockProduct: Product = {
  id: '1',
  name: 'Test Product',
  category: 'Test',
  priceValue: 100,
  image: 'test.jpg',
  description: 'Test description',
};

const mockProduct2: Product = {
  id: '2',
  name: 'Test Product 2',
  category: 'Test',
  priceValue: 50,
  image: 'test2.jpg',
  description: 'Test description 2',
};

describe('Cart Store', () => {
  beforeEach(() => {
    useCart.setState({ items: [] });
  });

  it('should add item to cart', () => {
    const { addItem, getItems } = useCart.getState();
    addItem(mockProduct);
    expect(getItems()).toHaveLength(1);
    expect(getItems()[0].product.id).toBe('1');
  });

  it('should increase quantity when adding same item', () => {
    const { addItem, getItems } = useCart.getState();
    addItem(mockProduct);
    addItem(mockProduct);
    expect(getItems()).toHaveLength(1);
    expect(getItems()[0].qty).toBe(2);
  });

  it('should remove item from cart', () => {
    const { addItem, removeItem, getItems } = useCart.getState();
    addItem(mockProduct);
    removeItem('1');
    expect(getItems()).toHaveLength(0);
  });

  it('should update quantity', () => {
    const { addItem, updateQty, getItems } = useCart.getState();
    addItem(mockProduct);
    updateQty('1', 5);
    expect(getItems()[0].qty).toBe(5);
  });

  it('should remove item when quantity is 0', () => {
    const { addItem, updateQty, getItems } = useCart.getState();
    addItem(mockProduct);
    updateQty('1', 0);
    expect(getItems()).toHaveLength(0);
  });

  it('should calculate correct total', () => {
    const { addItem, total } = useCart.getState();
    addItem(mockProduct);
    addItem(mockProduct2);
    expect(total()).toBe(150); // 100 + 50
  });

  it('should calculate correct subtotal with quantity', () => {
    const { addItem, getSubtotal } = useCart.getState();
    addItem({ ...mockProduct, qty: 2 } as any);
    addItem({ ...mockProduct2, qty: 3 } as any);
    expect(getSubtotal()).toBe(350); // (100 * 2) + (50 * 3)
  });

  it('should calculate tax correctly', () => {
    const { addItem, getTax } = useCart.getState();
    addItem(mockProduct);
    expect(getTax(0.1)).toBe(10); // 100 * 0.1
  });

  it('should calculate shipping correctly', () => {
    const { getShipping, addItem } = useCart.getState();
    expect(getShipping()).toBe(0); // Empty cart
    addItem(mockProduct);
    expect(getShipping()).toBe(10); // Non-empty cart
  });

  it('should calculate final total correctly', () => {
    const { addItem, getFinalTotal } = useCart.getState();
    addItem(mockProduct);
    const total = getFinalTotal(0.1, 10);
    expect(total).toBe(120); // 100 + (100 * 0.1) + 10
  });

  it('should count items correctly', () => {
    const { addItem, count } = useCart.getState();
    addItem(mockProduct);
    addItem(mockProduct);
    addItem(mockProduct2);
    expect(count()).toBe(3); // 2 + 1
  });

  it('should clear cart', () => {
    const { addItem, clearCart, getItems } = useCart.getState();
    addItem(mockProduct);
    addItem(mockProduct2);
    clearCart();
    expect(getItems()).toHaveLength(0);
  });

  it('should check if cart has items', () => {
    const { addItem, hasItems, clearCart } = useCart.getState();
    expect(hasItems()).toBe(false);
    addItem(mockProduct);
    expect(hasItems()).toBe(true);
    clearCart();
    expect(hasItems()).toBe(false);
  });
});
