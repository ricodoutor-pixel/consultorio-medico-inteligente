import { router, protectedProcedure, publicProcedure } from "../_core/trpc";
import { z } from "zod";
import { DigitalSignatureService } from "../services/DigitalSignatureService";

export const digitalSignatureRouter = router({
  /**
   * Criar contrato de assinatura para médico
   */
  createDoctorContract: protectedProcedure
    .input(
      z.object({
        doctorId: z.string(),
        doctorName: z.string(),
        doctorEmail: z.string().email(),
        crm: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      return await DigitalSignatureService.createDoctorContractSignature(
        input.doctorId,
        input.doctorName,
        input.doctorEmail,
        input.crm
      );
    }),

  /**
   * Criar contrato de assinatura para lojista
   */
  createShopkeeperContract: protectedProcedure
    .input(
      z.object({
        shopkeeperId: z.string(),
        shopName: z.string(),
        shopEmail: z.string().email(),
        cnpj: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      return await DigitalSignatureService.createShopkeeperContractSignature(
        input.shopkeeperId,
        input.shopName,
        input.shopEmail,
        input.cnpj
      );
    }),

  /**
   * Obter status de assinatura
   */
  getStatus: publicProcedure
    .input(z.object({ documentId: z.string() }))
    .query(async ({ input }) => {
      return await DigitalSignatureService.getSignatureStatus(input.documentId);
    }),

  /**
   * Marcar como assinado
   */
  markAsSigned: publicProcedure
    .input(
      z.object({
        documentId: z.string(),
        signerEmail: z.string().email(),
      })
    )
    .mutation(async ({ input }) => {
      return await DigitalSignatureService.markAsSigned(
        input.documentId,
        input.signerEmail
      );
    }),

  /**
   * Rejeitar assinatura
   */
  reject: publicProcedure
    .input(
      z.object({
        documentId: z.string(),
        signerEmail: z.string().email(),
      })
    )
    .mutation(async ({ input }) => {
      return await DigitalSignatureService.rejectSignature(
        input.documentId,
        input.signerEmail
      );
    }),

  /**
   * Obter documentos pendentes
   */
  getPending: protectedProcedure.query(async () => {
    return await DigitalSignatureService.getPendingDocuments();
  }),

  /**
   * Obter estatísticas
   */
  getStats: protectedProcedure.query(async () => {
    return await DigitalSignatureService.getSignatureStats();
  }),
});
