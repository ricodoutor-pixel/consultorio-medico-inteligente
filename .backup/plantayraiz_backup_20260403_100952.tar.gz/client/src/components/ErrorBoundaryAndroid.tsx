// ============================================================================
// ERROR BOUNDARY ANDROID — Capturar e Recuperar de Crashes
// Planta & Raiz 3.0 — Estabilidade em Dispositivos Móveis
// ============================================================================

import React, { ReactNode, ErrorInfo } from 'react';
import { AlertCircle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorCount: number;
}

/**
 * ErrorBoundary customizado para Android
 * Captura erros de renderização e oferece opção de recuperação
 */
export class ErrorBoundaryAndroid extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorCount: 0,
    };
  }

  static getDerivedStateFromError(error: Error): State {
    return {
      hasError: true,
      error,
      errorCount: 0,
    };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // Log erro para monitoramento
    console.error('ErrorBoundary capturou erro:', error);
    console.error('Error Info:', errorInfo);

    // Incrementar contador de erros
    this.setState((prevState) => ({
      errorCount: prevState.errorCount + 1,
    }));

    // Se muitos erros, limpar localStorage como último recurso
    if (this.state.errorCount > 3) {
      console.warn('Muitos erros detectados. Limpando cache local...');
      try {
        localStorage.clear();
        sessionStorage.clear();
      } catch (e) {
        console.error('Erro ao limpar storage:', e);
      }
    }
  }

  handleReset = () => {
    this.setState({
      hasError: false,
      error: null,
      errorCount: 0,
    });

    // Recarregar página
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-red-950/20 border border-red-500 rounded-lg p-6 flex flex-col items-center justify-center">
          <div className="text-center space-y-4">
            <AlertCircle className="w-16 h-16 text-red-500 mx-auto" />
            <h1 className="text-2xl font-bold text-white">Oops! Algo deu errado</h1>
            <p className="text-gray-300 max-w-md">
              Desculpe, encontramos um erro. Tente recarregar a página.
            </p>

            {process.env.NODE_ENV === 'development' && this.state.error && (
              <div className="bg-gray-900 p-4 rounded text-left text-sm text-gray-300 max-w-md overflow-auto max-h-32">
                <p className="font-mono text-red-400">{this.state.error.message}</p>
              </div>
            )}

            <div className="flex gap-2 justify-center">
              <Button
                onClick={this.handleReset}
                className="bg-green-600 hover:bg-green-700"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Recarregar
              </Button>
              <Button
                onClick={() => (window.location.href = '/')}
                variant="outline"
              >
                Ir para Home
              </Button>
            </div>

            {this.state.errorCount > 2 && (
              <p className="text-yellow-500 text-sm">
                ⚠️ Múltiplos erros detectados. Cache foi limpo.
              </p>
            )}
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundaryAndroid;
