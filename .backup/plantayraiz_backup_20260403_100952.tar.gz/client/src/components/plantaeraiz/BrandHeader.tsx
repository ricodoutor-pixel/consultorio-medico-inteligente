import { Leaf } from 'lucide-react';

export function BrandHeader() {
  return (
    <div className="flex items-center gap-2">
      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/20">
        <Leaf className="h-6 w-6 text-accent" />
      </div>
      <div className="flex flex-col">
        <span className="text-lg font-bold leading-none text-foreground">Planta</span>
        <span className="text-xs text-muted-foreground">& Raiz</span>
      </div>
    </div>
  );
}
