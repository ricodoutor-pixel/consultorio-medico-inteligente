import axios from 'axios';

/**
 * MercadoPagoSplitService - Integração com Mercado Pago Split
 * Gerencia divisão automática de pagamentos entre plataforma, médicos e lojistas
 */

interface SplitConfig {
  accessToken: string;
  publicKey: string;
  clientId: string;
  clientSecret: string;
  platformAccountId: string;
  environment: 'sandbox' | 'production';
}

interface PaymentSplit {
  totalAmount: number;
  platformFee: number; // 5% para lojistas, 7% para médicos
  recipientAmount: number;
  splits: Array<{
    account: string;
    amount: number;
    description: string;
  }>;
}

interface MercadoPagoPayment {
  id: string;
  status: string;
  statusDetail: string;
  transactionAmount: number;
  description: string;
  externalReference: string;
  paymentMethodId: string;
  paymentTypeId: string;
  payerEmail: string;
  dateCreated: string;
  dateApproved?: string;
  splits?: Array<{
    wallet_id: string;
    amount: number;
  }>;
}

export class MercadoPagoSplitService {
  private config: SplitConfig;
  private baseUrl: string;

  constructor(config: SplitConfig) {
    this.config = config;
    this.baseUrl =
      config.environment === 'production'
        ? 'https://api.mercadopago.com'
        : 'https://api.sandbox.mercadopago.com';
  }

  /**
   * Calcular divisão de pagamento
   */
  calculateSplit(
    totalAmount: number,
    type: 'consultation' | 'product',
    isSubscriber: boolean = false
  ): PaymentSplit {
    let platformFeePercentage = 0;

    if (type === 'consultation') {
      // Consultas médicas: 7% para plataforma (se não assinante)
      platformFeePercentage = isSubscriber ? 0 : 7;
    } else if (type === 'product') {
      // Produtos/shopping: 5% para plataforma
      platformFeePercentage = 5;
    }

    const platformFee = (totalAmount * platformFeePercentage) / 100;
    const recipientAmount = totalAmount - platformFee;

    return {
      totalAmount,
      platformFee,
      recipientAmount,
      splits: [
        {
          account: this.config.platformAccountId,
          amount: platformFee,
          description: `Taxa de plataforma (${platformFeePercentage}%)`,
        },
        {
          account: 'recipient-account', // Será preenchido dinamicamente
          amount: recipientAmount,
          description:
            type === 'consultation'
              ? 'Pagamento de consulta'
              : 'Pagamento de produto',
        },
      ],
    };
  }

  /**
   * Criar pagamento com split
   */
  async createPaymentWithSplit(
    consultationId: number,
    patientEmail: string,
    doctorId: number,
    doctorAccountId: string,
    totalAmount: number,
    description: string,
    isSubscriber: boolean = false
  ): Promise<MercadoPagoPayment> {
    try {
      // 1. Calcular split
      const split = this.calculateSplit(totalAmount, 'consultation', isSubscriber);

      // 2. Criar pagamento no Mercado Pago
      const paymentPayload = {
        transaction_amount: split.totalAmount,
        description: description,
        external_reference: `consultation-${consultationId}`,
        payer: {
          email: patientEmail,
        },
        payment_method_id: 'account_money', // Carteira do Mercado Pago
        notification_url: `${process.env.APP_URL}/api/webhooks/mercadopago`,
        // Split configuration
        charges: [
          {
            account_id: this.config.platformAccountId,
            amount: split.platformFee,
            description: split.splits[0].description,
          },
          {
            account_id: doctorAccountId,
            amount: split.recipientAmount,
            description: split.splits[1].description,
          },
        ],
      };

      const response = await axios.post(
        `${this.baseUrl}/v1/payments`,
        paymentPayload,
        {
          headers: {
            Authorization: `Bearer ${this.config.accessToken}`,
            'Content-Type': 'application/json',
          },
        }
      );

      return {
        id: response.data.id,
        status: response.data.status,
        statusDetail: response.data.status_detail,
        transactionAmount: response.data.transaction_amount,
        description: response.data.description,
        externalReference: response.data.external_reference,
        paymentMethodId: response.data.payment_method_id,
        paymentTypeId: response.data.payment_type_id,
        payerEmail: response.data.payer.email,
        dateCreated: response.data.date_created,
        dateApproved: response.data.date_approved,
      };
    } catch (error) {
      console.error('Erro ao criar pagamento com split:', error);
      throw new Error('Falha ao processar pagamento');
    }
  }

  /**
   * Obter informações de pagamento
   */
  async getPaymentInfo(paymentId: string): Promise<MercadoPagoPayment> {
    try {
      const response = await axios.get(
        `${this.baseUrl}/v1/payments/${paymentId}`,
        {
          headers: {
            Authorization: `Bearer ${this.config.accessToken}`,
          },
        }
      );

      return {
        id: response.data.id,
        status: response.data.status,
        statusDetail: response.data.status_detail,
        transactionAmount: response.data.transaction_amount,
        description: response.data.description,
        externalReference: response.data.external_reference,
        paymentMethodId: response.data.payment_method_id,
        paymentTypeId: response.data.payment_type_id,
        payerEmail: response.data.payer.email,
        dateCreated: response.data.date_created,
        dateApproved: response.data.date_approved,
      };
    } catch (error) {
      console.error('Erro ao obter informações de pagamento:', error);
      throw new Error('Falha ao obter informações de pagamento');
    }
  }

  /**
   * Criar conta para médico no Mercado Pago
   */
  async createDoctorAccount(
    doctorEmail: string,
    doctorName: string,
    doctorCPF: string
  ): Promise<{ accountId: string; accessToken: string }> {
    try {
      // 1. Criar conta de usuário
      const userResponse = await axios.post(
        `${this.baseUrl}/v1/users`,
        {
          email: doctorEmail,
          first_name: doctorName.split(' ')[0],
          last_name: doctorName.split(' ').slice(1).join(' '),
          identification: {
            type: 'CPF',
            number: doctorCPF,
          },
        },
        {
          headers: {
            Authorization: `Bearer ${this.config.accessToken}`,
          },
        }
      );

      const userId = userResponse.data.id;

      // 2. Gerar token de acesso para o médico
      const tokenResponse = await axios.post(
        `${this.baseUrl}/oauth/token`,
        {
          grant_type: 'authorization_code',
          client_id: this.config.clientId,
          client_secret: this.config.clientSecret,
          code: `doctor-${userId}`, // Simplificado para exemplo
          redirect_uri: `${process.env.APP_URL}/auth/mercadopago/callback`,
        }
      );

      return {
        accountId: userId,
        accessToken: tokenResponse.data.access_token,
      };
    } catch (error) {
      console.error('Erro ao criar conta de médico:', error);
      throw new Error('Falha ao criar conta no Mercado Pago');
    }
  }

  /**
   * Transferir fundos para conta do médico
   */
  async transferFundsToDoctorAccount(
    doctorAccountId: string,
    amount: number,
    consultationId: number
  ): Promise<{ transferId: string; status: string }> {
    try {
      const response = await axios.post(
        `${this.baseUrl}/v1/transfers`,
        {
          amount: amount,
          receiver_id: doctorAccountId,
          description: `Pagamento de consulta #${consultationId}`,
          external_reference: `transfer-consultation-${consultationId}`,
        },
        {
          headers: {
            Authorization: `Bearer ${this.config.accessToken}`,
            'Content-Type': 'application/json',
          },
        }
      );

      return {
        transferId: response.data.id,
        status: response.data.status,
      };
    } catch (error) {
      console.error('Erro ao transferir fundos:', error);
      throw new Error('Falha ao transferir fundos');
    }
  }

  /**
   * Webhook para processar notificações de pagamento
   */
  async handlePaymentWebhook(
    paymentId: string,
    status: string
  ): Promise<void> {
    try {
      // 1. Obter informações do pagamento
      const payment = await this.getPaymentInfo(paymentId);

      // 2. Atualizar status no banco de dados
      // await db.payments.update({
      //   where: { mercadoPagoId: paymentId },
      //   data: { status: status }
      // });

      // 3. Se aprovado, fazer split
      if (status === 'approved') {
        console.log(`Pagamento ${paymentId} aprovado. Split processado.`);
        // Aqui você faria a lógica de divisão de fundos
      }

      // 4. Se rejeitado, notificar usuário
      if (status === 'rejected') {
        console.log(`Pagamento ${paymentId} rejeitado.`);
        // Notificar paciente sobre falha
      }
    } catch (error) {
      console.error('Erro ao processar webhook:', error);
      throw new Error('Falha ao processar webhook de pagamento');
    }
  }

  /**
   * Obter saldo da conta
   */
  async getAccountBalance(accountId: string): Promise<number> {
    try {
      const response = await axios.get(
        `${this.baseUrl}/v1/accounts/${accountId}/balance`,
        {
          headers: {
            Authorization: `Bearer ${this.config.accessToken}`,
          },
        }
      );

      return response.data.available_balance;
    } catch (error) {
      console.error('Erro ao obter saldo:', error);
      return 0;
    }
  }
}

/**
 * Factory para criar instância do serviço
 */
export function createMercadoPagoSplitService(): MercadoPagoSplitService {
  return new MercadoPagoSplitService({
    accessToken: process.env.MERCADO_PAGO_ACCESS_TOKEN || '',
    publicKey: process.env.MERCADO_PAGO_PUBLIC_KEY || '',
    clientId: process.env.MERCADO_PAGO_CLIENT_ID || '',
    clientSecret: process.env.MERCADO_PAGO_CLIENT_SECRET || '',
    platformAccountId: process.env.MERCADO_PAGO_PLATFORM_ACCOUNT_ID || '',
    environment: (process.env.MERCADO_PAGO_ENVIRONMENT as 'sandbox' | 'production') || 'sandbox',
  });
}
