/**
 * 🐸 VERDINHO PREMIUM REALISTIC — SVG Interativo com Aparência Realista
 * 
 * Características:
 * - Corpo completo com barriga amarela
 * - Olhos amarelos com pupilas que seguem o mouse
 * - Boca vermelha grande com dentes
 * - Patas com dedos e unhas
 * - Pintas verdes no corpo
 * - Animações fluidas (pisca, salta, braços)
 * - 100% responsivo
 */

import React, { useState, useEffect, useRef } from 'react';

interface VerdinhoPremiumRealisticProps {
  size?: 'small' | 'medium' | 'large';
  position?: 'header' | 'center' | 'floating';
  onChat?: () => void;
  interactive?: boolean;
}

const VerdinhoPremiumRealistic: React.FC<VerdinhoPremiumRealisticProps> = ({
  size = 'medium',
  position = 'floating',
  onChat,
  interactive = true
}) => {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isBlinking, setIsBlinking] = useState(false);
  const [isJumping, setIsJumping] = useState(false);
  const [armRotation, setArmRotation] = useState(0);
  const svgRef = useRef<SVGSVGElement>(null);

  // Tamanhos
  const sizeMap = {
    small: 120,
    medium: 180,
    large: 240
  };

  const viewBoxSize = 200;
  const size_px = sizeMap[size];

  // Rastrear movimento do mouse
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!interactive || !svgRef.current) return;

      const rect = svgRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      setMousePos({ x, y });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [interactive]);

  // Piscar dos olhos
  useEffect(() => {
    const blinkInterval = setInterval(() => {
      setIsBlinking(true);
      setTimeout(() => setIsBlinking(false), 150);
    }, 3000 + Math.random() * 2000);

    return () => clearInterval(blinkInterval);
  }, []);

  // Saltar ocasionalmente
  useEffect(() => {
    const jumpInterval = setInterval(() => {
      setIsJumping(true);
      setTimeout(() => setIsJumping(false), 600);
    }, 5000 + Math.random() * 3000);

    return () => clearInterval(jumpInterval);
  }, []);

  // Movimento dos braços
  useEffect(() => {
    const armInterval = setInterval(() => {
      setArmRotation((prev) => (prev + 5) % 360);
    }, 50);

    return () => clearInterval(armInterval);
  }, []);

  // Calcular posição dos olhos seguindo o mouse
  const calculateEyePosition = (eyeCenterX: number, eyeCenterY: number) => {
    if (!interactive) return { x: eyeCenterX, y: eyeCenterY };

    const rect = svgRef.current?.getBoundingClientRect();
    if (!rect) return { x: eyeCenterX, y: eyeCenterY };

    const angle = Math.atan2(mousePos.y - rect.height / 2, mousePos.x - rect.width / 2);
    const distance = 8; // Distância máxima da pupila

    return {
      x: eyeCenterX + Math.cos(angle) * distance,
      y: eyeCenterY + Math.sin(angle) * distance
    };
  };

  const leftPupil = calculateEyePosition(65, 70);
  const rightPupil = calculateEyePosition(135, 70);

  const jumpTransform = isJumping ? 'translate(0, -30)' : 'translate(0, 0)';
  const jumpTransition = 'transform 0.6s cubic-bezier(0.34, 1.56, 0.64, 1)';

  return (
    <div
      className={`flex items-center justify-center cursor-pointer transition-transform hover:scale-110 ${
        position === 'header' ? 'fixed top-4 right-4 z-40' : position === 'center' ? 'flex justify-center' : ''
      }`}
      onClick={onChat}
      title="Clique para conversar com Verdinho"
    >
      <svg
        ref={svgRef}
        viewBox={`0 0 ${viewBoxSize} ${viewBoxSize}`}
        width={size_px}
        height={size_px}
        className="filter drop-shadow-lg"
        style={{ transition: jumpTransition, transform: jumpTransform }}
      >
        {/* Definições de gradientes e filtros */}
        <defs>
          <radialGradient id="bodyGradient" cx="40%" cy="40%">
            <stop offset="0%" stopColor="#7FFF00" />
            <stop offset="100%" stopColor="#32CD32" />
          </radialGradient>

          <radialGradient id="bellyGradient" cx="50%" cy="50%">
            <stop offset="0%" stopColor="#FFFF99" />
            <stop offset="100%" stopColor="#FFFF00" />
          </radialGradient>

          <radialGradient id="eyeGradient" cx="35%" cy="35%">
            <stop offset="0%" stopColor="#FFFF99" />
            <stop offset="100%" stopColor="#FFD700" />
          </radialGradient>

          <filter id="shadow" x="-50%" y="-50%" width="200%" height="200%">
            <feDropShadow dx="2" dy="2" stdDeviation="3" floodOpacity="0.3" />
          </filter>
        </defs>

        {/* Corpo principal (elipse) */}
        <ellipse cx="100" cy="110" rx="55" ry="65" fill="url(#bodyGradient)" filter="url(#shadow)" />

        {/* Barriga amarela */}
        <ellipse cx="100" cy="120" rx="35" ry="45" fill="url(#bellyGradient)" />

        {/* Pintas verdes no corpo */}
        <circle cx="75" cy="85" r="4" fill="#228B22" opacity="0.7" />
        <circle cx="125" cy="95" r="3" fill="#228B22" opacity="0.7" />
        <circle cx="85" cy="140" r="3.5" fill="#228B22" opacity="0.7" />
        <circle cx="115" cy="145" r="3" fill="#228B22" opacity="0.7" />
        <circle cx="70" cy="120" r="2.5" fill="#228B22" opacity="0.7" />
        <circle cx="130" cy="130" r="2.5" fill="#228B22" opacity="0.7" />

        {/* Pata traseira esquerda */}
        <g transform="translate(60, 165)">
          <ellipse cx="0" cy="0" rx="18" ry="22" fill="url(#bodyGradient)" />
          {/* Dedos */}
          <circle cx="-12" cy="15" r="5" fill="#32CD32" />
          <circle cx="-5" cy="18" r="5" fill="#32CD32" />
          <circle cx="5" cy="18" r="5" fill="#32CD32" />
          <circle cx="12" cy="15" r="5" fill="#32CD32" />
          {/* Unhas */}
          <circle cx="-12" cy="18" r="2" fill="#1a1a1a" />
          <circle cx="-5" cy="21" r="2" fill="#1a1a1a" />
          <circle cx="5" cy="21" r="2" fill="#1a1a1a" />
          <circle cx="12" cy="18" r="2" fill="#1a1a1a" />
        </g>

        {/* Pata traseira direita */}
        <g transform="translate(140, 165)">
          <ellipse cx="0" cy="0" rx="18" ry="22" fill="url(#bodyGradient)" />
          {/* Dedos */}
          <circle cx="-12" cy="15" r="5" fill="#32CD32" />
          <circle cx="-5" cy="18" r="5" fill="#32CD32" />
          <circle cx="5" cy="18" r="5" fill="#32CD32" />
          <circle cx="12" cy="15" r="5" fill="#32CD32" />
          {/* Unhas */}
          <circle cx="-12" cy="18" r="2" fill="#1a1a1a" />
          <circle cx="-5" cy="21" r="2" fill="#1a1a1a" />
          <circle cx="5" cy="21" r="2" fill="#1a1a1a" />
          <circle cx="12" cy="18" r="2" fill="#1a1a1a" />
        </g>

        {/* Braço esquerdo */}
        <g transform={`translate(55, 100) rotate(${armRotation * 0.5})`}>
          <ellipse cx="0" cy="0" rx="12" ry="35" fill="url(#bodyGradient)" />
          {/* Mão */}
          <circle cx="0" cy="-35" r="14" fill="#32CD32" />
          {/* Dedos */}
          <circle cx="-8" cy="-42" r="4" fill="#32CD32" />
          <circle cx="0" cy="-46" r="4" fill="#32CD32" />
          <circle cx="8" cy="-42" r="4" fill="#32CD32" />
        </g>

        {/* Braço direito */}
        <g transform={`translate(145, 100) rotate(-${armRotation * 0.5})`}>
          <ellipse cx="0" cy="0" rx="12" ry="35" fill="url(#bodyGradient)" />
          {/* Mão */}
          <circle cx="0" cy="-35" r="14" fill="#32CD32" />
          {/* Dedos */}
          <circle cx="-8" cy="-42" r="4" fill="#32CD32" />
          <circle cx="0" cy="-46" r="4" fill="#32CD32" />
          <circle cx="8" cy="-42" r="4" fill="#32CD32" />
        </g>

        {/* Olho esquerdo */}
        <g>
          <circle cx="65" cy="70" r="18" fill="url(#eyeGradient)" />
          {/* Brilho */}
          <circle cx="60" cy="60" r="6" fill="white" opacity="0.6" />
          {/* Pupila */}
          {!isBlinking ? (
            <>
              <circle cx={leftPupil.x} cy={leftPupil.y} r="10" fill="#000000" />
              <circle cx={leftPupil.x - 3} cy={leftPupil.y - 3} r="3" fill="white" opacity="0.8" />
            </>
          ) : (
            <line x1="55" y1="70" x2="75" y2="70" stroke="#000000" strokeWidth="2" />
          )}
        </g>

        {/* Olho direito */}
        <g>
          <circle cx="135" cy="70" r="18" fill="url(#eyeGradient)" />
          {/* Brilho */}
          <circle cx="140" cy="60" r="6" fill="white" opacity="0.6" />
          {/* Pupila */}
          {!isBlinking ? (
            <>
              <circle cx={rightPupil.x} cy={rightPupil.y} r="10" fill="#000000" />
              <circle cx={rightPupil.x - 3} cy={rightPupil.y - 3} r="3" fill="white" opacity="0.8" />
            </>
          ) : (
            <line x1="125" y1="70" x2="145" y2="70" stroke="#000000" strokeWidth="2" />
          )}
        </g>

        {/* Boca vermelha grande */}
        <g>
          {/* Lábio superior */}
          <path
            d="M 85 95 Q 100 105 115 95"
            fill="none"
            stroke="#DC143C"
            strokeWidth="3"
            strokeLinecap="round"
          />
          {/* Lábio inferior */}
          <path
            d="M 85 95 Q 100 110 115 95"
            fill="#FF1744"
            opacity="0.8"
          />
          {/* Língua */}
          <ellipse cx="100" cy="108" rx="8" ry="6" fill="#FF69B4" />
          {/* Dentes */}
          <line x1="90" y1="95" x2="90" y2="102" stroke="white" strokeWidth="1.5" />
          <line x1="100" y1="95" x2="100" y2="103" stroke="white" strokeWidth="1.5" />
          <line x1="110" y1="95" x2="110" y2="102" stroke="white" strokeWidth="1.5" />
        </g>

        {/* Narinas */}
        <circle cx="92" cy="85" r="2" fill="#1a1a1a" />
        <circle cx="108" cy="85" r="2" fill="#1a1a1a" />

        {/* Tooltip ao hover */}
        <text
          x="100"
          y="30"
          textAnchor="middle"
          fontSize="12"
          fill="#00FF00"
          opacity="0"
          className="hover:opacity-100 transition-opacity"
          style={{ pointerEvents: 'none' }}
        >
          💬 Clique para conversar!
        </text>
      </svg>
    </div>
  );
};

export default VerdinhoPremiumRealistic;
