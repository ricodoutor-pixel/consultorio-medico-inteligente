export interface CannabisStrain {
  id: number;
  nome: string;
  tipo: string;
  thc: string;
  cbd: string;
  descricao: string;
  efeitos: string[];
  sabores: string[];
  beneficiosSaude: string[];
  origem: string;
  florescimento: string;
  dificuldade: string;
  rendimento: string;
  avaliacao: number;
  imagem: string;
  terpenos?: string[];
  aplicacoesMedicas?: { condicao: string; eficacia: "baixa" | "média" | "alta"; evidencia: "anedótica" | "preliminar" | "estabelecida" }[];
}

// Local AI-generated cannabis flower images by type
import indicaPurple from "@/assets/strains/indica-purple.jpg";
import indicaDeep from "@/assets/strains/indica-deep.jpg";
import indicaPink from "@/assets/strains/indica-pink.jpg";
import indicaGold from "@/assets/strains/indica-gold.jpg";
import indicaDark from "@/assets/strains/indica-dark.jpg";
import indicaEmerald from "@/assets/strains/indica-emerald.jpg";
import indicaLavender from "@/assets/strains/indica-lavender.jpg";
import indicaRoyal from "@/assets/strains/indica-royal.jpg";
import sativaGreen from "@/assets/strains/sativa-green.jpg";
import sativaLime from "@/assets/strains/sativa-lime.jpg";
import sativaForest from "@/assets/strains/sativa-forest.jpg";
import sativaYellow from "@/assets/strains/sativa-yellow.jpg";
import sativaAmber from "@/assets/strains/sativa-amber.jpg";
import sativaCitrus from "@/assets/strains/sativa-citrus.jpg";
import sativaRuby from "@/assets/strains/sativa-ruby.jpg";
import sativaNeon from "@/assets/strains/sativa-neon.jpg";
import hybridOrange from "@/assets/strains/hybrid-orange.jpg";
import hybridGold from "@/assets/strains/hybrid-gold.jpg";
import hybridRed from "@/assets/strains/hybrid-red.jpg";
import hybridBlue from "@/assets/strains/hybrid-blue.jpg";
import hybridMagenta from "@/assets/strains/hybrid-magenta.jpg";
import hybridAmber from "@/assets/strains/hybrid-amber.jpg";
import hybridTeal from "@/assets/strains/hybrid-teal.jpg";
import hybridSunset from "@/assets/strains/hybrid-sunset.jpg";
import cbdFrosty from "@/assets/strains/cbd-frosty.jpg";
import cbdEmerald from "@/assets/strains/cbd-emerald.jpg";
import cbdSilver from "@/assets/strains/cbd-silver.jpg";
import cbdWhite from "@/assets/strains/cbd-white.jpg";
import cbdMint from "@/assets/strains/cbd-mint.jpg";
import medicinalPurple from "@/assets/strains/medicinal-purple.jpg";
import medicinalSilver from "@/assets/strains/medicinal-silver.jpg";
import medicinalGold from "@/assets/strains/medicinal-gold.jpg";
import medicinalRose from "@/assets/strains/medicinal-rose.jpg";
// Named strain images
import imgCharlottesWeb from "@/assets/strains/charlottes-web.jpg";
import imgACDC from "@/assets/strains/acdc.jpg";
import imgHarlequin from "@/assets/strains/harlequin.jpg";
import imgCannatonic from "@/assets/strains/cannatonic.jpg";
import imgBlueDream from "@/assets/strains/blue-dream.jpg";
import imgOGKush from "@/assets/strains/og-kush.jpg";
import imgGranddaddyPurple from "@/assets/strains/granddaddy-purple.jpg";
import imgNorthernLights from "@/assets/strains/northern-lights.jpg";
import imgSourDiesel from "@/assets/strains/sour-diesel.jpg";

// Named strain map — direct 1:1 images for known strains
const namedStrainImages: Record<string, string> = {
  "Charlotte's Web": imgCharlottesWeb,
  "ACDC": imgACDC,
  "Harlequin": imgHarlequin,
  "Cannatonic": imgCannatonic,
  "Blue Dream": imgBlueDream,
  "OG Kush": imgOGKush,
  "Granddaddy Purple": imgGranddaddyPurple,
  "Northern Lights": imgNorthernLights,
  "Sour Diesel": imgSourDiesel,
};

const indicaImages = [indicaPurple, indicaDeep, indicaPink, indicaGold, indicaDark, indicaEmerald, indicaLavender, indicaRoyal];
const sativaImages = [sativaGreen, sativaLime, sativaForest, sativaYellow, sativaAmber, sativaCitrus, sativaRuby, sativaNeon];
const hybridImages = [hybridOrange, hybridGold, hybridRed, hybridBlue, hybridMagenta, hybridAmber, hybridTeal, hybridSunset];
const cbdImages = [cbdFrosty, cbdEmerald, cbdSilver, cbdWhite, cbdMint];
const medicinalImages = [medicinalPurple, medicinalSilver, medicinalGold, medicinalRose];

const aiImg = (name: string, type: string) => {
  // First check for named strain images
  if (namedStrainImages[name]) return namedStrainImages[name];
  
  const seed = Math.abs([...name].reduce((h, c) => ((h << 5) - h) + c.charCodeAt(0), 0));
  const t = type.toLowerCase();
  if (t.includes("medicinal") || t.includes("especializada")) return medicinalImages[seed % medicinalImages.length];
  if (t.includes("indica")) return indicaImages[seed % indicaImages.length];
  if (t.includes("sativa")) return sativaImages[seed % sativaImages.length];
  if (t.includes("cbd")) return cbdImages[seed % cbdImages.length];
  return hybridImages[seed % hybridImages.length];
};

export const getPlantImage = (id: number) => {
  const strain = strains.find(s => s.id === id);
  return strain?.imagem || "/placeholder.svg";
};

export const getPlantImageFallback = (_id: number) => "/placeholder.svg";

// Terpene profiles by strain type
const terpenosIndica = ["Mirceno", "Linalol", "β-Cariofileno", "Humuleno"];
const terpenosSativa = ["Limoneno", "Pineno", "Terpinoleno", "Ocimeno"];
const terpenosHibrida = ["Mirceno", "Limoneno", "β-Cariofileno", "Pineno"];
const terpenosCBD = ["Mirceno", "β-Cariofileno", "Bisabolol", "Guaiol"];
const terpenosMedicinal = ["β-Cariofileno", "Mirceno", "Linalol", "Bisabolol"];

export const getTerpenosByType = (tipo: string): string[] => {
  const t = tipo.toLowerCase();
  if (t.includes("medicinal") || t.includes("especializada")) return terpenosMedicinal;
  if (t.includes("cbd")) return terpenosCBD;
  if (t.includes("indica")) return terpenosIndica;
  if (t.includes("sativa")) return terpenosSativa;
  return terpenosHibrida;
};

export const terpenoInfo: Record<string, { cor: string; efeito: string }> = {
  "Mirceno": { cor: "hsl(142,70%,45%)", efeito: "Relaxamento, sedação, anti-inflamatório" },
  "Limoneno": { cor: "hsl(45,76%,52%)", efeito: "Energia, humor, ansiolítico" },
  "Linalol": { cor: "hsl(270,60%,60%)", efeito: "Calmante, ansiolítico, analgésico" },
  "β-Cariofileno": { cor: "hsl(25,80%,50%)", efeito: "Anti-inflamatório, analgésico" },
  "Pineno": { cor: "hsl(160,50%,45%)", efeito: "Alerta, anti-inflamatório, broncodilatador" },
  "Humuleno": { cor: "hsl(35,60%,45%)", efeito: "Supressor de apetite, anti-inflamatório" },
  "Terpinoleno": { cor: "hsl(200,50%,55%)", efeito: "Sedativo, antioxidante, antibacteriano" },
  "Ocimeno": { cor: "hsl(180,50%,50%)", efeito: "Anti-inflamatório, antifúngico" },
  "Bisabolol": { cor: "hsl(300,40%,60%)", efeito: "Anti-irritação, anti-inflamatório" },
  "Guaiol": { cor: "hsl(120,30%,55%)", efeito: "Anti-inflamatório, antimicrobiano" },
};

export const strainCategories = [
  { nome: "Alto CBD", emoji: "💚", descricao: "Fins terapêuticos" },
  { nome: "Sativa", emoji: "☀️", descricao: "Energia e criatividade" },
  { nome: "Indica", emoji: "🌙", descricao: "Relaxamento profundo" },
  { nome: "Híbrida", emoji: "🌿", descricao: "Efeitos balanceados" },
  { nome: "Medicinal", emoji: "🏥", descricao: "Uso farmacêutico" },
];

export const strains: CannabisStrain[] = [
  // === 1-9: ORIGINAIS COM FOTOS LOCAIS ===
  {
    id: 1, nome: "Charlotte's Web", tipo: "Alto CBD", thc: "0.3% - 1%", cbd: "15% - 20%",
    descricao: "Variedade com altíssimo teor de CBD, desenvolvida pelos irmãos Stanley nos EUA. Ficou mundialmente famosa pelo caso de Charlotte Figi, uma criança com epilepsia severa (Síndrome de Dravet) que obteve melhora significativa com seu uso.",
    efeitos: ["Relaxamento", "Clareza mental", "Sem efeito psicoativo significativo"],
    sabores: ["Terroso", "Herbáceo", "Pinho"],
    beneficiosSaude: ["Epilepsia", "Ansiedade", "Inflamação", "Dor crônica"],
    origem: "EUA — Irmãos Stanley", florescimento: "9-12 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.9, imagem: aiImg("Charlotte's Web", "Alto CBD"),
  },
  {
    id: 2, nome: "ACDC", tipo: "Alto CBD", thc: "1% - 6%", cbd: "14% - 20%",
    descricao: "Fenótipo de alto CBD derivado da Cannatonic, com proporção CBD:THC de até 20:1. Uma das variedades mais utilizadas em terapias com canabidiol no mundo.",
    efeitos: ["Calmante", "Foco", "Leve relaxamento corporal"],
    sabores: ["Terroso", "Madeira", "Cereja"],
    beneficiosSaude: ["Ansiedade", "Dor neuropática", "Esclerose múltipla", "Artrite"],
    origem: "Espanha", florescimento: "9-10 semanas", dificuldade: "Fácil", rendimento: "350-450g/m²", avaliacao: 4.8, imagem: aiImg("ACDC", "Alto CBD"),
  },
  {
    id: 3, nome: "Harlequin", tipo: "Sativa dominante (rica em CBD)", thc: "4% - 10%", cbd: "8% - 15%",
    descricao: "Sativa dominante com proporção consistente de CBD:THC de 5:2. Permite alívio terapêutico sem efeitos psicoativos intensos, mantendo clareza e funcionalidade durante o dia.",
    efeitos: ["Equilíbrio mental", "Alívio da dor", "Leve euforia controlada"],
    sabores: ["Manga", "Terroso", "Cítrico"],
    beneficiosSaude: ["Dor crônica", "Inflamação", "Ansiedade", "Enxaqueca"],
    origem: "Colômbia/Tailândia/Suíça", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "300-400g/m²", avaliacao: 4.7, imagem: aiImg("Harlequin", "Sativa CBD"),
  },
  {
    id: 4, nome: "Cannatonic", tipo: "Híbrida (rica em CBD)", thc: "5% - 8%", cbd: "6% - 17%",
    descricao: "Híbrida medicinal resultado do cruzamento entre MK Ultra e G13 Haze. Conhecida pelo baixo THC e alto CBD, é amplamente prescrita para tratamento de dor e espasmos musculares.",
    efeitos: ["Relaxamento", "Calma mental", "Pouco efeito psicoativo"],
    sabores: ["Cítrico", "Terroso", "Amadeirado"],
    beneficiosSaude: ["Espasmos musculares", "Dor crônica", "Estresse", "Inflamação"],
    origem: "Espanha — Resin Seeds", florescimento: "9-10 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.6, imagem: aiImg("Cannatonic", "Híbrida CBD"),
  },
  {
    id: 5, nome: "Blue Dream", tipo: "Híbrida (Sativa dominante)", thc: "17% - 24%", cbd: "0.1% - 0.2%",
    descricao: "Cruzamento de Blueberry Indica com Super Silver Haze. Uma das variedades mais populares da Califórnia, oferece equilíbrio perfeito entre relaxamento corporal e estimulação cerebral criativa.",
    efeitos: ["Energia", "Criatividade", "Euforia leve"],
    sabores: ["Mirtilo", "Baunilha", "Doce"],
    beneficiosSaude: ["Depressão", "Fadiga", "Dor leve", "Estresse"],
    origem: "EUA — Califórnia", florescimento: "9-10 semanas", dificuldade: "Fácil", rendimento: "500-600g/m²", avaliacao: 4.8, imagem: aiImg("Blue Dream", "Híbrida Sativa"),
  },
  {
    id: 6, nome: "OG Kush", tipo: "Híbrida (Indica dominante)", thc: "19% - 26%", cbd: "<1%",
    descricao: "Linhagem icônica da costa oeste americana. Base genética para inúmeras variedades modernas, oferece potente efeito cerebral e corporal balanceado.",
    efeitos: ["Relaxamento profundo", "Sedação leve", "Alívio da tensão"],
    sabores: ["Pinho", "Terroso", "Amadeirado"],
    beneficiosSaude: ["Dor crônica", "Insônia", "Ansiedade", "Estresse"],
    origem: "EUA — Flórida/Califórnia", florescimento: "8-9 semanas", dificuldade: "Difícil", rendimento: "350-450g/m²", avaliacao: 4.7, imagem: aiImg("OG Kush", "Híbrida Indica"),
  },
  {
    id: 7, nome: "Granddaddy Purple", tipo: "Indica", thc: "17% - 23%", cbd: "<1%",
    descricao: "Indica clássica resultado do cruzamento de Purple Urkle e Big Bud. Reconhecida pelos tricomas densos e coloração púrpura intensa.",
    efeitos: ["Sedação", "Relaxamento corporal intenso", "Efeito calmante"],
    sabores: ["Uva", "Baga", "Doce"],
    beneficiosSaude: ["Insônia", "Espasmos musculares", "Dor intensa", "Perda de apetite"],
    origem: "EUA — Ken Estes", florescimento: "8-11 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.6, imagem: aiImg("Granddaddy Purple", "Indica"),
  },
  {
    id: 8, nome: "Northern Lights", tipo: "Indica", thc: "16% - 21%", cbd: "<1%",
    descricao: "Uma das indicas puras mais famosas do mundo. Reconhecida por seu crescimento compacto, resina cristalina e efeitos profundamente relaxantes.",
    efeitos: ["Relaxamento profundo", "Sensação de bem-estar", "Auxílio no sono"],
    sabores: ["Pinho", "Terroso", "Doce"],
    beneficiosSaude: ["Insônia", "Ansiedade", "Dor crônica", "Estresse"],
    origem: "EUA — Pacific Northwest", florescimento: "7-9 semanas", dificuldade: "Fácil", rendimento: "500-600g/m²", avaliacao: 4.7, imagem: aiImg("Northern Lights", "Indica"),
  },
  {
    id: 9, nome: "Sour Diesel", tipo: "Sativa", thc: "20% - 25%", cbd: "<1%",
    descricao: "Sativa de ação rápida com aroma pungente de combustível diesel. Uma das sativas mais energizantes e estimulantes disponíveis.",
    efeitos: ["Energia intensa", "Foco", "Estimulação mental"],
    sabores: ["Diesel", "Cítrico", "Terroso"],
    beneficiosSaude: ["Depressão", "Fadiga", "Estresse", "Dor leve"],
    origem: "EUA — Costa Leste", florescimento: "10-11 semanas", dificuldade: "Difícil", rendimento: "400-500g/m²", avaliacao: 4.7, imagem: aiImg("Sour Diesel", "Sativa"),
  },

  // === 10-100: VARIEDADES COM IMAGENS DE IA ===
  {
    id: 10, nome: "White Widow", tipo: "Híbrida", thc: "18% - 25%", cbd: "<1%",
    descricao: "Uma das variedades mais famosas do mundo, originária da Holanda. Cruzamento de uma sativa brasileira com uma indica do sul da Índia, produz buds cobertos de resina branca cristalina.",
    efeitos: ["Euforia", "Energia criativa", "Relaxamento equilibrado"],
    sabores: ["Terroso", "Amadeirado", "Picante"],
    beneficiosSaude: ["Depressão", "Estresse", "Dor", "Fadiga"],
    origem: "Holanda — Green House Seeds", florescimento: "8-9 semanas", dificuldade: "Fácil", rendimento: "450-550g/m²", avaliacao: 4.8, imagem: aiImg("White Widow", "Hybrid"),
  },
  {
    id: 11, nome: "Jack Herer", tipo: "Sativa", thc: "18% - 24%", cbd: "<1%",
    descricao: "Nomeada em homenagem ao ativista americano Jack Herer, é um cruzamento de Haze, Northern Lights #5 e Shiva Skunk. Premiada múltiplas vezes na Cannabis Cup.",
    efeitos: ["Clareza mental", "Energia", "Felicidade"],
    sabores: ["Pinho", "Especiarias", "Floral"],
    beneficiosSaude: ["Depressão", "Fadiga", "Estresse", "Falta de foco"],
    origem: "Holanda — Sensi Seeds", florescimento: "8-10 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.8, imagem: aiImg("Jack Herer", "Sativa"),
  },
  {
    id: 12, nome: "Amnesia Haze", tipo: "Sativa", thc: "20% - 25%", cbd: "<1%",
    descricao: "Sativa poderosa com genética de South Asian, Jamaican e Haze. Vencedora da Cannabis Cup, conhecida por seu efeito cerebral intenso e duradouro.",
    efeitos: ["Euforia intensa", "Energia", "Criatividade"],
    sabores: ["Cítrico", "Limão", "Terroso"],
    beneficiosSaude: ["Depressão", "Fadiga crônica", "Estresse", "TDAH"],
    origem: "Holanda", florescimento: "10-12 semanas", dificuldade: "Difícil", rendimento: "500-650g/m²", avaliacao: 4.7, imagem: aiImg("Amnesia Haze", "Sativa"),
  },
  {
    id: 13, nome: "Afghan Kush", tipo: "Indica", thc: "15% - 20%", cbd: "1% - 6%",
    descricao: "Indica landrace pura originária das montanhas Hindu Kush no Afeganistão. Uma das variedades mais antigas e geneticamente puras conhecidas.",
    efeitos: ["Sedação profunda", "Relaxamento total", "Sono"],
    sabores: ["Terroso", "Haxixe", "Pinho"],
    beneficiosSaude: ["Insônia severa", "Dor crônica", "Ansiedade", "Perda de apetite"],
    origem: "Afeganistão — Hindu Kush", florescimento: "7-8 semanas", dificuldade: "Fácil", rendimento: "400-500g/m²", avaliacao: 4.6, imagem: aiImg("Afghan Kush", "Indica"),
  },
  {
    id: 14, nome: "Girl Scout Cookies", tipo: "Híbrida (Indica dominante)", thc: "25% - 28%", cbd: "<1%",
    descricao: "Cruzamento de OG Kush com Durban Poison, criada em São Francisco. Conhecida por seus altíssimos níveis de THC e efeito complexo de corpo inteiro.",
    efeitos: ["Euforia intensa", "Relaxamento", "Felicidade"],
    sabores: ["Doce", "Terroso", "Menta"],
    beneficiosSaude: ["Dor severa", "Náusea", "Perda de apetite", "Depressão"],
    origem: "EUA — São Francisco", florescimento: "9-10 semanas", dificuldade: "Difícil", rendimento: "300-400g/m²", avaliacao: 4.9, imagem: aiImg("Girl Scout Cookies", "Hybrid Indica"),
  },
  {
    id: 15, nome: "AK-47", tipo: "Híbrida (Sativa dominante)", thc: "13% - 20%", cbd: "<1%",
    descricao: "Apesar do nome agressivo, é conhecida por proporcionar calma e relaxamento constante. Mistura de genéticas colombiana, mexicana, tailandesa e afegã.",
    efeitos: ["Relaxamento mental", "Sociabilidade", "Leve euforia"],
    sabores: ["Terroso", "Floral", "Ácido"],
    beneficiosSaude: ["Ansiedade social", "Dor crônica", "Estresse", "Depressão"],
    origem: "Holanda — Serious Seeds", florescimento: "7-9 semanas", dificuldade: "Fácil", rendimento: "350-500g/m²", avaliacao: 4.5, imagem: aiImg("AK-47", "Sativa Hybrid"),
  },
  {
    id: 16, nome: "Gorilla Glue #4", tipo: "Híbrida", thc: "25% - 30%", cbd: "<1%",
    descricao: "Uma das variedades mais potentes do mundo. Cruzamento de Chem's Sister, Sour Dubb e Chocolate Diesel. Nomeada pela resina pegajosa que produz.",
    efeitos: ["Relaxamento pesado", "Euforia", "Couch-lock"],
    sabores: ["Chocolate", "Diesel", "Café"],
    beneficiosSaude: ["Dor intensa", "Insônia", "Estresse severo", "Espasmos musculares"],
    origem: "EUA — GG Strains", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "500-600g/m²", avaliacao: 4.8, imagem: aiImg("Gorilla Glue", "Hybrid"),
  },
  {
    id: 17, nome: "Gelato", tipo: "Híbrida", thc: "20% - 25%", cbd: "<1%",
    descricao: "Cruzamento de Sunset Sherbet com Thin Mint Girl Scout Cookies. Produz flores densas e coloridas com aroma doce irresistível.",
    efeitos: ["Euforia", "Relaxamento", "Criatividade"],
    sabores: ["Doce", "Lavanda", "Cítrico"],
    beneficiosSaude: ["Dor", "Fadiga", "Insônia", "Ansiedade"],
    origem: "EUA — Cookie Fam", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.8, imagem: aiImg("Gelato", "Hybrid"),
  },
  {
    id: 18, nome: "Wedding Cake", tipo: "Híbrida (Indica dominante)", thc: "22% - 27%", cbd: "<1%",
    descricao: "Também conhecida como Pink Cookies. Cruzamento de Triangle Kush com Animal Mints. Flores extremamente densas com alto teor de terpenos.",
    efeitos: ["Relaxamento profundo", "Euforia suave", "Calma"],
    sabores: ["Baunilha", "Doce", "Terroso"],
    beneficiosSaude: ["Dor crônica", "Insônia", "Ansiedade", "Inflamação"],
    origem: "EUA — Seed Junky Genetics", florescimento: "7-9 semanas", dificuldade: "Moderada", rendimento: "450-550g/m²", avaliacao: 4.7, imagem: aiImg("Wedding Cake", "Indica Hybrid"),
  },
  {
    id: 19, nome: "Purple Haze", tipo: "Sativa", thc: "15% - 20%", cbd: "<1%",
    descricao: "Imortalizada pela música de Jimi Hendrix. Cruzamento de Purple Thai com Haze. Conhecida pela coloração roxa intensa e efeito cerebral estimulante.",
    efeitos: ["Euforia", "Energia", "Criatividade explosiva"],
    sabores: ["Uva", "Terroso", "Bagas"],
    beneficiosSaude: ["Depressão", "Fadiga", "Estresse", "Dor de cabeça"],
    origem: "EUA/Colômbia", florescimento: "9-10 semanas", dificuldade: "Moderada", rendimento: "350-450g/m²", avaliacao: 4.6, imagem: aiImg("Purple Haze", "Sativa"),
  },
  {
    id: 20, nome: "Bubba Kush", tipo: "Indica", thc: "15% - 22%", cbd: "<1%",
    descricao: "Indica pesada originária de Los Angeles nos anos 90. Descendente de OG Kush, produz efeitos fortemente sedativos e relaxantes.",
    efeitos: ["Sedação", "Relaxamento muscular", "Sono profundo"],
    sabores: ["Chocolate", "Café", "Terroso"],
    beneficiosSaude: ["Insônia", "Dor crônica", "Estresse", "Espasmos"],
    origem: "EUA — Los Angeles", florescimento: "8-9 semanas", dificuldade: "Fácil", rendimento: "400-500g/m²", avaliacao: 4.6, imagem: aiImg("Bubba Kush", "Indica"),
  },
  {
    id: 21, nome: "Trainwreck", tipo: "Sativa dominante", thc: "18% - 25%", cbd: "<1%",
    descricao: "Sativa potente de genética mexicana, tailandesa e afegã. Conhecida pelo efeito cerebral rápido e intenso, como um trem sem freios.",
    efeitos: ["Euforia rápida", "Energia intensa", "Foco"],
    sabores: ["Pinho", "Limão", "Especiarias"],
    beneficiosSaude: ["Dor", "TEPT", "Ansiedade", "Enxaqueca"],
    origem: "EUA — Califórnia", florescimento: "8-10 semanas", dificuldade: "Moderada", rendimento: "450-550g/m²", avaliacao: 4.6, imagem: aiImg("Trainwreck", "Sativa"),
  },
  {
    id: 22, nome: "Skywalker OG", tipo: "Indica", thc: "20% - 30%", cbd: "<1%",
    descricao: "Cruzamento de Skywalker com OG Kush. Indica poderosa que combina potência extrema com sabores complexos de especiarias e combustível.",
    efeitos: ["Relaxamento total", "Euforia espacial", "Couch-lock"],
    sabores: ["Especiarias", "Diesel", "Herbal"],
    beneficiosSaude: ["Dor severa", "Insônia", "Estresse", "Náusea"],
    origem: "EUA", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.7, imagem: aiImg("Skywalker OG", "Indica"),
  },
  {
    id: 23, nome: "Pineapple Express", tipo: "Híbrida (Sativa dominante)", thc: "17% - 24%", cbd: "<1%",
    descricao: "Popularizada pelo filme de mesmo nome. Cruzamento de Trainwreck com Hawaiian. Aroma tropical intenso com efeito energético e feliz.",
    efeitos: ["Felicidade", "Energia", "Foco criativo"],
    sabores: ["Abacaxi", "Manga", "Cedro"],
    beneficiosSaude: ["Depressão", "Fadiga", "Estresse", "Dor leve"],
    origem: "EUA", florescimento: "7-8 semanas", dificuldade: "Fácil", rendimento: "500-600g/m²", avaliacao: 4.5, imagem: aiImg("Pineapple Express", "Sativa Hybrid"),
  },
  {
    id: 24, nome: "Zkittlez", tipo: "Indica", thc: "15% - 23%", cbd: "<1%",
    descricao: "Cruzamento de Grape Ape e Grapefruit, vencedora da Emerald Cup. Conhecida pelo perfil de terpenos frutado extremamente complexo.",
    efeitos: ["Relaxamento suave", "Felicidade", "Calma focada"],
    sabores: ["Frutas tropicais", "Uva", "Doce"],
    beneficiosSaude: ["Ansiedade", "Depressão", "Dor", "Insônia leve"],
    origem: "EUA — 3rd Gen Family", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.7, imagem: aiImg("Zkittlez", "Indica"),
  },
  {
    id: 25, nome: "Durban Poison", tipo: "Sativa", thc: "15% - 25%", cbd: "<1%",
    descricao: "Sativa landrace pura originária de Durban, África do Sul. Uma das sativas puras mais energéticas e estimulantes do mundo.",
    efeitos: ["Energia pura", "Foco extremo", "Motivação"],
    sabores: ["Doce", "Anis", "Terroso"],
    beneficiosSaude: ["Fadiga", "Depressão", "TDAH", "Dor de cabeça"],
    origem: "África do Sul — Durban", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "350-450g/m²", avaliacao: 4.6, imagem: aiImg("Durban Poison", "Sativa"),
  },
  {
    id: 26, nome: "Cheese", tipo: "Indica", thc: "15% - 20%", cbd: "1%",
    descricao: "Fenótipo britânico de Skunk #1 que se tornou lendário no Reino Unido. Inconfundível pelo aroma pungente de queijo envelhecido.",
    efeitos: ["Relaxamento", "Euforia", "Felicidade"],
    sabores: ["Queijo", "Terroso", "Pungente"],
    beneficiosSaude: ["Estresse", "Dor", "Insônia", "Perda de apetite"],
    origem: "Reino Unido", florescimento: "8-9 semanas", dificuldade: "Fácil", rendimento: "500-600g/m²", avaliacao: 4.5, imagem: aiImg("Cheese", "Indica"),
  },
  {
    id: 27, nome: "Super Silver Haze", tipo: "Sativa", thc: "18% - 23%", cbd: "<1%",
    descricao: "Três vezes campeã da Cannabis Cup. Cruzamento de Northern Lights, Skunk #1 e Haze. Uma das sativas mais premiadas da história.",
    efeitos: ["Energia duradoura", "Euforia", "Criatividade"],
    sabores: ["Cítrico", "Especiarias", "Herbal"],
    beneficiosSaude: ["Depressão", "Fadiga crônica", "Náusea", "Enxaqueca"],
    origem: "Holanda — Green House Seeds", florescimento: "9-11 semanas", dificuldade: "Difícil", rendimento: "450-550g/m²", avaliacao: 4.8, imagem: aiImg("Super Silver Haze", "Sativa"),
  },
  {
    id: 28, nome: "Blueberry", tipo: "Indica", thc: "17% - 24%", cbd: "<1%",
    descricao: "Criação lendária de DJ Short nos anos 70. Cruzamento de indica afegã com genéticas tailandesas e oaxaqueñas. Coloração azul-púrpura marcante.",
    efeitos: ["Relaxamento profundo", "Euforia", "Sono tranquilo"],
    sabores: ["Mirtilo", "Doce", "Baunilha"],
    beneficiosSaude: ["Insônia", "Dor", "Estresse", "Ansiedade"],
    origem: "EUA — DJ Short", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "400-450g/m²", avaliacao: 4.7, imagem: aiImg("Blueberry", "Indica"),
  },
  {
    id: 29, nome: "Tangie", tipo: "Sativa", thc: "19% - 22%", cbd: "<1%",
    descricao: "Remake moderna da clássica Tangerine Dream. Cruzamento de California Orange com Skunk Hybrid. Aroma cítrico de tangerina extremamente marcante.",
    efeitos: ["Energia", "Criatividade", "Otimismo"],
    sabores: ["Tangerina", "Cítrico", "Doce"],
    beneficiosSaude: ["Depressão", "Fadiga", "Estresse", "Falta de apetite"],
    origem: "EUA — DNA Genetics", florescimento: "9-10 semanas", dificuldade: "Moderada", rendimento: "450-550g/m²", avaliacao: 4.6, imagem: aiImg("Tangie", "Sativa"),
  },
  {
    id: 30, nome: "Strawberry Cough", tipo: "Sativa", thc: "15% - 20%", cbd: "<1%",
    descricao: "Famosa pelo sabor de morango fresco e pela tendência de provocar tosse mesmo em fumantes experientes. Sativa de efeito cerebral claro e motivador.",
    efeitos: ["Euforia", "Energia social", "Felicidade"],
    sabores: ["Morango", "Doce", "Terroso"],
    beneficiosSaude: ["Ansiedade social", "Depressão", "Estresse", "Fadiga"],
    origem: "EUA", florescimento: "9-10 semanas", dificuldade: "Moderada", rendimento: "350-450g/m²", avaliacao: 4.5, imagem: aiImg("Strawberry Cough", "Sativa"),
  },
  {
    id: 31, nome: "Do-Si-Dos", tipo: "Indica", thc: "19% - 30%", cbd: "<1%",
    descricao: "Cruzamento potente de Girl Scout Cookies com Face Off OG. Indica pesada com flores muito densas cobertas de tricomas.",
    efeitos: ["Relaxamento pesado", "Euforia", "Sedação"],
    sabores: ["Menta", "Floral", "Terroso"],
    beneficiosSaude: ["Dor intensa", "Insônia", "Estresse", "Espasmos"],
    origem: "EUA — Archive Seed Bank", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.7, imagem: aiImg("Do-Si-Dos", "Indica"),
  },
  {
    id: 32, nome: "Bruce Banner", tipo: "Híbrida", thc: "24% - 30%", cbd: "<1%",
    descricao: "Nomeada em homenagem ao alter ego do Hulk. Cruzamento de OG Kush com Strawberry Diesel. Uma das variedades mais potentes já testadas.",
    efeitos: ["Euforia explosiva", "Energia", "Relaxamento"],
    sabores: ["Diesel", "Doce", "Terroso"],
    beneficiosSaude: ["Dor severa", "Depressão", "Estresse", "Náusea"],
    origem: "EUA — Dark Horse Genetics", florescimento: "8-10 semanas", dificuldade: "Moderada", rendimento: "500-600g/m²", avaliacao: 4.7, imagem: aiImg("Bruce Banner", "Hybrid"),
  },
  {
    id: 33, nome: "Lemon Haze", tipo: "Sativa", thc: "15% - 20%", cbd: "<1%",
    descricao: "Cruzamento de Lemon Skunk com Silver Haze. Duas vezes campeã da Cannabis Cup com seu perfil cítrico refrescante.",
    efeitos: ["Energia", "Felicidade", "Foco"],
    sabores: ["Limão", "Cítrico", "Doce"],
    beneficiosSaude: ["Depressão", "Fadiga", "Estresse", "Ansiedade"],
    origem: "Holanda — Green House Seeds", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "450-550g/m²", avaliacao: 4.6, imagem: aiImg("Lemon Haze", "Sativa"),
  },
  {
    id: 34, nome: "Purple Kush", tipo: "Indica", thc: "17% - 27%", cbd: "<1%",
    descricao: "Indica pura resultado do cruzamento de Hindu Kush com Purple Afghani. Coloração roxa escura e efeito extremamente sedativo.",
    efeitos: ["Sedação total", "Relaxamento muscular", "Sono"],
    sabores: ["Uva", "Terroso", "Sândalo"],
    beneficiosSaude: ["Insônia severa", "Dor crônica", "Estresse", "Náusea"],
    origem: "EUA — Oakland", florescimento: "8 semanas", dificuldade: "Fácil", rendimento: "400-500g/m²", avaliacao: 4.6, imagem: aiImg("Purple Kush", "Indica"),
  },
  {
    id: 35, nome: "Maui Wowie", tipo: "Sativa", thc: "13% - 19%", cbd: "<1%",
    descricao: "Sativa tropical landrace originária das ilhas vulcânicas do Havaí. Associada à cultura surf e ao espírito aloha das ilhas.",
    efeitos: ["Energia tropical", "Felicidade", "Criatividade"],
    sabores: ["Tropical", "Cítrico", "Pinho"],
    beneficiosSaude: ["Depressão", "Fadiga", "Estresse", "Dor leve"],
    origem: "Havaí", florescimento: "9-11 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.4, imagem: aiImg("Maui Wowie", "Sativa"),
  },
  {
    id: 36, nome: "Hindu Kush", tipo: "Indica", thc: "15% - 20%", cbd: "1% - 2%",
    descricao: "Landrace indica pura das montanhas Hindu Kush entre Paquistão e Afeganistão. Adaptada a climas extremos, produz resina espessa como proteção natural.",
    efeitos: ["Relaxamento profundo", "Calma", "Sono"],
    sabores: ["Sândalo", "Pinho", "Terroso"],
    beneficiosSaude: ["Insônia", "Ansiedade", "Dor", "Náusea"],
    origem: "Paquistão/Afeganistão", florescimento: "7-8 semanas", dificuldade: "Fácil", rendimento: "350-450g/m²", avaliacao: 4.5, imagem: aiImg("Hindu Kush", "Indica"),
  },
  {
    id: 37, nome: "Green Crack", tipo: "Sativa", thc: "15% - 25%", cbd: "<1%",
    descricao: "Originalmente chamada Cush, renomeada por Snoop Dogg. Sativa pura com efeito cerebral afiado e energético.",
    efeitos: ["Energia explosiva", "Foco", "Motivação"],
    sabores: ["Manga", "Cítrico", "Tropical"],
    beneficiosSaude: ["Fadiga crônica", "Depressão", "Estresse", "TDAH"],
    origem: "EUA — Califórnia", florescimento: "7-9 semanas", dificuldade: "Fácil", rendimento: "500-600g/m²", avaliacao: 4.6, imagem: aiImg("Green Crack", "Sativa"),
  },
  {
    id: 38, nome: "Runtz", tipo: "Híbrida", thc: "19% - 29%", cbd: "<1%",
    descricao: "Cruzamento de Zkittlez com Gelato, rapidamente se tornou uma das variedades mais desejadas. Buds extremamente densos e coloridos com aroma de doces.",
    efeitos: ["Euforia", "Relaxamento", "Felicidade"],
    sabores: ["Doce", "Frutas", "Tropical"],
    beneficiosSaude: ["Estresse", "Dor", "Ansiedade", "Insônia"],
    origem: "EUA — Cookies", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.8, imagem: aiImg("Runtz", "Hybrid"),
  },
  {
    id: 39, nome: "Mimosa", tipo: "Híbrida (Sativa dominante)", thc: "19% - 27%", cbd: "<1%",
    descricao: "Cruzamento de Clementine com Purple Punch. Aroma cítrico brilhante com notas de champanhe. Perfeita para uso matutino.",
    efeitos: ["Energia feliz", "Motivação", "Foco"],
    sabores: ["Laranja", "Tropical", "Champanhe"],
    beneficiosSaude: ["Depressão", "Fadiga", "Estresse", "Ansiedade"],
    origem: "EUA — Symbiotic Genetics", florescimento: "9-10 semanas", dificuldade: "Moderada", rendimento: "450-550g/m²", avaliacao: 4.7, imagem: aiImg("Mimosa", "Sativa Hybrid"),
  },
  {
    id: 40, nome: "Cereal Milk", tipo: "Híbrida", thc: "18% - 23%", cbd: "<1%",
    descricao: "Cruzamento de Y Life com Snowman. Sabor exato do leite que sobra após comer cereal doce. Variedade rara e muito procurada.",
    efeitos: ["Euforia suave", "Relaxamento", "Criatividade"],
    sabores: ["Doce cremoso", "Baunilha", "Frutas"],
    beneficiosSaude: ["Ansiedade", "Depressão", "Dor leve", "Estresse"],
    origem: "EUA — Cookies", florescimento: "8-9 semanas", dificuldade: "Difícil", rendimento: "350-450g/m²", avaliacao: 4.7, imagem: aiImg("Cereal Milk", "Hybrid"),
  },
  {
    id: 41, nome: "Cherry Pie", tipo: "Indica", thc: "16% - 24%", cbd: "<1%",
    descricao: "Cruzamento de Granddaddy Purple com Durban Poison. Aroma irresistível de torta de cereja com efeito relaxante e edificante.",
    efeitos: ["Relaxamento", "Euforia", "Felicidade"],
    sabores: ["Cereja", "Doce", "Terroso"],
    beneficiosSaude: ["Ansiedade", "Bipolaridade", "Dor", "TEPT"],
    origem: "EUA — Califórnia", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.5, imagem: aiImg("Cherry Pie", "Indica"),
  },
  {
    id: 42, nome: "Forbidden Fruit", tipo: "Indica", thc: "14% - 26%", cbd: "<1%",
    descricao: "Cruzamento de Cherry Pie com Tangie. Combinação exótica de frutas tropicais com efeito profundamente relaxante e sensorial.",
    efeitos: ["Relaxamento sensorial", "Calma", "Sonolência"],
    sabores: ["Cereja", "Manga", "Grapefruit"],
    beneficiosSaude: ["Insônia", "Dor", "Ansiedade", "Depressão"],
    origem: "EUA", florescimento: "9-10 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.6, imagem: aiImg("Forbidden Fruit", "Indica"),
  },
  {
    id: 43, nome: "Sunset Sherbet", tipo: "Indica", thc: "15% - 19%", cbd: "<1%",
    descricao: "Descendente de Girl Scout Cookies criada por Mr. Sherbinski. Buds coloridos com sabor doce complexo de sorvete.",
    efeitos: ["Relaxamento", "Euforia suave", "Criatividade"],
    sabores: ["Frutas", "Menta", "Doce cremoso"],
    beneficiosSaude: ["Estresse", "Dor", "Perda de apetite", "Ansiedade"],
    origem: "EUA — Sherbinski", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "450-500g/m²", avaliacao: 4.6, imagem: aiImg("Sunset Sherbet", "Indica"),
  },
  {
    id: 44, nome: "Kosher Kush", tipo: "Indica", thc: "20% - 25%", cbd: "<1%",
    descricao: "Primeira variedade de cannabis a receber bênção de um rabino. Indica potente com efeito pesado e sabor terroso profundo.",
    efeitos: ["Sedação profunda", "Relaxamento total", "Sono"],
    sabores: ["Terroso", "Frutado", "Pinho"],
    beneficiosSaude: ["Insônia severa", "Dor crônica", "TEPT", "Ansiedade"],
    origem: "EUA — DNA Genetics", florescimento: "9-10 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.7, imagem: aiImg("Kosher Kush", "Indica"),
  },
  {
    id: 45, nome: "Headband", tipo: "Híbrida", thc: "17% - 27%", cbd: "<1%",
    descricao: "Cruzamento de OG Kush com Sour Diesel. Nomeada pela sensação de pressão suave ao redor da cabeça, como uma faixa.",
    efeitos: ["Relaxamento cerebral", "Euforia", "Calma"],
    sabores: ["Limão", "Diesel", "Cremoso"],
    beneficiosSaude: ["Dor de cabeça", "Estresse", "Depressão", "Dor"],
    origem: "EUA", florescimento: "9-11 semanas", dificuldade: "Difícil", rendimento: "350-450g/m²", avaliacao: 4.5, imagem: aiImg("Headband", "Hybrid"),
  },
  {
    id: 46, nome: "LA Confidential", tipo: "Indica", thc: "19% - 25%", cbd: "<1%",
    descricao: "Indica potente criada pela DNA Genetics em Amsterdã. Efeito rápido e intensamente sedativo, ideal para uso noturno.",
    efeitos: ["Sedação", "Relaxamento profundo", "Sono"],
    sabores: ["Pinho", "Skunk", "Terroso"],
    beneficiosSaude: ["Insônia", "Dor intensa", "Ansiedade", "Espasmos"],
    origem: "Holanda — DNA Genetics", florescimento: "7-8 semanas", dificuldade: "Fácil", rendimento: "400-500g/m²", avaliacao: 4.6, imagem: aiImg("LA Confidential", "Indica"),
  },
  {
    id: 47, nome: "Banana Kush", tipo: "Indica", thc: "18% - 25%", cbd: "<1%",
    descricao: "Cruzamento de Ghost OG com Skunk Haze. Forte aroma de banana madura com efeito relaxante e eufórico.",
    efeitos: ["Relaxamento feliz", "Euforia", "Criatividade"],
    sabores: ["Banana", "Doce", "Tropical"],
    beneficiosSaude: ["Estresse", "Depressão", "Dor", "Insônia"],
    origem: "EUA — Califórnia", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.5, imagem: aiImg("Banana Kush", "Indica"),
  },
  {
    id: 48, nome: "Death Star", tipo: "Indica", thc: "20% - 27%", cbd: "<1%",
    descricao: "Cruzamento de Sensi Star com Sour Diesel. Indica poderosa com aroma complexo de diesel e skunk. Efeito pesado e duradouro.",
    efeitos: ["Sedação intensa", "Relaxamento total", "Euforia"],
    sabores: ["Diesel", "Skunk", "Doce"],
    beneficiosSaude: ["Dor crônica", "Insônia", "Estresse severo", "Náusea"],
    origem: "EUA — Ohio", florescimento: "9-10 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.5, imagem: aiImg("Death Star", "Indica"),
  },
  {
    id: 49, nome: "Critical Mass", tipo: "Indica", thc: "19% - 22%", cbd: "5% - 8%",
    descricao: "Descendente de Afghani e Skunk #1. Conhecida por produzir buds tão pesados que podem quebrar os galhos sem suporte.",
    efeitos: ["Relaxamento", "Calma", "Sono"],
    sabores: ["Doce", "Terroso", "Cítrico"],
    beneficiosSaude: ["Dor", "Insônia", "Ansiedade", "Inflamação"],
    origem: "Espanha — Mr. Nice Seeds", florescimento: "6-8 semanas", dificuldade: "Fácil", rendimento: "600-800g/m²", avaliacao: 4.5, imagem: aiImg("Critical Mass", "Indica"),
  },
  {
    id: 50, nome: "White Rhino", tipo: "Indica", thc: "18% - 25%", cbd: "<1%",
    descricao: "Descendente de White Widow com genéticas norte-americanas. Buds extremamente densos com efeito sedativo poderoso.",
    efeitos: ["Sedação", "Relaxamento muscular", "Sono"],
    sabores: ["Terroso", "Amadeirado", "Doce"],
    beneficiosSaude: ["Dor severa", "Insônia", "Estresse", "Perda de apetite"],
    origem: "Holanda — Green House Seeds", florescimento: "9-10 semanas", dificuldade: "Moderada", rendimento: "500-600g/m²", avaliacao: 4.5, imagem: aiImg("White Rhino", "Indica"),
  },
  {
    id: 51, nome: "MAC (Miracle Alien Cookies)", tipo: "Híbrida", thc: "20% - 23%", cbd: "<1%",
    descricao: "Cruzamento de Alien Cookies, Colombian e Starfighter. Flores brilhantes cobertas de tricomas com aromas cítricos e diesel.",
    efeitos: ["Euforia", "Criatividade", "Relaxamento"],
    sabores: ["Cítrico", "Diesel", "Floral"],
    beneficiosSaude: ["Depressão", "Dor", "Estresse", "Ansiedade"],
    origem: "EUA — Capulator", florescimento: "9-10 semanas", dificuldade: "Difícil", rendimento: "350-450g/m²", avaliacao: 4.7, imagem: aiImg("MAC", "Hybrid"),
  },
  {
    id: 52, nome: "Platinum OG", tipo: "Indica", thc: "17% - 24%", cbd: "<1%",
    descricao: "Cruzamento triplo de Master Kush, OG Kush e uma terceira genética indica desconhecida. Indica pesada para uso noturno.",
    efeitos: ["Relaxamento profundo", "Sedação", "Couch-lock"],
    sabores: ["Café", "Especiarias", "Herbal"],
    beneficiosSaude: ["Insônia", "Dor intensa", "Estresse", "Espasmos musculares"],
    origem: "EUA", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "350-450g/m²", avaliacao: 4.5, imagem: aiImg("Platinum OG", "Indica"),
  },
  {
    id: 53, nome: "Tropicana Cookies", tipo: "Sativa", thc: "19% - 28%", cbd: "<1%",
    descricao: "Cruzamento de Girl Scout Cookies com Tangie. Coloração púrpura escura com aroma explosivo de suco de laranja.",
    efeitos: ["Energia", "Euforia", "Criatividade"],
    sabores: ["Laranja", "Tangerina", "Terroso"],
    beneficiosSaude: ["Depressão", "Fadiga", "Estresse", "Ansiedade"],
    origem: "EUA — Oni Seed Co", florescimento: "9-10 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.7, imagem: aiImg("Tropicana Cookies", "Sativa"),
  },
  {
    id: 54, nome: "Ice Cream Cake", tipo: "Indica", thc: "20% - 25%", cbd: "<1%",
    descricao: "Cruzamento de Wedding Cake com Gelato #33. Sabor cremoso e doce que remete a sorvete de baunilha com efeito relaxante potente.",
    efeitos: ["Relaxamento profundo", "Euforia suave", "Sono"],
    sabores: ["Baunilha", "Cremoso", "Doce"],
    beneficiosSaude: ["Insônia", "Dor", "Ansiedade", "Depressão"],
    origem: "EUA — Seed Junky Genetics", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.7, imagem: aiImg("Ice Cream Cake", "Indica"),
  },
  {
    id: 55, nome: "Sherblato", tipo: "Híbrida", thc: "20% - 24%", cbd: "<1%",
    descricao: "Cruzamento de Sunset Sherbet com Gelato. Combinação perfeita de duas variedades de sobremesa premiadas.",
    efeitos: ["Euforia", "Relaxamento", "Felicidade"],
    sabores: ["Frutas", "Cremoso", "Baga"],
    beneficiosSaude: ["Estresse", "Dor", "Insônia leve", "Ansiedade"],
    origem: "EUA", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.6, imagem: aiImg("Sherblato", "Hybrid"),
  },
  {
    id: 56, nome: "Motor Breath", tipo: "Indica", thc: "25% - 30%", cbd: "<1%",
    descricao: "Cruzamento de Chemdog com SFV OG Kush. Uma das indicas mais potentes, com aroma diesel extremamente pungente.",
    efeitos: ["Sedação extrema", "Relaxamento total", "Couch-lock"],
    sabores: ["Diesel", "Químico", "Terroso"],
    beneficiosSaude: ["Dor severa", "Insônia crônica", "TEPT", "Espasmos"],
    origem: "EUA — Pisces Genetics", florescimento: "9-10 semanas", dificuldade: "Difícil", rendimento: "350-450g/m²", avaliacao: 4.6, imagem: aiImg("Motor Breath", "Indica"),
  },
  {
    id: 57, nome: "King Louis XIII", tipo: "Indica", thc: "20% - 28%", cbd: "<1%",
    descricao: "Fenótipo de OG Kush que emergiu em Los Angeles. Nomeada em homenagem ao rei francês, possui efeito real e majestoso.",
    efeitos: ["Relaxamento régio", "Sedação", "Calma"],
    sabores: ["Pinho", "Terroso", "Skunk"],
    beneficiosSaude: ["Insônia", "Dor crônica", "Estresse", "Ansiedade"],
    origem: "EUA — Los Angeles", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "350-450g/m²", avaliacao: 4.6, imagem: aiImg("King Louis XIII", "Indica"),
  },
  {
    id: 58, nome: "Tahoe OG", tipo: "Indica", thc: "20% - 25%", cbd: "<1%",
    descricao: "Fenótipo de OG Kush de Lake Tahoe. Versão mais potente e sedativa que a OG Kush original.",
    efeitos: ["Sedação rápida", "Relaxamento muscular", "Sono"],
    sabores: ["Limão", "Terroso", "Pinho"],
    beneficiosSaude: ["Insônia severa", "Dor intensa", "Estresse", "Enxaqueca"],
    origem: "EUA — Lake Tahoe", florescimento: "9-10 semanas", dificuldade: "Difícil", rendimento: "350-450g/m²", avaliacao: 4.6, imagem: aiImg("Tahoe OG", "Indica"),
  },
  {
    id: 59, nome: "Chemdawg", tipo: "Híbrida", thc: "15% - 20%", cbd: "<1%",
    descricao: "Uma das variedades mais importantes da história da cannabis. Ancestral genético de Sour Diesel e OG Kush. Origem misteriosa e debatida.",
    efeitos: ["Euforia cerebral", "Criatividade", "Relaxamento"],
    sabores: ["Diesel", "Químico", "Terroso"],
    beneficiosSaude: ["Dor", "Depressão", "Ansiedade", "Estresse"],
    origem: "EUA — Desconhecida", florescimento: "9-10 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.6, imagem: aiImg("Chemdawg", "Hybrid"),
  },
  {
    id: 60, nome: "Lamb's Bread", tipo: "Sativa", thc: "16% - 21%", cbd: "<1%",
    descricao: "Sativa landrace jamaicana, supostamente a variedade favorita de Bob Marley. Efeito cerebral edificante e espiritual.",
    efeitos: ["Energia espiritual", "Criatividade", "Introspecção"],
    sabores: ["Herbal", "Queijo", "Terroso"],
    beneficiosSaude: ["Depressão", "Fadiga", "Estresse", "Ansiedade"],
    origem: "Jamaica", florescimento: "9-10 semanas", dificuldade: "Moderada", rendimento: "300-400g/m²", avaliacao: 4.5, imagem: aiImg("Lambs Bread", "Sativa"),
  },
  {
    id: 61, nome: "Remedy", tipo: "Alto CBD", thc: "<1%", cbd: "14% - 18%",
    descricao: "Cruzamento de Afghan Skunk com Cannatonic. Variedade de altíssimo CBD com praticamente zero efeito psicoativo.",
    efeitos: ["Calma profunda", "Relaxamento sem intoxicação", "Clareza"],
    sabores: ["Limão", "Menta", "Pinho"],
    beneficiosSaude: ["Ansiedade", "Inflamação", "Epilepsia", "Dor"],
    origem: "EUA — Oregon", florescimento: "8-9 semanas", dificuldade: "Fácil", rendimento: "400-500g/m²", avaliacao: 4.7, imagem: aiImg("Remedy", "Alto CBD"),
  },
  {
    id: 62, nome: "Ringo's Gift", tipo: "Alto CBD", thc: "1% - 7%", cbd: "10% - 20%",
    descricao: "Nomeada em homenagem ao pioneiro do CBD Lawrence Ringo. Cruzamento de ACDC com Harle-Tsu. Proporção CBD:THC de até 24:1.",
    efeitos: ["Relaxamento terapêutico", "Clareza", "Calma"],
    sabores: ["Menta", "Pinho", "Floral"],
    beneficiosSaude: ["Epilepsia", "Dor neuropática", "Ansiedade", "Artrite"],
    origem: "EUA — SoHum Seeds", florescimento: "8-9 semanas", dificuldade: "Fácil", rendimento: "400-500g/m²", avaliacao: 4.7, imagem: aiImg("Ringos Gift", "Alto CBD"),
  },
  {
    id: 63, nome: "Harle-Tsu", tipo: "Alto CBD", thc: "1% - 2%", cbd: "18% - 22%",
    descricao: "Cruzamento de Harlequin com Sour Tsunami. Uma das variedades com maior proporção CBD:THC disponíveis, ideal para pacientes sensíveis.",
    efeitos: ["Alívio sem intoxicação", "Calma", "Foco"],
    sabores: ["Pinho", "Herbal", "Terroso"],
    beneficiosSaude: ["Dor crônica", "Inflamação", "Ansiedade", "Epilepsia"],
    origem: "EUA — Southern Humboldt Seed Collective", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "350-450g/m²", avaliacao: 4.8, imagem: aiImg("Harle-Tsu", "Alto CBD"),
  },
  {
    id: 64, nome: "Pennywise", tipo: "Alto CBD", thc: "8% - 12%", cbd: "8% - 15%",
    descricao: "Cruzamento de Harlequin com Jack the Ripper. Proporção CBD:THC de 1:1, oferecendo efeitos terapêuticos equilibrados.",
    efeitos: ["Relaxamento equilibrado", "Clareza", "Calma focada"],
    sabores: ["Café", "Pimenta", "Bubblegum"],
    beneficiosSaude: ["TEPT", "Epilepsia", "Artrite", "Ansiedade"],
    origem: "EUA — TGA Subcool Seeds", florescimento: "9-10 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.5, imagem: aiImg("Pennywise", "Alto CBD"),
  },
  {
    id: 65, nome: "Sour Tsunami", tipo: "Alto CBD", thc: "1% - 10%", cbd: "10% - 11%",
    descricao: "Uma das primeiras variedades cultivadas especificamente para alto teor de CBD. Cruzamento de Sour Diesel com NYC Diesel.",
    efeitos: ["Alívio terapêutico", "Relaxamento", "Sem efeito psicoativo"],
    sabores: ["Diesel", "Chocolate", "Terroso"],
    beneficiosSaude: ["Dor crônica", "Inflamação", "Convulsões", "Ansiedade"],
    origem: "EUA — Lawrence Ringo", florescimento: "9-10 semanas", dificuldade: "Moderada", rendimento: "350-450g/m²", avaliacao: 4.6, imagem: aiImg("Sour Tsunami", "Alto CBD"),
  },
  {
    id: 66, nome: "Stephen Hawking Kush", tipo: "Alto CBD", thc: "5% - 8%", cbd: "10% - 15%",
    descricao: "Homenagem ao físico Stephen Hawking. Indica de alto CBD desenvolvida para pacientes com condições neurológicas graves.",
    efeitos: ["Relaxamento profundo", "Alívio", "Calma mental"],
    sabores: ["Menta", "Cereja", "Herbal"],
    beneficiosSaude: ["ELA", "Esclerose múltipla", "Dor neuropática", "Espasmos"],
    origem: "EUA", florescimento: "8-9 semanas", dificuldade: "Fácil", rendimento: "400-500g/m²", avaliacao: 4.6, imagem: aiImg("Stephen Hawking Kush", "Alto CBD"),
  },
  {
    id: 67, nome: "Elektra", tipo: "Alto CBD", thc: "<1%", cbd: "15% - 20%",
    descricao: "Variedade hemp de alto CBD com perfil de terpenos complexo e aroma de vinho e chocolate. Legal na maioria das jurisdições.",
    efeitos: ["Calma", "Relaxamento suave", "Bem-estar"],
    sabores: ["Vinho", "Chocolate", "Cítrico"],
    beneficiosSaude: ["Ansiedade", "Dor leve", "Inflamação", "Estresse"],
    origem: "EUA — Oregon CBD", florescimento: "8-9 semanas", dificuldade: "Fácil", rendimento: "450-550g/m²", avaliacao: 4.4, imagem: aiImg("Elektra", "Alto CBD"),
  },
  {
    id: 68, nome: "Lifter", tipo: "Alto CBD", thc: "<1%", cbd: "14% - 20%",
    descricao: "Hemp de alto CBD com efeito energético e edificante, perfeita para uso diurno sem efeitos psicoativos.",
    efeitos: ["Energia suave", "Foco", "Bem-estar"],
    sabores: ["Frutas", "Queijo", "Funky"],
    beneficiosSaude: ["Fadiga", "Ansiedade", "Dor", "Inflamação"],
    origem: "EUA — Oregon CBD", florescimento: "8-9 semanas", dificuldade: "Fácil", rendimento: "500-600g/m²", avaliacao: 4.4, imagem: aiImg("Lifter", "Alto CBD"),
  },
  {
    id: 69, nome: "Suzy Q", tipo: "Alto CBD", thc: "<1%", cbd: "10% - 15%",
    descricao: "Variedade de CBD pura sem efeitos psicoativos. Ideal para pacientes que precisam de alívio durante o trabalho ou atividades diárias.",
    efeitos: ["Calma funcional", "Alívio", "Clareza total"],
    sabores: ["Pinho", "Terroso", "Herbal"],
    beneficiosSaude: ["Ansiedade", "Dor", "Inflamação", "Estresse"],
    origem: "EUA — Burning Bush Nurseries", florescimento: "8-9 semanas", dificuldade: "Fácil", rendimento: "350-450g/m²", avaliacao: 4.3, imagem: aiImg("Suzy Q", "Alto CBD"),
  },
  {
    id: 70, nome: "Super Lemon Haze", tipo: "Sativa", thc: "16% - 25%", cbd: "<1%",
    descricao: "Cruzamento de Lemon Skunk com Super Silver Haze. Duas vezes campeã da Cannabis Cup. Aroma explosivo de limão siciliano.",
    efeitos: ["Energia explosiva", "Felicidade", "Foco"],
    sabores: ["Limão", "Cítrico", "Doce"],
    beneficiosSaude: ["Depressão", "Fadiga", "Estresse", "Ansiedade"],
    origem: "Holanda — Green House Seeds", florescimento: "9-10 semanas", dificuldade: "Moderada", rendimento: "500-600g/m²", avaliacao: 4.7, imagem: aiImg("Super Lemon Haze", "Sativa"),
  },
  {
    id: 71, nome: "Alien OG", tipo: "Híbrida", thc: "20% - 28%", cbd: "<1%",
    descricao: "Cruzamento de Tahoe OG com Alien Kush. Híbrida potente com efeito cerebral intenso seguido de relaxamento profundo.",
    efeitos: ["Euforia intensa", "Relaxamento", "Felicidade"],
    sabores: ["Limão", "Pinho", "Terroso"],
    beneficiosSaude: ["Dor", "Insônia", "Estresse", "Ansiedade"],
    origem: "EUA — Cali Connection", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "350-450g/m²", avaliacao: 4.6, imagem: aiImg("Alien OG", "Hybrid"),
  },
  {
    id: 72, nome: "Papaya", tipo: "Indica", thc: "20% - 25%", cbd: "<1%",
    descricao: "Indica tropical com genéticas de Citral #13 e Ice #2. Sabor doce tropical de mamão papaia com efeito relaxante e feliz.",
    efeitos: ["Relaxamento tropical", "Euforia", "Felicidade"],
    sabores: ["Mamão", "Manga", "Tropical"],
    beneficiosSaude: ["Estresse", "Dor", "Insônia", "Perda de apetite"],
    origem: "Holanda — Nirvana Seeds", florescimento: "8-9 semanas", dificuldade: "Fácil", rendimento: "500-600g/m²", avaliacao: 4.5, imagem: aiImg("Papaya", "Indica"),
  },
  {
    id: 73, nome: "Dutch Treat", tipo: "Indica", thc: "18% - 25%", cbd: "<1%",
    descricao: "Variedade de coffeeshop clássica de Amsterdã. Indica com efeito cerebral surpreendentemente ativo para uma indica.",
    efeitos: ["Euforia cerebral", "Relaxamento", "Felicidade"],
    sabores: ["Pinho", "Eucalipto", "Doce"],
    beneficiosSaude: ["Ansiedade", "Estresse", "Dor", "Fadiga"],
    origem: "Holanda", florescimento: "7-8 semanas", dificuldade: "Fácil", rendimento: "400-500g/m²", avaliacao: 4.5, imagem: aiImg("Dutch Treat", "Indica"),
  },
  {
    id: 74, nome: "Mango Kush", tipo: "Indica", thc: "16% - 21%", cbd: "<1%",
    descricao: "Cruzamento de Hindu Kush com Mango. Sabor intenso de manga madura com efeito relaxante e social.",
    efeitos: ["Relaxamento feliz", "Sociabilidade", "Calma"],
    sabores: ["Manga", "Banana", "Tropical"],
    beneficiosSaude: ["Estresse", "Ansiedade", "Dor leve", "Depressão"],
    origem: "EUA", florescimento: "8-9 semanas", dificuldade: "Fácil", rendimento: "400-500g/m²", avaliacao: 4.4, imagem: aiImg("Mango Kush", "Indica"),
  },
  {
    id: 75, nome: "Chocolope", tipo: "Sativa", thc: "18% - 21%", cbd: "<1%",
    descricao: "Cruzamento de Chocolate Thai com Cannalope Haze. Sativa com sabor único de chocolate que lembra café gourmet.",
    efeitos: ["Energia", "Motivação", "Foco mental"],
    sabores: ["Chocolate", "Café", "Baunilha"],
    beneficiosSaude: ["Depressão", "Fadiga", "Estresse", "TDAH"],
    origem: "Holanda — DNA Genetics", florescimento: "9-10 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.6, imagem: aiImg("Chocolope", "Sativa"),
  },
  {
    id: 76, nome: "White Fire OG", tipo: "Híbrida", thc: "22% - 30%", cbd: "<1%",
    descricao: "Cruzamento de Fire OG com The White. Também conhecida como WiFi OG. Extremamente potente com tricomas brancos densos.",
    efeitos: ["Euforia intensa", "Energia", "Foco"],
    sabores: ["Terroso", "Diesel", "Ácido"],
    beneficiosSaude: ["Dor crônica", "Depressão", "Fadiga", "Ansiedade"],
    origem: "EUA — OG Raskal Seeds", florescimento: "9-10 semanas", dificuldade: "Difícil", rendimento: "350-450g/m²", avaliacao: 4.6, imagem: aiImg("White Fire OG", "Hybrid"),
  },
  {
    id: 77, nome: "Slurricane", tipo: "Indica", thc: "20% - 28%", cbd: "<1%",
    descricao: "Cruzamento de Do-Si-Dos com Purple Punch. Indica premiada com sabor frutado tropical e efeito profundamente relaxante.",
    efeitos: ["Sedação", "Relaxamento profundo", "Euforia suave"],
    sabores: ["Uva", "Tropical", "Cremoso"],
    beneficiosSaude: ["Insônia", "Dor", "Estresse", "Ansiedade"],
    origem: "EUA — In House Genetics", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.7, imagem: aiImg("Slurricane", "Indica"),
  },
  {
    id: 78, nome: "Gary Payton", tipo: "Híbrida", thc: "20% - 25%", cbd: "<1%",
    descricao: "Colaboração entre Cookies e Powerzzzup Genetics. Nomeada em homenagem ao jogador de basquete. Variedade exótica altamente desejada.",
    efeitos: ["Euforia", "Relaxamento", "Criatividade"],
    sabores: ["Diesel", "Terroso", "Doce"],
    beneficiosSaude: ["Estresse", "Depressão", "Dor", "Ansiedade"],
    origem: "EUA — Cookies x Powerzzzup", florescimento: "9-10 semanas", dificuldade: "Difícil", rendimento: "300-400g/m²", avaliacao: 4.7, imagem: aiImg("Gary Payton", "Hybrid"),
  },
  {
    id: 79, nome: "Apple Fritter", tipo: "Híbrida", thc: "22% - 32%", cbd: "<1%",
    descricao: "Cruzamento de Sour Apple com Animal Cookies. Sabor de massa de torta de maçã com canela. Extremamente potente.",
    efeitos: ["Euforia intensa", "Relaxamento", "Felicidade"],
    sabores: ["Maçã", "Baunilha", "Canela"],
    beneficiosSaude: ["Dor crônica", "Insônia", "Estresse", "Depressão"],
    origem: "EUA — Lumpy's Flowers", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.8, imagem: aiImg("Apple Fritter", "Hybrid"),
  },
  {
    id: 80, nome: "Grape Ape", tipo: "Indica", thc: "15% - 23%", cbd: "<1%",
    descricao: "Cruzamento de Mendocino Purps, Skunk e Afghani. Coloração púrpura profunda com sabor doce de uva concentrado.",
    efeitos: ["Relaxamento", "Calma", "Sono"],
    sabores: ["Uva", "Baga", "Doce"],
    beneficiosSaude: ["Insônia", "Dor", "Ansiedade", "Estresse"],
    origem: "EUA — Apothecary Genetics", florescimento: "7-8 semanas", dificuldade: "Fácil", rendimento: "400-500g/m²", avaliacao: 4.5, imagem: aiImg("Grape Ape", "Indica"),
  },
  {
    id: 81, nome: "Dosidos #22", tipo: "Indica", thc: "22% - 30%", cbd: "<1%",
    descricao: "Fenótipo específico do Do-Si-Dos selecionado por sua potência excepcional e perfil de terpenos únicos com notas de lavanda.",
    efeitos: ["Sedação potente", "Relaxamento muscular", "Sono"],
    sabores: ["Lavanda", "Menta", "Terroso"],
    beneficiosSaude: ["Dor severa", "Insônia crônica", "Espasmos", "TEPT"],
    origem: "EUA", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.6, imagem: aiImg("Dosidos 22", "Indica"),
  },
  {
    id: 82, nome: "Cali Orange", tipo: "Híbrida", thc: "12% - 15%", cbd: "<1%",
    descricao: "Também conhecida como California Orange Bud. Clássica dos anos 80 com sabor puro de laranja fresca.",
    efeitos: ["Energia suave", "Felicidade", "Sociabilidade"],
    sabores: ["Laranja", "Cítrico", "Doce"],
    beneficiosSaude: ["Estresse", "Depressão", "Fadiga", "Ansiedade leve"],
    origem: "EUA — Califórnia", florescimento: "8-9 semanas", dificuldade: "Fácil", rendimento: "400-500g/m²", avaliacao: 4.3, imagem: aiImg("Cali Orange", "Hybrid"),
  },
  {
    id: 83, nome: "Blackberry Kush", tipo: "Indica", thc: "16% - 20%", cbd: "<1%",
    descricao: "Cruzamento de Afghani com Blackberry. Indica com sabor intenso de amora preta e efeito profundamente relaxante.",
    efeitos: ["Sedação", "Relaxamento", "Sono profundo"],
    sabores: ["Amora", "Terroso", "Diesel"],
    beneficiosSaude: ["Insônia", "Dor", "Estresse", "Espasmos musculares"],
    origem: "EUA", florescimento: "7-8 semanas", dificuldade: "Fácil", rendimento: "400-500g/m²", avaliacao: 4.5, imagem: aiImg("Blackberry Kush", "Indica"),
  },
  {
    id: 84, nome: "London Pound Cake", tipo: "Indica", thc: "20% - 29%", cbd: "<1%",
    descricao: "Variedade misteriosa criada pela Cookies. Sabor doce e complexo de bolo inglês com notas de frutas e especiarias.",
    efeitos: ["Relaxamento profundo", "Euforia", "Calma"],
    sabores: ["Bolo", "Frutas", "Baunilha"],
    beneficiosSaude: ["Ansiedade", "Dor", "Insônia", "Depressão"],
    origem: "EUA — Cookies", florescimento: "8-9 semanas", dificuldade: "Difícil", rendimento: "350-450g/m²", avaliacao: 4.7, imagem: aiImg("London Pound Cake", "Indica"),
  },
  {
    id: 85, nome: "Kali Mist", tipo: "Sativa", thc: "15% - 19%", cbd: "<1%",
    descricao: "Sativa pura premiada, perfeita para uso diurno. Efeito cerebral claro e funcional sem sedação.",
    efeitos: ["Clareza mental", "Energia", "Criatividade"],
    sabores: ["Herbal", "Pinho", "Especiarias"],
    beneficiosSaude: ["Depressão", "TDAH", "Fadiga", "Enxaqueca"],
    origem: "Holanda — Serious Seeds", florescimento: "10-12 semanas", dificuldade: "Difícil", rendimento: "350-450g/m²", avaliacao: 4.5, imagem: aiImg("Kali Mist", "Sativa"),
  },
  {
    id: 86, nome: "Golden Goat", tipo: "Sativa dominante", thc: "16% - 23%", cbd: "<1%",
    descricao: "Cruzamento acidental no Kansas entre Island Sweet Skunk, Hawaiian e Romulan. Buds dourados com aroma tropical.",
    efeitos: ["Felicidade", "Energia", "Criatividade"],
    sabores: ["Tropical", "Doce", "Cítrico"],
    beneficiosSaude: ["Depressão", "Estresse", "Dor", "Fadiga"],
    origem: "EUA — Kansas", florescimento: "9-11 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.5, imagem: aiImg("Golden Goat", "Sativa"),
  },
  {
    id: 87, nome: "Biscotti", tipo: "Indica", thc: "21% - 25%", cbd: "<1%",
    descricao: "Cruzamento de Gelato #25 com South Florida OG. Sabor doce de biscoito italiano com toque de diesel.",
    efeitos: ["Relaxamento", "Euforia suave", "Calma"],
    sabores: ["Biscoito", "Diesel", "Doce"],
    beneficiosSaude: ["Ansiedade", "Dor", "Insônia", "Estresse"],
    origem: "EUA — Cookies", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "350-450g/m²", avaliacao: 4.6, imagem: aiImg("Biscotti", "Indica"),
  },
  {
    id: 88, nome: "Purple Punch", tipo: "Indica", thc: "18% - 25%", cbd: "<1%",
    descricao: "Cruzamento de Larry OG com Granddaddy Purple. Sabor de suco de uva concentrado com efeito sedativo suave.",
    efeitos: ["Relaxamento", "Euforia", "Sono suave"],
    sabores: ["Uva", "Mirtilo", "Baunilha"],
    beneficiosSaude: ["Insônia", "Estresse", "Dor", "Ansiedade"],
    origem: "EUA — Supernova Gardens", florescimento: "7-8 semanas", dificuldade: "Fácil", rendimento: "400-500g/m²", avaliacao: 4.7, imagem: aiImg("Purple Punch", "Indica"),
  },
  {
    id: 89, nome: "Jack Frost", tipo: "Híbrida (Sativa dominante)", thc: "17% - 23%", cbd: "<1%",
    descricao: "Cruzamento de Jack Herer, Northern Lights e White Widow. Tricomas tão abundantes que parecem geada, daí o nome.",
    efeitos: ["Energia", "Euforia", "Clareza"],
    sabores: ["Pinho", "Limão", "Doce"],
    beneficiosSaude: ["Depressão", "Fadiga", "Estresse", "Dor"],
    origem: "Holanda", florescimento: "8-10 semanas", dificuldade: "Moderada", rendimento: "450-550g/m²", avaliacao: 4.5, imagem: aiImg("Jack Frost", "Sativa Hybrid"),
  },
  {
    id: 90, nome: "Lava Cake", tipo: "Indica", thc: "15% - 25%", cbd: "<1%",
    descricao: "Cruzamento de Thin Mint GSC com Grape Pie. Buds densos e púrpuros com sabor cremoso de bolo de lava de chocolate.",
    efeitos: ["Relaxamento profundo", "Euforia", "Calma"],
    sabores: ["Chocolate", "Baunilha", "Menta"],
    beneficiosSaude: ["Dor", "Insônia", "Ansiedade", "Estresse"],
    origem: "EUA — Cannarado Genetics", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "350-450g/m²", avaliacao: 4.6, imagem: aiImg("Lava Cake", "Indica"),
  },
  {
    id: 91, nome: "Candyland", tipo: "Sativa", thc: "14% - 24%", cbd: "<1%",
    descricao: "Cruzamento de Granddaddy Purple com Bay Platinum Cookies. Sativa doce da Bay Area com buds dourados e resinosos.",
    efeitos: ["Energia feliz", "Motivação", "Criatividade"],
    sabores: ["Doce", "Terroso", "Especiarias"],
    beneficiosSaude: ["Depressão", "Dor", "Fadiga", "Ansiedade"],
    origem: "EUA — Ken Estes", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.5, imagem: aiImg("Candyland", "Sativa"),
  },
  {
    id: 92, nome: "Guava", tipo: "Híbrida", thc: "18% - 24%", cbd: "<1%",
    descricao: "Cruzamento de Stardawg com Biscotti. Aroma tropical de goiaba com notas de diesel. Buds coloridos e muito resinosos.",
    efeitos: ["Euforia", "Relaxamento", "Felicidade"],
    sabores: ["Goiaba", "Tropical", "Diesel"],
    beneficiosSaude: ["Estresse", "Dor", "Depressão", "Ansiedade"],
    origem: "EUA — Cookies", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.6, imagem: aiImg("Guava", "Hybrid"),
  },
  {
    id: 93, nome: "Mochi", tipo: "Indica", thc: "21% - 29%", cbd: "<1%",
    descricao: "Também conhecida como Gelato #47 ou Mochi Gelato. Fenótipo específico do Gelato com notas doces e cremosas.",
    efeitos: ["Relaxamento", "Euforia", "Criatividade"],
    sabores: ["Doce cremoso", "Menta", "Baunilha"],
    beneficiosSaude: ["Dor", "Insônia", "Estresse", "Ansiedade"],
    origem: "EUA — Sherbinski", florescimento: "8-9 semanas", dificuldade: "Difícil", rendimento: "350-450g/m²", avaliacao: 4.6, imagem: aiImg("Mochi Gelato", "Indica"),
  },
  {
    id: 94, nome: "Hawaiian Snow", tipo: "Sativa", thc: "20% - 24%", cbd: "<1%",
    descricao: "Cruzamento triplo de Hawaiian Haze, Neville's Haze e Pure Haze. Campeã da Cannabis Cup 2003. Sativa com efeito extremamente duradouro.",
    efeitos: ["Energia intensa", "Euforia duradoura", "Criatividade"],
    sabores: ["Tropical", "Especiarias", "Herbal"],
    beneficiosSaude: ["Depressão", "Fadiga crônica", "Estresse", "Dor de cabeça"],
    origem: "Holanda — Green House Seeds", florescimento: "10-14 semanas", dificuldade: "Difícil", rendimento: "400-500g/m²", avaliacao: 4.6, imagem: aiImg("Hawaiian Snow", "Sativa"),
  },
  {
    id: 95, nome: "Moby Dick", tipo: "Sativa dominante", thc: "21% - 27%", cbd: "<1%",
    descricao: "Cruzamento de White Widow com Haze. Umas das sativas mais potentes do mundo, popular na Europa por sua produtividade e potência.",
    efeitos: ["Euforia cerebral", "Energia", "Motivação"],
    sabores: ["Cítrico", "Eucalipto", "Baunilha"],
    beneficiosSaude: ["Depressão", "Fadiga", "Estresse", "Dor"],
    origem: "Espanha — Dinafem", florescimento: "9-10 semanas", dificuldade: "Moderada", rendimento: "600-700g/m²", avaliacao: 4.7, imagem: aiImg("Moby Dick", "Sativa"),
  },
  {
    id: 96, nome: "Blackwater OG", tipo: "Indica", thc: "18% - 22%", cbd: "<1%",
    descricao: "Cruzamento de Mendo Purps com SFV OG Kush. Indica colorida com coloração púrpura escura e efeito sedativo potente.",
    efeitos: ["Sedação", "Relaxamento profundo", "Sono"],
    sabores: ["Uva", "Pinho", "Bagas escuras"],
    beneficiosSaude: ["Insônia", "Dor crônica", "Estresse", "Espasmos"],
    origem: "EUA — Cali Connection", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.5, imagem: aiImg("Blackwater OG", "Indica"),
  },
  {
    id: 97, nome: "Acapulco Gold", tipo: "Sativa", thc: "15% - 23%", cbd: "<1%",
    descricao: "Sativa landrace lendária do México. Considerada uma das melhores variedades de todos os tempos, com coloração dourada característica.",
    efeitos: ["Euforia", "Energia", "Felicidade duradoura"],
    sabores: ["Terroso", "Butterscotch", "Coffee"],
    beneficiosSaude: ["Depressão", "Fadiga", "Náusea", "Dor"],
    origem: "México — Acapulco", florescimento: "10-11 semanas", dificuldade: "Difícil", rendimento: "350-450g/m²", avaliacao: 4.7, imagem: aiImg("Acapulco Gold", "Sativa"),
  },
  {
    id: 98, nome: "Cookies and Cream", tipo: "Híbrida", thc: "20% - 26%", cbd: "<1%",
    descricao: "Cruzamento de Starfighter com Girl Scout Cookies phenotype. Vencedora do US Cannabis Cup, com sabor de biscoito com creme.",
    efeitos: ["Euforia", "Relaxamento", "Criatividade"],
    sabores: ["Biscoito", "Baunilha", "Doce"],
    beneficiosSaude: ["Dor", "Estresse", "Depressão", "Ansiedade"],
    origem: "EUA — Exotic Genetix", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.7, imagem: aiImg("Cookies and Cream", "Hybrid"),
  },
  {
    id: 99, nome: "Romulan", tipo: "Indica", thc: "16% - 24%", cbd: "<1%",
    descricao: "Nomeada em homenagem aos romulanos de Star Trek. Indica potente originária de British Columbia com efeito pesado e imediato.",
    efeitos: ["Sedação imediata", "Relaxamento profundo", "Sono"],
    sabores: ["Pinho", "Terroso", "Especiarias"],
    beneficiosSaude: ["Insônia", "Dor intensa", "Espasmos", "TEPT"],
    origem: "Canadá — British Columbia", florescimento: "7-8 semanas", dificuldade: "Fácil", rendimento: "400-500g/m²", avaliacao: 4.5, imagem: aiImg("Romulan", "Indica"),
  },
  {
    id: 100, nome: "Laughing Buddha", tipo: "Sativa", thc: "18% - 22%", cbd: "<1%",
    descricao: "Cruzamento de Thai com Jamaican sativas. Vencedora da Cannabis Cup 2003. Famosa por induzir ataques de riso incontroláveis.",
    efeitos: ["Riso incontrolável", "Felicidade", "Energia social"],
    sabores: ["Herbal", "Doce", "Frutado"],
    beneficiosSaude: ["Depressão", "Estresse", "Ansiedade social", "Fadiga"],
    origem: "Holanda — Barney's Farm", florescimento: "10-12 semanas", dificuldade: "Moderada", rendimento: "500-600g/m²", avaliacao: 4.7, imagem: aiImg("Laughing Buddha", "Sativa"),
  },

  // === 101-110: MEDICINAIS ESPECIALIZADAS ===
  {
    id: 101, nome: "Avidekel", tipo: "Medicinal Especializada", thc: "8% - 12%", cbd: "8% - 12%",
    descricao: "Desenvolvida pela Tikun Olam em Israel, é uma das variedades medicinais mais estudadas do mundo. Utilizada em ensaios clínicos para TEPT, dor crônica e inflamação intestinal. Proporção 1:1 THC:CBD.",
    efeitos: ["Balanceado", "Alívio de dor", "Clareza mental"],
    sabores: ["Terroso", "Herbal", "Leve especiaria"],
    beneficiosSaude: ["TEPT", "Doença de Crohn", "Dor crônica", "Inflamação"],
    origem: "Israel — Tikun Olam", florescimento: "8-10 semanas", dificuldade: "Moderada", rendimento: "350-450g/m²", avaliacao: 4.9, imagem: aiImg("Avidekel", "Medicinal CBD"),
    terpenos: ["β-Cariofileno", "Mirceno", "Linalol", "Bisabolol"],
    aplicacoesMedicas: [
      { condicao: "TEPT", eficacia: "alta", evidencia: "estabelecida" },
      { condicao: "Doença de Crohn", eficacia: "alta", evidencia: "preliminar" },
      { condicao: "Dor crônica", eficacia: "alta", evidencia: "estabelecida" },
    ],
  },
  {
    id: 102, nome: "Bedrocan", tipo: "Medicinal Especializada", thc: "22%", cbd: "<1%",
    descricao: "Variedade farmacêutica padronizada produzida pela Bedrocan na Holanda. Utilizada em programas médicos governamentais na Europa. Padrão ouro para cannabis medicinal com THC controlado.",
    efeitos: ["Relaxamento profundo", "Alívio de dor intensa", "Sedação"],
    sabores: ["Terroso", "Pinho", "Amadeirado"],
    beneficiosSaude: ["Dor severa", "Espasticidade", "Insônia", "Caquexia"],
    origem: "Holanda — Bedrocan BV", florescimento: "8-9 semanas", dificuldade: "Controlada", rendimento: "Padronizado", avaliacao: 4.8, imagem: aiImg("Bedrocan", "Medicinal"),
    terpenos: ["Mirceno", "β-Cariofileno", "Humuleno", "Pineno"],
    aplicacoesMedicas: [
      { condicao: "Dor oncológica", eficacia: "alta", evidencia: "estabelecida" },
      { condicao: "Esclerose múltipla", eficacia: "alta", evidencia: "estabelecida" },
      { condicao: "Caquexia", eficacia: "média", evidencia: "preliminar" },
    ],
  },
  {
    id: 103, nome: "Bediol", tipo: "Medicinal Especializada", thc: "6% - 8%", cbd: "6% - 8%",
    descricao: "Variedade 1:1 da Bedrocan, prescrita para pacientes que necessitam de efeito balanceado. Amplamente utilizada em programas médicos na Holanda, Alemanha e Itália.",
    efeitos: ["Balanceado suave", "Relaxamento", "Clareza"],
    sabores: ["Herbal", "Terroso", "Floral"],
    beneficiosSaude: ["Dor moderada", "Ansiedade", "Inflamação", "Náusea"],
    origem: "Holanda — Bedrocan BV", florescimento: "8-9 semanas", dificuldade: "Controlada", rendimento: "Padronizado", avaliacao: 4.7, imagem: aiImg("Bediol", "Medicinal CBD"),
    terpenos: ["Linalol", "Mirceno", "β-Cariofileno", "Bisabolol"],
    aplicacoesMedicas: [
      { condicao: "Ansiedade", eficacia: "alta", evidencia: "estabelecida" },
      { condicao: "Dor neuropática", eficacia: "média", evidencia: "preliminar" },
    ],
  },
  {
    id: 104, nome: "Pedanios 22/1", tipo: "Medicinal Especializada", thc: "22%", cbd: "1%",
    descricao: "Produzida pela Aurora Cannabis para o mercado farmacêutico alemão. Prescrita pelo sistema de saúde alemão (Krankenkasse) para dor crônica e espasticidade.",
    efeitos: ["Relaxamento intenso", "Alívio de dor", "Sedação"],
    sabores: ["Terroso", "Pinho", "Especiarias"],
    beneficiosSaude: ["Dor crônica", "Espasticidade", "Insônia", "Estresse severo"],
    origem: "Alemanha — Aurora Cannabis", florescimento: "8-10 semanas", dificuldade: "Controlada", rendimento: "Padronizado", avaliacao: 4.7, imagem: aiImg("Pedanios", "Medicinal"),
    terpenos: ["Mirceno", "Humuleno", "β-Cariofileno", "Pineno"],
    aplicacoesMedicas: [
      { condicao: "Dor crônica", eficacia: "alta", evidencia: "estabelecida" },
      { condicao: "Espasticidade", eficacia: "alta", evidencia: "estabelecida" },
    ],
  },
  {
    id: 105, nome: "Tilray T25", tipo: "Medicinal Especializada", thc: "25%", cbd: "<1%",
    descricao: "Cannabis medicinal de grau farmacêutico da Tilray. Produzida em instalações GMP (Good Manufacturing Practice) no Canadá. Utilizada em programas de acesso compassivo em 20+ países.",
    efeitos: ["Potente relaxamento", "Alívio intenso de dor", "Sono profundo"],
    sabores: ["Terroso", "Amendoado", "Especiarias"],
    beneficiosSaude: ["Dor oncológica", "Insônia severa", "Espasmos musculares", "TEPT"],
    origem: "Canadá — Tilray", florescimento: "9-10 semanas", dificuldade: "Controlada", rendimento: "Padronizado", avaliacao: 4.8, imagem: aiImg("Tilray T25", "Medicinal"),
    terpenos: ["Mirceno", "β-Cariofileno", "Linalol", "Humuleno"],
    aplicacoesMedicas: [
      { condicao: "Dor oncológica", eficacia: "alta", evidencia: "estabelecida" },
      { condicao: "TEPT", eficacia: "alta", evidencia: "preliminar" },
      { condicao: "Insônia severa", eficacia: "alta", evidencia: "estabelecida" },
    ],
  },
  {
    id: 106, nome: "Pennywise 1:1", tipo: "Medicinal Especializada", thc: "5% - 8%", cbd: "5% - 8%",
    descricao: "Cruzamento de Harlequin com Jack the Ripper. Proporção 1:1 ideal para pacientes que necessitam de efeito entourage sem psicoatividade excessiva. Amplamente prescrita para epilepsia e TEPT.",
    efeitos: ["Balanceado", "Clareza", "Relaxamento suave"],
    sabores: ["Café", "Pimenta", "Terroso"],
    beneficiosSaude: ["Epilepsia", "TEPT", "Ansiedade", "Dor neuropática"],
    origem: "EUA — TGA Subcool Seeds", florescimento: "8-9 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.8, imagem: aiImg("Pennywise", "Medicinal CBD"),
    terpenos: ["β-Cariofileno", "Mirceno", "Guaiol", "Bisabolol"],
    aplicacoesMedicas: [
      { condicao: "Epilepsia", eficacia: "alta", evidencia: "preliminar" },
      { condicao: "TEPT", eficacia: "alta", evidencia: "preliminar" },
      { condicao: "Ansiedade", eficacia: "alta", evidencia: "estabelecida" },
    ],
  },
  {
    id: 107, nome: "Spectrum Red No.2", tipo: "Medicinal Especializada", thc: "18%", cbd: "<1%",
    descricao: "Da linha Spectrum da Canopy Growth. Sistema de cores para facilitar prescrição médica. Red indica alto THC para dor intensa. Utilizada no programa canadense de cannabis medicinal.",
    efeitos: ["Relaxamento", "Alívio de dor", "Sedação"],
    sabores: ["Terroso", "Herbal", "Pinho"],
    beneficiosSaude: ["Dor intensa", "Insônia", "Espasmos", "Náusea quimio"],
    origem: "Canadá — Canopy Growth", florescimento: "8-9 semanas", dificuldade: "Controlada", rendimento: "Padronizado", avaliacao: 4.6, imagem: aiImg("Spectrum Red", "Medicinal"),
    terpenos: ["Mirceno", "β-Cariofileno", "Humuleno", "Linalol"],
    aplicacoesMedicas: [
      { condicao: "Dor intensa", eficacia: "alta", evidencia: "estabelecida" },
      { condicao: "Náusea por quimioterapia", eficacia: "alta", evidencia: "estabelecida" },
    ],
  },
  {
    id: 108, nome: "Ringo's Gift", tipo: "Medicinal Especializada", thc: "5% - 8%", cbd: "10% - 15%",
    descricao: "Nomeada em homenagem a Lawrence Ringo, pioneiro do movimento CBD. Cruzamento de ACDC com Harle-Tsu. Uma das variedades medicinais mais prescritas nos EUA para dor e inflamação.",
    efeitos: ["Relaxamento sem psicoatividade", "Clareza", "Bem-estar"],
    sabores: ["Menta", "Pinho", "Terroso"],
    beneficiosSaude: ["Dor crônica", "Inflamação", "Artrite", "Ansiedade"],
    origem: "EUA — SoHum Seeds", florescimento: "8-9 semanas", dificuldade: "Fácil", rendimento: "450-550g/m²", avaliacao: 4.8, imagem: aiImg("Ringos Gift", "Medicinal CBD"),
    terpenos: ["Mirceno", "β-Cariofileno", "Bisabolol", "Pineno"],
    aplicacoesMedicas: [
      { condicao: "Artrite", eficacia: "alta", evidencia: "preliminar" },
      { condicao: "Fibromialgia", eficacia: "média", evidencia: "preliminar" },
      { condicao: "Inflamação", eficacia: "alta", evidencia: "estabelecida" },
    ],
  },
  {
    id: 109, nome: "Sour Tsunami", tipo: "Medicinal Especializada", thc: "1% - 3%", cbd: "11% - 14%",
    descricao: "Uma das primeiras variedades cultivadas especificamente para alto CBD. Desenvolvida por Lawrence Ringo. Revolucionou a cannabis medicinal ao provar que plantas com alto CBD e baixo THC eram possíveis.",
    efeitos: ["Sem psicoatividade", "Alívio de dor", "Anti-inflamatório"],
    sabores: ["Diesel", "Chocolate", "Terroso"],
    beneficiosSaude: ["Dor crônica", "Inflamação", "Convulsões", "Ansiedade"],
    origem: "EUA — Southern Humboldt", florescimento: "9-10 semanas", dificuldade: "Moderada", rendimento: "400-500g/m²", avaliacao: 4.7, imagem: aiImg("Sour Tsunami", "Medicinal CBD"),
    terpenos: ["Mirceno", "β-Cariofileno", "Guaiol", "Linalol"],
    aplicacoesMedicas: [
      { condicao: "Convulsões", eficacia: "alta", evidencia: "preliminar" },
      { condicao: "Dor crônica", eficacia: "alta", evidencia: "estabelecida" },
      { condicao: "Inflamação", eficacia: "alta", evidencia: "estabelecida" },
    ],
  },
  {
    id: 110, nome: "Remedy", tipo: "Medicinal Especializada", thc: "0.5% - 1%", cbd: "10% - 15%",
    descricao: "Desenvolvida especificamente para uso medicinal com THC quase zero. Ideal para pacientes que não toleram nenhum efeito psicoativo. Amplamente prescrita para crianças com epilepsia e idosos com dor crônica.",
    efeitos: ["Zero psicoatividade", "Relaxamento suave", "Bem-estar"],
    sabores: ["Limão", "Pinho", "Menta"],
    beneficiosSaude: ["Epilepsia pediátrica", "Dor em idosos", "Ansiedade severa", "Insônia"],
    origem: "EUA — Dutch Treat Seeds", florescimento: "8-9 semanas", dificuldade: "Fácil", rendimento: "400-500g/m²", avaliacao: 4.9, imagem: aiImg("Remedy", "Medicinal CBD"),
    terpenos: ["Mirceno", "Bisabolol", "Linalol", "β-Cariofileno"],
    aplicacoesMedicas: [
      { condicao: "Epilepsia pediátrica", eficacia: "alta", evidencia: "preliminar" },
      { condicao: "Dor em idosos", eficacia: "alta", evidencia: "preliminar" },
      { condicao: "Ansiedade severa", eficacia: "alta", evidencia: "estabelecida" },
    ],
  },
];
