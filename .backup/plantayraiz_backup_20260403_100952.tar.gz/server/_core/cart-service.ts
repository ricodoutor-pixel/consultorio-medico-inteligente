import { cacheGet, cacheSet, cacheDel } from './cache';
import { Cart, CartItem, CartSummary } from './cart-schemas';
import { v4 as uuidv4 } from 'uuid';

const CART_TTL = 30 * 24 * 60 * 60; // 30 days
const CART_CACHE_PREFIX = 'cart';

/**
 * Get cart key for user
 */
function getCartKey(userId: string): string {
  return `${CART_CACHE_PREFIX}:${userId}`;
}

/**
 * Calculate cart totals
 */
function calculateTotals(items: CartItem[]): {
  subtotal: number;
  tax: number;
  shipping: number;
  total: number;
} {
  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const tax = subtotal * 0.1; // 10% tax
  const shipping = subtotal > 100 ? 0 : 15; // Free shipping over 100

  return {
    subtotal,
    tax,
    shipping,
    total: subtotal + tax + shipping,
  };
}

/**
 * Get or create cart for user
 */
export async function getOrCreateCart(userId: string): Promise<Cart> {
  const cacheKey = getCartKey(userId);
  const cached = await cacheGet<Cart>(cacheKey);

  if (cached) {
    return cached;
  }

  const newCart: Cart = {
    id: uuidv4(),
    userId,
    items: [],
    subtotal: 0,
    tax: 0,
    shipping: 0,
    total: 0,
    currency: 'BRL',
    createdAt: new Date(),
    updatedAt: new Date(),
    expiresAt: new Date(Date.now() + CART_TTL * 1000),
  };

  await cacheSet(cacheKey, newCart, CART_TTL);
  return newCart;
}

/**
 * Get cart for user
 */
export async function getCart(userId: string): Promise<Cart | null> {
  const cacheKey = getCartKey(userId);
  return await cacheGet<Cart>(cacheKey);
}

/**
 * Add item to cart
 */
export async function addToCart(
  userId: string,
  item: Omit<CartItem, 'id'>
): Promise<Cart> {
  const cart = await getOrCreateCart(userId);

  // Check if item already exists
  const existingItem = cart.items.find((i) => i.productId === item.productId);

  if (existingItem) {
    // Update quantity
    existingItem.quantity += item.quantity;
  } else {
    // Add new item
    cart.items.push({
      ...item,
      id: uuidv4(),
    });
  }

  // Recalculate totals
  const totals = calculateTotals(cart.items);
  cart.subtotal = totals.subtotal;
  cart.tax = totals.tax;
  cart.shipping = totals.shipping;
  cart.total = totals.total;
  cart.updatedAt = new Date();

  // Save to cache
  const cacheKey = getCartKey(userId);
  await cacheSet(cacheKey, cart, CART_TTL);

  return cart;
}

/**
 * Update cart item quantity
 */
export async function updateCartItem(
  userId: string,
  productId: string,
  quantity: number
): Promise<Cart | null> {
  const cart = await getCart(userId);
  if (!cart) return null;

  const item = cart.items.find((i) => i.productId === productId);
  if (!item) return null;

  if (quantity <= 0) {
    // Remove item if quantity is 0 or less
    cart.items = cart.items.filter((i) => i.productId !== productId);
  } else {
    item.quantity = quantity;
  }

  // Recalculate totals
  const totals = calculateTotals(cart.items);
  cart.subtotal = totals.subtotal;
  cart.tax = totals.tax;
  cart.shipping = totals.shipping;
  cart.total = totals.total;
  cart.updatedAt = new Date();

  // Save to cache
  const cacheKey = getCartKey(userId);
  await cacheSet(cacheKey, cart, CART_TTL);

  return cart;
}

/**
 * Remove item from cart
 */
export async function removeFromCart(userId: string, productId: string): Promise<Cart | null> {
  const cart = await getCart(userId);
  if (!cart) return null;

  cart.items = cart.items.filter((i) => i.productId !== productId);

  // Recalculate totals
  const totals = calculateTotals(cart.items);
  cart.subtotal = totals.subtotal;
  cart.tax = totals.tax;
  cart.shipping = totals.shipping;
  cart.total = totals.total;
  cart.updatedAt = new Date();

  // Save to cache
  const cacheKey = getCartKey(userId);
  await cacheSet(cacheKey, cart, CART_TTL);

  return cart;
}

/**
 * Clear cart
 */
export async function clearCart(userId: string): Promise<boolean> {
  const cacheKey = getCartKey(userId);
  return await cacheDel(cacheKey);
}

/**
 * Get cart summary
 */
export async function getCartSummary(userId: string): Promise<CartSummary | null> {
  const cart = await getCart(userId);
  if (!cart) return null;

  return {
    itemCount: cart.items.reduce((sum, item) => sum + item.quantity, 0),
    subtotal: cart.subtotal,
    tax: cart.tax,
    shipping: cart.shipping,
    total: cart.total,
    currency: cart.currency,
  };
}

/**
 * Validate cart items (check stock, prices, etc)
 */
export async function validateCart(cart: Cart): Promise<{
  valid: boolean;
  errors: string[];
}> {
  const errors: string[] = [];

  if (cart.items.length === 0) {
    errors.push('Cart is empty');
  }

  for (const item of cart.items) {
    if (item.quantity <= 0) {
      errors.push(`Invalid quantity for ${item.name}`);
    }

    if (item.price <= 0) {
      errors.push(`Invalid price for ${item.name}`);
    }

    // TODO: Check stock availability
    // TODO: Validate price hasn't changed
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Convert cart to order (after checkout)
 */
export async function convertCartToOrder(
  userId: string,
  orderId: string
): Promise<boolean> {
  const cart = await getCart(userId);
  if (!cart) return false;

  // Store order in cache with longer TTL
  const orderKey = `order:${orderId}`;
  await cacheSet(orderKey, cart, 90 * 24 * 60 * 60); // 90 days

  // Clear cart
  await clearCart(userId);

  return true;
}
