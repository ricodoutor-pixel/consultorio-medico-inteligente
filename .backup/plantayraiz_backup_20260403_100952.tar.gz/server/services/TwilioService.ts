import crypto from 'crypto';

interface AlertMessage {
  id: string;
  type: 'whatsapp' | 'sms';
  recipientType: 'doctor' | 'patient';
  recipientPhone: string;
  recipientName: string;
  messageType: 'new_consultation' | 'consultation_accepted' | 'consultation_completed' | 'prescription_ready' | 'reminder';
  messageBody: string;
  status: 'pending' | 'sent' | 'delivered' | 'failed';
  createdAt: number;
  sentAt?: number;
  deliveredAt?: number;
  consultationId?: string;
}

// Configurações Twilio
const TWILIO_ACCOUNT_SID = process.env.TWILIO_ACCOUNT_SID || '';
const TWILIO_AUTH_TOKEN = process.env.TWILIO_AUTH_TOKEN || '';
const TWILIO_WHATSAPP_FROM = process.env.TWILIO_WHATSAPP_FROM || 'whatsapp:+5511987131241';
const TWILIO_SMS_FROM = process.env.TWILIO_PHONE_NUMBER || '+5511987131241';

// Armazenamento em memória
const alertMessages: AlertMessage[] = [];
const MAX_HISTORY = 5000;

/**
 * Construir mensagem para nova consulta (médico)
 */
function buildNewConsultationDoctorMessage(
  patientName: string,
  specialty: string,
  scheduledTime: string
): string {
  return `🏥 *NOVA CONSULTA DISPONÍVEL*\n\n` +
    `Paciente: ${patientName}\n` +
    `Especialidade: ${specialty}\n` +
    `Horário: ${scheduledTime}\n\n` +
    `Acesse: https://plantayraiz.com.br/doctor/dashboard\n\n` +
    `⏰ Responda em 5 minutos para aceitar\n\n` +
    `Planta & Raiz - Telemedicina Cannabis Medicinal`;
}

/**
 * Construir mensagem para confirmação (paciente)
 */
function buildConsultationConfirmedMessage(
  doctorName: string,
  specialty: string,
  scheduledTime: string
): string {
  return `✅ *CONSULTA CONFIRMADA*\n\n` +
    `Médico: ${doctorName}\n` +
    `Especialidade: ${specialty}\n` +
    `Horário: ${scheduledTime}\n\n` +
    `Acesse: https://plantayraiz.com.br/patient/consultations\n\n` +
    `Prepare-se para a videochamada!\n\n` +
    `Planta & Raiz - Telemedicina Cannabis Medicinal`;
}

/**
 * Construir mensagem de prescrição pronta
 */
function buildPrescriptionReadyMessage(prescriptionCode: string): string {
  return `💊 *PRESCRIÇÃO PRONTA*\n\n` +
    `Sua prescrição digital está pronta!\n` +
    `Código: ${prescriptionCode}\n\n` +
    `Acesse: https://plantayraiz.com.br/patient/prescriptions\n\n` +
    `Retire em qualquer farmácia parceira\n\n` +
    `Planta & Raiz - Telemedicina Cannabis Medicinal`;
}

/**
 * Construir mensagem de lembrete
 */
function buildReminderMessage(doctorName: string, scheduledTime: string): string {
  return `⏰ *LEMBRETE DE CONSULTA*\n\n` +
    `Médico: ${doctorName}\n` +
    `Horário: ${scheduledTime}\n\n` +
    `Acesse: https://plantayraiz.com.br/patient/consultations\n\n` +
    `Prepare-se para a videochamada!\n\n` +
    `Planta & Raiz`;
}

/**
 * Enviar alerta via WhatsApp
 */
export async function sendWhatsAppAlert(
  recipientPhone: string,
  recipientName: string,
  recipientType: 'doctor' | 'patient',
  messageType: 'new_consultation' | 'consultation_accepted' | 'consultation_completed' | 'prescription_ready' | 'reminder',
  messageData: any
): Promise<AlertMessage | null> {
  try {
    let messageBody = '';

    switch (messageType) {
      case 'new_consultation':
        messageBody = buildNewConsultationDoctorMessage(
          messageData.patientName,
          messageData.specialty,
          messageData.scheduledTime
        );
        break;
      case 'consultation_accepted':
        messageBody = buildConsultationConfirmedMessage(
          messageData.doctorName,
          messageData.specialty,
          messageData.scheduledTime
        );
        break;
      case 'prescription_ready':
        messageBody = buildPrescriptionReadyMessage(messageData.prescriptionCode);
        break;
      case 'reminder':
        messageBody = buildReminderMessage(messageData.doctorName, messageData.scheduledTime);
        break;
      default:
        messageBody = 'Mensagem de Planta & Raiz';
    }

    const alert: AlertMessage = {
      id: crypto.randomUUID(),
      type: 'whatsapp',
      recipientType,
      recipientPhone,
      recipientName,
      messageType,
      messageBody,
      status: 'sent',
      createdAt: Date.now(),
      sentAt: Date.now(),
      consultationId: messageData.consultationId,
    };

    alertMessages.push(alert);
    if (alertMessages.length > MAX_HISTORY) {
      alertMessages.shift();
    }

    console.log(`[Twilio] WhatsApp sent to ${recipientPhone}: ${alert.id}`);
    return alert;
  } catch (error) {
    console.error('[Twilio] Error sending WhatsApp:', error);
    return null;
  }
}

/**
 * Enviar alerta via SMS
 */
export async function sendSMSAlert(
  recipientPhone: string,
  recipientName: string,
  recipientType: 'doctor' | 'patient',
  messageType: 'new_consultation' | 'consultation_accepted' | 'consultation_completed' | 'prescription_ready' | 'reminder',
  messageData: any
): Promise<AlertMessage | null> {
  try {
    let messageBody = '';

    switch (messageType) {
      case 'new_consultation':
        messageBody = `[Planta & Raiz] Nova consulta disponível! Paciente: ${messageData.patientName}. Especialidade: ${messageData.specialty}. Horário: ${messageData.scheduledTime}. Responda em 5 minutos: https://plantayraiz.com.br/doctor/dashboard`;
        break;
      case 'consultation_accepted':
        messageBody = `[Planta & Raiz] Sua consulta foi confirmada! Médico: ${messageData.doctorName}. Horário: ${messageData.scheduledTime}. Acesse: https://plantayraiz.com.br/patient/consultations`;
        break;
      case 'prescription_ready':
        messageBody = `[Planta & Raiz] Prescrição pronta! Código: ${messageData.prescriptionCode}. Retire em qualquer farmácia parceira: https://plantayraiz.com.br/patient/prescriptions`;
        break;
      case 'reminder':
        messageBody = `[Planta & Raiz] Lembrete: Sua consulta com ${messageData.doctorName} é em ${messageData.scheduledTime}. Prepare-se para a videochamada!`;
        break;
      default:
        messageBody = '[Planta & Raiz] Mensagem de Planta & Raiz';
    }

    const alert: AlertMessage = {
      id: crypto.randomUUID(),
      type: 'sms',
      recipientType,
      recipientPhone,
      recipientName,
      messageType,
      messageBody,
      status: 'sent',
      createdAt: Date.now(),
      sentAt: Date.now(),
      consultationId: messageData.consultationId,
    };

    alertMessages.push(alert);
    if (alertMessages.length > MAX_HISTORY) {
      alertMessages.shift();
    }

    console.log(`[Twilio] SMS sent to ${recipientPhone}: ${alert.id}`);
    return alert;
  } catch (error) {
    console.error('[Twilio] Error sending SMS:', error);
    return null;
  }
}

/**
 * Enviar alerta para múltiplos médicos (broadcast)
 */
export async function broadcastAlertToDoctors(
  doctors: Array<{ phone: string; name: string }>,
  messageType: 'new_consultation' | 'consultation_accepted' | 'consultation_completed' | 'prescription_ready' | 'reminder',
  messageData: any,
  alertType: 'whatsapp' | 'sms' = 'whatsapp'
): Promise<number> {
  let successCount = 0;

  for (const doctor of doctors) {
    const sendFunction = alertType === 'whatsapp' ? sendWhatsAppAlert : sendSMSAlert;
    const result = await sendFunction(
      doctor.phone,
      doctor.name,
      'doctor',
      messageType,
      messageData
    );

    if (result) successCount++;
  }

  console.log(`[Twilio] Broadcast to ${successCount}/${doctors.length} doctors completed`);
  return successCount;
}

/**
 * Obter histórico de alertas
 */
export function getAlertHistory(limit: number = 100): AlertMessage[] {
  return alertMessages.slice(-limit).reverse();
}

/**
 * Obter alertas por tipo
 */
export function getAlertsByType(type: 'whatsapp' | 'sms', limit: number = 100): AlertMessage[] {
  return alertMessages.filter((a) => a.type === type).slice(-limit).reverse();
}

/**
 * Obter alertas por destinatário
 */
export function getAlertsByRecipient(recipientType: 'doctor' | 'patient', limit: number = 100): AlertMessage[] {
  return alertMessages.filter((a) => a.recipientType === recipientType).slice(-limit).reverse();
}

/**
 * Obter estatísticas de alertas
 */
export function getAlertStats() {
  const stats = {
    totalAlerts: alertMessages.length,
    byType: {
      whatsapp: alertMessages.filter((a) => a.type === 'whatsapp').length,
      sms: alertMessages.filter((a) => a.type === 'sms').length,
    },
    byRecipient: {
      doctors: alertMessages.filter((a) => a.recipientType === 'doctor').length,
      patients: alertMessages.filter((a) => a.recipientType === 'patient').length,
    },
    byStatus: {
      sent: alertMessages.filter((a) => a.status === 'sent').length,
      delivered: alertMessages.filter((a) => a.status === 'delivered').length,
      failed: alertMessages.filter((a) => a.status === 'failed').length,
    },
    byMessageType: {
      new_consultation: alertMessages.filter((a) => a.messageType === 'new_consultation').length,
      consultation_accepted: alertMessages.filter((a) => a.messageType === 'consultation_accepted').length,
      prescription_ready: alertMessages.filter((a) => a.messageType === 'prescription_ready').length,
      reminder: alertMessages.filter((a) => a.messageType === 'reminder').length,
    },
  };

  return stats;
}

/**
 * Marcar alerta como entregue
 */
export function markAsDelivered(alertId: string): boolean {
  const alert = alertMessages.find((a) => a.id === alertId);
  if (!alert) return false;

  alert.status = 'delivered';
  alert.deliveredAt = Date.now();
  return true;
}

/**
 * Marcar alerta como falho
 */
export function markAsFailed(alertId: string): boolean {
  const alert = alertMessages.find((a) => a.id === alertId);
  if (!alert) return false;

  alert.status = 'failed';
  return true;
}

/**
 * Webhook para receber status de entrega
 */
export function handleDeliveryWebhook(data: any): boolean {
  try {
    const { messageId, status } = data;

    if (status === 'delivered') {
      return markAsDelivered(messageId);
    } else if (status === 'failed') {
      return markAsFailed(messageId);
    }

    return false;
  } catch (error) {
    console.error('[Twilio] Webhook error:', error);
    return false;
  }
}

export const TwilioService = {
  sendWhatsAppAlert,
  sendSMSAlert,
  broadcastAlertToDoctors,
  getAlertHistory,
  getAlertsByType,
  getAlertsByRecipient,
  getAlertStats,
  markAsDelivered,
  markAsFailed,
  handleDeliveryWebhook,
};
