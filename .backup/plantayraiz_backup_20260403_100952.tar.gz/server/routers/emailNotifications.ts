import { router, protectedProcedure } from "../_core/trpc";
import { z } from "zod";
import { EmailNotificationService } from "../services/EmailNotificationService";

export const emailNotificationsRouter = router({
  /**
   * Alertar sobre falha de Payout
   */
  alertPayoutFailure: protectedProcedure
    .input(
      z.object({
        payoutId: z.string(),
        recipientId: z.string(),
        amount: z.number(),
        reason: z.string(),
        bankAccount: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      return await EmailNotificationService.alertPayoutFailure(
        input.payoutId,
        input.recipientId,
        input.amount,
        input.reason,
        input.bankAccount
      );
    }),

  /**
   * Detectar atividade suspeita
   */
  detectSuspiciousActivity: protectedProcedure
    .input(
      z.object({
        entityId: z.string(),
        entityType: z.enum(["doctor", "shopkeeper", "patient"]),
        activityType: z.string(),
        details: z.record(z.any()),
      })
    )
    .mutation(async ({ input }) => {
      return await EmailNotificationService.detectSuspiciousActivity(
        input.entityId,
        input.entityType,
        input.activityType,
        input.details
      );
    }),

  /**
   * Alertar sobre problema de conformidade
   */
  alertComplianceIssue: protectedProcedure
    .input(
      z.object({
        entityId: z.string(),
        entityType: z.enum(["doctor", "shopkeeper"]),
        issue: z.string(),
        affectedRecords: z.array(z.string()),
      })
    )
    .mutation(async ({ input }) => {
      return await EmailNotificationService.alertComplianceIssue(
        input.entityId,
        input.entityType,
        input.issue,
        input.affectedRecords
      );
    }),

  /**
   * Alertar sobre fraude detectada
   */
  alertFraudDetection: protectedProcedure
    .input(
      z.object({
        transactionId: z.string(),
        entityId: z.string(),
        fraudScore: z.number().min(0).max(100),
        indicators: z.array(z.string()),
      })
    )
    .mutation(async ({ input }) => {
      return await EmailNotificationService.alertFraudDetection(
        input.transactionId,
        input.entityId,
        input.fraudScore,
        input.indicators
      );
    }),

  /**
   * Alertar sobre transação de alto valor
   */
  alertHighValueTransaction: protectedProcedure
    .input(
      z.object({
        transactionId: z.string(),
        entityId: z.string(),
        amount: z.number(),
        threshold: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      return await EmailNotificationService.alertHighValueTransaction(
        input.transactionId,
        input.entityId,
        input.amount,
        input.threshold
      );
    }),

  /**
   * Obter histórico de alertas
   */
  getHistory: protectedProcedure
    .input(z.object({ limit: z.number().default(100) }))
    .query(async ({ input }) => {
      return await EmailNotificationService.getAlertHistory(input.limit);
    }),

  /**
   * Obter alertas por nível
   */
  getByLevel: protectedProcedure
    .input(z.object({ level: z.enum(["critical", "warning", "info"]) }))
    .query(async ({ input }) => {
      return await EmailNotificationService.getAlertsByLevel(input.level);
    }),

  /**
   * Obter estatísticas de alertas
   */
  getStats: protectedProcedure.query(async () => {
    return await EmailNotificationService.getAlertStats();
  }),

  /**
   * Obter anomalias detectadas
   */
  getAnomalies: protectedProcedure.query(async () => {
    return await EmailNotificationService.getDetectedAnomalies();
  }),
});
