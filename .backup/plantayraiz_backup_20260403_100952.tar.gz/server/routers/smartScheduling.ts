import { router, protectedProcedure, publicProcedure } from '../_core/trpc';
import { z } from 'zod';
import { SmartSchedulingService } from '../services/SmartSchedulingService';

export const smartSchedulingRouter = router({
  registerDoctor: protectedProcedure
    .input(
      z.object({
        id: z.string(),
        name: z.string(),
        specialty: z.string(),
        maxConsultationsPerDay: z.number(),
        workingHours: z.object({
          start: z.number(),
          end: z.number(),
        }),
        breakTimes: z.array(
          z.object({
            start: z.number(),
            end: z.number(),
          })
        ),
        consultationDuration: z.number(),
        unavailableDates: z.array(z.string()),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const success = SmartSchedulingService.registerDoctor(input);
        return {
          success,
          message: success ? 'Médico registrado com sucesso' : 'Erro ao registrar médico',
        };
      } catch (error) {
        console.error('[smartScheduling] registerDoctor error:', error);
        return {
          success: false,
          message: 'Erro ao registrar médico',
        };
      }
    }),

  getAvailableSlots: publicProcedure
    .input(
      z.object({
        doctorId: z.string(),
        date: z.string(),
        specialty: z.string().optional(),
      })
    )
    .query(async ({ input }) => {
      try {
        const slots = SmartSchedulingService.getAvailableSlots(
          input.doctorId,
          input.date,
          input.specialty
        );
        return {
          success: true,
          slots,
          count: slots.length,
        };
      } catch (error) {
        console.error('[smartScheduling] getAvailableSlots error:', error);
        return {
          success: false,
          slots: [],
          count: 0,
        };
      }
    }),

  findBestDoctor: publicProcedure
    .input(
      z.object({
        specialty: z.string(),
        preferredDate: z.string(),
      })
    )
    .query(async ({ input }) => {
      try {
        const result = SmartSchedulingService.findBestAvailableDoctor(
          input.specialty,
          input.preferredDate
        );
        return {
          success: !!result,
          data: result,
        };
      } catch (error) {
        console.error('[smartScheduling] findBestDoctor error:', error);
        return {
          success: false,
          data: null,
        };
      }
    }),

  scheduleAppointment: protectedProcedure
    .input(
      z.object({
        doctorId: z.string(),
        patientId: z.string(),
        patientName: z.string(),
        patientPhone: z.string(),
        specialty: z.string(),
        scheduledTime: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const appointment = SmartSchedulingService.scheduleAppointment(
          input.doctorId,
          input.patientId,
          input.patientName,
          input.patientPhone,
          input.specialty,
          input.scheduledTime
        );

        return {
          success: !!appointment,
          appointment,
          message: appointment ? 'Consulta agendada com sucesso' : 'Horário não disponível',
        };
      } catch (error) {
        console.error('[smartScheduling] scheduleAppointment error:', error);
        return {
          success: false,
          appointment: null,
          message: 'Erro ao agendar consulta',
        };
      }
    }),

  confirmAppointment: protectedProcedure
    .input(z.object({ appointmentId: z.string() }))
    .mutation(async ({ input }) => {
      try {
        const success = SmartSchedulingService.confirmAppointment(input.appointmentId);
        return {
          success,
          message: success ? 'Consulta confirmada' : 'Consulta não encontrada',
        };
      } catch (error) {
        console.error('[smartScheduling] confirmAppointment error:', error);
        return {
          success: false,
          message: 'Erro ao confirmar consulta',
        };
      }
    }),

  cancelAppointment: protectedProcedure
    .input(z.object({ appointmentId: z.string() }))
    .mutation(async ({ input }) => {
      try {
        const success = SmartSchedulingService.cancelAppointment(input.appointmentId);
        return {
          success,
          message: success ? 'Consulta cancelada' : 'Consulta não encontrada',
        };
      } catch (error) {
        console.error('[smartScheduling] cancelAppointment error:', error);
        return {
          success: false,
          message: 'Erro ao cancelar consulta',
        };
      }
    }),

  getPendingAppointments: publicProcedure
    .input(z.object({ doctorId: z.string().optional() }))
    .query(async ({ input }) => {
      try {
        const appointments = SmartSchedulingService.getPendingAppointments(input.doctorId);
        return {
          success: true,
          data: appointments,
          count: appointments.length,
        };
      } catch (error) {
        console.error('[smartScheduling] getPendingAppointments error:', error);
        return {
          success: false,
          data: [],
          count: 0,
        };
      }
    }),

  getHistory: publicProcedure
    .input(z.object({ limit: z.number().default(100) }))
    .query(async ({ input }) => {
      try {
        const history = SmartSchedulingService.getAppointmentHistory(input.limit);
        return {
          success: true,
          data: history,
          count: history.length,
        };
      } catch (error) {
        console.error('[smartScheduling] getHistory error:', error);
        return {
          success: false,
          data: [],
          count: 0,
        };
      }
    }),

  getStats: publicProcedure.query(async () => {
    try {
      const stats = SmartSchedulingService.getSchedulingStats();
      return {
        success: true,
        data: stats,
      };
    } catch (error) {
      console.error('[smartScheduling] getStats error:', error);
      return {
        success: false,
        data: null,
      };
    }
  }),

  sendReminder: protectedProcedure
    .input(z.object({ appointmentId: z.string() }))
    .mutation(async ({ input }) => {
      try {
        const success = SmartSchedulingService.sendReminderNotification(input.appointmentId);
        return {
          success,
          message: success ? 'Lembrete enviado' : 'Consulta não encontrada',
        };
      } catch (error) {
        console.error('[smartScheduling] sendReminder error:', error);
        return {
          success: false,
          message: 'Erro ao enviar lembrete',
        };
      }
    }),
});
