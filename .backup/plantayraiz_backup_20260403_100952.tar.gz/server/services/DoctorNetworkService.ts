import crypto from 'crypto';

interface Doctor {
  id: string;
  name: string;
  crm: string;
  specialty: string;
  country: string;
  state: string;
  city: string;
  score: number; // 0-100
  isOnline: boolean;
  lastSeen: number;
  maxConcurrentConsultations: number;
  currentConsultations: number;
  responseTime: number; // em segundos
  acceptanceRate: number; // 0-100
  patientRating: number; // 0-5
  consultationsCompleted: number;
  languages: string[];
  specializations: string[];
  certifications: string[];
  hourlyRate: number; // em dólares
  availability: {
    monday: { start: number; end: number };
    tuesday: { start: number; end: number };
    wednesday: { start: number; end: number };
    thursday: { start: number; end: number };
    friday: { start: number; end: number };
    saturday: { start: number; end: number };
    sunday: { start: number; end: number };
  };
}

interface DoctorStatus {
  doctorId: string;
  isOnline: boolean;
  lastUpdate: number;
  currentConsultations: number;
  nextAvailable: number;
}

// Armazenamento em memória
const doctors = new Map<string, Doctor>();
const doctorStatuses = new Map<string, DoctorStatus>();
const MAX_HISTORY = 1000;

/**
 * Registrar médico na rede
 */
export function registerDoctor(doctor: Doctor): boolean {
  try {
    doctors.set(doctor.id, doctor);
    doctorStatuses.set(doctor.id, {
      doctorId: doctor.id,
      isOnline: false,
      lastUpdate: Date.now(),
      currentConsultations: 0,
      nextAvailable: Date.now(),
    });

    console.log(`[DoctorNetwork] Doctor registered: ${doctor.name} (${doctor.crm})`);
    return true;
  } catch (error) {
    console.error('[DoctorNetwork] Error registering doctor:', error);
    return false;
  }
}

/**
 * Médico entra online
 */
export function goOnline(doctorId: string): boolean {
  const doctor = doctors.get(doctorId);
  const status = doctorStatuses.get(doctorId);

  if (!doctor || !status) return false;

  doctor.isOnline = true;
  doctor.lastSeen = Date.now();
  status.isOnline = true;
  status.lastUpdate = Date.now();

  console.log(`[DoctorNetwork] Doctor online: ${doctor.name}`);
  return true;
}

/**
 * Médico sai offline
 */
export function goOffline(doctorId: string): boolean {
  const doctor = doctors.get(doctorId);
  const status = doctorStatuses.get(doctorId);

  if (!doctor || !status) return false;

  doctor.isOnline = false;
  doctor.lastSeen = Date.now();
  status.isOnline = false;
  status.lastUpdate = Date.now();

  console.log(`[DoctorNetwork] Doctor offline: ${doctor.name}`);
  return true;
}

/**
 * Obter médicos online por especialidade
 */
export function getOnlineDoctorsBySpecialty(specialty: string): Doctor[] {
  return Array.from(doctors.values()).filter(
    (d) => d.isOnline && d.specialty === specialty && d.currentConsultations < d.maxConcurrentConsultations
  );
}

/**
 * Obter médicos online por país
 */
export function getOnlineDoctorsByCountry(country: string): Doctor[] {
  return Array.from(doctors.values()).filter(
    (d) => d.isOnline && d.country === country && d.currentConsultations < d.maxConcurrentConsultations
  );
}

/**
 * Calcular score do médico
 */
export function calculateDoctorScore(doctorId: string): number {
  const doctor = doctors.get(doctorId);
  if (!doctor) return 0;

  // Fórmula de score: 40% aceitação + 30% avaliação + 20% tempo resposta + 10% disponibilidade
  const acceptanceScore = doctor.acceptanceRate * 0.4;
  const ratingScore = (doctor.patientRating / 5) * 100 * 0.3;
  const responseScore = Math.max(0, 100 - (doctor.responseTime / 60) * 10) * 0.2; // Máx 60s
  const availabilityScore = (doctor.currentConsultations / doctor.maxConcurrentConsultations) < 0.8 ? 10 : 5;

  const totalScore = acceptanceScore + ratingScore + responseScore + availabilityScore;
  doctor.score = Math.min(100, Math.max(0, totalScore));

  return doctor.score;
}

/**
 * Obter melhor médico disponível (estilo Uber)
 */
export function findBestAvailableDoctor(
  specialty: string,
  country: string,
  state?: string
): Doctor | null {
  let candidates = Array.from(doctors.values()).filter(
    (d) =>
      d.isOnline &&
      d.specialty === specialty &&
      d.country === country &&
      d.currentConsultations < d.maxConcurrentConsultations &&
      (!state || d.state === state)
  );

  if (candidates.length === 0) return null;

  // Ordenar por score (decrescente)
  candidates.sort((a, b) => {
    const scoreA = calculateDoctorScore(a.id);
    const scoreB = calculateDoctorScore(b.id);
    return scoreB - scoreA;
  });

  return candidates[0];
}

/**
 * Iniciar consulta (incrementar contador)
 */
export function startConsultation(doctorId: string): boolean {
  const doctor = doctors.get(doctorId);
  const status = doctorStatuses.get(doctorId);

  if (!doctor || !status) return false;

  if (doctor.currentConsultations >= doctor.maxConcurrentConsultations) {
    return false;
  }

  doctor.currentConsultations++;
  status.currentConsultations++;

  console.log(`[DoctorNetwork] Consultation started: ${doctor.name} (${doctor.currentConsultations}/${doctor.maxConcurrentConsultations})`);
  return true;
}

/**
 * Finalizar consulta (decrementar contador)
 */
export function endConsultation(doctorId: string): boolean {
  const doctor = doctors.get(doctorId);
  const status = doctorStatuses.get(doctorId);

  if (!doctor || !status) return false;

  if (doctor.currentConsultations > 0) {
    doctor.currentConsultations--;
    status.currentConsultations--;
    doctor.consultationsCompleted++;

    console.log(`[DoctorNetwork] Consultation ended: ${doctor.name} (${doctor.currentConsultations}/${doctor.maxConcurrentConsultations})`);
    return true;
  }

  return false;
}

/**
 * Atualizar taxa de aceitação
 */
export function updateAcceptanceRate(doctorId: string, accepted: boolean): void {
  const doctor = doctors.get(doctorId);
  if (!doctor) return;

  const totalConsultations = doctor.consultationsCompleted + 1;
  const acceptedCount = Math.round((doctor.acceptanceRate / 100) * doctor.consultationsCompleted) + (accepted ? 1 : 0);

  doctor.acceptanceRate = (acceptedCount / totalConsultations) * 100;
}

/**
 * Atualizar avaliação do médico
 */
export function updateDoctorRating(doctorId: string, rating: number): void {
  const doctor = doctors.get(doctorId);
  if (!doctor || rating < 0 || rating > 5) return;

  const totalConsultations = doctor.consultationsCompleted + 1;
  const currentRatingSum = doctor.patientRating * doctor.consultationsCompleted;
  doctor.patientRating = (currentRatingSum + rating) / totalConsultations;
}

/**
 * Obter status de médico
 */
export function getDoctorStatus(doctorId: string): DoctorStatus | null {
  return doctorStatuses.get(doctorId) || null;
}

/**
 * Obter informações do médico
 */
export function getDoctorInfo(doctorId: string): Doctor | null {
  return doctors.get(doctorId) || null;
}

/**
 * Listar todos os médicos online
 */
export function getAllOnlineDoctors(): Doctor[] {
  return Array.from(doctors.values()).filter((d) => d.isOnline);
}

/**
 * Obter estatísticas da rede
 */
export function getNetworkStats() {
  const allDoctors = Array.from(doctors.values());
  const onlineDoctors = allDoctors.filter((d) => d.isOnline);

  return {
    totalDoctors: allDoctors.length,
    onlineDoctors: onlineDoctors.length,
    offlineDoctors: allDoctors.length - onlineDoctors.length,
    totalConsultationsCompleted: allDoctors.reduce((sum, d) => sum + d.consultationsCompleted, 0),
    averageScore: allDoctors.reduce((sum, d) => sum + d.score, 0) / allDoctors.length,
    averageRating: allDoctors.reduce((sum, d) => sum + d.patientRating, 0) / allDoctors.length,
    specialties: Array.from(new Set(allDoctors.map((d) => d.specialty))),
    countries: Array.from(new Set(allDoctors.map((d) => d.country))),
  };
}

/**
 * Obter médicos por filtros
 */
export function searchDoctors(filters: {
  specialty?: string;
  country?: string;
  state?: string;
  minScore?: number;
  onlineOnly?: boolean;
}): Doctor[] {
  return Array.from(doctors.values()).filter((d) => {
    if (filters.specialty && d.specialty !== filters.specialty) return false;
    if (filters.country && d.country !== filters.country) return false;
    if (filters.state && d.state !== filters.state) return false;
    if (filters.minScore && calculateDoctorScore(d.id) < filters.minScore) return false;
    if (filters.onlineOnly && !d.isOnline) return false;
    return true;
  });
}

export const DoctorNetworkService = {
  registerDoctor,
  goOnline,
  goOffline,
  getOnlineDoctorsBySpecialty,
  getOnlineDoctorsByCountry,
  calculateDoctorScore,
  findBestAvailableDoctor,
  startConsultation,
  endConsultation,
  updateAcceptanceRate,
  updateDoctorRating,
  getDoctorStatus,
  getDoctorInfo,
  getAllOnlineDoctors,
  getNetworkStats,
  searchDoctors,
};
