import { router, publicProcedure, protectedProcedure } from '../_core/trpc';
import { z } from 'zod';
import { TwilioWhatsAppService } from '../services/TwilioWhatsAppService';

const twilioService = new TwilioWhatsAppService();

export const whatsappRouter = router({
  /**
   * Enviar alerta de nova consulta para médico
   */
  sendDoctorAlert: protectedProcedure
    .input(
      z.object({
        doctorPhone: z.string().regex(/^\+\d{1,15}$/),
        doctorName: z.string(),
        patientName: z.string(),
        consultationDate: z.string(),
        consultationTime: z.string(),
        consultationValue: z.number().positive(),
        consultationLink: z.string().url(),
        consultationId: z.string().uuid().optional()
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        // Enviar mensagem via Twilio
        const result = await twilioService.sendDoctorAlert(
          input.doctorPhone,
          input.doctorName,
          input.patientName,
          input.consultationDate,
          input.consultationTime,
          input.consultationValue,
          input.consultationLink
        );

        // TODO: Registrar no banco de dados quando tabelas forem criadas
        // if (result.success && result.sid) {
        //   const db = await getDb();
        //   if (!db) throw new Error('Database not available');
        //   await db.insert(whatsappAlerts).values({...});
        // }

        return {
          success: result.success,
          sid: result.sid,
          error: result.error,
          message: result.success ? 'Alerta enviado com sucesso' : 'Erro ao enviar alerta'
        };
      } catch (error: any) {
        console.error('Erro ao enviar alerta para médico:', error);
        return {
          success: false,
          error: error.message,
          message: 'Erro ao enviar alerta'
        };
      }
    }),

  /**
   * Enviar confirmação de consulta para paciente
   */
  sendPatientConfirmation: protectedProcedure
    .input(
      z.object({
        patientPhone: z.string().regex(/^\+\d{1,15}$/),
        patientName: z.string(),
        doctorName: z.string(),
        consultationDate: z.string(),
        consultationTime: z.string(),
        consultationLink: z.string().url(),
        consultationId: z.string().uuid().optional()
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        const result = await twilioService.sendPatientConfirmation(
          input.patientPhone,
          input.patientName,
          input.doctorName,
          input.consultationDate,
          input.consultationTime,
          input.consultationLink
        );

        return {
          success: result.success,
          sid: result.sid,
          error: result.error,
          message: result.success ? 'Confirmação enviada com sucesso' : 'Erro ao enviar confirmação'
        };
      } catch (error: any) {
        console.error('Erro ao enviar confirmação para paciente:', error);
        return {
          success: false,
          error: error.message,
          message: 'Erro ao enviar confirmação'
        };
      }
    }),

  /**
   * Enviar lembrete 1 hora antes da consulta
   */
  sendReminderAlert: protectedProcedure
    .input(
      z.object({
        recipientPhone: z.string().regex(/^\+\d{1,15}$/),
        recipientName: z.string(),
        recipientType: z.enum(['doctor', 'patient']),
        doctorName: z.string(),
        patientName: z.string(),
        consultationTime: z.string(),
        consultationLink: z.string().url(),
        consultationId: z.string().uuid().optional()
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        const result = await twilioService.sendReminderAlert(
          input.recipientPhone,
          input.recipientName,
          input.recipientType,
          input.doctorName,
          input.patientName,
          input.consultationTime,
          input.consultationLink
        );

        return {
          success: result.success,
          sid: result.sid,
          error: result.error,
          message: result.success ? 'Lembrete enviado com sucesso' : 'Erro ao enviar lembrete'
        };
      } catch (error: any) {
        console.error('Erro ao enviar lembrete:', error);
        return {
          success: false,
          error: error.message,
          message: 'Erro ao enviar lembrete'
        };
      }
    }),

  /**
   * Enviar notificação de conclusão de consulta
   */
  sendCompletionNotification: protectedProcedure
    .input(
      z.object({
        recipientPhone: z.string().regex(/^\+\d{1,15}$/),
        recipientName: z.string(),
        recipientType: z.enum(['doctor', 'patient']),
        otherPartyName: z.string(),
        prescriptionLink: z.string().url().optional(),
        consultationId: z.string().uuid().optional()
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        const result = await twilioService.sendCompletionNotification(
          input.recipientPhone,
          input.recipientName,
          input.recipientType,
          input.otherPartyName,
          input.prescriptionLink
        );

        return {
          success: result.success,
          sid: result.sid,
          error: result.error,
          message: result.success ? 'Notificação enviada com sucesso' : 'Erro ao enviar notificação'
        };
      } catch (error: any) {
        console.error('Erro ao enviar notificação:', error);
        return {
          success: false,
          error: error.message,
          message: 'Erro ao enviar notificação'
        };
      }
    }),

  /**
   * Obter histórico de alertas enviados
   */
  getAlertHistory: protectedProcedure
    .input(
      z.object({
        recipientPhone: z.string().optional(),
        messageType: z.string().optional(),
        limit: z.number().default(50)
      })
    )
    .query(async ({ input, ctx }) => {
      try {
        // TODO: Implementar quando tabelas forem criadas
        return {
          success: true,
          alerts: [],
          count: 0
        };
      } catch (error: any) {
        console.error('Erro ao obter histórico:', error);
        return {
          success: false,
          error: error.message,
          alerts: []
        };
      }
    }),

  /**
   * Obter logs de comunicação
   */
  getCommunicationLogs: protectedProcedure
    .input(
      z.object({
        messageSid: z.string().optional(),
        status: z.string().optional(),
        limit: z.number().default(100)
      })
    )
    .query(async ({ input, ctx }) => {
      try {
        // TODO: Implementar quando tabelas forem criadas
        return {
          success: true,
          logs: [],
          count: 0
        };
      } catch (error: any) {
        console.error('Erro ao obter logs:', error);
        return {
          success: false,
          error: error.message,
          logs: []
        };
      }
    }),

  /**
   * Testar conexão com Twilio
   */
  testConnection: publicProcedure.query(async () => {
    try {
      const result = await twilioService.testConnection();
      return {
        success: result.success,
        message: result.message
      };
    } catch (error: any) {
      return {
        success: false,
        message: `Erro ao testar conexão: ${error.message}`
      };
    }
  })
});
