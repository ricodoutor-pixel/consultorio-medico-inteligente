import { ReactNode } from 'react';

interface SpotlightShellProps {
  children: ReactNode;
}

export function SpotlightShell({ children }: SpotlightShellProps) {
  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-background">
      {/* Spotlight effect background */}
      <div className="pointer-events-none fixed inset-0">
        {/* Gradient spotlight 1 */}
        <div className="absolute -top-40 -right-40 h-80 w-80 rounded-full bg-accent/20 blur-3xl opacity-20 animate-pulse"></div>
        
        {/* Gradient spotlight 2 */}
        <div className="absolute -bottom-40 -left-40 h-80 w-80 rounded-full bg-accent/10 blur-3xl opacity-15 animate-pulse-slow"></div>
        
        {/* Gradient spotlight 3 */}
        <div className="absolute top-1/2 left-1/2 h-96 w-96 -translate-x-1/2 -translate-y-1/2 rounded-full bg-accent/5 blur-3xl opacity-10"></div>
      </div>

      {/* Content */}
      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
}
