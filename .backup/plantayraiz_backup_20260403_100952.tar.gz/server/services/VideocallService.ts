import crypto from 'crypto';
import axios from 'axios';

/**
 * VideocallService - Integração com Jitsi/Daily.co
 * Gerencia videochamadas entre pacientes e médicos com gravação criptografada
 */

interface VideocallConfig {
  provider: 'jitsi' | 'daily';
  jitsiServerUrl?: string;
  dailyApiKey?: string;
  encryptionKey: string;
  recordingBucket: string;
}

interface VideocallSession {
  id: string;
  consultationId: number;
  patientId: number;
  doctorId: number;
  roomName: string;
  joinUrl: string;
  recordingUrl?: string;
  isRecording: boolean;
  startTime: Date;
  endTime?: Date;
  duration?: number;
  encryptedData?: string;
}

export class VideocallService {
  private config: VideocallConfig;

  constructor(config: VideocallConfig) {
    this.config = config;
  }

  /**
   * Criar sessão de videochamada
   */
  async createVideocallSession(
    consultationId: number,
    patientId: number,
    doctorId: number,
    patientName: string,
    doctorName: string
  ): Promise<VideocallSession> {
    const roomName = `consultation-${consultationId}-${Date.now()}`;

    if (this.config.provider === 'daily') {
      return this.createDailySession(
        consultationId,
        patientId,
        doctorId,
        roomName,
        patientName,
        doctorName
      );
    } else {
      return this.createJitsiSession(
        consultationId,
        patientId,
        doctorId,
        roomName,
        patientName,
        doctorName
      );
    }
  }

  /**
   * Criar sessão com Daily.co (recomendado para produção)
   */
  private async createDailySession(
    consultationId: number,
    patientId: number,
    doctorId: number,
    roomName: string,
    patientName: string,
    doctorName: string
  ): Promise<VideocallSession> {
    try {
      // 1. Criar room no Daily.co
      const roomResponse = await axios.post(
        'https://api.daily.co/v1/rooms',
        {
          name: roomName,
          properties: {
            exp: Math.floor(Date.now() / 1000) + 86400, // Expira em 24h
            max_participants: 2,
            enable_recording: 'cloud',
            enable_chat: true,
            enable_screenshare: true,
            enable_knocking: false,
            enable_network_ui: true,
            enable_prejoin_ui: true,
            start_video_off: false,
            start_audio_off: false,
            owner_only_broadcast: false,
            enable_advanced_chat: true,
            sfu_switchover: 1000,
            max_cam_streams: 2,
            max_screen_streams: 1,
          },
        },
        {
          headers: {
            Authorization: `Bearer ${this.config.dailyApiKey}`,
            'Content-Type': 'application/json',
          },
        }
      );

      const room = roomResponse.data;

      // 2. Gerar tokens de acesso para paciente e médico
      const patientToken = this.generateDailyToken(
        room.name,
        patientName,
        'patient'
      );
      const doctorToken = this.generateDailyToken(
        room.name,
        doctorName,
        'doctor'
      );

      // 3. Criar URLs de acesso
      const patientUrl = `https://${room.url}?t=${patientToken}`;
      const doctorUrl = `https://${room.url}?t=${doctorToken}`;

      // 4. Retornar sessão
      return {
        id: room.id,
        consultationId,
        patientId,
        doctorId,
        roomName: room.name,
        joinUrl: room.url,
        isRecording: true,
        startTime: new Date(),
        encryptedData: this.encryptSessionData({
          patientUrl,
          doctorUrl,
          roomId: room.id,
          roomName: room.name,
        }),
      };
    } catch (error) {
      console.error('Erro ao criar sessão Daily.co:', error);
      throw new Error('Falha ao criar sessão de videochamada');
    }
  }

  /**
   * Criar sessão com Jitsi (alternativa open-source)
   */
  private async createJitsiSession(
    consultationId: number,
    patientId: number,
    doctorId: number,
    roomName: string,
    patientName: string,
    doctorName: string
  ): Promise<VideocallSession> {
    // Jitsi é self-hosted, então apenas retornamos a URL
    const jitsiUrl = this.config.jitsiServerUrl || 'https://meet.jit.si';
    const joinUrl = `${jitsiUrl}/${roomName}`;

    return {
      id: `jitsi-${consultationId}-${Date.now()}`,
      consultationId,
      patientId,
      doctorId,
      roomName,
      joinUrl,
      isRecording: true,
      startTime: new Date(),
      encryptedData: this.encryptSessionData({
        roomName,
        jitsiUrl,
        patientName,
        doctorName,
      }),
    };
  }

  /**
   * Gerar JWT token para Daily.co
   */
  private generateDailyToken(
    roomName: string,
    userName: string,
    userRole: 'patient' | 'doctor'
  ): string {
    // Implementar JWT generation com Daily.co SDK
    // Este é um exemplo simplificado
    const payload = {
      room_name: roomName,
      user_name: userName,
      user_id: `${userRole}-${Date.now()}`,
      exp: Math.floor(Date.now() / 1000) + 3600, // Expira em 1h
    };

    // Em produção, usar Daily.co SDK para gerar token
    return Buffer.from(JSON.stringify(payload)).toString('base64');
  }

  /**
   * Encriptar dados da sessão
   */
  private encryptSessionData(data: any): string {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv(
      'aes-256-cbc',
      Buffer.from(this.config.encryptionKey),
      iv
    );

    let encrypted = cipher.update(JSON.stringify(data), 'utf8', 'hex');
    encrypted += cipher.final('hex');

    return `${iv.toString('hex')}:${encrypted}`;
  }

  /**
   * Descriptografar dados da sessão
   */
  decryptSessionData(encryptedData: string): any {
    const [ivHex, encrypted] = encryptedData.split(':');
    const iv = Buffer.from(ivHex, 'hex');
    const decipher = crypto.createDecipheriv(
      'aes-256-cbc',
      Buffer.from(this.config.encryptionKey),
      iv
    );

    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');

    return JSON.parse(decrypted);
  }

  /**
   * Finalizar sessão e obter gravação
   */
  async endVideocallSession(
    sessionId: string
  ): Promise<{ duration: number; recordingUrl?: string }> {
    try {
      if (this.config.provider === 'daily') {
        // Obter informações da gravação do Daily.co
        const response = await axios.get(
          `https://api.daily.co/v1/recordings?room_id=${sessionId}`,
          {
            headers: {
              Authorization: `Bearer ${this.config.dailyApiKey}`,
            },
          }
        );

        const recordings = response.data.data;
        const latestRecording = recordings[0];

        return {
          duration: latestRecording?.duration || 0,
          recordingUrl: latestRecording?.download_link,
        };
      }

      return { duration: 0 };
    } catch (error) {
      console.error('Erro ao finalizar sessão:', error);
      throw new Error('Falha ao finalizar sessão de videochamada');
    }
  }

  /**
   * Obter status da gravação
   */
  async getRecordingStatus(sessionId: string): Promise<{
    isRecording: boolean;
    recordingUrl?: string;
    duration?: number;
  }> {
    try {
      if (this.config.provider === 'daily') {
        const response = await axios.get(
          `https://api.daily.co/v1/recordings?room_id=${sessionId}`,
          {
            headers: {
              Authorization: `Bearer ${this.config.dailyApiKey}`,
            },
          }
        );

        const recordings = response.data.data;
        const latestRecording = recordings[0];

        return {
          isRecording: latestRecording?.status === 'processing',
          recordingUrl: latestRecording?.download_link,
          duration: latestRecording?.duration,
        };
      }

      return { isRecording: false };
    } catch (error) {
      console.error('Erro ao obter status de gravação:', error);
      return { isRecording: false };
    }
  }

  /**
   * Armazenar gravação criptografada no S3
   */
  async storeEncryptedRecording(
    recordingUrl: string,
    consultationId: number,
    doctorId: number
  ): Promise<string> {
    try {
      // 1. Baixar gravação
      const response = await axios.get(recordingUrl, {
        responseType: 'arraybuffer',
      });

      const recordingBuffer = response.data;

      // 2. Encriptar gravação
      const iv = crypto.randomBytes(16);
      const cipher = crypto.createCipheriv(
        'aes-256-cbc',
        Buffer.from(this.config.encryptionKey),
        iv
      );

      let encrypted = cipher.update(recordingBuffer);
      encrypted = Buffer.concat([encrypted, cipher.final()]);

      // 3. Armazenar no S3
      const s3Key = `recordings/consultation-${consultationId}-doctor-${doctorId}-${Date.now()}.enc`;

      // Aqui você usaria o serviço de storage (S3) para armazenar
      // const { url } = await storagePut(s3Key, encrypted, 'application/octet-stream');

      return s3Key;
    } catch (error) {
      console.error('Erro ao armazenar gravação:', error);
      throw new Error('Falha ao armazenar gravação');
    }
  }
}

/**
 * Factory para criar instância do serviço
 */
export function createVideocallService(): VideocallService {
  const encryptionKey = process.env.VIDEOCALL_ENCRYPTION_KEY || 'default-key-change-in-production';

  return new VideocallService({
    provider: (process.env.VIDEOCALL_PROVIDER as 'jitsi' | 'daily') || 'daily',
    dailyApiKey: process.env.DAILY_API_KEY,
    jitsiServerUrl: process.env.JITSI_SERVER_URL,
    encryptionKey: encryptionKey.padEnd(32, '0').substring(0, 32), // Garantir 32 bytes
    recordingBucket: process.env.RECORDING_BUCKET || 'planta-raiz-recordings',
  });
}
