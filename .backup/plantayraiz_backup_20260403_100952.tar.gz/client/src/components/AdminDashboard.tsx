// ============================================================================
// ADMIN DASHBOARD — GRÁFICOS EM TEMPO REAL
// Planta & Raiz 3.0 — Dashboard Administrativo Avançado
// ============================================================================

import React, { useEffect, useState } from 'react';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertCircle, TrendingUp, Users, DollarSign, AlertTriangle } from 'lucide-react';
import { trpc } from '@/lib/trpc';

// ============================================================================
// TIPOS E INTERFACES
// ============================================================================

interface RevenueData {
  date: string;
  revenue: number;
  consultations: number;
  commission: number;
}

interface DoctorMetrics {
  name: string;
  earnings: number;
  consultations: number;
  rating: number;
}

interface PaymentMetrics {
  successRate: number;
  declineRate: number;
  fraudRate: number;
  averageAmount: number;
}

interface GrowthForecast {
  month: string;
  projected: number;
  conservative: number;
  optimistic: number;
}

// ============================================================================
// ADMIN DASHBOARD COMPONENT
// ============================================================================

export const AdminDashboard: React.FC = () => {
  const [revenueData, setRevenueData] = useState<RevenueData[]>([]);
  const [doctorMetrics, setDoctorMetrics] = useState<DoctorMetrics[]>([]);
  const [paymentMetrics, setPaymentMetrics] = useState<PaymentMetrics | null>(null);
  const [growthForecast, setGrowthForecast] = useState<GrowthForecast[]>([]);
  const [anomalies, setAnomalies] = useState<number>(0);
  const [loading, setLoading] = useState(true);

  // Buscar dados do dashboard
  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true);

        // Simular dados para demonstração
        const mockRevenueData: RevenueData[] = [
          { date: '01/03', revenue: 5000, consultations: 50, commission: 350 },
          { date: '02/03', revenue: 7500, consultations: 75, commission: 525 },
          { date: '03/03', revenue: 6200, consultations: 62, commission: 434 },
          { date: '04/03', revenue: 9100, consultations: 91, commission: 637 },
          { date: '05/03', revenue: 8800, consultations: 88, commission: 616 },
        ];

        const mockDoctorMetrics: DoctorMetrics[] = [
          { name: 'Dr. Silva', earnings: 45000, consultations: 450, rating: 4.8 },
          { name: 'Dra. Santos', earnings: 38000, consultations: 380, rating: 4.7 },
          { name: 'Dr. Oliveira', earnings: 42000, consultations: 420, rating: 4.9 },
          { name: 'Dra. Costa', earnings: 35000, consultations: 350, rating: 4.6 },
          { name: 'Dr. Ferreira', earnings: 40000, consultations: 400, rating: 4.8 },
        ];

        const mockPaymentMetrics: PaymentMetrics = {
          successRate: 0.985,
          declineRate: 0.012,
          fraudRate: 0.003,
          averageAmount: 89.5,
        };

        const mockGrowthForecast: GrowthForecast[] = [
          { month: 'Mar', projected: 250000, conservative: 220000, optimistic: 280000 },
          { month: 'Abr', projected: 320000, conservative: 280000, optimistic: 360000 },
          { month: 'Mai', projected: 410000, conservative: 360000, optimistic: 460000 },
          { month: 'Jun', projected: 520000, conservative: 450000, optimistic: 590000 },
          { month: 'Jul', projected: 650000, conservative: 560000, optimistic: 740000 },
        ];

        setRevenueData(mockRevenueData);
        setDoctorMetrics(mockDoctorMetrics);
        setPaymentMetrics(mockPaymentMetrics);
        setGrowthForecast(mockGrowthForecast);
        setAnomalies(3);
      } catch (error) {
        console.error('Erro ao buscar dados do dashboard:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();

    // Atualizar dados a cada 30 segundos
    const interval = setInterval(fetchDashboardData, 30000);
    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500 mx-auto mb-4"></div>
          <p className="text-gray-400">Carregando dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full bg-black text-white p-8 space-y-8">
      {/* HEADER */}
      <div className="flex justify-between items-center">
        <h1 className="text-4xl font-bold">Dashboard Administrativo</h1>
        <div className="text-sm text-gray-400">
          Atualizado em: {new Date().toLocaleTimeString('pt-BR')}
        </div>
      </div>

      {/* ALERTAS CRÍTICOS */}
      {anomalies > 0 && (
        <div className="bg-red-900/20 border border-red-500/50 rounded-lg p-4 flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 text-red-500" />
          <div>
            <p className="font-semibold text-red-400">{anomalies} Anomalias Detectadas</p>
            <p className="text-sm text-red-300">Verifique o sistema de monitoramento para mais detalhes</p>
          </div>
        </div>
      )}

      {/* KPI CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gray-900 border-gray-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400 flex items-center gap-2">
              <DollarSign className="w-4 h-4" />
              Receita Total
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-500">R$ 36.600</div>
            <p className="text-xs text-gray-500 mt-1">+12% vs semana anterior</p>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400 flex items-center gap-2">
              <Users className="w-4 h-4" />
              Consultas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-500">366</div>
            <p className="text-xs text-gray-500 mt-1">+8% vs semana anterior</p>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400 flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              Taxa de Sucesso
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-yellow-500">98.5%</div>
            <p className="text-xs text-gray-500 mt-1">Pagamentos aprovados</p>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400 flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              Comissão Plataforma
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-purple-500">R$ 2.562</div>
            <p className="text-xs text-gray-500 mt-1">7% de todas as transações</p>
          </CardContent>
        </Card>
      </div>

      {/* GRÁFICOS PRINCIPAIS */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* RECEITA EM TEMPO REAL */}
        <Card className="bg-gray-900 border-gray-700">
          <CardHeader>
            <CardTitle>Receita em Tempo Real</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="date" stroke="#666" />
                <YAxis stroke="#666" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333' }}
                  labelStyle={{ color: '#fff' }}
                />
                <Legend />
                <Line type="monotone" dataKey="revenue" stroke="#10b981" strokeWidth={2} name="Receita (R$)" />
                <Line type="monotone" dataKey="commission" stroke="#8b5cf6" strokeWidth={2} name="Comissão (R$)" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* MÉTRICA DE PAGAMENTOS */}
        <Card className="bg-gray-900 border-gray-700">
          <CardHeader>
            <CardTitle>Saúde do Sistema de Pagamentos</CardTitle>
          </CardHeader>
          <CardContent>
            {paymentMetrics && (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={[
                      { name: 'Aprovados', value: paymentMetrics.successRate * 100 },
                      { name: 'Recusados', value: paymentMetrics.declineRate * 100 },
                      { name: 'Fraude', value: paymentMetrics.fraudRate * 100 },
                    ]}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: ${value.toFixed(1)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    <Cell fill="#10b981" />
                    <Cell fill="#ef4444" />
                    <Cell fill="#f59e0b" />
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      {/* TOP MÉDICOS */}
      <Card className="bg-gray-900 border-gray-700">
        <CardHeader>
          <CardTitle>Top 5 Médicos por Receita</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={doctorMetrics}>
              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
              <XAxis dataKey="name" stroke="#666" />
              <YAxis stroke="#666" />
              <Tooltip
                contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333' }}
                labelStyle={{ color: '#fff' }}
              />
              <Legend />
              <Bar dataKey="earnings" fill="#10b981" name="Ganhos (R$)" />
              <Bar dataKey="consultations" fill="#3b82f6" name="Consultas" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* PREVISÃO DE CRESCIMENTO */}
      <Card className="bg-gray-900 border-gray-700">
        <CardHeader>
          <CardTitle>Previsão de Crescimento (6 Meses)</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={growthForecast}>
              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
              <XAxis dataKey="month" stroke="#666" />
              <YAxis stroke="#666" />
              <Tooltip
                contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333' }}
                labelStyle={{ color: '#fff' }}
                formatter={(value) => `R$ ${(value / 1000).toFixed(0)}k`}
              />
              <Legend />
              <Line type="monotone" dataKey="optimistic" stroke="#10b981" strokeWidth={2} strokeDasharray="5 5" name="Cenário Otimista" />
              <Line type="monotone" dataKey="projected" stroke="#3b82f6" strokeWidth={2} name="Projeção Realista" />
              <Line type="monotone" dataKey="conservative" stroke="#ef4444" strokeWidth={2} strokeDasharray="5 5" name="Cenário Conservador" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* ESTATÍSTICAS DETALHADAS */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gray-900 border-gray-700">
          <CardHeader>
            <CardTitle className="text-sm">Valor Médio de Consulta</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-500">R$ {paymentMetrics?.averageAmount.toFixed(2)}</div>
            <p className="text-xs text-gray-500 mt-2">Intervalo: R$ 49 - R$ 130</p>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-700">
          <CardHeader>
            <CardTitle className="text-sm">Taxa de Recusa</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-500">{((paymentMetrics?.declineRate || 0) * 100).toFixed(2)}%</div>
            <p className="text-xs text-gray-500 mt-2">Dentro dos limites normais</p>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-700">
          <CardHeader>
            <CardTitle className="text-sm">Detecção de Fraude</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-500">{((paymentMetrics?.fraudRate || 0) * 100).toFixed(3)}%</div>
            <p className="text-xs text-gray-500 mt-2">Monitoramento ativo 24/7</p>
          </CardContent>
        </Card>
      </div>

      {/* RODAPÉ */}
      <div className="text-xs text-gray-500 border-t border-gray-700 pt-4">
        <p>Dashboard atualizado automaticamente a cada 30 segundos. Todos os dados em tempo real.</p>
      </div>
    </div>
  );
};

export default AdminDashboard;
