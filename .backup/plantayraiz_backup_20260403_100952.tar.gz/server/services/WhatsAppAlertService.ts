/**
 * WhatsApp Alert Service com Timeout de 5 Minutos
 * 
 * Responsabilidades:
 * - Enviar alertas para médicos de plantão
 * - Monitorar tempo de resposta (máximo 5 minutos)
 * - Encaminhar para próximo médico se timeout
 * - Registrar todas as tentativas
 * 
 * Integração: Twilio WhatsApp API
 * Autoridade: Dr. Edilson Bezerra
 */

import twilio from 'twilio';

interface DoctorAlert {
  doctorId: string;
  doctorName: string;
  doctorPhone: string;
  patientName: string;
  triageId: string;
  urgencyLevel: 'low' | 'medium' | 'high' | 'critical';
  symptoms: string;
}

interface AlertResult {
  alertId: string;
  doctorId: string;
  doctorName: string;
  status: 'sent' | 'timeout' | 'error';
  messageSid?: string;
  responseTime?: number; // em segundos
  respondedAt?: Date;
  errorMessage?: string;
  sentAt: Date;
}

export class WhatsAppAlertService {
  private twilioClient: twilio.Twilio;
  private twilioPhoneNumber: string;
  private maxResponseTime = 5 * 60 * 1000; // 5 minutos em ms
  private activeAlerts: Map<string, NodeJS.Timeout> = new Map();

  constructor() {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    this.twilioPhoneNumber = process.env.TWILIO_WHATSAPP_FROM || '+12138452925';

    if (!accountSid || !authToken) {
      console.warn('[WhatsApp Alert] Twilio credentials not configured');
      this.twilioClient = null as any;
    } else {
      this.twilioClient = twilio(accountSid, authToken);
    }
  }

  /**
   * Enviar alerta para médico com timeout de 5 minutos
   */
  async sendAlert(alert: DoctorAlert): Promise<AlertResult> {
    console.log(`[WhatsApp Alert] Enviando alerta para ${alert.doctorName}...`);

    const alertId = `ALERT-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

    try {
      // 1. Preparar mensagem
      const message = this.formatAlertMessage(alert);

      // 2. Enviar via Twilio WhatsApp
      const messageSid = await this.sendWhatsAppMessage(alert.doctorPhone, message);

      console.log(`[WhatsApp Alert] ✅ Alerta enviado (SID: ${messageSid})`);

      // 3. Configurar timeout de 5 minutos
      const timeoutHandle = setTimeout(() => {
        console.log(`[WhatsApp Alert] ⏱️ TIMEOUT para ${alert.doctorName} (${this.maxResponseTime / 1000 / 60} min)`);
        this.handleTimeout(alertId, alert);
      }, this.maxResponseTime);

      this.activeAlerts.set(alertId, timeoutHandle);

      return {
        alertId,
        doctorId: alert.doctorId,
        doctorName: alert.doctorName,
        status: 'sent',
        messageSid,
        sentAt: new Date(),
      };
    } catch (error) {
      console.error(`[WhatsApp Alert] ❌ Erro ao enviar alerta:`, error);

      return {
        alertId,
        doctorId: alert.doctorId,
        doctorName: alert.doctorName,
        status: 'error',
        errorMessage: error instanceof Error ? error.message : 'Erro desconhecido',
        sentAt: new Date(),
      };
    }
  }

  /**
   * Confirmar resposta do médico
   */
  async confirmResponse(alertId: string, doctorId: string): Promise<boolean> {
    console.log(`[WhatsApp Alert] Confirmando resposta do médico: ${doctorId}`);

    // Limpar timeout
    const timeout = this.activeAlerts.get(alertId);
    if (timeout) {
      clearTimeout(timeout);
      this.activeAlerts.delete(alertId);
      console.log(`[WhatsApp Alert] ✅ Médico respondeu dentro do prazo`);
      return true;
    }

    console.log(`[WhatsApp Alert] ⚠️ Alerta não encontrado ou expirado`);
    return false;
  }

  /**
   * Lidar com timeout
   */
  private async handleTimeout(alertId: string, alert: DoctorAlert): Promise<void> {
    console.log(`[WhatsApp Alert] Processando timeout para ${alert.doctorName}`);

    this.activeAlerts.delete(alertId);

    // Encaminhar para próximo médico (será implementado em BrisaAIService)
    // Por enquanto, registrar o timeout
    console.log(`[WhatsApp Alert] 📋 Registrando timeout e encaminhando para próximo médico`);
  }

  /**
   * Formatar mensagem de alerta
   */
  private formatAlertMessage(alert: DoctorAlert): string {
    const urgencyEmoji = {
      low: '🟢',
      medium: '🟡',
      high: '🔴',
      critical: '🚨',
    };

    return `
${urgencyEmoji[alert.urgencyLevel]} *ALERTA - Planta y Raiz*

👤 Paciente: ${alert.patientName}
🆔 ID Triagem: ${alert.triageId}
🚨 Urgência: ${alert.urgencyLevel.toUpperCase()}

📋 Sintomas: ${alert.symptoms}

⏰ *Tempo de resposta: 5 MINUTOS*

👉 Clique para aceitar ou rejeitar a consulta
Link: https://plantayraiz.com.br/triagem/${alert.triageId}

---
Sistema Planta y Raiz - Telemedicina Cannabis Medicinal
Autorizado por: Dr. Edilson Bezerra
    `.trim();
  }

  /**
   * Enviar mensagem via Twilio WhatsApp
   */
  private async sendWhatsAppMessage(phoneNumber: string, message: string): Promise<string> {
    if (!this.twilioClient) {
      throw new Error('Twilio client not configured');
    }

    try {
      const result = await this.twilioClient.messages.create({
        from: `whatsapp:${this.twilioPhoneNumber}`,
        to: `whatsapp:${phoneNumber}`,
        body: message,
      });

      return result.sid;
    } catch (error) {
      console.error('[WhatsApp Alert] Erro ao enviar mensagem:', error);
      throw error;
    }
  }

  /**
   * Obter status de alerta
   */
  getAlertStatus(alertId: string): { active: boolean; remainingTime: number } {
    const timeout = this.activeAlerts.get(alertId);
    return {
      active: timeout !== undefined,
      remainingTime: timeout ? this.maxResponseTime : 0,
    };
  }

  /**
   * Listar alertas ativos
   */
  getActiveAlerts(): { count: number; alertIds: string[] } {
    return {
      count: this.activeAlerts.size,
      alertIds: Array.from(this.activeAlerts.keys()),
    };
  }

  /**
   * Cancelar alerta
   */
  cancelAlert(alertId: string): boolean {
    const timeout = this.activeAlerts.get(alertId);
    if (timeout) {
      clearTimeout(timeout);
      this.activeAlerts.delete(alertId);
      console.log(`[WhatsApp Alert] Alerta cancelado: ${alertId}`);
      return true;
    }
    return false;
  }
}

// Exportar instância singleton
export const whatsAppAlertService = new WhatsAppAlertService();
