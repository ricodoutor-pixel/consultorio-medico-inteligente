import { Shield } from 'lucide-react';

export function ComplianceCard() {
  return (
    <div className="rounded-xl border border-border/60 bg-background/40 px-4 py-4 text-center backdrop-blur-sm">
      <div className="flex items-center justify-center gap-2 mb-2">
        <Shield className="h-4 w-4 text-accent" />
        <p className="text-sm font-semibold text-accent">Transparência e Conformidade</p>
      </div>
      <p className="text-sm text-muted-foreground">
        Operação em conformidade com a <span className="font-semibold text-foreground">RDC 327/2019 da ANVISA</span> e normas de Tokenização de Ativos Reais (RWA).
      </p>
    </div>
  );
}
