/**
 * AnvisaGuardianService - Guardião ANVISA para Conformidade
 * Valida prescrições, certificados ICP-Brasil e documentos
 */

interface PrescriptionValidation {
  id: string;
  doctorCRM: string;
  patientCPF: string;
  medicineANVISA: string;
  dosage: string;
  duration: string;
  status: "valid" | "invalid" | "pending_review";
  validatedAt?: Date;
  errors: string[];
}

interface ComplianceReport {
  id: string;
  entityType: "doctor" | "shopkeeper";
  entityId: string;
  checkDate: Date;
  status: "compliant" | "non_compliant" | "pending";
  findings: string[];
  score: number; // 0-100
  recommendations: string[];
}

export class AnvisaGuardianService {
  private static prescriptionValidations: Map<string, PrescriptionValidation> = new Map();
  private static complianceReports: Map<string, ComplianceReport> = new Map();

  /**
   * Validar prescrição conforme ANVISA
   */
  static async validatePrescription(
    prescriptionId: string,
    doctorCRM: string,
    patientCPF: string,
    medicineANVISA: string,
    dosage: string,
    duration: string
  ): Promise<PrescriptionValidation> {
    const errors: string[] = [];

    // Validar CRM do médico
    if (!this.isValidCRM(doctorCRM)) {
      errors.push("CRM inválido ou não registrado");
    }

    // Validar CPF do paciente
    if (!this.isValidCPF(patientCPF)) {
      errors.push("CPF do paciente inválido");
    }

    // Validar código ANVISA do medicamento
    if (!this.isValidANVISACode(medicineANVISA)) {
      errors.push("Medicamento não registrado na ANVISA");
    }

    // Validar dosagem
    if (!this.isValidDosage(dosage)) {
      errors.push("Dosagem fora dos padrões ANVISA");
    }

    // Validar duração do tratamento
    if (!this.isValidDuration(duration)) {
      errors.push("Duração do tratamento inválida");
    }

    const validation: PrescriptionValidation = {
      id: prescriptionId,
      doctorCRM,
      patientCPF,
      medicineANVISA,
      dosage,
      duration,
      status: errors.length === 0 ? "valid" : "invalid",
      validatedAt: new Date(),
      errors,
    };

    this.prescriptionValidations.set(prescriptionId, validation);
    return validation;
  }

  /**
   * Gerar relatório de conformidade para médico
   */
  static async generateDoctorComplianceReport(
    doctorId: string,
    doctorCRM: string,
    icp_brassilCertificate: string
  ): Promise<ComplianceReport> {
    const findings: string[] = [];
    const recommendations: string[] = [];
    let score = 100;

    // Verificar CRM
    if (!this.isValidCRM(doctorCRM)) {
      findings.push("CRM não verificado no CFM");
      score -= 20;
      recommendations.push("Validar CRM junto ao CFM");
    }

    // Verificar certificado ICP-Brasil
    if (!this.isValidICPBrasilCertificate(icp_brassilCertificate)) {
      findings.push("Certificado ICP-Brasil inválido ou expirado");
      score -= 30;
      recommendations.push("Renovar certificado ICP-Brasil");
    }

    // Verificar conformidade LGPD
    findings.push("Política de privacidade de dados implementada");
    recommendations.push("Manter conformidade LGPD atualizada");

    const report: ComplianceReport = {
      id: `compliance-doc-${doctorId}-${Date.now()}`,
      entityType: "doctor",
      entityId: doctorId,
      checkDate: new Date(),
      status: score >= 80 ? "compliant" : score >= 60 ? "pending" : "non_compliant",
      findings,
      score,
      recommendations,
    };

    this.complianceReports.set(report.id, report);
    return report;
  }

  /**
   * Gerar relatório de conformidade para lojista
   */
  static async generateShopkeeperComplianceReport(
    shopkeeperId: string,
    cnpj: string,
    registrationNumber: string
  ): Promise<ComplianceReport> {
    const findings: string[] = [];
    const recommendations: string[] = [];
    let score = 100;

    // Verificar CNPJ
    if (!this.isValidCNPJ(cnpj)) {
      findings.push("CNPJ não verificado na Receita Federal");
      score -= 25;
      recommendations.push("Validar CNPJ junto à Receita Federal");
    }

    // Verificar registro de farmácia
    if (!this.isValidPharmacyRegistration(registrationNumber)) {
      findings.push("Registro de farmácia não verificado");
      score -= 25;
      recommendations.push("Validar registro junto à ANVISA");
    }

    // Verificar conformidade LGPD
    findings.push("Política de privacidade de dados implementada");
    recommendations.push("Manter conformidade LGPD atualizada");

    // Verificar conformidade de armazenamento
    findings.push("Protocolo de armazenamento de medicamentos implementado");
    recommendations.push("Manter padrões de armazenamento conforme ANVISA");

    const report: ComplianceReport = {
      id: `compliance-shop-${shopkeeperId}-${Date.now()}`,
      entityType: "shopkeeper",
      entityId: shopkeeperId,
      checkDate: new Date(),
      status: score >= 80 ? "compliant" : score >= 60 ? "pending" : "non_compliant",
      findings,
      score,
      recommendations,
    };

    this.complianceReports.set(report.id, report);
    return report;
  }

  /**
   * Obter histórico de validações de prescrição
   */
  static async getPrescriptionHistory(doctorCRM: string): Promise<PrescriptionValidation[]> {
    return Array.from(this.prescriptionValidations.values()).filter(
      (p) => p.doctorCRM === doctorCRM
    );
  }

  /**
   * Obter relatórios de conformidade
   */
  static async getComplianceReports(entityId: string): Promise<ComplianceReport[]> {
    return Array.from(this.complianceReports.values()).filter(
      (r) => r.entityId === entityId
    );
  }

  /**
   * Validadores auxiliares
   */
  private static isValidCRM(crm: string): boolean {
    // Validação simplificada: CRM deve ter 6-7 dígitos
    return /^\d{6,7}$/.test(crm);
  }

  private static isValidCPF(cpf: string): boolean {
    // Validação simplificada: CPF deve ter 11 dígitos
    return /^\d{11}$/.test(cpf);
  }

  private static isValidCNPJ(cnpj: string): boolean {
    // Validação simplificada: CNPJ deve ter 14 dígitos
    return /^\d{14}$/.test(cnpj);
  }

  private static isValidANVISACode(code: string): boolean {
    // Validação simplificada: código ANVISA deve ter 8 dígitos
    return /^\d{8}$/.test(code);
  }

  private static isValidDosage(dosage: string): boolean {
    // Validação simplificada: dosagem deve conter número e unidade
    return /^\d+\s*(mg|ml|g|UI)$/i.test(dosage);
  }

  private static isValidDuration(duration: string): boolean {
    // Validação simplificada: duração deve conter número e período
    return /^\d+\s*(dia|dias|semana|semanas|mês|meses)$/i.test(duration);
  }

  private static isValidICPBrasilCertificate(certificate: string): boolean {
    // Validação simplificada: certificado deve ter pelo menos 20 caracteres
    return certificate.length >= 20;
  }

  private static isValidPharmacyRegistration(registration: string): boolean {
    // Validação simplificada: registro deve ter pelo menos 10 caracteres
    return registration.length >= 10;
  }

  /**
   * Obter estatísticas de conformidade
   */
  static async getComplianceStats(): Promise<{
    totalPrescriptions: number;
    validPrescriptions: number;
    invalidPrescriptions: number;
    totalReports: number;
    compliantEntities: number;
    nonCompliantEntities: number;
  }> {
    const prescriptions = Array.from(this.prescriptionValidations.values());
    const reports = Array.from(this.complianceReports.values());

    return {
      totalPrescriptions: prescriptions.length,
      validPrescriptions: prescriptions.filter((p) => p.status === "valid").length,
      invalidPrescriptions: prescriptions.filter((p) => p.status === "invalid").length,
      totalReports: reports.length,
      compliantEntities: reports.filter((r) => r.status === "compliant").length,
      nonCompliantEntities: reports.filter((r) => r.status === "non_compliant").length,
    };
  }
}
