import { useCallback, useEffect, useState } from 'react';
import { trpc } from '../lib/trpc';
import type { Cart, CartItem } from '../../../server/_core/cart-schemas';

const CART_STORAGE_KEY = 'planta-raiz-cart';
const CART_SYNC_INTERVAL = 30000; // 30 seconds

export interface UseCartReturn {
  cart: Cart | null;
  isLoading: boolean;
  error: string | null;
  itemCount: number;
  addItem: (item: Omit<CartItem, 'id'>) => Promise<void>;
  updateItem: (productId: string, quantity: number) => Promise<void>;
  removeItem: (productId: string) => Promise<void>;
  clear: () => Promise<void>;
  checkout: (data: any) => Promise<string | null>;
}

/**
 * Hook for managing shopping cart with localStorage persistence and Redis sync
 */
export function useCart(): UseCartReturn {
  const [cart, setCart] = useState<Cart | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // tRPC mutations and queries
  const getCartQuery = trpc.cart.getCart.useQuery();
  const addItemMutation = trpc.cart.addItem.useMutation();
  const updateItemMutation = trpc.cart.updateItem.useMutation();
  const removeItemMutation = trpc.cart.removeItem.useMutation();
  const clearMutation = trpc.cart.clear.useMutation();
  const checkoutMutation = trpc.cart.checkout.useMutation();

  // Initialize cart from localStorage or backend
  useEffect(() => {
    const initializeCart = async () => {
      try {
        // Try to get from localStorage first
        const stored = localStorage.getItem(CART_STORAGE_KEY);
        if (stored) {
          const parsedCart = JSON.parse(stored);
          setCart(parsedCart);
        }

        // Sync with backend
        if (getCartQuery.data?.cart) {
          setCart(getCartQuery.data.cart);
          localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(getCartQuery.data.cart));
        }

        setIsLoading(false);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to initialize cart');
        setIsLoading(false);
      }
    };

    initializeCart();
  }, [getCartQuery.data]);

  // Sync cart to localStorage whenever it changes
  useEffect(() => {
    if (cart) {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
    }
  }, [cart]);

  // Periodic sync with backend
  useEffect(() => {
    const interval = setInterval(() => {
      getCartQuery.refetch();
    }, CART_SYNC_INTERVAL);

    return () => clearInterval(interval);
  }, [getCartQuery]);

  const addItem = useCallback(
    async (item: Omit<CartItem, 'id'>) => {
      try {
        setError(null);
        const result = await addItemMutation.mutateAsync(item);
        if (result.cart) {
          setCart(result.cart);
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to add item');
      }
    },
    [addItemMutation]
  );

  const updateItem = useCallback(
    async (productId: string, quantity: number) => {
      try {
        setError(null);
        const result = await updateItemMutation.mutateAsync({ productId, quantity });
        if (result.cart) {
          setCart(result.cart);
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to update item');
      }
    },
    [updateItemMutation]
  );

  const removeItem = useCallback(
    async (productId: string) => {
      try {
        setError(null);
        const result = await removeItemMutation.mutateAsync({ productId });
        if (result.cart) {
          setCart(result.cart);
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to remove item');
      }
    },
    [removeItemMutation]
  );

  const clear = useCallback(async () => {
    try {
      setError(null);
      await clearMutation.mutateAsync();
      setCart(null);
      localStorage.removeItem(CART_STORAGE_KEY);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to clear cart');
    }
  }, [clearMutation]);

  const checkout = useCallback(
    async (data: any) => {
      try {
        setError(null);
        const result = await checkoutMutation.mutateAsync(data);
        if (result.success) {
          setCart(null);
          localStorage.removeItem(CART_STORAGE_KEY);
          return result.orderId || null;
        } else {
          setError(result.error || 'Checkout failed');
          return null;
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Checkout failed');
        return null;
      }
    },
    [checkoutMutation]
  );

  const itemCount = cart ? cart.items.reduce((sum, item) => sum + item.quantity, 0) : 0;

  return {
    cart,
    isLoading,
    error,
    itemCount,
    addItem,
    updateItem,
    removeItem,
    clear,
    checkout,
  };
}
