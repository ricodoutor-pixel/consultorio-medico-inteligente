import React, { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Phone, PhoneOff, Mic, MicOff, Video, VideoOff } from 'lucide-react';

interface VideocallComponentProps {
  roomName: string;
  joinUrl: string;
  patientName: string;
  doctorName: string;
  consultationId: number;
  onEnd: () => void;
}

/**
 * Componente de Videochamada com Daily.co
 */
export const VideocallComponent: React.FC<VideocallComponentProps> = ({
  roomName,
  joinUrl,
  patientName,
  doctorName,
  consultationId,
  onEnd,
}) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [isAudioOn, setIsAudioOn] = useState(true);
  const [isVideoOn, setIsVideoOn] = useState(true);
  const [duration, setDuration] = useState(0);
  const durationIntervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    // Iniciar timer de duração
    durationIntervalRef.current = setInterval(() => {
      setDuration((prev) => prev + 1);
    }, 1000);

    return () => {
      if (durationIntervalRef.current) {
        clearInterval(durationIntervalRef.current);
      }
    };
  }, []);

  const handleEndCall = async () => {
    // Finalizar chamada
    if (durationIntervalRef.current) {
      clearInterval(durationIntervalRef.current);
    }

    // Notificar backend
    try {
      // await trpc.videocall.endSession.mutate({
      //   sessionId: roomName,
      //   consultationId
      // });
    } catch (error) {
      console.error('Erro ao finalizar chamada:', error);
    }

    onEnd();
  };

  const toggleAudio = () => {
    setIsAudioOn(!isAudioOn);
    // Enviar comando ao iframe do Daily.co
    if (iframeRef.current) {
      iframeRef.current.contentWindow?.postMessage(
        {
          action: 'set-audio',
          enabled: !isAudioOn,
        },
        '*'
      );
    }
  };

  const toggleVideo = () => {
    setIsVideoOn(!isVideoOn);
    // Enviar comando ao iframe do Daily.co
    if (iframeRef.current) {
      iframeRef.current.contentWindow?.postMessage(
        {
          action: 'set-video',
          enabled: !isVideoOn,
        },
        '*'
      );
    }
  };

  const formatDuration = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    return `${hours.toString().padStart(2, '0')}:${minutes
      .toString()
      .padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="w-full h-screen bg-black flex flex-col">
      {/* Header com informações */}
      <div className="bg-gray-900 text-white p-4 flex justify-between items-center">
        <div>
          <h2 className="text-lg font-bold">Consulta em andamento</h2>
          <p className="text-sm text-gray-400">
            {patientName} ↔ {doctorName}
          </p>
        </div>
        <div className="text-right">
          <p className="text-2xl font-bold text-green-400">
            {formatDuration(duration)}
          </p>
          <p className="text-xs text-gray-400">Duração</p>
        </div>
      </div>

      {/* Videochamada (Daily.co iframe) */}
      <div className="flex-1 bg-black">
        <iframe
          ref={iframeRef}
          src={joinUrl}
          style={{
            width: '100%',
            height: '100%',
            border: 'none',
          }}
          allow="camera; microphone; display-capture"
        />
      </div>

      {/* Controles */}
      <div className="bg-gray-900 text-white p-4 flex justify-center gap-4">
        <Button
          onClick={toggleAudio}
          variant={isAudioOn ? 'default' : 'destructive'}
          className="flex items-center gap-2"
        >
          {isAudioOn ? (
            <>
              <Mic size={20} />
              Microfone Ligado
            </>
          ) : (
            <>
              <MicOff size={20} />
              Microfone Desligado
            </>
          )}
        </Button>

        <Button
          onClick={toggleVideo}
          variant={isVideoOn ? 'default' : 'destructive'}
          className="flex items-center gap-2"
        >
          {isVideoOn ? (
            <>
              <Video size={20} />
              Câmera Ligada
            </>
          ) : (
            <>
              <VideoOff size={20} />
              Câmera Desligada
            </>
          )}
        </Button>

        <Button
          onClick={handleEndCall}
          variant="destructive"
          className="flex items-center gap-2"
        >
          <PhoneOff size={20} />
          Encerrar Chamada
        </Button>
      </div>
    </div>
  );
};

export default VideocallComponent;
