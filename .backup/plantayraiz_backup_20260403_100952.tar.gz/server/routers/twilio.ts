import { router, protectedProcedure, publicProcedure } from '../_core/trpc';
import { z } from 'zod';
import { TwilioService } from '../services/TwilioService';

export const twilioRouter = router({
  sendWhatsAppAlert: protectedProcedure
    .input(
      z.object({
        recipientPhone: z.string(),
        recipientName: z.string(),
        recipientType: z.enum(['doctor', 'patient']),
        messageType: z.enum(['new_consultation', 'consultation_accepted', 'consultation_completed', 'prescription_ready', 'reminder']),
        messageData: z.record(z.any()),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const alert = await TwilioService.sendWhatsAppAlert(
          input.recipientPhone,
          input.recipientName,
          input.recipientType,
          input.messageType,
          input.messageData
        );

        return {
          success: !!alert,
          alert,
          message: alert ? 'Alerta WhatsApp enviado com sucesso' : 'Erro ao enviar alerta',
        };
      } catch (error) {
        console.error('[twilio] sendWhatsAppAlert error:', error);
        return {
          success: false,
          message: 'Erro ao enviar alerta WhatsApp',
        };
      }
    }),

  sendSMSAlert: protectedProcedure
    .input(
      z.object({
        recipientPhone: z.string(),
        recipientName: z.string(),
        recipientType: z.enum(['doctor', 'patient']),
        messageType: z.enum(['new_consultation', 'consultation_accepted', 'consultation_completed', 'prescription_ready', 'reminder']),
        messageData: z.record(z.any()),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const alert = await TwilioService.sendSMSAlert(
          input.recipientPhone,
          input.recipientName,
          input.recipientType,
          input.messageType,
          input.messageData
        );

        return {
          success: !!alert,
          alert,
          message: alert ? 'Alerta SMS enviado com sucesso' : 'Erro ao enviar alerta',
        };
      } catch (error) {
        console.error('[twilio] sendSMSAlert error:', error);
        return {
          success: false,
          message: 'Erro ao enviar alerta SMS',
        };
      }
    }),

  broadcastToDoctors: protectedProcedure
    .input(
      z.object({
        doctors: z.array(
          z.object({
            phone: z.string(),
            name: z.string(),
          })
        ),
        messageType: z.enum(['new_consultation', 'consultation_accepted', 'consultation_completed', 'prescription_ready', 'reminder']),
        messageData: z.record(z.any()),
        alertType: z.enum(['whatsapp', 'sms']).default('whatsapp'),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const successCount = await TwilioService.broadcastAlertToDoctors(
          input.doctors,
          input.messageType,
          input.messageData,
          input.alertType
        );

        return {
          success: true,
          successCount,
          totalDoctors: input.doctors.length,
          message: `Alertas enviados para ${successCount}/${input.doctors.length} médicos`,
        };
      } catch (error) {
        console.error('[twilio] broadcastToDoctors error:', error);
        return {
          success: false,
          successCount: 0,
          totalDoctors: input.doctors.length,
          message: 'Erro ao enviar alertas',
        };
      }
    }),

  getHistory: publicProcedure
    .input(z.object({ limit: z.number().default(100) }))
    .query(async ({ input }) => {
      try {
        const history = TwilioService.getAlertHistory(input.limit);
        return {
          success: true,
          data: history,
          count: history.length,
        };
      } catch (error) {
        console.error('[twilio] getHistory error:', error);
        return {
          success: false,
          data: [],
          count: 0,
        };
      }
    }),

  getByType: publicProcedure
    .input(
      z.object({
        type: z.enum(['whatsapp', 'sms']),
        limit: z.number().default(100),
      })
    )
    .query(async ({ input }) => {
      try {
        const alerts = TwilioService.getAlertsByType(input.type, input.limit);
        return {
          success: true,
          data: alerts,
          count: alerts.length,
        };
      } catch (error) {
        console.error('[twilio] getByType error:', error);
        return {
          success: false,
          data: [],
          count: 0,
        };
      }
    }),

  getByRecipient: publicProcedure
    .input(
      z.object({
        recipientType: z.enum(['doctor', 'patient']),
        limit: z.number().default(100),
      })
    )
    .query(async ({ input }) => {
      try {
        const alerts = TwilioService.getAlertsByRecipient(input.recipientType, input.limit);
        return {
          success: true,
          data: alerts,
          count: alerts.length,
        };
      } catch (error) {
        console.error('[twilio] getByRecipient error:', error);
        return {
          success: false,
          data: [],
          count: 0,
        };
      }
    }),

  getStats: publicProcedure.query(async () => {
    try {
      const stats = TwilioService.getAlertStats();
      return {
        success: true,
        data: stats,
      };
    } catch (error) {
      console.error('[twilio] getStats error:', error);
      return {
        success: false,
        data: null,
      };
    }
  }),

  handleDeliveryWebhook: publicProcedure
    .input(
      z.object({
        messageId: z.string(),
        status: z.enum(['delivered', 'failed']),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const success = TwilioService.handleDeliveryWebhook(input);
        return {
          success,
          message: success ? 'Status atualizado' : 'Mensagem não encontrada',
        };
      } catch (error) {
        console.error('[twilio] handleDeliveryWebhook error:', error);
        return {
          success: false,
          message: 'Erro ao atualizar status',
        };
      }
    }),

  testAlert: protectedProcedure
    .input(
      z.object({
        phone: z.string(),
        name: z.string(),
        type: z.enum(['whatsapp', 'sms']),
        recipientType: z.enum(['doctor', 'patient']),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        // Verificar se é admin
        if (ctx.user?.role !== 'admin') {
          throw new Error('Unauthorized: Only admins can send test alerts');
        }

        const sendFunction = input.type === 'whatsapp' ? TwilioService.sendWhatsAppAlert : TwilioService.sendSMSAlert;

        const alert = await sendFunction(
          input.phone,
          input.name,
          input.recipientType,
          'new_consultation',
          {
            patientName: 'Paciente Teste',
            specialty: 'Clínico Geral',
            scheduledTime: new Date().toLocaleString('pt-BR'),
            consultationId: 'test-' + Date.now(),
          }
        );

        return {
          success: !!alert,
          alert,
          message: alert ? `Alerta de teste ${input.type} enviado com sucesso` : 'Erro ao enviar alerta de teste',
        };
      } catch (error) {
        console.error('[twilio] testAlert error:', error);
        return {
          success: false,
          message: 'Erro ao enviar alerta de teste',
        };
      }
    }),
});
