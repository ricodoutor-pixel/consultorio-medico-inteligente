import React, { useEffect, useState } from 'react';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';

interface Campaign {
  id: string;
  name: string;
  type: 'email' | 'sms' | 'push' | 'social' | 'content';
  status: 'active' | 'paused' | 'completed' | 'scheduled';
  startDate: number;
  endDate: number;
  budget: number;
  spent: number;
  impressions: number;
  clicks: number;
  conversions: number;
  roi: number;
  targetAudience: string;
}

interface CampaignMetrics {
  totalBudget: number;
  totalSpent: number;
  totalImpressions: number;
  totalClicks: number;
  totalConversions: number;
  averageROI: number;
  activeCampaigns: number;
}

export const MarketingCampaignDashboard: React.FC = () => {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [metrics, setMetrics] = useState<CampaignMetrics>({
    totalBudget: 0,
    totalSpent: 0,
    totalImpressions: 0,
    totalClicks: 0,
    totalConversions: 0,
    averageROI: 0,
    activeCampaigns: 0,
  });
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(null);
  const [showDetails, setShowDetails] = useState(false);
  const [showNewCampaign, setShowNewCampaign] = useState(false);

  // Simular dados de campanhas
  useEffect(() => {
    const mockCampaigns: Campaign[] = [
      {
        id: 'camp_001',
        name: 'Email Re-engajamento Médicos',
        type: 'email',
        status: 'active',
        startDate: Date.now() - 7 * 24 * 60 * 60 * 1000,
        endDate: Date.now() + 7 * 24 * 60 * 60 * 1000,
        budget: 5000,
        spent: 2500,
        impressions: 45000,
        clicks: 4500,
        conversions: 450,
        roi: 3.5,
        targetAudience: 'Médicos inativos (30+ dias)',
      },
      {
        id: 'camp_002',
        name: 'SMS Pacientes Ativos',
        type: 'sms',
        status: 'active',
        startDate: Date.now() - 3 * 24 * 60 * 60 * 1000,
        endDate: Date.now() + 4 * 24 * 60 * 60 * 1000,
        budget: 3000,
        spent: 1500,
        impressions: 25000,
        clicks: 3000,
        conversions: 360,
        roi: 4.2,
        targetAudience: 'Pacientes com histórico de compra',
      },
      {
        id: 'camp_003',
        name: 'Conteúdo Blog Cannabis',
        type: 'content',
        status: 'active',
        startDate: Date.now() - 30 * 24 * 60 * 60 * 1000,
        endDate: Date.now() + 30 * 24 * 60 * 60 * 1000,
        budget: 2000,
        spent: 1200,
        impressions: 120000,
        clicks: 6000,
        conversions: 600,
        roi: 2.8,
        targetAudience: 'Usuários novos (0-7 dias)',
      },
      {
        id: 'camp_004',
        name: 'Social Media LinkedIn',
        type: 'social',
        status: 'paused',
        startDate: Date.now() - 14 * 24 * 60 * 60 * 1000,
        endDate: Date.now() + 14 * 24 * 60 * 60 * 1000,
        budget: 4000,
        spent: 2000,
        impressions: 80000,
        clicks: 4000,
        conversions: 200,
        roi: 2.1,
        targetAudience: 'Profissionais de saúde',
      },
      {
        id: 'camp_005',
        name: 'Push Notification App',
        type: 'push',
        status: 'scheduled',
        startDate: Date.now() + 2 * 24 * 60 * 60 * 1000,
        endDate: Date.now() + 9 * 24 * 60 * 60 * 1000,
        budget: 1500,
        spent: 0,
        impressions: 0,
        clicks: 0,
        conversions: 0,
        roi: 0,
        targetAudience: 'Usuários do app mobile',
      },
    ];

    setCampaigns(mockCampaigns);

    // Calcular métricas
    const totalBudget = mockCampaigns.reduce((sum, c) => sum + c.budget, 0);
    const totalSpent = mockCampaigns.reduce((sum, c) => sum + c.spent, 0);
    const totalImpressions = mockCampaigns.reduce((sum, c) => sum + c.impressions, 0);
    const totalClicks = mockCampaigns.reduce((sum, c) => sum + c.clicks, 0);
    const totalConversions = mockCampaigns.reduce((sum, c) => sum + c.conversions, 0);
    const activeCampaigns = mockCampaigns.filter((c) => c.status === 'active').length;
    const averageROI = mockCampaigns.reduce((sum, c) => sum + c.roi, 0) / mockCampaigns.length;

    setMetrics({
      totalBudget,
      totalSpent,
      totalImpressions,
      totalClicks,
      totalConversions,
      averageROI,
      activeCampaigns,
    });
  }, []);

  const performanceData = campaigns.map((c) => ({
    name: c.name.substring(0, 15),
    roi: c.roi,
    conversions: c.conversions,
  }));

  const conversionFunnelData = [
    { stage: 'Impressões', value: metrics.totalImpressions },
    { stage: 'Cliques', value: metrics.totalClicks },
    { stage: 'Conversões', value: metrics.totalConversions },
  ];

  const campaignTypeDistribution = [
    { name: 'Email', value: campaigns.filter((c) => c.type === 'email').length },
    { name: 'SMS', value: campaigns.filter((c) => c.type === 'sms').length },
    { name: 'Push', value: campaigns.filter((c) => c.type === 'push').length },
    { name: 'Social', value: campaigns.filter((c) => c.type === 'social').length },
    { name: 'Content', value: campaigns.filter((c) => c.type === 'content').length },
  ];

  const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6'];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-500/20 text-green-500';
      case 'paused':
        return 'bg-yellow-500/20 text-yellow-500';
      case 'completed':
        return 'bg-blue-500/20 text-blue-500';
      case 'scheduled':
        return 'bg-purple-500/20 text-purple-500';
      default:
        return 'bg-slate-500/20 text-slate-500';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'email':
        return '📧';
      case 'sms':
        return '💬';
      case 'push':
        return '🔔';
      case 'social':
        return '📱';
      case 'content':
        return '📝';
      default:
        return '📊';
    }
  };

  return (
    <div className="w-full space-y-6 p-6 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-white">📊 Painel de Campanhas de Marketing</h1>
          <p className="text-slate-400">Gerenciamento autônomo de campanhas com métricas em tempo real</p>
        </div>
        <Button onClick={() => setShowNewCampaign(true)} className="bg-green-600 hover:bg-green-700">
          + Nova Campanha
        </Button>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <div className="space-y-2">
              <p className="text-sm text-slate-400">Orçamento Total</p>
              <p className="text-2xl font-bold text-green-500">R$ {(metrics.totalBudget / 1000).toFixed(1)}k</p>
              <p className="text-xs text-slate-500">Gasto: R$ {(metrics.totalSpent / 1000).toFixed(1)}k</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <div className="space-y-2">
              <p className="text-sm text-slate-400">Campanhas Ativas</p>
              <p className="text-2xl font-bold text-blue-500">{metrics.activeCampaigns}</p>
              <p className="text-xs text-slate-500">Total: {campaigns.length}</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <div className="space-y-2">
              <p className="text-sm text-slate-400">ROI Médio</p>
              <p className="text-2xl font-bold text-purple-500">{metrics.averageROI.toFixed(1)}x</p>
              <p className="text-xs text-slate-500">Retorno sobre investimento</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <div className="space-y-2">
              <p className="text-sm text-slate-400">Conversões</p>
              <p className="text-2xl font-bold text-orange-500">{metrics.totalConversions}</p>
              <p className="text-xs text-slate-500">Taxa: {((metrics.totalConversions / metrics.totalClicks) * 100).toFixed(1)}%</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Performance por Campanha */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Performance por Campanha</CardTitle>
            <CardDescription>ROI e conversões</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
                <XAxis dataKey="name" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }} />
                <Legend />
                <Bar dataKey="roi" fill="#10b981" name="ROI" />
                <Bar dataKey="conversions" fill="#3b82f6" name="Conversões" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Distribuição por Tipo */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Distribuição por Tipo</CardTitle>
            <CardDescription>Campanhas ativas</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={campaignTypeDistribution} cx="50%" cy="50%" labelLine={false} label={({ name, value }) => `${name}: ${value}`} outerRadius={80} fill="#8884d8" dataKey="value">
                  {campaignTypeDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Funil de Conversão */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Funil de Conversão</CardTitle>
          <CardDescription>Jornada do usuário</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={conversionFunnelData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
              <XAxis type="number" stroke="#94a3b8" />
              <YAxis dataKey="stage" type="category" stroke="#94a3b8" />
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }} />
              <Bar dataKey="value" fill="#10b981" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Lista de Campanhas */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Campanhas Ativas</CardTitle>
          <CardDescription>Clique para ver detalhes</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {campaigns.map((campaign) => (
              <div
                key={campaign.id}
                onClick={() => {
                  setSelectedCampaign(campaign);
                  setShowDetails(true);
                }}
                className="p-4 bg-slate-700 rounded-lg border border-slate-600 hover:border-slate-500 cursor-pointer transition"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3 flex-1">
                    <span className="text-2xl">{getTypeIcon(campaign.type)}</span>
                    <div className="flex-1">
                      <h3 className="font-semibold text-white">{campaign.name}</h3>
                      <p className="text-sm text-slate-400">{campaign.targetAudience}</p>
                    </div>
                  </div>
                  <Badge className={getStatusColor(campaign.status)}>{campaign.status}</Badge>
                </div>

                <div className="mt-3 grid grid-cols-4 gap-4 text-sm">
                  <div>
                    <p className="text-slate-400">Orçamento</p>
                    <p className="font-semibold text-white">R$ {(campaign.budget / 1000).toFixed(1)}k</p>
                  </div>
                  <div>
                    <p className="text-slate-400">Impressões</p>
                    <p className="font-semibold text-white">{(campaign.impressions / 1000).toFixed(0)}k</p>
                  </div>
                  <div>
                    <p className="text-slate-400">Conversões</p>
                    <p className="font-semibold text-white">{campaign.conversions}</p>
                  </div>
                  <div>
                    <p className="text-slate-400">ROI</p>
                    <p className="font-semibold text-green-500">{campaign.roi.toFixed(1)}x</p>
                  </div>
                </div>

                <div className="mt-3 w-full bg-slate-600 rounded-full h-2">
                  <div className="bg-green-500 h-2 rounded-full" style={{ width: `${(campaign.spent / campaign.budget) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Campaign Details Dialog */}
      <Dialog open={showDetails} onOpenChange={setShowDetails}>
        <DialogContent className="bg-slate-800 border-slate-700 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white">{selectedCampaign?.name}</DialogTitle>
            <DialogDescription>{selectedCampaign?.targetAudience}</DialogDescription>
          </DialogHeader>

          {selectedCampaign && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <p className="text-xs text-slate-400">Status</p>
                  <Badge className={getStatusColor(selectedCampaign.status)}>{selectedCampaign.status}</Badge>
                </div>
                <div className="space-y-2">
                  <p className="text-xs text-slate-400">Tipo</p>
                  <p className="text-sm text-white">{selectedCampaign.type}</p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <p className="text-xs text-slate-400">Orçamento</p>
                  <p className="text-lg font-bold text-green-500">R$ {(selectedCampaign.budget / 1000).toFixed(1)}k</p>
                  <p className="text-xs text-slate-500">Gasto: R$ {(selectedCampaign.spent / 1000).toFixed(1)}k</p>
                </div>
                <div className="space-y-2">
                  <p className="text-xs text-slate-400">ROI</p>
                  <p className="text-lg font-bold text-purple-500">{selectedCampaign.roi.toFixed(1)}x</p>
                </div>
                <div className="space-y-2">
                  <p className="text-xs text-slate-400">Taxa de Conversão</p>
                  <p className="text-lg font-bold text-blue-500">
                    {((selectedCampaign.conversions / selectedCampaign.clicks) * 100).toFixed(1)}%
                  </p>
                </div>
              </div>

              <Alert className="bg-slate-700 border-slate-600">
                <AlertDescription className="text-slate-200">
                  Impressões: {selectedCampaign.impressions} | Cliques: {selectedCampaign.clicks} | Conversões: {selectedCampaign.conversions}
                </AlertDescription>
              </Alert>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* New Campaign Dialog */}
      <Dialog open={showNewCampaign} onOpenChange={setShowNewCampaign}>
        <DialogContent className="bg-slate-800 border-slate-700">
          <DialogHeader>
            <DialogTitle className="text-white">Nova Campanha</DialogTitle>
            <DialogDescription>Criar campanha de marketing automática</DialogDescription>
          </DialogHeader>

          <Alert className="bg-green-500/20 border-green-500">
            <AlertDescription className="text-green-500">
              ✅ Campanha será criada automaticamente com base em recomendações de IA
            </AlertDescription>
          </Alert>

          <div className="space-y-4">
            <p className="text-sm text-slate-300">
              Selecione o tipo de campanha desejado e o sistema criará automaticamente com budget, público-alvo e cronograma otimizados.
            </p>
            <div className="grid grid-cols-2 gap-2">
              {['Email', 'SMS', 'Push', 'Social', 'Content'].map((type) => (
                <Button key={type} variant="outline" className="bg-slate-700 border-slate-600 hover:bg-slate-600">
                  {type}
                </Button>
              ))}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Footer */}
      <div className="text-center text-slate-500 text-sm pt-6 border-t border-slate-700">
        <p>Atualização em tempo real | Última atualização: {new Date().toLocaleTimeString('pt-BR')}</p>
      </div>
    </div>
  );
};
