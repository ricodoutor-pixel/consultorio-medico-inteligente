import jwt from 'jsonwebtoken';
import { cacheGet, cacheSet, cacheDel } from './cache';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';
const JWT_EXPIRY = '15m';
const REFRESH_TOKEN_EXPIRY = '7d';

export interface TokenPayload {
  userId: string;
  email: string;
  role: 'user' | 'admin' | 'doctor';
  iat?: number;
  exp?: number;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}

/**
 * Generate JWT access token
 */
export function generateAccessToken(payload: Omit<TokenPayload, 'iat' | 'exp'>): string {
  return jwt.sign(payload, JWT_SECRET, {
    expiresIn: JWT_EXPIRY,
    algorithm: 'HS256',
  });
}

/**
 * Generate refresh token (stored in cache)
 */
export async function generateRefreshToken(userId: string): Promise<string> {
  const token = jwt.sign({ userId }, JWT_SECRET, {
    expiresIn: REFRESH_TOKEN_EXPIRY,
    algorithm: 'HS256',
  });

  // Store in cache with TTL
  await cacheSet(`refresh-token:${userId}`, token, 7 * 24 * 60 * 60); // 7 days

  return token;
}

/**
 * Generate both access and refresh tokens
 */
export async function generateTokenPair(
  payload: Omit<TokenPayload, 'iat' | 'exp'>
): Promise<AuthTokens> {
  const accessToken = generateAccessToken(payload);
  const refreshToken = await generateRefreshToken(payload.userId);

  return {
    accessToken,
    refreshToken,
    expiresIn: 15 * 60, // 15 minutes in seconds
  };
}

/**
 * Verify JWT token
 */
export function verifyToken(token: string): TokenPayload | null {
  try {
    const decoded = jwt.verify(token, JWT_SECRET, {
      algorithms: ['HS256'],
    }) as TokenPayload;
    return decoded;
  } catch (error) {
    return null;
  }
}

/**
 * Refresh access token using refresh token
 */
export async function refreshAccessToken(
  refreshToken: string,
  userId: string
): Promise<AuthTokens | null> {
  try {
    // Verify refresh token
    const decoded = jwt.verify(refreshToken, JWT_SECRET, {
      algorithms: ['HS256'],
    }) as { userId: string };

    if (decoded.userId !== userId) {
      return null;
    }

    // Check if token is in cache (not revoked)
    const cachedToken = await cacheGet<string>(`refresh-token:${userId}`);
    if (!cachedToken || cachedToken !== refreshToken) {
      return null;
    }

    // Generate new token pair
    const newTokens = await generateTokenPair({
      userId,
      email: '', // Should be fetched from DB
      role: 'user', // Should be fetched from DB
    });

    return newTokens;
  } catch (error) {
    return null;
  }
}

/**
 * Revoke refresh token (logout)
 */
export async function revokeRefreshToken(userId: string): Promise<boolean> {
  return await cacheDel(`refresh-token:${userId}`);
}

/**
 * Revoke all refresh tokens for a user (logout from all devices)
 */
export async function revokeAllRefreshTokens(userId: string): Promise<boolean> {
  // Set a flag in cache to invalidate all tokens
  await cacheSet(`revoke-all:${userId}`, true, 7 * 24 * 60 * 60);
  return true;
}

/**
 * Check if user has revoked all tokens
 */
export async function hasRevokedAllTokens(userId: string): Promise<boolean> {
  const revoked = await cacheGet<boolean>(`revoke-all:${userId}`);
  return !!revoked;
}

/**
 * Extract token from Authorization header
 */
export function extractTokenFromHeader(authHeader?: string): string | null {
  if (!authHeader) return null;

  const parts = authHeader.split(' ');
  if (parts.length !== 2 || parts[0] !== 'Bearer') {
    return null;
  }

  return parts[1];
}

/**
 * Validate authorization header and return payload
 */
export async function validateAuthHeader(authHeader?: string): Promise<TokenPayload | null> {
  const token = extractTokenFromHeader(authHeader);
  if (!token) return null;

  const payload = verifyToken(token);
  if (!payload) return null;

  // Check if user has revoked all tokens
  const revoked = await hasRevokedAllTokens(payload.userId);
  if (revoked) return null;

  return payload;
}
