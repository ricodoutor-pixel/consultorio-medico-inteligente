import crypto from 'crypto';
import { DoctorNetworkService } from './DoctorNetworkService';

interface MatchRequest {
  id: string;
  patientId: string;
  patientName: string;
  specialty: string;
  country: string;
  state?: string;
  preferredLanguage?: string;
  urgency: 'low' | 'medium' | 'high' | 'emergency';
  budget?: number; // em dólares
  createdAt: number;
}

interface MatchResult {
  matchId: string;
  matchRequest: MatchRequest;
  matchedDoctorId: string;
  matchedDoctorName: string;
  matchScore: number; // 0-100
  estimatedWaitTime: number; // em segundos
  consultationFee: number; // em dólares
  status: 'pending' | 'accepted' | 'rejected' | 'completed';
  createdAt: number;
  acceptedAt?: number;
  completedAt?: number;
}

// Armazenamento em memória
const matchRequests: MatchRequest[] = [];
const matchResults: MatchResult[] = [];
const MAX_HISTORY = 5000;

/**
 * Criar requisição de matching
 */
export function createMatchRequest(request: Omit<MatchRequest, 'id' | 'createdAt'>): MatchRequest {
  const matchRequest: MatchRequest = {
    ...request,
    id: crypto.randomUUID(),
    createdAt: Date.now(),
  };

  matchRequests.push(matchRequest);
  if (matchRequests.length > MAX_HISTORY) {
    matchRequests.shift();
  }

  console.log(`[Matching] Request created: ${matchRequest.id} (${request.specialty})`);
  return matchRequest;
}

/**
 * Encontrar melhor match (Uber-style)
 */
export function findBestMatch(matchRequestId: string): MatchResult | null {
  const matchRequest = matchRequests.find((r) => r.id === matchRequestId);
  if (!matchRequest) return null;

  // Encontrar melhor médico disponível
  const bestDoctor = DoctorNetworkService.findBestAvailableDoctor(
    matchRequest.specialty,
    matchRequest.country,
    matchRequest.state
  );

  if (!bestDoctor) {
    console.log(`[Matching] No available doctors for request: ${matchRequestId}`);
    return null;
  }

  // Calcular match score
  const matchScore = calculateMatchScore(matchRequest, bestDoctor);

  // Estimar tempo de espera
  const estimatedWaitTime = calculateWaitTime(bestDoctor);

  // Determinar taxa de consulta
  const consultationFee = bestDoctor.hourlyRate / 4; // Consulta de 15 minutos

  const matchResult: MatchResult = {
    matchId: crypto.randomUUID(),
    matchRequest,
    matchedDoctorId: bestDoctor.id,
    matchedDoctorName: bestDoctor.name,
    matchScore,
    estimatedWaitTime,
    consultationFee,
    status: 'pending',
    createdAt: Date.now(),
  };

  matchResults.push(matchResult);
  if (matchResults.length > MAX_HISTORY) {
    matchResults.shift();
  }

  console.log(`[Matching] Match found: ${matchResult.matchId} (Score: ${matchScore})`);
  return matchResult;
}

/**
 * Calcular score de compatibilidade
 */
function calculateMatchScore(request: MatchRequest, doctor: any): number {
  let score = 0;

  // Score base: score do médico (40%)
  score += (doctor.score || 0) * 0.4;

  // Compatibilidade de idioma (20%)
  if (request.preferredLanguage && doctor.languages?.includes(request.preferredLanguage)) {
    score += 20;
  }

  // Compatibilidade de orçamento (20%)
  if (!request.budget || doctor.hourlyRate / 4 <= request.budget) {
    score += 20;
  }

  // Urgência (20%)
  const urgencyBonus = {
    low: 5,
    medium: 10,
    high: 15,
    emergency: 20,
  };
  score += urgencyBonus[request.urgency] || 0;

  return Math.min(100, score);
}

/**
 * Calcular tempo de espera estimado
 */
function calculateWaitTime(doctor: any): number {
  // Tempo base: 2 minutos
  let waitTime = 120;

  // Adicionar tempo por consulta em andamento (5 minutos cada)
  waitTime += (doctor.currentConsultations || 0) * 300;

  // Reduzir se score é alto
  if (doctor.score > 80) {
    waitTime -= 60;
  }

  return Math.max(0, waitTime);
}

/**
 * Aceitar match (médico confirma)
 */
export function acceptMatch(matchId: string): boolean {
  const matchResult = matchResults.find((m) => m.matchId === matchId);
  if (!matchResult) return false;

  matchResult.status = 'accepted';
  matchResult.acceptedAt = Date.now();

  // Iniciar consulta para o médico
  DoctorNetworkService.startConsultation(matchResult.matchedDoctorId);

  console.log(`[Matching] Match accepted: ${matchId}`);
  return true;
}

/**
 * Rejeitar match (médico recusa)
 */
export function rejectMatch(matchId: string): boolean {
  const matchResult = matchResults.find((m) => m.matchId === matchId);
  if (!matchResult) return false;

  matchResult.status = 'rejected';

  // Atualizar taxa de aceitação do médico
  DoctorNetworkService.updateAcceptanceRate(matchResult.matchedDoctorId, false);

  console.log(`[Matching] Match rejected: ${matchId}`);
  return true;
}

/**
 * Completar match (consulta finalizada)
 */
export function completeMatch(matchId: string, doctorRating?: number): boolean {
  const matchResult = matchResults.find((m) => m.matchId === matchId);
  if (!matchResult) return false;

  matchResult.status = 'completed';
  matchResult.completedAt = Date.now();

  // Finalizar consulta para o médico
  DoctorNetworkService.endConsultation(matchResult.matchedDoctorId);

  // Atualizar taxa de aceitação
  DoctorNetworkService.updateAcceptanceRate(matchResult.matchedDoctorId, true);

  // Atualizar avaliação se fornecida
  if (doctorRating) {
    DoctorNetworkService.updateDoctorRating(matchResult.matchedDoctorId, doctorRating);
  }

  console.log(`[Matching] Match completed: ${matchId}`);
  return true;
}

/**
 * Obter histórico de matches
 */
export function getMatchHistory(limit: number = 100): MatchResult[] {
  return matchResults.slice(-limit).reverse();
}

/**
 * Obter matches por status
 */
export function getMatchesByStatus(status: 'pending' | 'accepted' | 'rejected' | 'completed', limit: number = 100): MatchResult[] {
  return matchResults.filter((m) => m.status === status).slice(-limit).reverse();
}

/**
 * Obter estatísticas de matching
 */
export function getMatchingStats() {
  const stats = {
    totalMatches: matchResults.length,
    pendingMatches: matchResults.filter((m) => m.status === 'pending').length,
    acceptedMatches: matchResults.filter((m) => m.status === 'accepted').length,
    rejectedMatches: matchResults.filter((m) => m.status === 'rejected').length,
    completedMatches: matchResults.filter((m) => m.status === 'completed').length,
    averageMatchScore: matchResults.reduce((sum, m) => sum + m.matchScore, 0) / matchResults.length || 0,
    averageWaitTime: matchResults.reduce((sum, m) => sum + m.estimatedWaitTime, 0) / matchResults.length || 0,
    totalRevenue: matchResults
      .filter((m) => m.status === 'completed')
      .reduce((sum, m) => sum + m.consultationFee, 0),
  };

  return stats;
}

/**
 * Obter matches por paciente
 */
export function getMatchesByPatient(patientId: string): MatchResult[] {
  return matchResults.filter((m) => m.matchRequest.patientId === patientId);
}

/**
 * Obter matches por médico
 */
export function getMatchesByDoctor(doctorId: string): MatchResult[] {
  return matchResults.filter((m) => m.matchedDoctorId === doctorId);
}

export const MatchingService = {
  createMatchRequest,
  findBestMatch,
  acceptMatch,
  rejectMatch,
  completeMatch,
  getMatchHistory,
  getMatchesByStatus,
  getMatchingStats,
  getMatchesByPatient,
  getMatchesByDoctor,
};
