import { z } from 'zod';

/**
 * Cart item schema
 */
export const CartItemSchema = z.object({
  id: z.string().uuid(),
  productId: z.string().uuid(),
  name: z.string().min(1).max(255),
  price: z.number().positive(),
  quantity: z.number().int().positive().max(1000),
  image: z.string().url().optional(),
  category: z.string().optional(),
});

export type CartItem = z.infer<typeof CartItemSchema>;

/**
 * Cart schema
 */
export const CartSchema = z.object({
  id: z.string().uuid(),
  userId: z.string().uuid(),
  items: z.array(CartItemSchema),
  subtotal: z.number().nonnegative(),
  tax: z.number().nonnegative(),
  shipping: z.number().nonnegative(),
  total: z.number().nonnegative(),
  currency: z.string().length(3).default('BRL'),
  createdAt: z.date(),
  updatedAt: z.date(),
  expiresAt: z.date().optional(),
});

export type Cart = z.infer<typeof CartSchema>;

/**
 * Add to cart input
 */
export const AddToCartSchema = z.object({
  productId: z.string().uuid(),
  name: z.string().min(1).max(255),
  price: z.number().positive(),
  quantity: z.number().int().positive().max(1000),
  image: z.string().url().optional(),
  category: z.string().optional(),
});

export type AddToCartInput = z.infer<typeof AddToCartSchema>;

/**
 * Update cart item input
 */
export const UpdateCartItemSchema = z.object({
  productId: z.string().uuid(),
  quantity: z.number().int().positive().max(1000),
});

export type UpdateCartItemInput = z.infer<typeof UpdateCartItemSchema>;

/**
 * Remove from cart input
 */
export const RemoveFromCartSchema = z.object({
  productId: z.string().uuid(),
});

export type RemoveFromCartInput = z.infer<typeof RemoveFromCartSchema>;

/**
 * Cart summary
 */
export const CartSummarySchema = z.object({
  itemCount: z.number().int().nonnegative(),
  subtotal: z.number().nonnegative(),
  tax: z.number().nonnegative(),
  shipping: z.number().nonnegative(),
  total: z.number().nonnegative(),
  currency: z.string().length(3),
});

export type CartSummary = z.infer<typeof CartSummarySchema>;

/**
 * Checkout input
 */
export const CheckoutSchema = z.object({
  shippingAddress: z.object({
    street: z.string().min(5),
    number: z.string().min(1),
    complement: z.string().optional(),
    city: z.string().min(2),
    state: z.string().length(2),
    zipCode: z.string().regex(/^\d{5}-?\d{3}$/),
    country: z.string().length(2).default('BR'),
  }),
  billingAddress: z.object({
    street: z.string().min(5),
    number: z.string().min(1),
    complement: z.string().optional(),
    city: z.string().min(2),
    state: z.string().length(2),
    zipCode: z.string().regex(/^\d{5}-?\d{3}$/),
    country: z.string().length(2).default('BR'),
  }).optional(),
  paymentMethod: z.enum(['credit_card', 'pix', 'bank_transfer']),
  notes: z.string().max(500).optional(),
});

export type CheckoutInput = z.infer<typeof CheckoutSchema>;

/**
 * Cart response
 */
export const CartResponseSchema = z.object({
  success: z.boolean(),
  cart: CartSchema.optional(),
  message: z.string().optional(),
  error: z.string().optional(),
});

export type CartResponse = z.infer<typeof CartResponseSchema>;
