/**
 * DigitalSignatureService - Integração simplificada com Clicksign
 * Gerencia assinatura digital de contratos para médicos e lojistas
 */

interface SignatureDocument {
  id: string;
  type: "doctor_contract" | "shopkeeper_contract" | "service_terms";
  signers: Array<{
    email: string;
    name: string;
    status: "pending" | "signed" | "rejected";
  }>;
  status: "pending" | "completed" | "rejected";
  createdAt: Date;
  completedAt?: Date;
  signatureUrl?: string;
}

export class DigitalSignatureService {
  private static documents: Map<string, SignatureDocument> = new Map();

  /**
   * Criar solicitação de assinatura para médico
   */
  static async createDoctorContractSignature(
    doctorId: string,
    doctorName: string,
    doctorEmail: string,
    crm: string
  ): Promise<SignatureDocument> {
    const documentId = `doc-${doctorId}-${Date.now()}`;
    
    const document: SignatureDocument = {
      id: documentId,
      type: "doctor_contract",
      signers: [
        {
          email: doctorEmail,
          name: doctorName,
          status: "pending",
        },
        {
          email: "admin@plantayraiz.com.br",
          name: "Planta & Raiz Admin",
          status: "pending",
        },
      ],
      status: "pending",
      createdAt: new Date(),
      signatureUrl: `https://clicksign.com/signature/${documentId}`,
    };

    this.documents.set(documentId, document);

    // Simular envio de email com link de assinatura
    await this.sendSignatureEmail(
      doctorEmail,
      doctorName,
      document.signatureUrl,
      "Contrato de Prestação de Serviços Médicos"
    );

    return document;
  }

  /**
   * Criar solicitação de assinatura para lojista
   */
  static async createShopkeeperContractSignature(
    shopkeeperId: string,
    shopName: string,
    shopEmail: string,
    cnpj: string
  ): Promise<SignatureDocument> {
    const documentId = `shop-${shopkeeperId}-${Date.now()}`;
    
    const document: SignatureDocument = {
      id: documentId,
      type: "shopkeeper_contract",
      signers: [
        {
          email: shopEmail,
          name: shopName,
          status: "pending",
        },
        {
          email: "admin@plantayraiz.com.br",
          name: "Planta & Raiz Admin",
          status: "pending",
        },
      ],
      status: "pending",
      createdAt: new Date(),
      signatureUrl: `https://clicksign.com/signature/${documentId}`,
    };

    this.documents.set(documentId, document);

    // Simular envio de email com link de assinatura
    await this.sendSignatureEmail(
      shopEmail,
      shopName,
      document.signatureUrl,
      "Contrato de Parceria Comercial"
    );

    return document;
  }

  /**
   * Obter status de assinatura
   */
  static async getSignatureStatus(documentId: string): Promise<SignatureDocument | null> {
    return this.documents.get(documentId) || null;
  }

  /**
   * Marcar documento como assinado
   */
  static async markAsSigned(
    documentId: string,
    signerEmail: string
  ): Promise<SignatureDocument | null> {
    const document = this.documents.get(documentId);
    if (!document) return null;

    // Atualizar status do signatário
    const signer = document.signers.find((s) => s.email === signerEmail);
    if (signer) {
      signer.status = "signed";
    }

    // Verificar se todos assinaram
    const allSigned = document.signers.every((s) => s.status === "signed");
    if (allSigned) {
      document.status = "completed";
      document.completedAt = new Date();
    }

    this.documents.set(documentId, document);
    return document;
  }

  /**
   * Rejeitar documento
   */
  static async rejectSignature(
    documentId: string,
    signerEmail: string
  ): Promise<SignatureDocument | null> {
    const document = this.documents.get(documentId);
    if (!document) return null;

    const signer = document.signers.find((s) => s.email === signerEmail);
    if (signer) {
      signer.status = "rejected";
    }

    document.status = "rejected";
    this.documents.set(documentId, document);
    return document;
  }

  /**
   * Enviar email com link de assinatura
   */
  private static async sendSignatureEmail(
    email: string,
    name: string,
    signatureUrl: string,
    documentType: string
  ): Promise<void> {
    // Simular envio de email
    console.log(`[EMAIL] Enviando link de assinatura para ${name} (${email})`);
    console.log(`[EMAIL] Tipo de documento: ${documentType}`);
    console.log(`[EMAIL] URL: ${signatureUrl}`);
    
    // Em produção, usar serviço de email real (SendGrid, AWS SES, etc.)
  }

  /**
   * Obter todos os documentos pendentes
   */
  static async getPendingDocuments(): Promise<SignatureDocument[]> {
    return Array.from(this.documents.values()).filter(
      (doc) => doc.status === "pending"
    );
  }

  /**
   * Obter estatísticas de assinatura
   */
  static async getSignatureStats(): Promise<{
    total: number;
    pending: number;
    completed: number;
    rejected: number;
  }> {
    const docs = Array.from(this.documents.values());
    return {
      total: docs.length,
      pending: docs.filter((d) => d.status === "pending").length,
      completed: docs.filter((d) => d.status === "completed").length,
      rejected: docs.filter((d) => d.status === "rejected").length,
    };
  }
}
