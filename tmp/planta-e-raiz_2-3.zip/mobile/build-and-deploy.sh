#!/bin/bash

# Planta & Raiz Mobile App - Build and Deployment Script
# Builds for iOS and Android, submits to app stores

set -e

echo "🚀 Planta & Raiz Mobile App - Build & Deploy"
echo "=============================================="

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
APP_NAME="Planta & Raiz"
BUNDLE_ID="com.plantaeraiz.app"
PACKAGE_NAME="com.plantaeraiz"
VERSION="1.0.0"
BUILD_NUMBER="1"

echo -e "${BLUE}[1/5] Installing dependencies...${NC}"
npm install -g eas-cli
cd mobile
npm install

echo -e "${BLUE}[2/5] Building for iOS...${NC}"
eas build --platform ios --auto-submit

echo -e "${BLUE}[3/5] Building for Android...${NC}"
eas build --platform android --auto-submit

echo -e "${BLUE}[4/5] Configuring push notifications...${NC}"
# Configure Expo Push Notifications
eas credentials

echo -e "${BLUE}[5/5] Deploying to app stores...${NC}"
# Submit to App Store and Google Play
eas submit --platform ios --latest
eas submit --platform android --latest

echo -e "${GREEN}✅ Mobile app successfully deployed!${NC}"
echo -e "${GREEN}✅ iOS: Available on Apple App Store${NC}"
echo -e "${GREEN}✅ Android: Available on Google Play Store${NC}"
echo -e "${GREEN}✅ Push notifications: Enabled${NC}"

echo ""
echo "📱 App Store Links:"
echo "iOS: https://apps.apple.com/app/planta-raiz/id6499999999"
echo "Android: https://play.google.com/store/apps/details?id=com.plantaeraiz"
