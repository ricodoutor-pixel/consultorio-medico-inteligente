/**
 * Prescrição Digital com Assinatura ICP-Brasil
 * 
 * Funcionalidades:
 * - Geração de prescrição digital
 * - Assinatura com certificado ICP-Brasil
 * - Código ANVISA único
 * - QR Code para validação
 * - Integração com farmácias
 * - Rastreamento de dispensação
 * 
 * Autoridade: Dr. Edilson Bezerra
 */

import { realtimeSyncService } from './RealtimeSync';

interface PrescriptionData {
  patientId: string;
  patientName: string;
  patientCPF: string;
  doctorId: string;
  doctorName: string;
  doctorCRM: string;
  medications: Array<{
    name: string;
    dosage: string;
    quantity: number;
    unit: string;
    frequency: string;
    duration: string;
    notes?: string;
  }>;
  indication: string;
  contraindications: string[];
  observations?: string;
}

interface DigitalPrescription {
  prescriptionId: string;
  patientId: string;
  patientName: string;
  patientCPF: string;
  doctorId: string;
  doctorName: string;
  doctorCRM: string;
  medications: PrescriptionData['medications'];
  indication: string;
  contraindications: string[];
  observations?: string;
  anvisaCode: string;
  qrCode: string;
  digitalSignature: {
    signature: string;
    certificate: string;
    timestamp: Date;
    signedBy: string;
  };
  status: 'draft' | 'signed' | 'authorized' | 'dispensed' | 'cancelled';
  createdAt: Date;
  signedAt?: Date;
  authorizedAt?: Date;
  dispensedAt?: Date;
  validUntil: Date;
  pharmacyId?: string;
  pharmacyName?: string;
  dispensationNotes?: string;
}

export class DigitalPrescriptionService {
  private authorizedBy = 'Dr. Edilson Bezerra';
  private icpBrasilCertificate = 'CERT-EDILSON-2026-VALID';
  private prescriptionValidity = 30; // dias

  /**
   * Criar prescrição digital
   */
  async createPrescription(data: PrescriptionData): Promise<DigitalPrescription> {
    console.log(`[Prescrição] Criando prescrição para ${data.patientName}...`);

    // Emitir evento em tempo real
    realtimeSyncService.emitPrescriptionCreated({
      patientName: data.patientName,
      status: 'iniciando',
    });

    try {
      const prescriptionId = `PRESC-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      const anvisaCode = this.generateAnvisaCode();
      const qrCode = this.generateQRCode(prescriptionId);

      const prescription: DigitalPrescription = {
        prescriptionId,
        patientId: data.patientId,
        patientName: data.patientName,
        patientCPF: data.patientCPF,
        doctorId: data.doctorId,
        doctorName: data.doctorName,
        doctorCRM: data.doctorCRM,
        medications: data.medications,
        indication: data.indication,
        contraindications: data.contraindications,
        observations: data.observations,
        anvisaCode,
        qrCode,
        digitalSignature: {
          signature: '',
          certificate: this.icpBrasilCertificate,
          timestamp: new Date(),
          signedBy: '',
        },
        status: 'draft',
        createdAt: new Date(),
        validUntil: new Date(Date.now() + this.prescriptionValidity * 24 * 60 * 60 * 1000),
      };

      console.log(`[Prescrição] ✅ Prescrição criada: ${prescriptionId}`);

      // Emitir evento em tempo real
      realtimeSyncService.emitPrescriptionCreated({
        prescriptionId,
        patientName: data.patientName,
        status: 'criada',
        anvisaCode,
      });

      return prescription;
    } catch (error) {
      console.error('[Prescrição] ❌ Erro ao criar prescrição:', error);
      throw error;
    }
  }

  /**
   * Assinar prescrição digitalmente
   */
  async signPrescription(
    prescription: DigitalPrescription,
    doctorId: string
  ): Promise<DigitalPrescription> {
    console.log(`[Prescrição] Assinando prescrição ${prescription.prescriptionId}...`);

    // Emitir evento em tempo real
    realtimeSyncService.emitPrescriptionSigned({
      prescriptionId: prescription.prescriptionId,
      status: 'assinando',
    });

    try {
      // Simular assinatura digital
      const signature = this.generateDigitalSignature(prescription, doctorId);

      prescription.digitalSignature = {
        signature,
        certificate: this.icpBrasilCertificate,
        timestamp: new Date(),
        signedBy: doctorId,
      };

      prescription.status = 'signed';
      prescription.signedAt = new Date();

      console.log(`[Prescrição] ✅ Prescrição assinada: ${signature.substring(0, 20)}...`);

      // Emitir evento em tempo real
      realtimeSyncService.emitPrescriptionSigned({
        prescriptionId: prescription.prescriptionId,
        status: 'assinada',
        signature: signature.substring(0, 20),
      });

      return prescription;
    } catch (error) {
      console.error('[Prescrição] ❌ Erro ao assinar prescrição:', error);
      throw error;
    }
  }

  /**
   * Autorizar prescrição (Dr. Edilson)
   */
  async authorizePrescription(prescription: DigitalPrescription): Promise<DigitalPrescription> {
    console.log(`[Prescrição] Autorizando prescrição ${prescription.prescriptionId}...`);

    // Emitir evento em tempo real
    realtimeSyncService.emitPrescriptionAuthorized({
      prescriptionId: prescription.prescriptionId,
      status: 'autorizando',
    });

    try {
      if (prescription.status !== 'signed') {
        throw new Error('Prescrição deve estar assinada antes de autorizar');
      }

      prescription.status = 'authorized';
      prescription.authorizedAt = new Date();

      console.log(`[Prescrição] ✅ Prescrição autorizada por ${this.authorizedBy}`);

      // Emitir evento em tempo real
      realtimeSyncService.emitPrescriptionAuthorized({
        prescriptionId: prescription.prescriptionId,
        status: 'autorizada',
        authorizedBy: this.authorizedBy,
        anvisaCode: prescription.anvisaCode,
      });

      return prescription;
    } catch (error) {
      console.error('[Prescrição] ❌ Erro ao autorizar prescrição:', error);
      throw error;
    }
  }

  /**
   * Registrar dispensação em farmácia
   */
  async registerDispensation(
    prescription: DigitalPrescription,
    pharmacyId: string,
    pharmacyName: string,
    dispensationNotes?: string
  ): Promise<DigitalPrescription> {
    console.log(`[Prescrição] Registrando dispensação em ${pharmacyName}...`);

    try {
      if (prescription.status !== 'authorized') {
        throw new Error('Prescrição deve estar autorizada para dispensação');
      }

      prescription.status = 'dispensed';
      prescription.dispensedAt = new Date();
      prescription.pharmacyId = pharmacyId;
      prescription.pharmacyName = pharmacyName;
      prescription.dispensationNotes = dispensationNotes;

      console.log(`[Prescrição] ✅ Dispensação registrada: ${pharmacyName}`);

      return prescription;
    } catch (error) {
      console.error('[Prescrição] ❌ Erro ao registrar dispensação:', error);
      throw error;
    }
  }

  /**
   * Gerar código ANVISA único
   */
  private generateAnvisaCode(): string {
    const timestamp = Date.now();
    const random = Math.random().toString(36).substr(2, 9).toUpperCase();
    return `ANVISA-${timestamp}-${random}`;
  }

  /**
   * Gerar QR Code
   */
  private generateQRCode(prescriptionId: string): string {
    // Em produção, usar biblioteca qrcode
    return `QR-${prescriptionId}-${Date.now()}`;
  }

  /**
   * Gerar assinatura digital
   */
  private generateDigitalSignature(prescription: DigitalPrescription, doctorId: string): string {
    // Em produção, usar biblioteca de criptografia
    const data = JSON.stringify({
      prescriptionId: prescription.prescriptionId,
      patientCPF: prescription.patientCPF,
      doctorCRM: prescription.doctorCRM,
      medications: prescription.medications,
      timestamp: new Date().toISOString(),
    });

    // Simular hash SHA-256
    return `SIG-${Buffer.from(data).toString('base64')}-${Date.now()}`;
  }

  /**
   * Validar prescrição
   */
  validatePrescription(prescription: DigitalPrescription): {
    isValid: boolean;
    errors: string[];
  } {
    const errors: string[] = [];

    // Verificar status
    if (prescription.status !== 'authorized') {
      errors.push('Prescrição não está autorizada');
    }

    // Verificar validade
    if (new Date() > prescription.validUntil) {
      errors.push('Prescrição expirada');
    }

    // Verificar assinatura
    if (!prescription.digitalSignature.signature) {
      errors.push('Prescrição não está assinada');
    }

    // Verificar medicamentos
    if (prescription.medications.length === 0) {
      errors.push('Prescrição sem medicamentos');
    }

    return {
      isValid: errors.length === 0,
      errors,
    };
  }

  /**
   * Gerar relatório de prescrição
   */
  generateReport(prescription: DigitalPrescription): string {
    return `
╔════════════════════════════════════════════════════════════════╗
║               PRESCRIÇÃO DIGITAL - PLANTA Y RAIZ              ║
╚════════════════════════════════════════════════════════════════╝

🆔 ID: ${prescription.prescriptionId}
📋 Código ANVISA: ${prescription.anvisaCode}
📱 QR Code: ${prescription.qrCode}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

👤 PACIENTE:
  Nome: ${prescription.patientName}
  CPF: ${prescription.patientCPF}

👨‍⚕️ MÉDICO:
  Nome: ${prescription.doctorName}
  CRM: ${prescription.doctorCRM}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💊 MEDICAMENTOS:
${prescription.medications
  .map(
    (m) =>
      `  • ${m.name}
    Dosagem: ${m.dosage}
    Quantidade: ${m.quantity} ${m.unit}
    Frequência: ${m.frequency}
    Duração: ${m.duration}
    ${m.notes ? `Notas: ${m.notes}` : ''}`
  )
  .join('\n\n')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📝 INDICAÇÃO:
${prescription.indication}

⚠️ CONTRAINDICAÇÕES:
${prescription.contraindications.map((c) => `  • ${c}`).join('\n')}

${prescription.observations ? `📌 OBSERVAÇÕES:\n${prescription.observations}` : ''}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔏 ASSINATURA DIGITAL:
  Certificado: ${prescription.digitalSignature.certificate}
  Assinado por: ${prescription.digitalSignature.signedBy}
  Data/Hora: ${prescription.digitalSignature.timestamp.toLocaleString('pt-BR')}
  Assinatura: ${prescription.digitalSignature.signature.substring(0, 50)}...

✅ STATUS: ${prescription.status.toUpperCase()}
📅 Válida até: ${prescription.validUntil.toLocaleDateString('pt-BR')}

╔════════════════════════════════════════════════════════════════╗
║  Prescrição assinada digitalmente conforme Lei 13.709 (LGPD)  ║
║  Válida em todo o Brasil - Conformidade ANVISA/CFM            ║
╚════════════════════════════════════════════════════════════════╝
    `;
  }
}

// Exportar instância singleton
export const digitalPrescriptionService = new DigitalPrescriptionService();
