import React, { useState, useEffect } from "react";
import {
  LogOut,
  Clock,
  Users,
  DollarSign,
  Star,
  Activity,
  MessageSquare,
  Video,
  ToggleRight,
  ToggleLeft,
  TrendingUp,
  Calendar,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import BLISS_COLORS from "@/styles/bliss-colors";

export default function SpecialistDashboard() {
  const [isOnline, setIsOnline] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Mock data
  const specialist = {
    name: "Dr. João Silva",
    specialty: "Neurologia",
    avatar: "👨‍⚕️",
    crm: "123456/SP",
    rating: 4.9,
    totalConsultations: 342,
  };

  const stats = {
    todayConsultations: 5,
    thisMonthConsultations: 47,
    thisMonthEarnings: 5640,
    pendingPayment: 564,
    averageRating: 4.9,
  };

  const activeSessions = [
    {
      id: 1,
      patientName: "João Silva",
      sessionType: "chat",
      startedAt: new Date(Date.now() - 15 * 60 * 1000),
      duration: 15,
    },
    {
      id: 2,
      patientName: "Maria Santos",
      sessionType: "video",
      startedAt: new Date(Date.now() - 5 * 60 * 1000),
      duration: 5,
    },
  ];

  const upcomingConsultations = [
    {
      id: 1,
      patientName: "Pedro Costa",
      scheduledAt: new Date(Date.now() + 30 * 60 * 1000),
      type: "video",
      consultationPrice: 120,
    },
    {
      id: 2,
      patientName: "Ana Silva",
      scheduledAt: new Date(Date.now() + 90 * 60 * 1000),
      type: "chat",
      consultationPrice: 100,
    },
  ];

  const monthlyEarnings = [
    { day: "1-5", earnings: 600 },
    { day: "6-10", earnings: 1200 },
    { day: "11-15", earnings: 1100 },
    { day: "16-20", earnings: 1300 },
    { day: "21-25", earnings: 1000 },
    { day: "26-31", earnings: 440 },
  ];

  const toggleOnlineStatus = () => {
    setIsOnline(!isOnline);
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: BLISS_COLORS.gray[50] }}>
      {/* Header with Online Status */}
      <div className="sticky top-0 z-40 bg-white border-b" style={{ borderColor: BLISS_COLORS.primary[200] }}>
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className="text-5xl">{specialist.avatar}</div>
              <div>
                <h1 className="text-3xl font-bold" style={{ color: BLISS_COLORS.primary[700] }}>
                  {specialist.name}
                </h1>
                <p className="text-gray-600">{specialist.specialty} • CRM: {specialist.crm}</p>
              </div>
            </div>

            {/* Online Status Toggle */}
            <div className="flex flex-col items-end gap-2">
              <button
                onClick={toggleOnlineStatus}
                className="flex items-center gap-3 px-6 py-3 rounded-lg border-2 font-bold transition"
                style={{
                  borderColor: isOnline ? "#10b981" : "#ef4444",
                  backgroundColor: isOnline ? "#d1fae5" : "#fee2e2",
                  color: isOnline ? "#065f46" : "#7f1d1d",
                }}
              >
                {isOnline ? (
                  <>
                    <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse"></div>
                    <ToggleRight className="w-5 h-5" />
                    Online
                  </>
                ) : (
                  <>
                    <div className="w-3 h-3 rounded-full bg-gray-400"></div>
                    <ToggleLeft className="w-5 h-5" />
                    Offline
                  </>
                )}
              </button>
              <p className="text-xs text-gray-600">{currentTime.toLocaleTimeString("pt-BR")}</p>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {[
              {
                label: "Hoje",
                value: stats.todayConsultations,
                icon: <Calendar className="w-4 h-4" />,
              },
              {
                label: "Este Mês",
                value: stats.thisMonthConsultations,
                icon: <Users className="w-4 h-4" />,
              },
              {
                label: "Ganhos",
                value: `R$ ${stats.thisMonthEarnings}`,
                icon: <DollarSign className="w-4 h-4" />,
              },
              {
                label: "Pendente",
                value: `R$ ${stats.pendingPayment}`,
                icon: <Clock className="w-4 h-4" />,
              },
              {
                label: "Rating",
                value: `${stats.averageRating}⭐`,
                icon: <Star className="w-4 h-4" />,
              },
            ].map((stat, idx) => (
              <div
                key={idx}
                className="p-3 rounded-lg text-center text-sm"
                style={{ backgroundColor: BLISS_COLORS.primary[50] }}
              >
                <p className="text-gray-600 mb-1">{stat.label}</p>
                <p className="font-bold" style={{ color: BLISS_COLORS.primary[700] }}>
                  {stat.value}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Active Sessions */}
            <div className="bg-white rounded-lg border p-6" style={{ borderColor: BLISS_COLORS.primary[200] }}>
              <div className="flex items-center gap-2 mb-4">
                <Activity className="w-5 h-5" style={{ color: BLISS_COLORS.primary[500] }} />
                <h2 className="text-xl font-bold" style={{ color: BLISS_COLORS.primary[700] }}>
                  Sessões Ativas ({activeSessions.length}/5)
                </h2>
              </div>

              {activeSessions.length > 0 ? (
                <div className="space-y-3">
                  {activeSessions.map((session) => (
                    <div
                      key={session.id}
                      className="flex items-center justify-between p-4 rounded-lg border"
                      style={{ borderColor: BLISS_COLORS.primary[100] }}
                    >
                      <div className="flex items-center gap-4 flex-1">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-green-400 to-blue-500 flex items-center justify-center text-white font-bold">
                          {session.patientName.charAt(0)}
                        </div>
                        <div>
                          <p className="font-bold" style={{ color: BLISS_COLORS.primary[700] }}>
                            {session.patientName}
                          </p>
                          <p className="text-xs text-gray-600 flex items-center gap-1">
                            {session.sessionType === "chat" ? (
                              <>
                                <MessageSquare className="w-3 h-3" /> Chat
                              </>
                            ) : (
                              <>
                                <Video className="w-3 h-3" /> Vídeo
                              </>
                            )}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-sm" style={{ color: BLISS_COLORS.primary[700] }}>
                          {session.duration} min
                        </p>
                        <p className="text-xs text-gray-600">em andamento</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center text-gray-600 py-8">Nenhuma sessão ativa no momento</p>
              )}
            </div>

            {/* Upcoming Consultations */}
            <div className="bg-white rounded-lg border p-6" style={{ borderColor: BLISS_COLORS.primary[200] }}>
              <h2 className="text-xl font-bold mb-4" style={{ color: BLISS_COLORS.primary[700] }}>
                📅 Próximas Consultas
              </h2>

              <div className="space-y-3">
                {upcomingConsultations.map((consultation) => (
                  <div
                    key={consultation.id}
                    className="flex items-center justify-between p-4 rounded-lg border"
                    style={{ borderColor: BLISS_COLORS.primary[100] }}
                  >
                    <div className="flex-1">
                      <p className="font-bold" style={{ color: BLISS_COLORS.primary[700] }}>
                        {consultation.patientName}
                      </p>
                      <p className="text-sm text-gray-600">
                        {consultation.scheduledAt.toLocaleTimeString("pt-BR", {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold" style={{ color: "#10b981" }}>
                        R$ {consultation.consultationPrice}
                      </p>
                      <p className="text-xs text-gray-600">
                        {consultation.type === "video" ? "📹 Vídeo" : "💬 Chat"}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Monthly Earnings Chart */}
            <div className="bg-white rounded-lg border p-6" style={{ borderColor: BLISS_COLORS.primary[200] }}>
              <div className="flex items-center gap-2 mb-4">
                <TrendingUp className="w-5 h-5" style={{ color: BLISS_COLORS.primary[500] }} />
                <h2 className="text-xl font-bold" style={{ color: BLISS_COLORS.primary[700] }}>
                  Ganhos Este Mês
                </h2>
              </div>

              <div className="flex items-end gap-2 h-32">
                {monthlyEarnings.map((data, idx) => (
                  <div key={idx} className="flex-1 flex flex-col items-center">
                    <div className="text-xs text-gray-600 mb-2">R$ {data.earnings}</div>
                    <div
                      className="w-full rounded-t transition hover:opacity-80"
                      style={{
                        backgroundColor: BLISS_COLORS.primary[500],
                        height: `${(data.earnings / 1300) * 100}%`,
                      }}
                    ></div>
                    <div className="text-xs text-gray-600 mt-2">{data.day}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Wallet */}
            <div className="bg-white rounded-lg border p-6" style={{ borderColor: BLISS_COLORS.primary[200] }}>
              <h3 className="font-bold mb-4" style={{ color: BLISS_COLORS.primary[700] }}>
                💰 Carteira
              </h3>

              <div className="space-y-3 mb-4">
                <div>
                  <p className="text-xs text-gray-600 mb-1">Disponível</p>
                  <p className="text-2xl font-bold" style={{ color: "#10b981" }}>
                    R$ {stats.pendingPayment}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-600 mb-1">Total Ganho</p>
                  <p className="text-lg font-bold" style={{ color: BLISS_COLORS.primary[700] }}>
                    R$ {stats.thisMonthEarnings + 2000}
                  </p>
                </div>
              </div>

              <Button
                className="w-full py-2 rounded-lg text-white font-bold"
                style={{ backgroundColor: BLISS_COLORS.primary[500] }}
              >
                Sacar via PIX
              </Button>
            </div>

            {/* Performance */}
            <div className="bg-white rounded-lg border p-6" style={{ borderColor: BLISS_COLORS.primary[200] }}>
              <h3 className="font-bold mb-4" style={{ color: BLISS_COLORS.primary[700] }}>
                📊 Performance
              </h3>

              <div className="space-y-3">
                <div>
                  <div className="flex justify-between mb-1">
                    <p className="text-sm text-gray-600">Taxa de Conclusão</p>
                    <p className="text-sm font-bold">98%</p>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="h-2 rounded-full"
                      style={{ backgroundColor: BLISS_COLORS.primary[500], width: "98%" }}
                    ></div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-1">
                    <p className="text-sm text-gray-600">Satisfação</p>
                    <p className="text-sm font-bold">4.9/5</p>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="h-2 rounded-full"
                      style={{ backgroundColor: BLISS_COLORS.accent[500], width: "98%" }}
                    ></div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-1">
                    <p className="text-sm text-gray-600">Disponibilidade</p>
                    <p className="text-sm font-bold">95%</p>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="h-2 rounded-full"
                      style={{ backgroundColor: "#10b981", width: "95%" }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-lg border p-6" style={{ borderColor: BLISS_COLORS.primary[200] }}>
              <h3 className="font-bold mb-4" style={{ color: BLISS_COLORS.primary[700] }}>
                Ações Rápidas
              </h3>

              <div className="space-y-2">
                <Button className="w-full py-2 rounded-lg border" style={{ borderColor: BLISS_COLORS.primary[200], color: BLISS_COLORS.primary[600] }}>
                  Editar Perfil
                </Button>
                <Button className="w-full py-2 rounded-lg border" style={{ borderColor: BLISS_COLORS.primary[200], color: BLISS_COLORS.primary[600] }}>
                  Gerenciar Horários
                </Button>
                <Button className="w-full py-2 rounded-lg border flex items-center justify-center gap-2" style={{ borderColor: "#ef4444", color: "#ef4444" }}>
                  <LogOut className="w-4 h-4" />
                  Sair
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
