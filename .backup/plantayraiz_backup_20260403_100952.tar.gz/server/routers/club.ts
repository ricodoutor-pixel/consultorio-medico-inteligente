import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import { db } from "../db";
import { clubPosts, clubPostComments, clubPostLikes, clubPostCommentLikes, clubNotifications, users } from "../../drizzle/schema";
import { eq, and, desc, sql } from "drizzle-orm";

export const clubRouter = router({
  getPosts: publicProcedure
    .input(z.object({ limit: z.number().default(10), offset: z.number().default(0) }).optional())
    .query(async ({ input }) => {
      const limit = input?.limit || 10;
      const offset = input?.offset || 0;
      const posts = await db.select().from(clubPosts).where(eq(clubPosts.status, "active")).orderBy(desc(clubPosts.createdAt)).limit(limit).offset(offset);
      return posts;
    }),

  getComments: publicProcedure
    .input(z.object({ postId: z.number(), limit: z.number().default(20), offset: z.number().default(0) }))
    .query(async ({ input }) => {
      const comments = await db.select().from(clubPostComments).where(and(eq(clubPostComments.postId, input.postId), eq(clubPostComments.status, "active"))).orderBy(desc(clubPostComments.createdAt)).limit(input.limit).offset(input.offset);
      return comments;
    }),

  addComment: protectedProcedure
    .input(z.object({ postId: z.number(), content: z.string().min(1).max(1000) }))
    .mutation(async ({ input, ctx }) => {
      const userId = ctx.user?.id;
      if (!userId) throw new Error("User not authenticated");
      
      // Get post details
      const post = await db.select().from(clubPosts).where(eq(clubPosts.id, input.postId));
      if (post.length === 0) throw new Error("Post not found");
      
      const result = await db.insert(clubPostComments).values({
        postId: input.postId,
        userId,
        content: input.content,
        likes: 0,
        status: "active",
      });
      
      await db.update(clubPosts).set({ commentCount: sql`${clubPosts.commentCount} + 1` }).where(eq(clubPosts.id, input.postId));
      
      // Create notification for post author
      if (post[0].userId !== userId) {
        const currentUser = await db.select().from(users).where(eq(users.id, userId));
        const userName = currentUser[0]?.name || "Usuário";
        
        await db.insert(clubNotifications).values({
          userId: post[0].userId,
          postId: input.postId,
          triggeredByUserId: userId,
          type: "comment",
          title: "Novo comentário",
          message: `${userName} comentou no seu post`,
          actionUrl: `/club?post=${input.postId}`,
          isRead: 0,
        });
      }
      
      return { success: true, commentId: result.insertId };
    }),

  likePost: protectedProcedure
    .input(z.object({ postId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const userId = ctx.user?.id;
      if (!userId) throw new Error("User not authenticated");
      
      const post = await db.select().from(clubPosts).where(eq(clubPosts.id, input.postId));
      if (post.length === 0) throw new Error("Post not found");
      
      const existing = await db.select().from(clubPostLikes).where(and(eq(clubPostLikes.postId, input.postId), eq(clubPostLikes.userId, userId)));
      if (existing.length > 0) {
        await db.delete(clubPostLikes).where(and(eq(clubPostLikes.postId, input.postId), eq(clubPostLikes.userId, userId)));
        await db.update(clubPosts).set({ likes: sql`${clubPosts.likes} - 1` }).where(eq(clubPosts.id, input.postId));
        return { success: true, liked: false };
      } else {
        await db.insert(clubPostLikes).values({ postId: input.postId, userId });
        await db.update(clubPosts).set({ likes: sql`${clubPosts.likes} + 1` }).where(eq(clubPosts.id, input.postId));
        
        // Create notification for post author
        if (post[0].userId !== userId) {
          const currentUser = await db.select().from(users).where(eq(users.id, userId));
          const userName = currentUser[0]?.name || "Usuário";
          
          await db.insert(clubNotifications).values({
            userId: post[0].userId,
            postId: input.postId,
            triggeredByUserId: userId,
            type: "like",
            title: "Novo curtida",
            message: `${userName} curtiu seu post`,
            actionUrl: `/club?post=${input.postId}`,
            isRead: 0,
          });
        }
        
        return { success: true, liked: true };
      }
    }),

  likeComment: protectedProcedure
    .input(z.object({ commentId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const userId = ctx.user?.id;
      if (!userId) throw new Error("User not authenticated");
      const existing = await db.select().from(clubPostCommentLikes).where(and(eq(clubPostCommentLikes.commentId, input.commentId), eq(clubPostCommentLikes.userId, userId)));
      if (existing.length > 0) {
        await db.delete(clubPostCommentLikes).where(and(eq(clubPostCommentLikes.commentId, input.commentId), eq(clubPostCommentLikes.userId, userId)));
        await db.update(clubPostComments).set({ likes: sql`${clubPostComments.likes} - 1` }).where(eq(clubPostComments.id, input.commentId));
        return { success: true, liked: false };
      } else {
        await db.insert(clubPostCommentLikes).values({ commentId: input.commentId, userId });
        await db.update(clubPostComments).set({ likes: sql`${clubPostComments.likes} + 1` }).where(eq(clubPostComments.id, input.commentId));
        return { success: true, liked: true };
      }
    }),

  deleteComment: protectedProcedure
    .input(z.object({ commentId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const userId = ctx.user?.id;
      if (!userId) throw new Error("User not authenticated");
      const comment = await db.select().from(clubPostComments).where(eq(clubPostComments.id, input.commentId));
      if (comment.length === 0) throw new Error("Comment not found");
      if (comment[0].userId !== userId && ctx.user?.role !== "admin") throw new Error("Not authorized");
      await db.update(clubPostComments).set({ status: "deleted" }).where(eq(clubPostComments.id, input.commentId));
      await db.update(clubPosts).set({ commentCount: sql`${clubPosts.commentCount} - 1` }).where(eq(clubPosts.id, comment[0].postId));
      return { success: true };
    }),

  createPost: protectedProcedure
    .input(z.object({ content: z.string().min(1).max(2000), images: z.array(z.string()).min(1) }))
    .mutation(async ({ input, ctx }) => {
      const userId = ctx.user?.id;
      if (!userId) throw new Error("User not authenticated");
      const result = await db.insert(clubPosts).values({
        userId,
        content: input.content,
        images: JSON.stringify(input.images),
        likes: 0,
        commentCount: 0,
        shareCount: 0,
        status: "active",
      });
      return { success: true, postId: result.insertId };
    }),
});
