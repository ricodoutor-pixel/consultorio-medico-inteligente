import { router, protectedProcedure, publicProcedure } from '../_core/trpc';
import { z } from 'zod';
import { DoctorNetworkService } from '../services/DoctorNetworkService';
import { MatchingService } from '../services/MatchingService';

export const doctorNetworkRouter = router({
  // Doctor Network endpoints
  goOnline: protectedProcedure
    .input(z.object({ doctorId: z.string() }))
    .mutation(async ({ input }) => {
      try {
        const success = DoctorNetworkService.goOnline(input.doctorId);
        return {
          success,
          message: success ? 'Médico online' : 'Médico não encontrado',
        };
      } catch (error) {
        console.error('[doctorNetwork] goOnline error:', error);
        return { success: false, message: 'Erro ao conectar' };
      }
    }),

  goOffline: protectedProcedure
    .input(z.object({ doctorId: z.string() }))
    .mutation(async ({ input }) => {
      try {
        const success = DoctorNetworkService.goOffline(input.doctorId);
        return {
          success,
          message: success ? 'Médico offline' : 'Médico não encontrado',
        };
      } catch (error) {
        console.error('[doctorNetwork] goOffline error:', error);
        return { success: false, message: 'Erro ao desconectar' };
      }
    }),

  getOnlineDoctors: publicProcedure
    .input(
      z.object({
        specialty: z.string().optional(),
        country: z.string().optional(),
      })
    )
    .query(async ({ input }) => {
      try {
        let doctors: any[] = [];

        if (input.specialty) {
          doctors = DoctorNetworkService.getOnlineDoctorsBySpecialty(input.specialty);
        } else if (input.country) {
          doctors = DoctorNetworkService.getOnlineDoctorsByCountry(input.country);
        } else {
          doctors = DoctorNetworkService.getAllOnlineDoctors();
        }

        return {
          success: true,
          data: doctors,
          count: doctors.length,
        };
      } catch (error) {
        console.error('[doctorNetwork] getOnlineDoctors error:', error);
        return { success: false, data: [], count: 0 };
      }
    }),

  getDoctorStatus: publicProcedure
    .input(z.object({ doctorId: z.string() }))
    .query(async ({ input }) => {
      try {
        const status = DoctorNetworkService.getDoctorStatus(input.doctorId);
        return {
          success: !!status,
          data: status,
        };
      } catch (error) {
        console.error('[doctorNetwork] getDoctorStatus error:', error);
        return { success: false, data: null };
      }
    }),

  getDoctorInfo: publicProcedure
    .input(z.object({ doctorId: z.string() }))
    .query(async ({ input }) => {
      try {
        const doctor = DoctorNetworkService.getDoctorInfo(input.doctorId);
        return {
          success: !!doctor,
          data: doctor,
        };
      } catch (error) {
        console.error('[doctorNetwork] getDoctorInfo error:', error);
        return { success: false, data: null };
      }
    }),

  getNetworkStats: publicProcedure.query(async () => {
    try {
      const stats = DoctorNetworkService.getNetworkStats();
      return { success: true, data: stats };
    } catch (error) {
      console.error('[doctorNetwork] getNetworkStats error:', error);
      return { success: false, data: null };
    }
  }),

  searchDoctors: publicProcedure
    .input(
      z.object({
        specialty: z.string().optional(),
        country: z.string().optional(),
        state: z.string().optional(),
        minScore: z.number().optional(),
        onlineOnly: z.boolean().optional(),
      })
    )
    .query(async ({ input }) => {
      try {
        const doctors = DoctorNetworkService.searchDoctors(input);
        return {
          success: true,
          data: doctors,
          count: doctors.length,
        };
      } catch (error) {
        console.error('[doctorNetwork] searchDoctors error:', error);
        return { success: false, data: [], count: 0 };
      }
    }),

  // Matching endpoints
  createMatchRequest: protectedProcedure
    .input(
      z.object({
        patientId: z.string(),
        patientName: z.string(),
        specialty: z.string(),
        country: z.string(),
        state: z.string().optional(),
        preferredLanguage: z.string().optional(),
        urgency: z.enum(['low', 'medium', 'high', 'emergency']),
        budget: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const matchRequest = MatchingService.createMatchRequest(input);
        return {
          success: true,
          data: matchRequest,
        };
      } catch (error) {
        console.error('[doctorNetwork] createMatchRequest error:', error);
        return { success: false, data: null };
      }
    }),

  findBestMatch: protectedProcedure
    .input(z.object({ matchRequestId: z.string() }))
    .mutation(async ({ input }) => {
      try {
        const matchResult = MatchingService.findBestMatch(input.matchRequestId);
        return {
          success: !!matchResult,
          data: matchResult,
          message: matchResult ? 'Match encontrado' : 'Nenhum médico disponível',
        };
      } catch (error) {
        console.error('[doctorNetwork] findBestMatch error:', error);
        return { success: false, data: null, message: 'Erro ao encontrar match' };
      }
    }),

  acceptMatch: protectedProcedure
    .input(z.object({ matchId: z.string() }))
    .mutation(async ({ input }) => {
      try {
        const success = MatchingService.acceptMatch(input.matchId);
        return {
          success,
          message: success ? 'Match aceito' : 'Match não encontrado',
        };
      } catch (error) {
        console.error('[doctorNetwork] acceptMatch error:', error);
        return { success: false, message: 'Erro ao aceitar match' };
      }
    }),

  rejectMatch: protectedProcedure
    .input(z.object({ matchId: z.string() }))
    .mutation(async ({ input }) => {
      try {
        const success = MatchingService.rejectMatch(input.matchId);
        return {
          success,
          message: success ? 'Match rejeitado' : 'Match não encontrado',
        };
      } catch (error) {
        console.error('[doctorNetwork] rejectMatch error:', error);
        return { success: false, message: 'Erro ao rejeitar match' };
      }
    }),

  completeMatch: protectedProcedure
    .input(
      z.object({
        matchId: z.string(),
        doctorRating: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const success = MatchingService.completeMatch(input.matchId, input.doctorRating);
        return {
          success,
          message: success ? 'Match completado' : 'Match não encontrado',
        };
      } catch (error) {
        console.error('[doctorNetwork] completeMatch error:', error);
        return { success: false, message: 'Erro ao completar match' };
      }
    }),

  getMatchHistory: publicProcedure
    .input(z.object({ limit: z.number().default(100) }))
    .query(async ({ input }) => {
      try {
        const history = MatchingService.getMatchHistory(input.limit);
        return {
          success: true,
          data: history,
          count: history.length,
        };
      } catch (error) {
        console.error('[doctorNetwork] getMatchHistory error:', error);
        return { success: false, data: [], count: 0 };
      }
    }),

  getMatchingStats: publicProcedure.query(async () => {
    try {
      const stats = MatchingService.getMatchingStats();
      return { success: true, data: stats };
    } catch (error) {
      console.error('[doctorNetwork] getMatchingStats error:', error);
      return { success: false, data: null };
    }
  }),
});
