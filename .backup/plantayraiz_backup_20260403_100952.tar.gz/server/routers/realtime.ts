/**
 * Realtime Router - Sincronização em Tempo Real
 * 
 * Endpoints para receber atualizações em tempo real:
 * - Triagem Brisa IA
 * - Prescrição Digital
 * - Pagamento Mercado Pago
 * - Alertas WhatsApp
 * - Status de Consulta
 */

import { protectedProcedure, publicProcedure, router } from '../_core/trpc';
import { z } from 'zod';
import { realtimeSyncService } from '../services/RealtimeSync';
import { mercadoPagoWebhookService } from '../services/MercadoPagoWebhook';
import { digitalPrescriptionService } from '../services/DigitalPrescriptionService';

export const realtimeRouter = router({
  /**
   * Inscrever em eventos em tempo real
   */
  subscribe: publicProcedure
    .input(z.object({ eventType: z.string() }))
    .subscription(({ input }) => {
      console.log(`[Realtime] Cliente inscrito em: ${input.eventType}`);

      // Retornar observable que emite eventos
      return new Promise((resolve) => {
        const unsubscribe = realtimeSyncService.subscribe(input.eventType, (event) => {
          console.log(`[Realtime] Emitindo evento para cliente: ${event.type}`);
          resolve(event);
        });

        // Limpar inscrição quando cliente desconectar
        return () => unsubscribe();
      });
    }),

  /**
   * Obter histórico de eventos
   */
  getEventHistory: publicProcedure
    .input(z.object({ limit: z.number().optional() }))
    .query(({ input }) => {
      const history = realtimeSyncService.getEventHistory(input.limit || 100);
      return { events: history, count: history.length };
    }),

  /**
   * Obter estatísticas em tempo real
   */
  getStats: publicProcedure.query(() => {
    const stats = realtimeSyncService.getStats();
    return stats;
  }),

  /**
   * Webhook Mercado Pago
   */
  mercadoPagoWebhook: publicProcedure
    .input(
      z.object({
        id: z.string(),
        type: z.string(),
        action: z.string(),
        data: z.object({ id: z.string() }),
      })
    )
    .mutation(async ({ input }) => {
      console.log(`[Realtime] Webhook Mercado Pago recebido: ${input.action}`);

      try {
        await mercadoPagoWebhookService.processWebhook(input as any);

        return {
          success: true,
          message: 'Webhook processado com sucesso',
        };
      } catch (error) {
        console.error('[Realtime] Erro ao processar webhook:', error);
        return {
          success: false,
          error: String(error),
        };
      }
    }),

  /**
   * Obter status de pagamento
   */
  getPaymentStatus: publicProcedure
    .input(z.object({ paymentId: z.string() }))
    .query(({ input }) => {
      const payment = mercadoPagoWebhookService.getPayment(input.paymentId);

      if (!payment) {
        return { found: false };
      }

      return {
        found: true,
        paymentId: payment.paymentId,
        status: payment.status,
        amount: payment.amount,
        currency: payment.currency,
        createdAt: payment.createdAt,
        approvedAt: payment.approvedAt,
      };
    }),

  /**
   * Listar pagamentos recentes
   */
  listRecentPayments: publicProcedure
    .input(z.object({ limit: z.number().optional() }))
    .query(({ input }) => {
      const payments = mercadoPagoWebhookService.listPayments(input.limit || 50);

      return {
        payments: payments.map((p) => ({
          paymentId: p.paymentId,
          status: p.status,
          amount: p.amount,
          currency: p.currency,
          createdAt: p.createdAt,
        })),
        count: payments.length,
      };
    }),

  /**
   * Obter relatório de pagamentos
   */
  getPaymentReport: publicProcedure.query(() => {
    const report = mercadoPagoWebhookService.generateReport();
    return { report };
  }),

  /**
   * Criar prescrição digital
   */
  createPrescription: protectedProcedure
    .input(
      z.object({
        patientId: z.string(),
        patientName: z.string(),
        patientCPF: z.string(),
        doctorId: z.string(),
        doctorName: z.string(),
        doctorCRM: z.string(),
        medications: z.array(
          z.object({
            name: z.string(),
            dosage: z.string(),
            quantity: z.number(),
            unit: z.string(),
            frequency: z.string(),
            duration: z.string(),
            notes: z.string().optional(),
          })
        ),
        indication: z.string(),
        contraindications: z.array(z.string()),
        observations: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      console.log(`[Realtime] Criando prescrição para ${input.patientName}`);

      try {
        const prescription = await digitalPrescriptionService.createPrescription({
          patientId: input.patientId,
          patientName: input.patientName,
          patientCPF: input.patientCPF,
          doctorId: input.doctorId,
          doctorName: input.doctorName,
          doctorCRM: input.doctorCRM,
          medications: input.medications,
          indication: input.indication,
          contraindications: input.contraindications,
          observations: input.observations,
        });

        return {
          success: true,
          prescriptionId: prescription.prescriptionId,
          anvisaCode: prescription.anvisaCode,
          qrCode: prescription.qrCode,
        };
      } catch (error) {
        console.error('[Realtime] Erro ao criar prescrição:', error);
        return {
          success: false,
          error: String(error),
        };
      }
    }),

  /**
   * Assinar prescrição
   */
  signPrescription: protectedProcedure
    .input(
      z.object({
        prescriptionId: z.string(),
        doctorId: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      console.log(`[Realtime] Assinando prescrição: ${input.prescriptionId}`);

      try {
        // Em produção, buscar prescrição do banco de dados
        return {
          success: true,
          message: 'Prescrição assinada com sucesso',
          prescriptionId: input.prescriptionId,
        };
      } catch (error) {
        console.error('[Realtime] Erro ao assinar prescrição:', error);
        return {
          success: false,
          error: String(error),
        };
      }
    }),

  /**
   * Autorizar prescrição (Dr. Edilson)
   */
  authorizePrescription: protectedProcedure
    .input(z.object({ prescriptionId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      console.log(`[Realtime] Autorizando prescrição: ${input.prescriptionId}`);

      try {
        // Verificar se é Dr. Edilson
        if (ctx.user.id !== 'DR-EDILSON-001') {
          return {
            success: false,
            error: 'Apenas Dr. Edilson pode autorizar prescrições',
          };
        }

        return {
          success: true,
          message: 'Prescrição autorizada com sucesso',
          prescriptionId: input.prescriptionId,
          authorizedBy: 'Dr. Edilson Bezerra',
        };
      } catch (error) {
        console.error('[Realtime] Erro ao autorizar prescrição:', error);
        return {
          success: false,
          error: String(error),
        };
      }
    }),

  /**
   * Limpar histórico de eventos
   */
  clearEventHistory: protectedProcedure.mutation(({ ctx }) => {
    // Apenas admin pode limpar
    if (ctx.user.role !== 'admin') {
      return {
        success: false,
        error: 'Apenas administradores podem limpar histórico',
      };
    }

    realtimeSyncService.clearHistory();

    return {
      success: true,
      message: 'Histórico de eventos limpo com sucesso',
    };
  }),
});
