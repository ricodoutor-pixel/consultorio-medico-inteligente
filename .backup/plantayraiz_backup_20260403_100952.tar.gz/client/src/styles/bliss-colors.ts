/**
 * Bliss Cannabis Color Palette
 * DNA Visual: Verde Medicinal + Branco Puro + Preto Profissional
 */

export const BLISS_COLORS = {
  // Primary - Verde Medicinal (Bliss Cannabis)
  primary: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e", // Main Green (Bliss)
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#145231",
  },

  // Secondary - Verde Escuro (Profissionalismo)
  secondary: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
  },

  // Accent - Ouro/Amarelo (Destaque)
  accent: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b", // Accent Gold
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
  },

  // Status Colors
  success: "#22c55e",
  warning: "#f59e0b",
  error: "#ef4444",
  info: "#3b82f6",

  // Neutral
  white: "#ffffff",
  black: "#000000",
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
  },

  // Bliss Gradients
  gradients: {
    primary: "linear-gradient(135deg, #22c55e 0%, #16a34a 100%)",
    accent: "linear-gradient(135deg, #f59e0b 0%, #d97706 100%)",
    dark: "linear-gradient(135deg, #1e293b 0%, #0f172a 100%)",
    light: "linear-gradient(135deg, #f0fdf4 0%, #f8fafc 100%)",
  },

  // Background Variants
  bg: {
    light: "#f9fafb",
    default: "#ffffff",
    dark: "#1f2937",
    darker: "#111827",
    bliss: "#f0fdf4", // Light green
  },

  // Text Variants
  text: {
    primary: "#111827",
    secondary: "#4b5563",
    tertiary: "#9ca3af",
    light: "#ffffff",
    bliss: "#15803d", // Dark green
  },

  // Border Colors
  border: {
    light: "#e5e7eb",
    default: "#d1d5db",
    dark: "#4b5563",
    bliss: "#22c55e",
  },
};

/**
 * CSS Variables for Tailwind Integration
 * Add to client/src/index.css @layer base
 */
export const generateCSSVariables = () => `
  :root {
    /* Primary Colors */
    --color-primary-50: ${BLISS_COLORS.primary[50]};
    --color-primary-500: ${BLISS_COLORS.primary[500]};
    --color-primary-600: ${BLISS_COLORS.primary[600]};
    --color-primary-700: ${BLISS_COLORS.primary[700]};

    /* Accent Colors */
    --color-accent-500: ${BLISS_COLORS.accent[500]};
    --color-accent-600: ${BLISS_COLORS.accent[600]};

    /* Status */
    --color-success: ${BLISS_COLORS.success};
    --color-warning: ${BLISS_COLORS.warning};
    --color-error: ${BLISS_COLORS.error};

    /* Neutral */
    --color-white: ${BLISS_COLORS.white};
    --color-black: ${BLISS_COLORS.black};
  }

  /* Light Mode (Default) */
  :root {
    --background: ${BLISS_COLORS.white};
    --foreground: ${BLISS_COLORS.text.primary};
    --card: ${BLISS_COLORS.gray[50]};
    --card-foreground: ${BLISS_COLORS.text.primary};
    --popover: ${BLISS_COLORS.white};
    --popover-foreground: ${BLISS_COLORS.text.primary};
    --muted: ${BLISS_COLORS.gray[100]};
    --muted-foreground: ${BLISS_COLORS.text.secondary};
    --accent: ${BLISS_COLORS.primary[500]};
    --accent-foreground: ${BLISS_COLORS.white};
    --destructive: ${BLISS_COLORS.error};
    --destructive-foreground: ${BLISS_COLORS.white};
    --border: ${BLISS_COLORS.border.light};
    --input: ${BLISS_COLORS.border.light};
    --ring: ${BLISS_COLORS.primary[500]};
    --radius: 0.5rem;
  }

  /* Dark Mode */
  .dark {
    --background: ${BLISS_COLORS.secondary[900]};
    --foreground: ${BLISS_COLORS.white};
    --card: ${BLISS_COLORS.secondary[800]};
    --card-foreground: ${BLISS_COLORS.white};
    --popover: ${BLISS_COLORS.secondary[800]};
    --popover-foreground: ${BLISS_COLORS.white};
    --muted: ${BLISS_COLORS.secondary[700]};
    --muted-foreground: ${BLISS_COLORS.gray[400]};
    --accent: ${BLISS_COLORS.primary[500]};
    --accent-foreground: ${BLISS_COLORS.secondary[900]};
    --destructive: ${BLISS_COLORS.error};
    --destructive-foreground: ${BLISS_COLORS.white};
    --border: ${BLISS_COLORS.secondary[700]};
    --input: ${BLISS_COLORS.secondary[700]};
    --ring: ${BLISS_COLORS.primary[500]};
  }
`;

export default BLISS_COLORS;
