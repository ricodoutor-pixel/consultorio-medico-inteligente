import { router, protectedProcedure } from '../_core/trpc';
import { z } from 'zod';
import {
  getOrCreateCart,
  getCart,
  addToCart,
  updateCartItem,
  removeFromCart,
  clearCart,
  getCartSummary,
  validateCart,
  convertCartToOrder,
} from '../_core/cart-service';
import {
  AddToCartSchema,
  UpdateCartItemSchema,
  RemoveFromCartSchema,
  CheckoutSchema,
} from '../_core/cart-schemas';

/**
 * Cart router - All procedures require authentication
 */
export const cartRouter = router({
  /**
   * Get current user's cart
   */
  getCart: protectedProcedure.query(async ({ ctx }) => {
    try {
      const cart = await getOrCreateCart(ctx.user.id);
      return {
        success: true,
        cart,
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to get cart',
      };
    }
  }),

  /**
   * Get cart summary (item count, totals)
   */
  getCartSummary: protectedProcedure.query(async ({ ctx }) => {
    try {
      const summary = await getCartSummary(ctx.user.id);
      return {
        success: true,
        summary,
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to get cart summary',
      };
    }
  }),

  /**
   * Add item to cart
   */
  addItem: protectedProcedure
    .input(AddToCartSchema)
    .mutation(async ({ ctx, input }) => {
      try {
        const cart = await addToCart(ctx.user.id, input);
        return {
          success: true,
          cart,
          message: 'Item added to cart',
        };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : 'Failed to add item',
        };
      }
    }),

  /**
   * Update item quantity
   */
  updateItem: protectedProcedure
    .input(UpdateCartItemSchema)
    .mutation(async ({ ctx, input }) => {
      try {
        const cart = await updateCartItem(ctx.user.id, input.productId, input.quantity);
        if (!cart) {
          return {
            success: false,
            error: 'Cart or item not found',
          };
        }
        return {
          success: true,
          cart,
          message: 'Item updated',
        };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : 'Failed to update item',
        };
      }
    }),

  /**
   * Remove item from cart
   */
  removeItem: protectedProcedure
    .input(RemoveFromCartSchema)
    .mutation(async ({ ctx, input }) => {
      try {
        const cart = await removeFromCart(ctx.user.id, input.productId);
        if (!cart) {
          return {
            success: false,
            error: 'Cart not found',
          };
        }
        return {
          success: true,
          cart,
          message: 'Item removed from cart',
        };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : 'Failed to remove item',
        };
      }
    }),

  /**
   * Clear entire cart
   */
  clear: protectedProcedure.mutation(async ({ ctx }) => {
    try {
      const success = await clearCart(ctx.user.id);
      return {
        success,
        message: success ? 'Cart cleared' : 'Failed to clear cart',
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to clear cart',
      };
    }
  }),

  /**
   * Validate cart before checkout
   */
  validate: protectedProcedure.query(async ({ ctx }) => {
    try {
      const cart = await getCart(ctx.user.id);
      if (!cart) {
        return {
          success: false,
          error: 'Cart not found',
        };
      }

      const validation = await validateCart(cart);
      return {
        success: validation.valid,
        valid: validation.valid,
        errors: validation.errors,
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to validate cart',
      };
    }
  }),

  /**
   * Checkout - Convert cart to order
   */
  checkout: protectedProcedure
    .input(CheckoutSchema)
    .mutation(async ({ ctx, input }) => {
      try {
        const cart = await getCart(ctx.user.id);
        if (!cart) {
          return {
            success: false,
            error: 'Cart not found',
          };
        }

        // Validate cart
        const validation = await validateCart(cart);
        if (!validation.valid) {
          return {
            success: false,
            error: 'Cart validation failed',
            errors: validation.errors,
          };
        }

        // TODO: Create order in database
        // TODO: Process payment
        // TODO: Send confirmation email
        // TODO: Clear cart

        const orderId = `order-${Date.now()}`;

        // Convert cart to order (clears cart)
        await convertCartToOrder(ctx.user.id, orderId);

        return {
          success: true,
          orderId,
          message: 'Order created successfully',
        };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : 'Checkout failed',
        };
      }
    }),

  /**
   * Get item count for badge
   */
  getItemCount: protectedProcedure.query(async ({ ctx }) => {
    try {
      const cart = await getCart(ctx.user.id);
      const count = cart ? cart.items.reduce((sum, item) => sum + item.quantity, 0) : 0;
      return {
        success: true,
        count,
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to get item count',
      };
    }
  }),
});
