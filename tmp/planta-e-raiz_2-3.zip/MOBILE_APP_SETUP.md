# 📱 Planta & Raiz - Mobile App (React Native)

## Setup Completo para iOS + Android

### 1. Instalação de Dependências

```bash
# Instalar Expo CLI
npm install -g expo-cli

# Criar novo projeto Expo
expo init planta-raiz-mobile
cd planta-raiz-mobile

# Instalar dependências principais
npm install react-native react-navigation react-native-gesture-handler
npm install react-native-screens react-native-safe-area-context
npm install @react-navigation/native @react-navigation/bottom-tabs
npm install @react-navigation/stack
npm install axios zustand
npm install react-native-push-notifications
npm install react-native-video-player
npm install react-native-maps
npm install react-native-webview
npm install react-native-svg
npm install react-native-linear-gradient
npm install react-native-blur
npm install react-native-haptic-feedback
npm install react-native-camera
npm install react-native-permissions
npm install react-native-geolocation-service
npm install react-native-netinfo
npm install react-native-device-info
```

### 2. Estrutura do Projeto

```
planta-raiz-mobile/
├── src/
│   ├── screens/
│   │   ├── HomeScreen.tsx
│   │   ├── ProfessionalsScreen.tsx
│   │   ├── MarketplaceScreen.tsx
│   │   ├── LibraryScreen.tsx
│   │   ├── ChatScreen.tsx
│   │   ├── ProfileScreen.tsx
│   │   ├── DashboardScreen.tsx
│   │   └── SettingsScreen.tsx
│   ├── components/
│   │   ├── BottomTabNavigator.tsx
│   │   ├── Header.tsx
│   │   ├── Card.tsx
│   │   ├── Button.tsx
│   │   ├── Modal.tsx
│   │   └── LoadingSpinner.tsx
│   ├── navigation/
│   │   ├── RootNavigator.tsx
│   │   └── types.ts
│   ├── services/
│   │   ├── api.ts
│   │   ├── auth.ts
│   │   ├── storage.ts
│   │   └── notifications.ts
│   ├── store/
│   │   ├── userStore.ts
│   │   ├── consultationStore.ts
│   │   └── cartStore.ts
│   ├── utils/
│   │   ├── colors.ts
│   │   ├── fonts.ts
│   │   ├── spacing.ts
│   │   └── helpers.ts
│   ├── hooks/
│   │   ├── useAuth.ts
│   │   ├── useConsultations.ts
│   │   └── useNotifications.ts
│   └── App.tsx
├── app.json
├── package.json
└── README.md
```

### 3. Configuração de Notificações Push

```typescript
// src/services/notifications.ts
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';

export const setupNotifications = async () => {
  if (Device.isDevice) {
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;
    
    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }
    
    if (finalStatus !== 'granted') {
      alert('Permissão de notificação negada!');
      return;
    }

    const token = (await Notifications.getExpoPushTokenAsync()).data;
    console.log('Push Token:', token);
    return token;
  }
};

// Configurar handler de notificações
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});
```

### 4. Integração com Backend

```typescript
// src/services/api.ts
import axios from 'axios';
import * as SecureStore from 'expo-secure-store';

const API_URL = 'https://api.plantaeraiz.com';

const api = axios.create({
  baseURL: API_URL,
  timeout: 10000,
});

// Interceptor para autenticação
api.interceptors.request.use(async (config) => {
  const token = await SecureStore.getItemAsync('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Interceptor para tratamento de erros
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      // Token expirado - fazer logout
      await SecureStore.deleteItemAsync('authToken');
    }
    return Promise.reject(error);
  }
);

export default api;
```

### 5. Gerenciamento de Estado com Zustand

```typescript
// src/store/userStore.ts
import create from 'zustand';

interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: 'patient' | 'professional' | 'pharmacy';
}

interface UserStore {
  user: User | null;
  isLoading: boolean;
  setUser: (user: User) => void;
  logout: () => void;
}

export const useUserStore = create<UserStore>((set) => ({
  user: null,
  isLoading: false,
  setUser: (user) => set({ user }),
  logout: () => set({ user: null }),
}));
```

### 6. Configuração de Autenticação

```typescript
// src/services/auth.ts
import * as SecureStore from 'expo-secure-store';
import api from './api';

export const login = async (email: string, password: string) => {
  const response = await api.post('/auth/login', { email, password });
  const { token, user } = response.data;
  
  await SecureStore.setItemAsync('authToken', token);
  return user;
};

export const logout = async () => {
  await SecureStore.deleteItemAsync('authToken');
};

export const getStoredToken = async () => {
  return await SecureStore.getItemAsync('authToken');
};
```

### 7. Build para iOS

```bash
# Instalar CocoaPods
sudo gem install cocoapods

# Preparar build
eas build --platform ios --profile preview

# Ou usar Xcode
cd ios
pod install
cd ..
npm run ios
```

### 8. Build para Android

```bash

# Preparar build
eas build --platform android --profile preview

# Ou usar Android Studio
npm run android
```

### 9. Recursos Principais da App

#### Home Screen
- Hero com CTA para agendamento
- Últimas consultas
- Lembretes de medicação
- Notificações recentes

#### Professionals Screen
- Busca com filtros
- Mapa de localização
- Perfil do profissional
- Agendamento rápido

#### Marketplace Screen
- Catálogo de produtos
- Carrinho de compras
- Checkout integrado
- Histórico de pedidos

#### Library Screen
- 100+ variedades com imagens
- Filtros avançados
- Modo comparação
- Reviews e ratings

#### Chat Screen
- Conversas com profissionais
- Suporte com bot IA
- Compartilhamento de arquivos
- Notificações em tempo real

#### Profile Screen
- Dados do usuário
- Histórico de consultas
- Prescrições digitais
- Configurações

#### Dashboard Screen
- Estatísticas de saúde
- Gráficos de atividade
- KPIs de negócio
- Relatórios

### 10. Testes

```bash
# Testes unitários
npm test

# Testes E2E com Detox
npm install detox-cli --global
detox build-framework-cache
detox build-app --configuration ios.sim.debug
detox test e2e --configuration ios.sim.debug --cleanup
```

### 11. Deployment

```bash
# Submeter para App Store
eas submit --platform ios

# Submeter para Google Play
eas submit --platform android
```

### 12. Monitoramento

```typescript
// src/services/analytics.ts
import * as Analytics from 'expo-firebase-analytics';

export const trackEvent = (name: string, params?: Record<string, any>) => {
  Analytics.logEvent(name, params);
};

export const trackScreenView = (screenName: string) => {
  Analytics.logScreenView({
    screen_name: screenName,
    screen_class: screenName,
  });
};
```

---

## Checklist de Implementação

- [ ] Projeto Expo criado
- [ ] Dependências instaladas
- [ ] Estrutura de pastas criada
- [ ] Autenticação implementada
- [ ] Notificações push configuradas
- [ ] Integração com backend
- [ ] Gerenciamento de estado
- [ ] Telas principais criadas
- [ ] Navegação configurada
- [ ] Testes implementados
- [ ] Build iOS testado
- [ ] Build Android testado
- [ ] App Store submission
- [ ] Google Play submission
- [ ] Monitoramento ativo

---

## Recursos Úteis

- [Expo Documentation](https://docs.expo.dev)
- [React Native Documentation](https://reactnative.dev)
- [React Navigation](https://reactnavigation.org)
- [Zustand](https://github.com/pmndrs/zustand)
- [Axios](https://axios-http.com)

---

*Última atualização: 24 de Fevereiro de 2026*
