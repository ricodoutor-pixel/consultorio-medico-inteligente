import React, { useState } from 'react';
import { ChevronDown, Shield, FileText, AlertCircle, CheckCircle2 } from 'lucide-react';

export default function Legal() {
  const [expandedSection, setExpandedSection] = useState<string | null>('disclaimer');

  const sections = [
    {
      id: 'disclaimer',
      title: '⚠️ Aviso Importante',
      icon: AlertCircle,
      content: `Planta & Raiz é uma plataforma intermediária que conecta pacientes a profissionais de saúde habilitados. NÃO somos um serviço médico.

• Diagnósticos e prescrições são responsabilidade EXCLUSIVA do profissional
• Não fazemos recomendações médicas
• Não garantimos resultados
• Consulte sempre um profissional habilitado

Medicamentos à base de cannabis são regulados pela ANVISA (RDC 327/2019). Apenas profissionais habilitados podem prescrever.`
    },
    {
      id: 'cannabis',
      title: 'ℹ️ Cannabis Medicinal',
      icon: FileText,
      content: `Cannabis medicinal é um medicamento regulado pela ANVISA.

• Pode ter efeitos colaterais
• Não é indicado para todos
• Requer prescrição de profissional habilitado
• Não é cura garantida

Procure sempre um profissional de saúde qualificado. A RDC 327/2019 permite a prescrição de medicamentos à base de cannabis por médicos habilitados.`
    },
    {
      id: 'responsabilidade',
      title: '📋 Responsabilidades',
      icon: Shield,
      content: `RESPONSABILIDADE DA PLATAFORMA:
Planta & Raiz é responsável por:
• Manter plataforma segura e funcional
• Verificar profissionais e vendedores
• Processar pagamentos corretamente
• Proteger dados do usuário
• Remover conteúdo ilegal

RESPONSABILIDADE DO PROFISSIONAL:
• Ter CRM ativo e em dia
• Fazer diagnóstico correto
• Prescrever medicamento apropriado
• Informar riscos e efeitos colaterais
• Manter sigilo profissional

RESPONSABILIDADE DO VENDEDOR:
• Ter autorização ANVISA
• Vender apenas produtos autorizados
• Descrever produto corretamente
• Entregar produto em bom estado
• Cumprir prazos de entrega`
    },
    {
      id: 'privacidade',
      title: '🔒 Privacidade & LGPD',
      icon: Shield,
      content: `Planta & Raiz segue a Lei Geral de Proteção de Dados (LGPD).

SEUS DIREITOS:
• Acessar seus dados
• Corrigir dados incorretos
• Deletar sua conta
• Exportar seus dados
• Revogar consentimento

COMO PROTEGEMOS:
• Criptografia HTTPS/TLS
• Backup seguro e diário
• Autenticação 2FA
• Logs de auditoria
• Conformidade PCI DSS

Seus dados são compartilhados apenas com profissional/vendedor para fornecer o serviço.`
    },
    {
      id: 'conformidade',
      title: '✅ Conformidade Regulatória',
      icon: CheckCircle2,
      content: `Planta & Raiz segue todas as regulações:

RDC 327/2019 - Cannabis Medicinal
• Verificação de profissionais habilitados
• Validação de produtos ANVISA
• Armazenamento seguro de receitas

RDC 333/2018 - Telemedicina
• Consultas seguras por chat/vídeo
• Prontuário eletrônico protegido
• Retenção de registros por 5 anos

LGPD - Proteção de Dados
• Consentimento explícito
• Transparência total
• Direito ao esquecimento
• Segurança de dados

Lei de Crimes Cibernéticos
• Proteção contra acesso não autorizado
• Criptografia de dados
• Monitoramento de segurança`
    },
    {
      id: 'termos',
      title: '📄 Termos de Uso',
      icon: FileText,
      content: `ACEITAÇÃO DOS TERMOS:
Ao usar Planta & Raiz, você aceita estes termos. Se não concordar, não use a plataforma.

ELEGIBILIDADE:
• Você deve ter 18 anos ou mais
• Você é responsável por manter confidencialidade de sua conta
• Você não pode usar a plataforma para fins ilegais

LIMITAÇÃO DE RESPONSABILIDADE:
Planta & Raiz não é responsável por:
• Diagnósticos ou tratamentos (profissional)
• Qualidade de produtos (vendedor)
• Entrega de produtos (transportadora)
• Efeitos colaterais (profissional)
• Comportamento de usuários

RESCISÃO:
Podemos encerrar sua conta se você violar estes termos ou leis aplicáveis.`
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 text-white py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-12 text-center">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">
            Centro Jurídico
          </h1>
          <p className="text-xl text-slate-300">
            Transparência, segurança e conformidade regulatória
          </p>
        </div>

        {/* Info Box */}
        <div className="bg-gradient-to-r from-green-900/30 to-emerald-900/30 border border-green-500/30 rounded-lg p-6 mb-8">
          <div className="flex gap-4">
            <Shield className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
            <div>
              <h3 className="font-bold text-green-400 mb-2">Planta & Raiz é uma Plataforma Ponte</h3>
              <p className="text-slate-300">
                Conectamos pacientes a profissionais habilitados. Não fazemos diagnósticos, prescrições ou tratamentos. 
                Toda responsabilidade médica é do profissional. Todos os produtos são verificados e autorizados pela ANVISA.
              </p>
            </div>
          </div>
        </div>

        {/* Accordion Sections */}
        <div className="space-y-4">
          {sections.map((section) => {
            const Icon = section.icon;
            const isExpanded = expandedSection === section.id;
            
            return (
              <div 
                key={section.id}
                className="border border-slate-700 rounded-lg overflow-hidden hover:border-green-500/50 transition-colors"
              >
                <button
                  onClick={() => setExpandedSection(isExpanded ? null : section.id)}
                  className="w-full px-6 py-4 bg-slate-800/50 hover:bg-slate-800 transition-colors flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <Icon className="w-5 h-5 text-green-400" />
                    <span className="font-semibold text-lg">{section.title}</span>
                  </div>
                  <ChevronDown 
                    className={`w-5 h-5 text-slate-400 transition-transform ${isExpanded ? 'rotate-180' : ''}`}
                  />
                </button>
                
                {isExpanded && (
                  <div className="px-6 py-4 bg-slate-900/50 border-t border-slate-700">
                    <p className="text-slate-300 whitespace-pre-line leading-relaxed">
                      {section.content}
                    </p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Compliance Checklist */}
        <div className="mt-12 bg-slate-800/50 border border-slate-700 rounded-lg p-8">
          <h2 className="text-2xl font-bold mb-6 text-green-400">✅ Conformidade Regulatória</h2>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold text-green-400 mb-3">Regulações</h3>
              <ul className="space-y-2 text-slate-300">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-400" />
                  RDC 327/2019 (Cannabis Medicinal)
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-400" />
                  RDC 333/2018 (Telemedicina)
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-400" />
                  LGPD (Proteção de Dados)
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-400" />
                  CDC (Defesa do Consumidor)
                </li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold text-green-400 mb-3">Segurança</h3>
              <ul className="space-y-2 text-slate-300">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-400" />
                  Criptografia HTTPS/TLS
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-400" />
                  Autenticação 2FA
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-400" />
                  PCI DSS (Pagamentos)
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-400" />
                  Backup Diário
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Contact */}
        <div className="mt-12 bg-gradient-to-r from-green-900/20 to-emerald-900/20 border border-green-500/30 rounded-lg p-8 text-center">
          <h2 className="text-2xl font-bold mb-4">Dúvidas Jurídicas?</h2>
          <p className="text-slate-300 mb-6">
            Entre em contato com nosso departamento jurídico
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="mailto:juridico@plantaeraiz.com.br"
              className="px-6 py-3 bg-green-600 hover:bg-green-700 rounded-lg font-semibold transition-colors"
            >
              📧 Email: juridico@plantaeraiz.com.br
            </a>
            <a 
              href="https://wa.me/5511987131241"
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 rounded-lg font-semibold transition-colors"
            >
              💬 WhatsApp: (11) 98713-1241
            </a>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-12 pt-8 border-t border-slate-700 text-center text-slate-400 text-sm">
          <p>Última atualização: 22 de fevereiro de 2026</p>
          <p className="mt-2">Planta & Raiz - Democratizando o acesso a medicamentos à base de cannabis</p>
        </div>
      </div>
    </div>
  );
}
