import { LineChart, Line, XAxis, YAxis, ResponsiveContainer } from 'recharts';
import { TrendingUp } from 'lucide-react';

export function GrowthChartCard() {
  const data = [
    { month: 'Jan', value: 100 },
    { month: 'Fev', value: 120 },
    { month: 'Mar', value: 145 },
    { month: 'Abr', value: 175 },
    { month: 'Mai', value: 210 },
    { month: 'Jun', value: 260 },
  ];

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-accent" />
          <span className="text-sm font-semibold text-foreground">Crescimento da Plataforma</span>
        </div>
        <span className="text-xs font-semibold text-green-500">+160%</span>
      </div>
      
      <div className="rounded-lg border border-border/40 bg-background/50 p-3">
        <ResponsiveContainer width="100%" height={120}>
          <LineChart data={data}>
            <XAxis 
              dataKey="month" 
              stroke="rgba(255,255,255,0.3)" 
              style={{ fontSize: '12px' }}
            />
            <YAxis 
              stroke="rgba(255,255,255,0.3)" 
              style={{ fontSize: '12px' }}
              width={30}
            />
            <Line 
              type="monotone" 
              dataKey="value" 
              stroke="rgb(217, 119, 6)" 
              strokeWidth={2}
              dot={false}
              isAnimationActive={true}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="text-center text-xs text-muted-foreground">
        <p>Mais de 10.000 usuários investindo</p>
      </div>
    </div>
  );
}
