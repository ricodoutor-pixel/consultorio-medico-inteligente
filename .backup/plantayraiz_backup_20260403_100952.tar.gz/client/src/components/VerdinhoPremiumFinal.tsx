/**
 * 🐸 VERDINHO PREMIUM — Mascote IA Interativo v2.0
 * 
 * Componente React com SVG 100% responsivo:
 * - Olhos que seguem o mouse (parallax tracking)
 * - Animações suaves e naturais
 * - Pisca ocasional
 * - Estilo cartoon premium (MetaMask-like)
 * - Glow effect neon verde
 * - Responsivo mobile-first
 */

import React, { useEffect, useRef, useState } from 'react';

interface VerdinhoPremiumFinalProps {
  onChat?: () => void;
  size?: 'small' | 'medium' | 'large';
  position?: 'header' | 'floating';
}

const VerdinhoPremiumFinal: React.FC<VerdinhoPremiumFinalProps> = ({
  onChat,
  size = 'medium',
  position = 'header'
}) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isBlinking, setIsBlinking] = useState(false);
  const [isHovering, setIsHovering] = useState(false);
  const [scale, setScale] = useState(1);

  // Configurações de tamanho
  const sizeConfig = {
    small: { width: 45, height: 45, scale: 0.75 },
    medium: { width: 60, height: 60, scale: 1 },
    large: { width: 80, height: 80, scale: 1.33 }
  };

  const config = sizeConfig[size];

  // Rastrear movimento do mouse
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (svgRef.current && containerRef.current) {
        const rect = svgRef.current.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        setMousePos({ x, y });
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  // Piscar ocasionalmente
  useEffect(() => {
    const blinkInterval = setInterval(() => {
      if (Math.random() < 0.15) {
        setIsBlinking(true);
        setTimeout(() => setIsBlinking(false), 150);
      }
    }, Math.random() * 2000 + 3000);

    return () => clearInterval(blinkInterval);
  }, []);

  // Hover animation
  useEffect(() => {
    if (isHovering) {
      setScale(1.1);
    } else {
      setScale(1);
    }
  }, [isHovering]);

  // Calcular posição dos olhos (parallax tracking)
  const calculateEyePosition = (eyeX: number, eyeY: number) => {
    const maxDistance = 8;
    const dx = mousePos.x - (config.width / 2);
    const dy = mousePos.y - (config.height / 2);
    const distance = Math.sqrt(dx * dx + dy * dy);
    const angle = Math.atan2(dy, dx);

    const moveDistance = Math.min(distance / 50, maxDistance);
    const pupilX = eyeX + Math.cos(angle) * moveDistance;
    const pupilY = eyeY + Math.sin(angle) * moveDistance;

    return { x: pupilX, y: pupilY };
  };

  // Posições dos olhos
  const leftEyeCenter = { x: 18, y: 20 };
  const rightEyeCenter = { x: 42, y: 20 };

  const leftPupil = calculateEyePosition(leftEyeCenter.x, leftEyeCenter.y);
  const rightPupil = calculateEyePosition(rightEyeCenter.x, rightEyeCenter.y);

  const positionClass = position === 'floating' 
    ? 'fixed bottom-6 right-6 z-50'
    : 'relative inline-block';

  return (
    <div
      ref={containerRef}
      className={`${positionClass} cursor-pointer group transition-transform duration-200`}
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
      onClick={onChat}
      style={{
        transform: `scale(${scale})`
      }}
    >
      {/* SVG Verdinho */}
      <svg
        ref={svgRef}
        width={config.width}
        height={config.height}
        viewBox="0 0 60 60"
        className={`transition-all duration-200 ${
          isHovering ? 'animate-glow' : ''
        }`}
        style={{
          filter: isHovering ? 'drop-shadow(0 0 12px rgba(0, 255, 0, 0.6))' : 'drop-shadow(0 0 8px rgba(0, 255, 0, 0.3))'
        }}
      >
        <defs>
          {/* Gradiente para o corpo */}
          <linearGradient id="bodyGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" style={{ stopColor: '#22C55E', stopOpacity: 1 }} />
            <stop offset="50%" style={{ stopColor: '#16A34A', stopOpacity: 1 }} />
            <stop offset="100%" style={{ stopColor: '#15803D', stopOpacity: 1 }} />
          </linearGradient>

          {/* Gradiente para os olhos */}
          <radialGradient id="eyeGradient" cx="35%" cy="35%">
            <stop offset="0%" style={{ stopColor: '#FFFFFF', stopOpacity: 1 }} />
            <stop offset="70%" style={{ stopColor: '#F0F9FF', stopOpacity: 1 }} />
            <stop offset="100%" style={{ stopColor: '#E0E7FF', stopOpacity: 1 }} />
          </radialGradient>

          {/* Sombra */}
          <filter id="shadow" x="-50%" y="-50%" width="200%" height="200%">
            <feDropShadow dx="0" dy="2" stdDeviation="3" floodOpacity="0.4" />
          </filter>

          {/* Glow effect */}
          <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="2" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Cabeça (corpo principal) */}
        <ellipse
          cx="30"
          cy="28"
          rx="24"
          ry="26"
          fill="url(#bodyGradient)"
          filter="url(#shadow)"
        />

        {/* Barriguinha (área clara) */}
        <ellipse
          cx="30"
          cy="32"
          rx="14"
          ry="16"
          fill="#C7F0D8"
          opacity="0.7"
        />

        {/* Pintas verdes (detalhes realistas) */}
        <circle cx="18" cy="20" r="2" fill="#166534" opacity="0.8" />
        <circle cx="42" cy="22" r="2.5" fill="#166534" opacity="0.8" />
        <circle cx="24" cy="38" r="1.8" fill="#166534" opacity="0.7" />
        <circle cx="36" cy="40" r="2" fill="#166534" opacity="0.7" />
        <circle cx="15" cy="35" r="1.5" fill="#166534" opacity="0.6" />
        <circle cx="45" cy="36" r="1.5" fill="#166534" opacity="0.6" />
        <circle cx="20" cy="48" r="1.2" fill="#166534" opacity="0.5" />
        <circle cx="40" cy="50" r="1.2" fill="#166534" opacity="0.5" />

        {/* Olho esquerdo (branco) */}
        <circle
          cx={leftEyeCenter.x}
          cy={leftEyeCenter.y}
          r="6"
          fill="url(#eyeGradient)"
          stroke="#E5E7EB"
          strokeWidth="0.5"
        />

        {/* Pupila esquerda (preta) - segue o mouse */}
        <circle
          cx={leftPupil.x}
          cy={leftPupil.y}
          r="3"
          fill="#000000"
          style={{
            transition: 'cx 0.1s ease-out, cy 0.1s ease-out'
          }}
        />

        {/* Brilho na pupila esquerda */}
        <circle
          cx={leftPupil.x - 0.8}
          cy={leftPupil.y - 0.8}
          r="1.2"
          fill="#FFFFFF"
          opacity="0.9"
        />

        {/* Pálpebra esquerda (piscar) */}
        {isBlinking && (
          <ellipse
            cx={leftEyeCenter.x}
            cy={leftEyeCenter.y}
            rx="6"
            ry="6"
            fill="#22C55E"
            opacity="0.95"
          />
        )}

        {/* Olho direito (branco) */}
        <circle
          cx={rightEyeCenter.x}
          cy={rightEyeCenter.y}
          r="6"
          fill="url(#eyeGradient)"
          stroke="#E5E7EB"
          strokeWidth="0.5"
        />

        {/* Pupila direita (preta) - segue o mouse */}
        <circle
          cx={rightPupil.x}
          cy={rightPupil.y}
          r="3"
          fill="#000000"
          style={{
            transition: 'cx 0.1s ease-out, cy 0.1s ease-out'
          }}
        />

        {/* Brilho na pupila direita */}
        <circle
          cx={rightPupil.x - 0.8}
          cy={rightPupil.y - 0.8}
          r="1.2"
          fill="#FFFFFF"
          opacity="0.9"
        />

        {/* Pálpebra direita (piscar) */}
        {isBlinking && (
          <ellipse
            cx={rightEyeCenter.x}
            cy={rightEyeCenter.y}
            rx="6"
            ry="6"
            fill="#22C55E"
            opacity="0.95"
          />
        )}

        {/* Boca (sorriso em U) */}
        <path
          d="M 24 38 Q 30 44 36 38"
          stroke="#DC2626"
          strokeWidth="2.5"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Língua (rosa) */}
        <ellipse
          cx="30"
          cy="42"
          rx="4"
          ry="3.5"
          fill="#F472B6"
          opacity="0.9"
        />

        {/* Nariz (pequeno) */}
        <circle
          cx="30"
          cy="28"
          r="1.5"
          fill="#166534"
          opacity="0.7"
        />

        {/* Destaque na cabeça (reflexo) */}
        <ellipse
          cx="22"
          cy="15"
          rx="8"
          ry="6"
          fill="#FFFFFF"
          opacity="0.15"
        />
      </svg>

      {/* Label abaixo do Verdinho */}
      <div
        className="absolute top-full mt-2 whitespace-nowrap text-xs font-medium text-green-400 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none"
        style={{ left: '50%', transform: 'translateX(-50%)' }}
      >
        pergunte ao verdinho!
      </div>

      {/* Tooltip ao hover */}
      <div
        className="absolute bottom-full mb-3 left-1/2 transform -translate-x-1/2 bg-gray-900 text-green-400 text-xs px-3 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap border border-green-500/30 shadow-lg"
      >
        💬 Clique para conversar
      </div>

      {/* Pulse animation indicator */}
      {!isHovering && (
        <div
          className="absolute inset-0 rounded-full border-2 border-green-400 opacity-30 animate-pulse"
          style={{
            width: config.width + 8,
            height: config.height + 8,
            left: -4,
            top: -4
          }}
        />
      )}
    </div>
  );
};

export default VerdinhoPremiumFinal;

/**
 * ============================================
 * COMO USAR NO HEADER
 * ============================================
 * 
 * import VerdinhoPremiumFinal from '@/components/VerdinhoPremiumFinal';
 * 
 * <header className="flex items-center justify-between px-6 py-4">
 *   <Logo />
 *   <VerdinhoPremiumFinal 
 *     size="medium" 
 *     position="header"
 *     onChat={() => setShowVerdinhChat(true)}
 *   />
 * </header>
 * 
 * OU FLUTUANTE:
 * 
 * <VerdinhoPremiumFinal 
 *   size="large" 
 *   position="floating"
 *   onChat={() => setShowVerdinhChat(true)}
 * />
 * 
 * ============================================
 */
