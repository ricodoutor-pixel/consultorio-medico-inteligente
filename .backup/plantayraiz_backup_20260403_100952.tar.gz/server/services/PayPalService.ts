import crypto from 'crypto';

interface PayPalOrder {
  id: string;
  orderId: string;
  patientId: string;
  consultationId: string;
  amount: number; // em dólares
  currency: 'USD';
  status: 'pending' | 'approved' | 'completed' | 'failed' | 'cancelled';
  payerEmail: string;
  payerName: string;
  createdAt: number;
  approvedAt?: number;
  completedAt?: number;
  failureReason?: string;
}

// Configurações PayPal
const PAYPAL_CLIENT_ID = process.env.PAYPAL_CLIENT_ID || '';
const PAYPAL_CLIENT_SECRET = process.env.PAYPAL_CLIENT_SECRET || '';
const PAYPAL_API_URL = process.env.PAYPAL_API_URL || 'https://api-m.sandbox.paypal.com';

// Armazenamento em memória
const orders: PayPalOrder[] = [];
const MAX_HISTORY = 5000;

/**
 * Criar ordem de pagamento PayPal
 */
export async function createPayPalOrder(
  patientId: string,
  consultationId: string,
  amount: number,
  payerEmail: string,
  payerName: string
): Promise<PayPalOrder | null> {
  try {
    const order: PayPalOrder = {
      id: crypto.randomUUID(),
      orderId: `ORDER-${Date.now()}`,
      patientId,
      consultationId,
      amount,
      currency: 'USD',
      status: 'pending',
      payerEmail,
      payerName,
      createdAt: Date.now(),
    };

    orders.push(order);
    if (orders.length > MAX_HISTORY) {
      orders.shift();
    }

    console.log(`[PayPal] Order created: ${order.orderId} ($${amount})`);
    return order;
  } catch (error) {
    console.error('[PayPal] Error creating order:', error);
    return null;
  }
}

/**
 * Aprovar pagamento PayPal
 */
export async function approvePayment(orderId: string): Promise<boolean> {
  try {
    const order = orders.find((o) => o.orderId === orderId);
    if (!order) return false;

    order.status = 'approved';
    order.approvedAt = Date.now();

    console.log(`[PayPal] Payment approved: ${orderId}`);
    return true;
  } catch (error) {
    console.error('[PayPal] Error approving payment:', error);
    return false;
  }
}

/**
 * Completar pagamento PayPal
 */
export async function completePayment(orderId: string): Promise<boolean> {
  try {
    const order = orders.find((o) => o.orderId === orderId);
    if (!order) return false;

    if (order.status !== 'approved') {
      return false;
    }

    order.status = 'completed';
    order.completedAt = Date.now();

    console.log(`[PayPal] Payment completed: ${orderId}`);
    return true;
  } catch (error) {
    console.error('[PayPal] Error completing payment:', error);
    return false;
  }
}

/**
 * Falhar pagamento
 */
export async function failPayment(orderId: string, reason: string): Promise<boolean> {
  try {
    const order = orders.find((o) => o.orderId === orderId);
    if (!order) return false;

    order.status = 'failed';
    order.failureReason = reason;

    console.log(`[PayPal] Payment failed: ${orderId} - ${reason}`);
    return true;
  } catch (error) {
    console.error('[PayPal] Error failing payment:', error);
    return false;
  }
}

/**
 * Cancelar pagamento
 */
export async function cancelPayment(orderId: string): Promise<boolean> {
  try {
    const order = orders.find((o) => o.orderId === orderId);
    if (!order) return false;

    if (order.status === 'completed') {
      return false; // Não pode cancelar pagamento já completado
    }

    order.status = 'cancelled';

    console.log(`[PayPal] Payment cancelled: ${orderId}`);
    return true;
  } catch (error) {
    console.error('[PayPal] Error cancelling payment:', error);
    return false;
  }
}

/**
 * Obter ordem de pagamento
 */
export function getOrder(orderId: string): PayPalOrder | null {
  return orders.find((o) => o.orderId === orderId) || null;
}

/**
 * Obter histórico de pagamentos
 */
export function getPaymentHistory(limit: number = 100): PayPalOrder[] {
  return orders.slice(-limit).reverse();
}

/**
 * Obter pagamentos por status
 */
export function getPaymentsByStatus(status: 'pending' | 'approved' | 'completed' | 'failed' | 'cancelled', limit: number = 100): PayPalOrder[] {
  return orders.filter((o) => o.status === status).slice(-limit).reverse();
}

/**
 * Obter pagamentos por paciente
 */
export function getPaymentsByPatient(patientId: string): PayPalOrder[] {
  return orders.filter((o) => o.patientId === patientId);
}

/**
 * Obter estatísticas de pagamento
 */
export function getPaymentStats() {
  const stats = {
    totalOrders: orders.length,
    pendingOrders: orders.filter((o) => o.status === 'pending').length,
    approvedOrders: orders.filter((o) => o.status === 'approved').length,
    completedOrders: orders.filter((o) => o.status === 'completed').length,
    failedOrders: orders.filter((o) => o.status === 'failed').length,
    cancelledOrders: orders.filter((o) => o.status === 'cancelled').length,
    totalRevenue: orders
      .filter((o) => o.status === 'completed')
      .reduce((sum, o) => sum + o.amount, 0),
    averageOrderValue: orders.length > 0
      ? orders.reduce((sum, o) => sum + o.amount, 0) / orders.length
      : 0,
    successRate: orders.length > 0
      ? (orders.filter((o) => o.status === 'completed').length / orders.length) * 100
      : 0,
  };

  return stats;
}

/**
 * Webhook para receber notificações de PayPal
 */
export async function handlePayPalWebhook(data: any): Promise<boolean> {
  try {
    const { event_type, resource } = data;

    switch (event_type) {
      case 'CHECKOUT.ORDER.APPROVED':
        return await approvePayment(resource.id);
      case 'PAYMENT.CAPTURE.COMPLETED':
        return await completePayment(resource.supplementary_data?.related_ids?.order_id);
      case 'PAYMENT.CAPTURE.DENIED':
        return await failPayment(resource.supplementary_data?.related_ids?.order_id, 'Payment denied');
      default:
        console.log(`[PayPal] Unknown webhook event: ${event_type}`);
        return false;
    }
  } catch (error) {
    console.error('[PayPal] Webhook error:', error);
    return false;
  }
}

/**
 * Gerar link de pagamento PayPal
 */
export function generatePaymentLink(orderId: string, amount: number, patientName: string): string {
  // Em produção, isso seria gerado via API PayPal
  // Por enquanto, retornar URL de sandbox
  return `${PAYPAL_API_URL}/checkoutnow?token=${orderId}`;
}

export const PayPalService = {
  createPayPalOrder,
  approvePayment,
  completePayment,
  failPayment,
  cancelPayment,
  getOrder,
  getPaymentHistory,
  getPaymentsByStatus,
  getPaymentsByPatient,
  getPaymentStats,
  handlePayPalWebhook,
  generatePaymentLink,
};
