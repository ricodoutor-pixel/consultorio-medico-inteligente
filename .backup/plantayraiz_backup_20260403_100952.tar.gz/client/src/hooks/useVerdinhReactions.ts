/**
 * 🐸 HOOK CUSTOMIZADO PARA REAÇÕES DO VERDINHO
 * 
 * Facilita o disparo de reações em diferentes eventos
 */

import { useVerdinhReaction, type ReactionType } from '@/contexts/VerdinhReactionContext';
import { useCallback } from 'react';

export const useVerdinhReactions = () => {
  const { triggerReaction } = useVerdinhReaction();

  return {
    dance: useCallback(() => {
      triggerReaction({ type: 'dance', duration: 3000, intensity: 'high' });
    }, [triggerReaction]),

    celebrate: useCallback(() => {
      triggerReaction({ type: 'celebrate', duration: 2500, intensity: 'high' });
    }, [triggerReaction]),

    confused: useCallback(() => {
      triggerReaction({ type: 'confused', duration: 2000, intensity: 'medium' });
    }, [triggerReaction]),

    frustrated: useCallback(() => {
      triggerReaction({ type: 'frustrated', duration: 2500, intensity: 'high' });
    }, [triggerReaction]),

    thinking: useCallback(() => {
      triggerReaction({ type: 'thinking', duration: 2000, intensity: 'medium' });
    }, [triggerReaction]),

    happy: useCallback(() => {
      triggerReaction({ type: 'happy', duration: 1500, intensity: 'medium' });
    }, [triggerReaction]),

    excited: useCallback(() => {
      triggerReaction({ type: 'excited', duration: 2500, intensity: 'high' });
    }, [triggerReaction]),

    // Reações baseadas em eventos específicos
    onPaymentSuccess: useCallback(() => {
      triggerReaction({ type: 'celebrate', duration: 3000, intensity: 'high' });
    }, [triggerReaction]),

    onConsultationBooked: useCallback(() => {
      triggerReaction({ type: 'happy', duration: 2000, intensity: 'medium' });
    }, [triggerReaction]),

    onMessageSent: useCallback(() => {
      triggerReaction({ type: 'happy', duration: 1500, intensity: 'low' });
    }, [triggerReaction]),

    onError: useCallback(() => {
      triggerReaction({ type: 'confused', duration: 2000, intensity: 'medium' });
    }, [triggerReaction]),

    onUserFrustrated: useCallback(() => {
      triggerReaction({ type: 'thinking', duration: 2500, intensity: 'medium' });
    }, [triggerReaction]),

    onUserHappy: useCallback(() => {
      triggerReaction({ type: 'dance', duration: 3000, intensity: 'high' });
    }, [triggerReaction]),
  };
};
