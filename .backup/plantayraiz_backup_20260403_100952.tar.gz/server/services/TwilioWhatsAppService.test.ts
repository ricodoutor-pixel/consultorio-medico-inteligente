import { describe, it, expect, beforeAll } from 'vitest';
import { TwilioWhatsAppService } from './TwilioWhatsAppService';

describe('TwilioWhatsAppService', () => {
  let service: TwilioWhatsAppService;

  beforeAll(() => {
    // Validar que as credenciais estão configuradas
    expect(process.env.TWILIO_ACCOUNT_SID).toBeDefined();
    expect(process.env.TWILIO_AUTH_TOKEN).toBeDefined();
    expect(process.env.TWILIO_WHATSAPP_FROM).toBeDefined();
    expect(process.env.DR_EDILSON_WHATSAPP).toBeDefined();

    // Criar instância do serviço
    service = new TwilioWhatsAppService();
  });

  it('deve validar credenciais Twilio', async () => {
    const result = await service.testConnection();
    expect(result.success).toBe(true);
    expect(result.message).toContain('Conexão com Twilio estabelecida');
  });

  it('deve enviar alerta para médico com sucesso', async () => {
    const result = await service.sendDoctorAlert(
      process.env.DR_EDILSON_WHATSAPP!,
      'Dr. Edilson Bezerra',
      'João Silva',
      '13/03/2026',
      '14:00',
      130,
      'https://plantayraiz.com.br/consultation/abc123'
    );

    expect(result.success).toBe(true);
    expect(result.sid).toBeDefined();
    expect(result.timestamp).toBeDefined();
  });

  it('deve enviar confirmação para paciente com sucesso', async () => {
    const result = await service.sendPatientConfirmation(
      process.env.DR_EDILSON_WHATSAPP!,
      'João Silva',
      'Dr. Edilson Bezerra',
      '13/03/2026',
      '14:00',
      'https://plantayraiz.com.br/consultation/abc123'
    );

    expect(result.success).toBe(true);
    expect(result.sid).toBeDefined();
    expect(result.timestamp).toBeDefined();
  });

  it('deve enviar lembrete com sucesso', async () => {
    const result = await service.sendReminderAlert(
      process.env.DR_EDILSON_WHATSAPP!,
      'Dr. Edilson Bezerra',
      'doctor',
      'Dr. Edilson Bezerra',
      'João Silva',
      '14:00',
      'https://plantayraiz.com.br/consultation/abc123'
    );

    expect(result.success).toBe(true);
    expect(result.sid).toBeDefined();
  });

  it('deve enviar notificação de conclusão com sucesso', async () => {
    const result = await service.sendCompletionNotification(
      process.env.DR_EDILSON_WHATSAPP!,
      'Dr. Edilson Bezerra',
      'doctor',
      'João Silva',
      'https://plantayraiz.com.br/prescription/xyz789'
    );

    expect(result.success).toBe(true);
    expect(result.sid).toBeDefined();
  });

  it('deve enviar mensagem genérica com sucesso', async () => {
    const result = await service.sendMessage({
      to: process.env.DR_EDILSON_WHATSAPP!,
      body: '✅ Teste de conexão Twilio - Planta y Raiz'
    });

    expect(result.success).toBe(true);
    expect(result.sid).toBeDefined();
  });
});
