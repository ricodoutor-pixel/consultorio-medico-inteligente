/**
 * 🐸 VERDINHO CHAT MODAL — Interface de Chat com IA + Análise de Sentimento
 */

import React, { useState, useRef, useEffect } from 'react';
import { X, Send, Loader, Trash2 } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import SentimentIndicator from './SentimentIndicator';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  sentiment?: {
    sentiment: string;
    emotion: string;
    score: number;
    suggestion: string;
    icon: string;
  };
}

interface VerdinhoChatModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const QUICK_SUGGESTIONS = [
  '💊 Como funciona o acesso a medicamentos?',
  '👨‍⚕️ Como encontro um especialista?',
  '📋 Qual é o processo de consulta?',
  '💰 Quais são os planos disponíveis?',
  '🔒 Meus dados estão seguros?',
  '📞 Como faço para cancelar?'
];

const VerdinhoChatModal: React.FC<VerdinhoChatModalProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // tRPC mutations
  const sendMessageMutation = trpc.verdinho.sendMessage.useMutation();
  const sentimentMutation = trpc.sentiment.analyze.useMutation();
  const getHistoryQuery = trpc.verdinho.getHistory.useQuery(undefined, {
    enabled: isOpen
  });
  const clearHistoryMutation = trpc.verdinho.clearHistory.useMutation();

  // Scroll para o final das mensagens
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  // Carregar histórico
  useEffect(() => {
    if (getHistoryQuery.data && messages.length === 0) {
      const loadedMessages = getHistoryQuery.data.map((msg) => ({
        id: msg.id,
        role: msg.role as 'user' | 'assistant',
        content: msg.content,
        timestamp: new Date(msg.createdAt)
      }));
      setMessages(loadedMessages);
    }
  }, [getHistoryQuery.data]);

  // Focus no input quando modal abre
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen]);

  const handleSendMessage = async (messageText?: string) => {
    const text = messageText || inputValue.trim();

    if (!text || isLoading) return;

    // Adicionar mensagem do usuário
    const userMessage: Message = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: new Date()
    };
    setMessages((prev) => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);
    setIsLoading(true);

    try {
      // Analisar sentimento
      const sentimentAnalysis = await sentimentMutation.mutateAsync({
        message: text,
        messageId: userMessage.id
      });

      // Atualizar mensagem com sentimento
      setMessages((prev) =>
        prev.map((m) =>
          m.id === userMessage.id
            ? {
                ...m,
                sentiment: {
                  sentiment: sentimentAnalysis.sentiment,
                  emotion: sentimentAnalysis.emotion,
                  score: sentimentAnalysis.score,
                  suggestion: sentimentAnalysis.suggestion,
                  icon: sentimentAnalysis.icon
                }
              }
            : m
        )
      );

      // Enviar mensagem
      const response = await sendMessageMutation.mutateAsync({
        message: text,
        conversationHistory: messages.map((m) => ({
          role: m.role,
          content: m.content
        }))
      });

      // Adicionar resposta da IA
      const assistantMessage: Message = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        content: response.response,
        timestamp: new Date()
      };
      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Erro ao enviar mensagem:', error);
    } finally {
      setIsTyping(false);
      setIsLoading(false);
    }
  };

  const handleClearHistory = async () => {
    if (confirm('Tem certeza que deseja limpar o histórico?')) {
      try {
        await clearHistoryMutation.mutateAsync();
        setMessages([]);
      } catch (error) {
        console.error('Erro ao limpar histórico:', error);
      }
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="w-full max-w-md h-96 bg-slate-900 rounded-lg shadow-xl flex flex-col border border-slate-700">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-700">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🐸</span>
            <h2 className="font-bold text-white">Verdinho</h2>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 && (
            <div className="text-center text-slate-400 py-8">
              <p className="mb-4">Olá! 👋 Sou o Verdinho, seu assistente IA.</p>
              <p className="text-sm">Como posso ajudá-lo hoje?</p>
            </div>
          )}

          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.role === 'user' ? 'flex-col items-end' : 'flex-col items-start'} gap-2`}
            >
              {/* Indicador de sentimento */}
              {message.role === 'user' && message.sentiment && (
                <SentimentIndicator
                  sentiment={message.sentiment.sentiment as any}
                  emotion={message.sentiment.emotion as any}
                  score={message.sentiment.score}
                  suggestion={message.sentiment.suggestion}
                  icon={message.sentiment.icon}
                  showDetails={true}
                />
              )}

              <div
                className={`max-w-xs px-4 py-2 rounded-lg ${
                  message.role === 'user'
                    ? 'bg-green-600 text-white'
                    : 'bg-slate-700 text-slate-100'
                }`}
              >
                <p className="text-sm">{message.content}</p>
                <p className="text-xs mt-1 opacity-70">
                  {message.timestamp.toLocaleTimeString('pt-BR', {
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </p>
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex items-center gap-2">
              <span className="text-2xl">🐸</span>
              <div className="bg-slate-700 px-4 py-2 rounded-lg">
                <p className="text-sm text-slate-300">Verdinho está digitando...</p>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestions */}
        {messages.length === 0 && (
          <div className="px-4 py-2 border-t border-slate-700 max-h-24 overflow-y-auto">
            <p className="text-xs text-slate-400 mb-2">Sugestões rápidas:</p>
            <div className="space-y-1">
              {QUICK_SUGGESTIONS.slice(0, 3).map((suggestion, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSendMessage(suggestion)}
                  className="w-full text-left text-xs px-2 py-1 rounded bg-slate-700 hover:bg-slate-600 text-slate-200 transition truncate"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input */}
        <div className="p-4 border-t border-slate-700 space-y-2">
          <div className="flex gap-2">
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Digite sua mensagem..."
              className="flex-1 px-3 py-2 bg-slate-800 border border-slate-600 rounded text-white placeholder-slate-400 focus:outline-none focus:border-green-500"
              disabled={isLoading}
            />
            <button
              onClick={() => handleSendMessage()}
              disabled={isLoading || !inputValue.trim()}
              className="px-3 py-2 bg-green-600 hover:bg-green-700 disabled:bg-slate-600 text-white rounded transition flex items-center gap-1"
            >
              {isLoading ? <Loader className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            </button>
          </div>
          <button
            onClick={handleClearHistory}
            className="w-full text-xs text-slate-400 hover:text-slate-300 flex items-center justify-center gap-1 transition"
          >
            <Trash2 className="w-3 h-3" />
            Limpar histórico
          </button>
        </div>
      </div>
    </div>
  );
};

export default VerdinhoChatModal;
