import { useEffect, useState } from 'react';

interface PushNotificationOptions {
  title: string;
  body: string;
  icon?: string;
  badge?: string;
  tag?: string;
  url?: string;
  type?: 'consultation' | 'payment' | 'prescription' | 'general';
}

export function usePushNotifications() {
  const [isSupported, setIsSupported] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [registration, setRegistration] = useState<ServiceWorkerRegistration | null>(null);

  // Verificar suporte a Push Notifications
  useEffect(() => {
    const supported =
      'serviceWorker' in navigator &&
      'PushManager' in window &&
      'Notification' in window;

    setIsSupported(supported);

    if (supported) {
      registerServiceWorker();
    }
  }, []);

  // Registrar Service Worker
  const registerServiceWorker = async () => {
    try {
      const reg = await navigator.serviceWorker.register('/sw.js', {
        scope: '/',
      });
      setRegistration(reg);
      console.log('[Push] Service Worker registered:', reg);

      // Verificar se já está inscrito
      const subscription = await reg.pushManager.getSubscription();
      setIsSubscribed(!!subscription);
    } catch (error) {
      console.error('[Push] Failed to register Service Worker:', error);
    }
  };

  // Solicitar permissão e se inscrever
  const subscribe = async () => {
    if (!isSupported || !registration) {
      console.error('[Push] Push notifications not supported');
      return false;
    }

    try {
      // Solicitar permissão
      if (Notification.permission === 'denied') {
        console.error('[Push] Notification permission denied');
        return false;
      }

      if (Notification.permission !== 'granted') {
        const permission = await Notification.requestPermission();
        if (permission !== 'granted') {
          console.error('[Push] Notification permission not granted');
          return false;
        }
      }

      // Gerar VAPID public key (deve vir do servidor)
      const vapidPublicKey = process.env.VITE_VAPID_PUBLIC_KEY;
      if (!vapidPublicKey) {
        console.error('[Push] VAPID public key not configured');
        return false;
      }

      // Se inscrever em push notifications
      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(vapidPublicKey),
      });

      // Enviar subscription para o servidor
      const response = await fetch('/api/trpc/notifications.subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ subscription: subscription.toJSON() }),
      });

      if (response.ok) {
        setIsSubscribed(true);
        console.log('[Push] Successfully subscribed to push notifications');
        return true;
      } else {
        console.error('[Push] Failed to save subscription on server');
        return false;
      }
    } catch (error) {
      console.error('[Push] Failed to subscribe:', error);
      return false;
    }
  };

  // Desinscrever
  const unsubscribe = async () => {
    if (!registration) {
      return false;
    }

    try {
      const subscription = await registration.pushManager.getSubscription();
      if (subscription) {
        await subscription.unsubscribe();
        setIsSubscribed(false);
        console.log('[Push] Successfully unsubscribed from push notifications');
        return true;
      }
    } catch (error) {
      console.error('[Push] Failed to unsubscribe:', error);
      return false;
    }
  };

  // Enviar notificação de teste (apenas para desenvolvimento)
  const sendTestNotification = async () => {
    if (!registration) {
      console.error('[Push] Service Worker not registered');
      return;
    }

    try {
      await registration.showNotification('Teste - Planta y Raiz', {
        body: 'Esta é uma notificação de teste',
        icon: '/logo.png',
        badge: '/logo.png',
        tag: 'test-notification',
      });
    } catch (error) {
      console.error('[Push] Failed to send test notification:', error);
    }
  };

  return {
    isSupported,
    isSubscribed,
    subscribe,
    unsubscribe,
    sendTestNotification,
  };
}

// Converter VAPID public key de base64 para Uint8Array
function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/\-/g, '+').replace(/_/g, '/');

  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }

  return outputArray;
}
