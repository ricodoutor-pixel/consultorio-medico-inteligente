import { EventEmitter } from 'events';

interface PushNotification {
  id: string;
  userId: string;
  title: string;
  body: string;
  icon?: string;
  badge?: string;
  tag?: string;
  timestamp: number;
  type: 'consultation' | 'payment' | 'prescription' | 'reminder' | 'alert';
  data?: Record<string, any>;
  read: boolean;
}

interface PushSubscription {
  userId: string;
  endpoint: string;
  auth: string;
  p256dh: string;
}

export class PushNotificationRealtimeService extends EventEmitter {
  private static instance: PushNotificationRealtimeService;
  private notifications: Map<string, PushNotification[]> = new Map();
  private subscriptions: Map<string, PushSubscription[]> = new Map();
  private maxNotificationsPerUser = 100;

  private constructor() {
    super();
    this.setMaxListeners(100);
  }

  static getInstance(): PushNotificationRealtimeService {
    if (!PushNotificationRealtimeService.instance) {
      PushNotificationRealtimeService.instance = new PushNotificationRealtimeService();
    }
    return PushNotificationRealtimeService.instance;
  }

  /**
   * Subscribe user to push notifications
   */
  subscribeUser(userId: string, subscription: PushSubscription): void {
    if (!this.subscriptions.has(userId)) {
      this.subscriptions.set(userId, []);
    }

    const userSubscriptions = this.subscriptions.get(userId)!;
    const exists = userSubscriptions.some((sub) => sub.endpoint === subscription.endpoint);

    if (!exists) {
      userSubscriptions.push(subscription);
      this.emit('subscription:added', { userId, subscription });
    }
  }

  /**
   * Unsubscribe user from push notifications
   */
  unsubscribeUser(userId: string, endpoint: string): void {
    const userSubscriptions = this.subscriptions.get(userId);
    if (userSubscriptions) {
      const index = userSubscriptions.findIndex((sub) => sub.endpoint === endpoint);
      if (index > -1) {
        userSubscriptions.splice(index, 1);
        this.emit('subscription:removed', { userId, endpoint });
      }
    }
  }

  /**
   * Send push notification to user
   */
  async sendNotification(
    userId: string,
    notification: Omit<PushNotification, 'id' | 'timestamp' | 'read'>
  ): Promise<PushNotification> {
    const pushNotification: PushNotification = {
      ...notification,
      id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: Date.now(),
      read: false,
    };

    // Store notification
    if (!this.notifications.has(userId)) {
      this.notifications.set(userId, []);
    }

    const userNotifications = this.notifications.get(userId)!;
    userNotifications.unshift(pushNotification);

    // Keep only last N notifications
    if (userNotifications.length > this.maxNotificationsPerUser) {
      userNotifications.pop();
    }

    // Emit event for real-time updates
    this.emit('notification:sent', {
      userId,
      notification: pushNotification,
    });

    // Send to all subscriptions
    const subscriptions = this.subscriptions.get(userId) || [];
    const sendPromises = subscriptions.map((sub) =>
      this.sendToSubscription(sub, pushNotification).catch((err) => {
        console.error(`Failed to send notification to ${sub.endpoint}:`, err);
      })
    );

    await Promise.all(sendPromises);

    return pushNotification;
  }

  /**
   * Send notification to specific subscription
   */
  private async sendToSubscription(
    subscription: PushSubscription,
    notification: PushNotification
  ): Promise<void> {
    // In production, this would use web-push library
    // For now, we'll simulate the send
    const payload = JSON.stringify({
      title: notification.title,
      body: notification.body,
      icon: notification.icon,
      badge: notification.badge,
      tag: notification.tag,
      data: notification.data,
    });

    // Simulate sending
    console.log(`[Push] Sending to ${subscription.endpoint}:`, payload);

    // Emit event
    this.emit('notification:delivered', {
      endpoint: subscription.endpoint,
      notification,
    });
  }

  /**
   * Get notifications for user
   */
  getNotifications(userId: string, limit: number = 50): PushNotification[] {
    const notifications = this.notifications.get(userId) || [];
    return notifications.slice(0, limit);
  }

  /**
   * Mark notification as read
   */
  markAsRead(userId: string, notificationId: string): boolean {
    const notifications = this.notifications.get(userId);
    if (!notifications) return false;

    const notification = notifications.find((n) => n.id === notificationId);
    if (notification) {
      notification.read = true;
      this.emit('notification:read', { userId, notificationId });
      return true;
    }

    return false;
  }

  /**
   * Mark all notifications as read
   */
  markAllAsRead(userId: string): number {
    const notifications = this.notifications.get(userId);
    if (!notifications) return 0;

    let count = 0;
    for (const notification of notifications) {
      if (!notification.read) {
        notification.read = true;
        count++;
      }
    }

    this.emit('notifications:all-read', { userId, count });
    return count;
  }

  /**
   * Delete notification
   */
  deleteNotification(userId: string, notificationId: string): boolean {
    const notifications = this.notifications.get(userId);
    if (!notifications) return false;

    const index = notifications.findIndex((n) => n.id === notificationId);
    if (index > -1) {
      notifications.splice(index, 1);
      this.emit('notification:deleted', { userId, notificationId });
      return true;
    }

    return false;
  }

  /**
   * Send consultation reminder
   */
  async sendConsultationReminder(
    userId: string,
    consultationId: string,
    doctorName: string,
    consultationTime: string
  ): Promise<PushNotification> {
    return this.sendNotification(userId, {
      userId,
      title: '📅 Lembrete de Consulta',
      body: `Sua consulta com ${doctorName} está marcada para ${consultationTime}`,
      type: 'reminder',
      data: {
        consultationId,
        doctorName,
        consultationTime,
      },
    });
  }

  /**
   * Send payment confirmation
   */
  async sendPaymentConfirmation(
    userId: string,
    amount: number,
    currency: string = 'BRL'
  ): Promise<PushNotification> {
    return this.sendNotification(userId, {
      userId,
      title: '✅ Pagamento Confirmado',
      body: `Seu pagamento de ${currency} ${amount.toFixed(2)} foi processado com sucesso`,
      type: 'payment',
      data: {
        amount,
        currency,
      },
    });
  }

  /**
   * Send prescription ready notification
   */
  async sendPrescriptionReady(
    userId: string,
    prescriptionId: string,
    doctorName: string
  ): Promise<PushNotification> {
    return this.sendNotification(userId, {
      userId,
      title: '💊 Prescrição Pronta',
      body: `Sua prescrição de ${doctorName} está pronta para download`,
      type: 'prescription',
      data: {
        prescriptionId,
        doctorName,
      },
    });
  }

  /**
   * Send new consultation alert
   */
  async sendConsultationAlert(
    userId: string,
    patientName: string,
    specialty: string
  ): Promise<PushNotification> {
    return this.sendNotification(userId, {
      userId,
      title: '🔔 Nova Consulta Disponível',
      body: `${patientName} solicitou uma consulta em ${specialty}`,
      type: 'alert',
      data: {
        patientName,
        specialty,
      },
    });
  }

  /**
   * Get unread notification count
   */
  getUnreadCount(userId: string): number {
    const notifications = this.notifications.get(userId) || [];
    return notifications.filter((n) => !n.read).length;
  }

  /**
   * Get notification statistics
   */
  getStats(userId: string): {
    total: number;
    unread: number;
    byType: Record<string, number>;
  } {
    const notifications = this.notifications.get(userId) || [];
    const byType: Record<string, number> = {
      consultation: 0,
      payment: 0,
      prescription: 0,
      reminder: 0,
      alert: 0,
    };

    for (const notification of notifications) {
      byType[notification.type]++;
    }

    return {
      total: notifications.length,
      unread: notifications.filter((n) => !n.read).length,
      byType,
    };
  }

  /**
   * Clear old notifications (older than 30 days)
   */
  clearOldNotifications(userId: string, daysOld: number = 30): number {
    const notifications = this.notifications.get(userId);
    if (!notifications) return 0;

    const cutoffTime = Date.now() - daysOld * 24 * 60 * 60 * 1000;
    const initialLength = notifications.length;

    const filtered = notifications.filter((n) => n.timestamp > cutoffTime);
    this.notifications.set(userId, filtered);

    const removed = initialLength - filtered.length;
    if (removed > 0) {
      this.emit('notifications:cleared', { userId, removed });
    }

    return removed;
  }
}

export const pushNotificationService = PushNotificationRealtimeService.getInstance();
