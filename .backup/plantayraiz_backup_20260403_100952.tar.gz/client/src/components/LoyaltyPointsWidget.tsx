import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Gift, TrendingUp, Zap, Star } from 'lucide-react';

interface UserPoints {
  totalPoints: number;
  availablePoints: number;
  level: 'bronze' | 'silver' | 'gold' | 'platinum';
  nextLevelPoints: number;
}

interface Reward {
  id: string;
  name: string;
  pointsCost: number;
  discountPercentage: number;
  category: string;
}

export const LoyaltyPointsWidget: React.FC = () => {
  const [userPoints, setUserPoints] = useState<UserPoints>({
    totalPoints: 2450,
    availablePoints: 2450,
    level: 'gold',
    nextLevelPoints: 3000,
  });

  const [rewards, setRewards] = useState<Reward[]>([
    {
      id: '1',
      name: 'Desconto 10%',
      pointsCost: 100,
      discountPercentage: 10,
      category: 'discount',
    },
    {
      id: '2',
      name: 'Desconto 20%',
      pointsCost: 250,
      discountPercentage: 20,
      category: 'discount',
    },
    {
      id: '3',
      name: 'Consulta Grátis',
      pointsCost: 500,
      discountPercentage: 100,
      category: 'free-consultation',
    },
  ]);

  const [selectedReward, setSelectedReward] = useState<Reward | null>(null);
  const [showRedeemDialog, setShowRedeemDialog] = useState(false);

  const levelColors = {
    bronze: 'bg-amber-600',
    silver: 'bg-slate-400',
    gold: 'bg-yellow-500',
    platinum: 'bg-purple-500',
  };

  const levelIcons = {
    bronze: '🥉',
    silver: '🥈',
    gold: '🥇',
    platinum: '👑',
  };

  const progressPercentage =
    ((userPoints.totalPoints - (userPoints.level === 'bronze' ? 0 : userPoints.nextLevelPoints - 500)) /
      (userPoints.nextLevelPoints - (userPoints.level === 'bronze' ? 0 : userPoints.nextLevelPoints - 500))) *
    100;

  const handleRedeemReward = (reward: Reward) => {
    if (userPoints.availablePoints >= reward.pointsCost) {
      setSelectedReward(reward);
      setShowRedeemDialog(true);
    }
  };

  const confirmRedeem = () => {
    if (selectedReward) {
      setUserPoints({
        ...userPoints,
        availablePoints: userPoints.availablePoints - selectedReward.pointsCost,
      });
      setShowRedeemDialog(false);
      setSelectedReward(null);
    }
  };

  return (
    <div className="w-full space-y-4">
      {/* Pontos Principais */}
      <Card className="bg-gradient-to-r from-yellow-50 to-amber-50 border-yellow-200">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-2xl font-bold text-yellow-900">
                {userPoints.totalPoints} Pontos
              </CardTitle>
              <CardDescription className="text-yellow-700">
                {userPoints.availablePoints} disponíveis para resgate
              </CardDescription>
            </div>
            <Zap className="w-8 h-8 text-yellow-500" />
          </div>
        </CardHeader>
      </Card>

      {/* Nível e Progresso */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className="text-2xl">{levelIcons[userPoints.level]}</span>
              <div>
                <CardTitle className="capitalize">{userPoints.level}</CardTitle>
                <CardDescription>Seu nível de fidelização</CardDescription>
              </div>
            </div>
            <Badge className={`${levelColors[userPoints.level]} text-white capitalize`}>
              {userPoints.level}
            </Badge>
          </div>

          {/* Barra de Progresso */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Progresso para próximo nível</span>
              <span className="font-semibold">
                {userPoints.totalPoints} / {userPoints.nextLevelPoints}
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className={`${levelColors[userPoints.level]} h-2 rounded-full transition-all duration-300`}
                style={{ width: `${Math.min(progressPercentage, 100)}%` }}
              />
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Benefícios por Nível */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Benefícios do Seu Nível</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {userPoints.level === 'bronze' && (
            <p className="text-sm text-gray-600">
              ✓ Ganhe 1 ponto por R$ 1 em consultas
            </p>
          )}
          {userPoints.level === 'silver' && (
            <>
              <p className="text-sm text-gray-600">
                ✓ Ganhe 1.1 pontos por R$ 1 em consultas
              </p>
              <p className="text-sm text-gray-600">
                ✓ Ganhe 1.6 pontos por R$ 1 em compras
              </p>
            </>
          )}
          {userPoints.level === 'gold' && (
            <>
              <p className="text-sm text-gray-600">
                ✓ Ganhe 1.2 pontos por R$ 1 em consultas
              </p>
              <p className="text-sm text-gray-600">
                ✓ Ganhe 1.7 pontos por R$ 1 em compras
              </p>
              <p className="text-sm text-gray-600">
                ✓ Acesso prioritário a recompensas exclusivas
              </p>
            </>
          )}
          {userPoints.level === 'platinum' && (
            <>
              <p className="text-sm text-gray-600">
                ✓ Ganhe 1.3 pontos por R$ 1 em consultas
              </p>
              <p className="text-sm text-gray-600">
                ✓ Ganhe 2 pontos por R$ 1 em compras
              </p>
              <p className="text-sm text-gray-600">
                ✓ Acesso VIP a eventos e promoções exclusivas
              </p>
              <p className="text-sm text-gray-600">
                ✓ Atendimento prioritário 24/7
              </p>
            </>
          )}
        </CardContent>
      </Card>

      {/* Recompensas Disponíveis */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Gift className="w-5 h-5" />
            Recompensas Disponíveis
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {rewards.map((reward) => {
            const canRedeem = userPoints.availablePoints >= reward.pointsCost;
            return (
              <div
                key={reward.id}
                className={`p-3 border rounded-lg transition-all ${
                  canRedeem
                    ? 'border-green-200 bg-green-50 hover:border-green-400'
                    : 'border-gray-200 bg-gray-50 opacity-60'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <p className="font-semibold text-sm">{reward.name}</p>
                    <p className="text-xs text-gray-600">
                      {reward.discountPercentage}% de desconto
                    </p>
                  </div>
                  <Badge variant="outline">{reward.pointsCost} pts</Badge>
                </div>
                <Button
                  size="sm"
                  className="w-full"
                  disabled={!canRedeem}
                  onClick={() => handleRedeemReward(reward)}
                  variant={canRedeem ? 'default' : 'outline'}
                >
                  {canRedeem ? 'Resgatar' : 'Pontos Insuficientes'}
                </Button>
              </div>
            );
          })}
        </CardContent>
      </Card>

      {/* Dicas para Ganhar Mais Pontos */}
      <Card className="bg-blue-50 border-blue-200">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2 text-blue-900">
            <TrendingUp className="w-4 h-4" />
            Dicas para Ganhar Mais Pontos
          </CardTitle>
        </CardHeader>
        <CardContent className="text-xs space-y-2 text-blue-800">
          <p>💡 Faça consultas regularmente - ganhe 1 ponto por R$ 1</p>
          <p>💡 Compre no marketplace - ganhe 1.5 pontos por R$ 1</p>
          <p>💡 Indique amigos - ganhe 100 pontos por referência</p>
          <p>💡 Participe de desafios - ganhe bônus especiais</p>
        </CardContent>
      </Card>

      {/* Redeem Dialog */}
      {showRedeemDialog && selectedReward && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 rounded-lg">
          <Card className="w-96">
            <CardHeader>
              <CardTitle>Confirmar Resgate</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Recompensa</p>
                <p className="font-semibold text-lg">{selectedReward.name}</p>
                <p className="text-sm text-gray-600 mt-2">
                  Desconto: {selectedReward.discountPercentage}%
                </p>
                <p className="text-sm text-gray-600">
                  Pontos: {selectedReward.pointsCost}
                </p>
              </div>

              <div className="space-y-2">
                <Button onClick={confirmRedeem} className="w-full">
                  Confirmar Resgate
                </Button>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => setShowRedeemDialog(false)}
                >
                  Cancelar
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

export default LoyaltyPointsWidget;
