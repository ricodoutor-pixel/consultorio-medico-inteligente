import { EventEmitter } from 'events';

interface DoctorApplication {
  id: string;
  email: string;
  fullName: string;
  crm: string;
  crmState: string;
  specialty: string;
  yearsOfExperience: number;
  icpBrasilCertificate: string;
  icpBrasilCertificateExpiry: string;
  bankAccount: {
    bank: string;
    accountType: string;
    accountNumber: string;
  };
  documents: {
    crmCertificate: string;
    identityDocument: string;
    addressProof: string;
    icpBrasilCertificate: string;
  };
  status: 'pending' | 'approved' | 'rejected' | 'under_review';
  submittedAt: number;
  reviewedAt?: number;
  reviewedBy?: string;
  notes?: string;
  validationResults: {
    crmValid: boolean;
    certificateValid: boolean;
    documentsComplete: boolean;
    bankAccountValid: boolean;
  };
}

interface RecruitmentStats {
  totalApplications: number;
  pendingReview: number;
  approved: number;
  rejected: number;
  approvalRate: number;
  averageReviewTime: number; // in hours
}

export class DoctorRecruitmentService extends EventEmitter {
  private static instance: DoctorRecruitmentService;
  private applications: Map<string, DoctorApplication> = new Map();
  private crmDatabase: Map<string, { valid: boolean; specialty: string }> = new Map();

  private constructor() {
    super();
    this.setMaxListeners(100);
    this.initializeCRMDatabase();
  }

  static getInstance(): DoctorRecruitmentService {
    if (!DoctorRecruitmentService.instance) {
      DoctorRecruitmentService.instance = new DoctorRecruitmentService();
    }
    return DoctorRecruitmentService.instance;
  }

  /**
   * Initialize mock CRM database
   */
  private initializeCRMDatabase(): void {
    // Add Dr. Edilson Bezerra
    this.crmDatabase.set('123456/SP', {
      valid: true,
      specialty: 'Clínica Geral',
    });

    // Add other mock doctors
    this.crmDatabase.set('654321/RJ', {
      valid: true,
      specialty: 'Psiquiatria',
    });

    this.crmDatabase.set('789012/MG', {
      valid: true,
      specialty: 'Dermatologia',
    });
  }

  /**
   * Submit doctor application
   */
  submitApplication(
    email: string,
    fullName: string,
    crm: string,
    crmState: string,
    specialty: string,
    yearsOfExperience: number,
    icpBrasilCertificate: string,
    icpBrasilCertificateExpiry: string,
    bankAccount: DoctorApplication['bankAccount'],
    documents: DoctorApplication['documents']
  ): DoctorApplication {
    // Validate CRM
    const crmKey = `${crm}/${crmState}`;
    const crmValid = this.validateCRM(crmKey);

    // Validate certificate
    const certificateValid = this.validateCertificate(icpBrasilCertificateExpiry);

    // Check documents
    const documentsComplete = Object.values(documents).every((doc) => doc && doc.length > 0);

    // Validate bank account
    const bankAccountValid = this.validateBankAccount(bankAccount);

    const application: DoctorApplication = {
      id: `app-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      email,
      fullName,
      crm,
      crmState,
      specialty,
      yearsOfExperience,
      icpBrasilCertificate,
      icpBrasilCertificateExpiry,
      bankAccount,
      documents,
      status: 'pending',
      submittedAt: Date.now(),
      validationResults: {
        crmValid,
        certificateValid,
        documentsComplete,
        bankAccountValid,
      },
    };

    // Auto-approve if all validations pass
    if (crmValid && certificateValid && documentsComplete && bankAccountValid) {
      application.status = 'approved';
      application.reviewedAt = Date.now();
      application.reviewedBy = 'SYSTEM';
    } else {
      application.status = 'under_review';
    }

    this.applications.set(application.id, application);

    // Emit event
    this.emit('application:submitted', { application });

    return application;
  }

  /**
   * Validate CRM number
   */
  private validateCRM(crmKey: string): boolean {
    return this.crmDatabase.has(crmKey);
  }

  /**
   * Validate ICP-Brasil certificate
   */
  private validateCertificate(expiryDate: string): boolean {
    try {
      const expiry = new Date(expiryDate);
      return expiry > new Date();
    } catch {
      return false;
    }
  }

  /**
   * Validate bank account
   */
  private validateBankAccount(bankAccount: DoctorApplication['bankAccount']): boolean {
    return (
      bankAccount.bank &&
      bankAccount.accountType &&
      bankAccount.accountNumber &&
      bankAccount.accountNumber.length >= 8
    );
  }

  /**
   * Get application by ID
   */
  getApplication(applicationId: string): DoctorApplication | null {
    return this.applications.get(applicationId) || null;
  }

  /**
   * Get all applications
   */
  getAllApplications(status?: string): DoctorApplication[] {
    const apps = Array.from(this.applications.values());
    if (status) {
      return apps.filter((app) => app.status === status);
    }
    return apps;
  }

  /**
   * Review application
   */
  reviewApplication(
    applicationId: string,
    approved: boolean,
    reviewedBy: string,
    notes?: string
  ): DoctorApplication | null {
    const application = this.applications.get(applicationId);
    if (!application) return null;

    application.status = approved ? 'approved' : 'rejected';
    application.reviewedAt = Date.now();
    application.reviewedBy = reviewedBy;
    application.notes = notes;

    this.emit('application:reviewed', {
      applicationId,
      approved,
      reviewedBy,
    });

    return application;
  }

  /**
   * Get pending applications
   */
  getPendingApplications(): DoctorApplication[] {
    return Array.from(this.applications.values()).filter(
      (app) => app.status === 'pending' || app.status === 'under_review'
    );
  }

  /**
   * Get approved applications
   */
  getApprovedApplications(): DoctorApplication[] {
    return Array.from(this.applications.values()).filter((app) => app.status === 'approved');
  }

  /**
   * Get recruitment statistics
   */
  getStats(): RecruitmentStats {
    const allApps = Array.from(this.applications.values());
    const pending = allApps.filter((app) => app.status === 'pending' || app.status === 'under_review')
      .length;
    const approved = allApps.filter((app) => app.status === 'approved').length;
    const rejected = allApps.filter((app) => app.status === 'rejected').length;

    // Calculate average review time
    const reviewedApps = allApps.filter((app) => app.reviewedAt);
    let averageReviewTime = 0;
    if (reviewedApps.length > 0) {
      const totalTime = reviewedApps.reduce((sum, app) => {
        return sum + (app.reviewedAt! - app.submittedAt);
      }, 0);
      averageReviewTime = totalTime / reviewedApps.length / (1000 * 60 * 60); // Convert to hours
    }

    return {
      totalApplications: allApps.length,
      pendingReview: pending,
      approved,
      rejected,
      approvalRate: allApps.length > 0 ? (approved / allApps.length) * 100 : 0,
      averageReviewTime,
    };
  }

  /**
   * Get applications by specialty
   */
  getApplicationsBySpecialty(specialty: string): DoctorApplication[] {
    return Array.from(this.applications.values()).filter(
      (app) => app.specialty.toLowerCase() === specialty.toLowerCase()
    );
  }

  /**
   * Get applications by state
   */
  getApplicationsByState(state: string): DoctorApplication[] {
    return Array.from(this.applications.values()).filter(
      (app) => app.crmState.toUpperCase() === state.toUpperCase()
    );
  }

  /**
   * Validate all documents for an application
   */
  validateDocuments(applicationId: string): boolean {
    const application = this.applications.get(applicationId);
    if (!application) return false;

    return application.validationResults.documentsComplete;
  }

  /**
   * Export approved doctors list
   */
  exportApprovedDoctors(): Array<{
    name: string;
    email: string;
    crm: string;
    specialty: string;
    yearsOfExperience: number;
  }> {
    return this.getApprovedApplications().map((app) => ({
      name: app.fullName,
      email: app.email,
      crm: `${app.crm}/${app.crmState}`,
      specialty: app.specialty,
      yearsOfExperience: app.yearsOfExperience,
    }));
  }
}

export const doctorRecruitmentService = DoctorRecruitmentService.getInstance();
