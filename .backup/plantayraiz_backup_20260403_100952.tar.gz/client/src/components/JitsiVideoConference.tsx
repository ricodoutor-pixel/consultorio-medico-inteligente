import { useEffect, useRef, useState } from 'react';
import { AlertCircle, Loader, Mic, MicOff, Video, VideoOff, Phone, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface JitsiVideoConferenceProps {
  roomName: string;
  userName: string;
  userEmail: string;
  userRole: 'professional' | 'patient' | 'admin';
  consultationId: string;
  enableRecording?: boolean;
  onSessionEnd?: (sessionData: any) => void;
  onError?: (error: Error) => void;
}

/**
 * Componente de Videoconferência Jitsi
 * Implementa criptografia E2E conforme CFM 2.113/2021
 *
 * Referência: https://jitsi.org/user-guide/secure-meetings/
 */
export default function JitsiVideoConference({
  roomName,
  userName,
  userEmail,
  userRole,
  consultationId,
  enableRecording = false,
  onSessionEnd,
  onError,
}: JitsiVideoConferenceProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const jitsiApiRef = useRef<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isMicOn, setIsMicOn] = useState(true);
  const [isVideoOn, setIsVideoOn] = useState(true);
  const [isRecording, setIsRecording] = useState(false);
  const [sessionDuration, setSessionDuration] = useState(0);

  useEffect(() => {
    // Carregar script Jitsi Meet
    const loadJitsiScript = async () => {
      try {
        // Verificar se script já foi carregado
        if ((window as any).JitsiMeetExternalAPI) {
          initializeJitsi();
          return;
        }

        const script = document.createElement('script');
        script.src = 'https://meet.jitsi.com/external_api.js';
        script.async = true;
        script.onload = () => {
          initializeJitsi();
        };
        script.onerror = () => {
          const errorMsg = 'Falha ao carregar Jitsi Meet';
          setError(errorMsg);
          onError?.(new Error(errorMsg));
        };
        document.body.appendChild(script);
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : 'Erro ao carregar videoconferência';
        setError(errorMsg);
        onError?.(new Error(errorMsg));
      }
    };

    const initializeJitsi = () => {
      if (!containerRef.current) return;

      try {
        const JitsiMeetExternalAPI = (window as any).JitsiMeetExternalAPI;

        const options = {
          roomName: roomName,
          width: '100%',
          height: '100%',
          parentNode: containerRef.current,
          configOverwrite: {
            // Criptografia E2E
            e2ee: {
              enabled: true,
            },
            // Qualidade de vídeo
            videoQuality: {
              preferred: 'high',
              minimum: 'low',
              maximum: 'hd',
            },
            // Desabilitar features não necessárias
            disableRemoteControl: false,
            disableAudioLevels: false,
            // Timeout de inatividade
            sessionTimeout: 30 * 60 * 1000,
          },
          interfaceConfigOverwrite: {
            // Botões da toolbar
            TOOLBAR_BUTTONS: [
              'microphone',
              'camera',
              'desktop',
              'fullscreen',
              'chat',
              'recording',
              'settings',
              'raisehand',
              'help',
            ],
            // Customização visual
            SHOW_JITSI_WATERMARK: true,
            SHOW_BRAND_WATERMARK: true,
            BRAND_WATERMARK_LINK: 'https://plantaeraiz.com',
            // Idioma
            DEFAULT_LANGUAGE: 'pt-BR',
            LANG_DETECTION: true,
            // Desabilitar features
            DISABLE_FOCUS_INDICATOR: false,
            DISABLE_DOMINANT_SPEAKER_INDICATOR: false,
          },
        };

        const api = new JitsiMeetExternalAPI('meet.jitsi.com', options);
        jitsiApiRef.current = api;

        // Configurar dados do usuário
        api.executeCommand('displayName', userName);
        api.executeCommand('email', userEmail);

        // Habilitar gravação se solicitado
        if (enableRecording && userRole === 'professional') {
          api.executeCommand('toggleRecording');
          setIsRecording(true);
        }

        // Listeners para eventos
        api.addEventListener('videoConferenceJoined', () => {
          setIsLoading(false);
          console.log('Usuário entrou na videoconferência');
        });

        api.addEventListener('videoConferenceLeft', () => {
          handleSessionEnd();
        });

        api.addEventListener('participantJoined', (participant: any) => {
          console.log('Participante entrou:', participant);
        });

        api.addEventListener('participantLeft', (participant: any) => {
          console.log('Participante saiu:', participant);
        });

        api.addEventListener('recordingStatusChanged', (status: any) => {
          console.log('Status de gravação:', status);
          setIsRecording(status.on);
        });

        api.addEventListener('audioMuteStatusChanged', (status: any) => {
          setIsMicOn(!status.muted);
        });

        api.addEventListener('videoMuteStatusChanged', (status: any) => {
          setIsVideoOn(!status.muted);
        });

        api.addEventListener('errorOccurred', (error: any) => {
          console.error('Erro na videoconferência:', error);
          setError(error.message || 'Erro na videoconferência');
          onError?.(new Error(error.message));
        });

        // Contador de duração
        const interval = setInterval(() => {
          setSessionDuration(prev => prev + 1);
        }, 1000);

        return () => clearInterval(interval);
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : 'Erro ao inicializar Jitsi';
        setError(errorMsg);
        onError?.(new Error(errorMsg));
      }
    };

    loadJitsiScript();

    return () => {
      if (jitsiApiRef.current) {
        jitsiApiRef.current.dispose();
        jitsiApiRef.current = null;
      }
    };
  }, [roomName, userName, userEmail, enableRecording, userRole, onError]);

  const handleSessionEnd = () => {
    if (onSessionEnd) {
      onSessionEnd({
        consultationId,
        roomName,
        duration: sessionDuration,
        endTime: new Date(),
        recording: isRecording,
      });
    }
  };

  const toggleMicrophone = () => {
    if (jitsiApiRef.current) {
      jitsiApiRef.current.executeCommand('toggleAudio');
    }
  };

  const toggleVideo = () => {
    if (jitsiApiRef.current) {
      jitsiApiRef.current.executeCommand('toggleVideo');
    }
  };

  const toggleRecording = () => {
    if (jitsiApiRef.current && userRole === 'professional') {
      jitsiApiRef.current.executeCommand('toggleRecording');
    }
  };

  const hangUp = () => {
    if (jitsiApiRef.current) {
      jitsiApiRef.current.executeCommand('hangup');
    }
  };

  const formatDuration = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    if (hours > 0) {
      return `${hours}h ${minutes}m ${secs}s`;
    }
    return `${minutes}m ${secs}s`;
  };

  return (
    <div className="w-full h-full bg-[#0A0E27] rounded-lg overflow-hidden flex flex-col">
      {/* HEADER */}
      <div className="bg-[#1a1f3a] border-b border-[#00FF00]/20 px-6 py-4 flex items-center justify-between">
        <div>
          <h2 className="text-white font-bold text-lg">Teleconsulta</h2>
          <p className="text-gray-400 text-sm">Duração: {formatDuration(sessionDuration)}</p>
        </div>
        <div className="flex items-center gap-2">
          {isRecording && (
            <div className="flex items-center gap-2 px-3 py-2 bg-red-500/20 border border-red-500 rounded-lg">
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
              <span className="text-red-400 text-sm font-bold">Gravando</span>
            </div>
          )}
          {isLoading && (
            <div className="flex items-center gap-2">
              <Loader className="w-4 h-4 text-[#00FF00] animate-spin" />
              <span className="text-gray-400 text-sm">Conectando...</span>
            </div>
          )}
        </div>
      </div>

      {/* VIDEO CONTAINER */}
      <div
        ref={containerRef}
        className="flex-1 bg-black relative"
        style={{ minHeight: '500px' }}
      />

      {/* CONTROLES */}
      <div className="bg-[#1a1f3a] border-t border-[#00FF00]/20 px-6 py-4 flex items-center justify-center gap-4">
        <Button
          onClick={toggleMicrophone}
          className={`p-3 rounded-full transition ${
            isMicOn
              ? 'bg-[#00FF00]/20 text-[#00FF00] hover:bg-[#00FF00]/30'
              : 'bg-red-500/20 text-red-400 hover:bg-red-500/30'
          }`}
          title={isMicOn ? 'Desativar microfone' : 'Ativar microfone'}
        >
          {isMicOn ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
        </Button>

        <Button
          onClick={toggleVideo}
          className={`p-3 rounded-full transition ${
            isVideoOn
              ? 'bg-[#00FF00]/20 text-[#00FF00] hover:bg-[#00FF00]/30'
              : 'bg-red-500/20 text-red-400 hover:bg-red-500/30'
          }`}
          title={isVideoOn ? 'Desativar câmera' : 'Ativar câmera'}
        >
          {isVideoOn ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
        </Button>

        {userRole === 'professional' && (
          <Button
            onClick={toggleRecording}
            className={`p-3 rounded-full transition ${
              isRecording
                ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30'
                : 'bg-[#9D4EDD]/20 text-[#9D4EDD] hover:bg-[#9D4EDD]/30'
            }`}
            title={isRecording ? 'Parar gravação' : 'Iniciar gravação'}
          >
            <div className="w-5 h-5 rounded-full border-2 border-current" />
          </Button>
        )}

        <Button
          onClick={hangUp}
          className="p-3 rounded-full bg-red-500/20 text-red-400 hover:bg-red-500/30 transition"
          title="Encerrar chamada"
        >
          <Phone className="w-5 h-5 rotate-135" />
        </Button>

        <Button
          className="p-3 rounded-full bg-white/10 text-gray-400 hover:bg-white/20 transition"
          title="Configurações"
        >
          <Settings className="w-5 h-5" />
        </Button>
      </div>

      {/* ERRO */}
      {error && (
        <Card className="absolute bottom-4 right-4 bg-red-500/20 border-red-500 p-4 max-w-xs">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="text-red-400 font-bold text-sm">Erro</h3>
              <p className="text-red-300 text-sm">{error}</p>
            </div>
          </div>
        </Card>
      )}

      {/* AVISO DE CONFORMIDADE */}
      <div className="bg-[#9D4EDD]/10 border-t border-[#9D4EDD]/20 px-6 py-3">
        <p className="text-[#9D4EDD] text-xs">
          ✓ Criptografia E2E ativada (Resolução CFM 2.113/2021) | Sessão será gravada para prontuário
        </p>
      </div>
    </div>
  );
}
