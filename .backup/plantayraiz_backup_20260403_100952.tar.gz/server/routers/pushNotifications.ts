import { router, publicProcedure, protectedProcedure } from '../_core/trpc';
import { z } from 'zod';
import { pushNotificationService } from '../services/PushNotificationRealtime';

export const pushNotificationsRouter = router({
  /**
   * Subscribe user to push notifications
   */
  subscribe: protectedProcedure
    .input(
      z.object({
        endpoint: z.string().url(),
        auth: z.string(),
        p256dh: z.string(),
      })
    )
    .mutation(({ input, ctx }) => {
      pushNotificationService.subscribeUser(ctx.user.id, {
        userId: ctx.user.id,
        endpoint: input.endpoint,
        auth: input.auth,
        p256dh: input.p256dh,
      });

      return {
        success: true,
        message: 'Subscribed to push notifications',
      };
    }),

  /**
   * Unsubscribe user from push notifications
   */
  unsubscribe: protectedProcedure
    .input(
      z.object({
        endpoint: z.string().url(),
      })
    )
    .mutation(({ input, ctx }) => {
      pushNotificationService.unsubscribeUser(ctx.user.id, input.endpoint);

      return {
        success: true,
        message: 'Unsubscribed from push notifications',
      };
    }),

  /**
   * Get user notifications
   */
  getNotifications: protectedProcedure
    .input(
      z.object({
        limit: z.number().default(50),
      })
    )
    .query(({ input, ctx }) => {
      const notifications = pushNotificationService.getNotifications(ctx.user.id, input.limit);

      return {
        success: true,
        data: notifications,
      };
    }),

  /**
   * Mark notification as read
   */
  markAsRead: protectedProcedure
    .input(
      z.object({
        notificationId: z.string(),
      })
    )
    .mutation(({ input, ctx }) => {
      const success = pushNotificationService.markAsRead(ctx.user.id, input.notificationId);

      return {
        success,
        message: success ? 'Notification marked as read' : 'Notification not found',
      };
    }),

  /**
   * Mark all notifications as read
   */
  markAllAsRead: protectedProcedure.mutation(({ ctx }) => {
    const count = pushNotificationService.markAllAsRead(ctx.user.id);

    return {
      success: true,
      data: {
        markedCount: count,
      },
    };
  }),

  /**
   * Delete notification
   */
  deleteNotification: protectedProcedure
    .input(
      z.object({
        notificationId: z.string(),
      })
    )
    .mutation(({ input, ctx }) => {
      const success = pushNotificationService.deleteNotification(ctx.user.id, input.notificationId);

      return {
        success,
        message: success ? 'Notification deleted' : 'Notification not found',
      };
    }),

  /**
   * Get unread count
   */
  getUnreadCount: protectedProcedure.query(({ ctx }) => {
    const unreadCount = pushNotificationService.getUnreadCount(ctx.user.id);

    return {
      success: true,
      data: {
        unreadCount,
      },
    };
  }),

  /**
   * Get notification statistics
   */
  getStats: protectedProcedure.query(({ ctx }) => {
    const stats = pushNotificationService.getStats(ctx.user.id);

    return {
      success: true,
      data: stats,
    };
  }),

  /**
   * Send test notification
   */
  sendTest: protectedProcedure.mutation(async ({ ctx }) => {
    const notification = await pushNotificationService.sendNotification(ctx.user.id, {
      userId: ctx.user.id,
      title: '🧪 Notificação de Teste',
      body: 'Esta é uma notificação de teste do sistema Planta & Raiz',
      type: 'alert',
      data: {
        test: true,
      },
    });

    return {
      success: true,
      data: notification,
    };
  }),

  /**
   * Send consultation reminder
   */
  sendConsultationReminder: protectedProcedure
    .input(
      z.object({
        userId: z.string(),
        consultationId: z.string(),
        doctorName: z.string(),
        consultationTime: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const notification = await pushNotificationService.sendConsultationReminder(
        input.userId,
        input.consultationId,
        input.doctorName,
        input.consultationTime
      );

      return {
        success: true,
        data: notification,
      };
    }),

  /**
   * Send payment confirmation
   */
  sendPaymentConfirmation: protectedProcedure
    .input(
      z.object({
        userId: z.string(),
        amount: z.number(),
        currency: z.string().default('BRL'),
      })
    )
    .mutation(async ({ input }) => {
      const notification = await pushNotificationService.sendPaymentConfirmation(
        input.userId,
        input.amount,
        input.currency
      );

      return {
        success: true,
        data: notification,
      };
    }),

  /**
   * Send prescription ready notification
   */
  sendPrescriptionReady: protectedProcedure
    .input(
      z.object({
        userId: z.string(),
        prescriptionId: z.string(),
        doctorName: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const notification = await pushNotificationService.sendPrescriptionReady(
        input.userId,
        input.prescriptionId,
        input.doctorName
      );

      return {
        success: true,
        data: notification,
      };
    }),

  /**
   * Send consultation alert (for doctors)
   */
  sendConsultationAlert: protectedProcedure
    .input(
      z.object({
        userId: z.string(),
        patientName: z.string(),
        specialty: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const notification = await pushNotificationService.sendConsultationAlert(
        input.userId,
        input.patientName,
        input.specialty
      );

      return {
        success: true,
        data: notification,
      };
    }),

  /**
   * Clear old notifications
   */
  clearOld: protectedProcedure
    .input(
      z.object({
        daysOld: z.number().default(30),
      })
    )
    .mutation(({ input, ctx }) => {
      const removed = pushNotificationService.clearOldNotifications(ctx.user.id, input.daysOld);

      return {
        success: true,
        data: {
          removedCount: removed,
        },
      };
    }),
});
