# 🚀 Guia de Deploy - Planta & Raiz

## Pré-requisitos

- Docker e Docker Compose instalados
- Node.js 22+ e pnpm
- PostgreSQL 15+
- Redis 7+
- Nginx configurado
- Certificado SSL válido

## Variáveis de Ambiente

Crie um arquivo `.env.production`:

```bash
# Database
DATABASE_URL=postgresql://user:password@postgres:5432/planta_raiz
DB_USER=postgres
DB_PASSWORD=your_secure_password
DB_NAME=planta_raiz

# Redis
REDIS_PASSWORD=your_redis_password
REDIS_URL=redis://:password@redis:6379

# Authentication
JWT_SECRET=your_jwt_secret_key_here

# Mercado Pago
MERCADO_PAGO_ACCESS_TOKEN=your_mp_token
MERCADO_PAGO_PUBLIC_KEY=your_mp_public_key
MERCADO_PAGO_CLIENT_ID=your_mp_client_id
MERCADO_PAGO_CLIENT_SECRET=your_mp_client_secret

# Jitsi
JITSI_API_URL=https://meet.jit.si
JITSI_API_KEY=your_jitsi_key

# Manus APIs
BUILT_IN_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=your_forge_api_key
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im
VITE_FRONTEND_FORGE_API_KEY=your_frontend_forge_key

# OAuth
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://login.manus.im
VITE_APP_ID=your_app_id

# Owner Info
OWNER_NAME=Your Name
OWNER_OPEN_ID=your_open_id

# Monitoring
GRAFANA_PASSWORD=your_grafana_password

# Node Environment
NODE_ENV=production
PORT=3000
LOG_LEVEL=info
```

## Deploy com Docker Compose

### 1. Clonar repositório

```bash
git clone https://github.com/seu-usuario/planta-raiz.git
cd planta-raiz
```

### 2. Configurar variáveis de ambiente

```bash
cp .env.example .env.production
# Editar .env.production com suas credenciais
nano .env.production
```

### 3. Iniciar serviços

```bash
# Build e inicie todos os serviços
docker-compose -f docker-compose.prod.yml up -d

# Verifique o status
docker-compose -f docker-compose.prod.yml ps

# Veja os logs
docker-compose -f docker-compose.prod.yml logs -f backend
```

### 4. Executar migrações de banco de dados

```bash
docker-compose -f docker-compose.prod.yml exec backend pnpm db:push
```

### 5. Criar usuário admin

```bash
docker-compose -f docker-compose.prod.yml exec backend node scripts/create-admin.js
```

## Configuração de Domínio

### 1. Apontar DNS

Aponte seu domínio para o IP do servidor:

```
example.com  A  123.45.67.89
www.example.com  CNAME  example.com
```

### 2. Configurar Nginx

Edite `nginx.conf`:

```nginx
upstream backend {
    server backend:3000;
}

server {
    listen 80;
    server_name example.com www.example.com;
    
    # Redirecionar para HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name example.com www.example.com;
    
    ssl_certificate /etc/nginx/ssl/cert.pem;
    ssl_certificate_key /etc/nginx/ssl/key.pem;
    
    # Configurações SSL
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;
    
    # Proxy para backend
    location /api {
        proxy_pass http://backend;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # Servir arquivos estáticos
    location / {
        root /app/dist/client;
        try_files $uri $uri/ /index.html;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

### 3. Certificado SSL com Let's Encrypt

```bash
# Instale certbot
sudo apt-get install certbot python3-certbot-nginx

# Gere certificado
sudo certbot certonly --standalone -d example.com -d www.example.com

# Copie para o container
sudo cp /etc/letsencrypt/live/example.com/fullchain.pem ./ssl/cert.pem
sudo cp /etc/letsencrypt/live/example.com/privkey.pem ./ssl/key.pem

# Reinicie nginx
docker-compose -f docker-compose.prod.yml restart nginx
```

## Monitoramento

### Prometheus

Acesse: `http://localhost:9090`

### Grafana

Acesse: `http://localhost:3001`
- Usuário: `admin`
- Senha: (definida em `GRAFANA_PASSWORD`)

## Backups

### Backup de banco de dados

```bash
# Backup automático diário
docker-compose -f docker-compose.prod.yml exec postgres pg_dump -U postgres planta_raiz > backup_$(date +%Y%m%d).sql

# Restaurar backup
docker-compose -f docker-compose.prod.yml exec -T postgres psql -U postgres planta_raiz < backup_20260225.sql
```

### Backup de dados Redis

```bash
docker-compose -f docker-compose.prod.yml exec redis redis-cli BGSAVE
```

## Atualizações

### Atualizar aplicação

```bash
# Pull latest changes
git pull origin main

# Rebuild e restart
docker-compose -f docker-compose.prod.yml up -d --build

# Executar migrações se necessário
docker-compose -f docker-compose.prod.yml exec backend pnpm db:push
```

## Troubleshooting

### Verificar logs

```bash
# Backend
docker-compose -f docker-compose.prod.yml logs -f backend

# Database
docker-compose -f docker-compose.prod.yml logs -f postgres

# Nginx
docker-compose -f docker-compose.prod.yml logs -f nginx
```

### Resetar banco de dados

```bash
# CUIDADO: Isso apagará todos os dados!
docker-compose -f docker-compose.prod.yml down -v
docker-compose -f docker-compose.prod.yml up -d
docker-compose -f docker-compose.prod.yml exec backend pnpm db:push
```

### Reiniciar serviços

```bash
# Reiniciar todos
docker-compose -f docker-compose.prod.yml restart

# Reiniciar específico
docker-compose -f docker-compose.prod.yml restart backend
```

## Performance

### Otimizações recomendadas

1. **Habilitar cache Redis**
   - Configurado automaticamente
   - TTL padrão: 1 hora

2. **Compressão Gzip**
   - Habilitada no Nginx
   - Reduz tamanho de resposta em 70%

3. **CDN para assets estáticos**
   - Recomendado: CloudFlare, AWS CloudFront
   - Configure em `nginx.conf`

4. **Database connection pooling**
   - Configurado com PgBouncer
   - Max connections: 100

## Segurança

### Checklist

- [ ] Certificado SSL válido
- [ ] Firewall configurado
- [ ] Backup automático ativo
- [ ] Monitoramento ativo
- [ ] Rate limiting habilitado
- [ ] CORS configurado
- [ ] Secrets não commitados
- [ ] Logs centralizados
- [ ] 2FA para admin
- [ ] Auditoria LGPD ativa

## Suporte

Para problemas ou dúvidas:
- Email: support@plantaeraiz.com
- Documentação: https://docs.plantaeraiz.com
- Issues: https://github.com/seu-usuario/planta-raiz/issues
