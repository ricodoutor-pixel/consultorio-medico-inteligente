/**
 * 🐸 VERDINHO REACTION CONTEXT — Sistema Global de Reações
 * 
 * Tipos de reações:
 * - dance: Dança feliz
 * - celebrate: Celebração com pulos
 * - confused: Confusão com cabeça inclinada
 * - frustrated: Frustração com tremor
 * - thinking: Pensamento com mão no queixo
 * - happy: Felicidade simples
 * - excited: Animação de entusiasmo
 */

import React, { createContext, useContext, useState, useCallback } from 'react';

export type ReactionType = 'dance' | 'celebrate' | 'confused' | 'frustrated' | 'thinking' | 'happy' | 'excited';

interface VerdinhReaction {
  type: ReactionType;
  duration?: number; // em ms
  intensity?: 'low' | 'medium' | 'high';
}

interface VerdinhReactionContextType {
  currentReaction: VerdinhReaction | null;
  isReacting: boolean;
  triggerReaction: (reaction: VerdinhReaction) => void;
  clearReaction: () => void;
}

const VerdinhReactionContext = createContext<VerdinhReactionContextType | undefined>(undefined);

export const VerdinhReactionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentReaction, setCurrentReaction] = useState<VerdinhReaction | null>(null);
  const [isReacting, setIsReacting] = useState(false);

  const triggerReaction = useCallback((reaction: VerdinhReaction) => {
    const duration = reaction.duration || 2000;

    setCurrentReaction(reaction);
    setIsReacting(true);

    // Auto-limpar após duração
    const timer = setTimeout(() => {
      setCurrentReaction(null);
      setIsReacting(false);
    }, duration);

    return () => clearTimeout(timer);
  }, []);

  const clearReaction = useCallback(() => {
    setCurrentReaction(null);
    setIsReacting(false);
  }, []);

  return (
    <VerdinhReactionContext.Provider value={{ currentReaction, isReacting, triggerReaction, clearReaction }}>
      {children}
    </VerdinhReactionContext.Provider>
  );
};

export const useVerdinhReaction = () => {
  const context = useContext(VerdinhReactionContext);
  if (!context) {
    throw new Error('useVerdinhReaction deve ser usado dentro de VerdinhReactionProvider');
  }
  return context;
};
