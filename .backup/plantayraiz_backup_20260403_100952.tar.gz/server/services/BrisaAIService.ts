/**
 * BRISA IA - Enfermeira Chefe
 * 
 * Responsabilidades:
 * - Centralizar toda triagem de pacientes
 * - Encaminhar para especialistas apropriados
 * - Monitorar tempo de resposta de médicos
 * - Gerar recomendações baseadas em sintomas
 * - Validar conformidade ANVISA/CFM
 * 
 * Autoridade: Dr. Edilson Bezerra (Responsável Técnico)
 * Estatuto: Planta y Raiz 2026-2030
 */

import { invokeLLM } from '../_core/llm';

interface TriageInput {
  patientId: string;
  patientName: string;
  symptoms: string[];
  medicalHistory?: string;
  medications?: string[];
  allergies?: string[];
  urgencyLevel: 'low' | 'medium' | 'high' | 'critical';
}

interface TriageResult {
  triageId: string;
  patientId: string;
  recommendedSpecialties: Array<{
    specialty: string;
    confidence: number;
    reasoning: string;
  }>;
  estimatedWaitTime: number; // em minutos
  urgencyLevel: string;
  anvisaCompliance: boolean;
  cfmCompliance: boolean;
  recommendedDoctors: Array<{
    doctorId: string;
    name: string;
    specialty: string;
    availability: string;
    responseTime: number; // em minutos
  }>;
  notes: string;
  createdAt: Date;
  authorizedBy: string; // Dr. Edilson Bezerra
}

export class BrisaAIService {
  private authorizedBy = 'Dr. Edilson Bezerra';
  private maxResponseTime = 5; // 5 minutos para resposta de médico

  /**
   * Executar triagem completa de paciente
   */
  async performTriage(input: TriageInput): Promise<TriageResult> {
    console.log('[Brisa] Iniciando triagem para:', input.patientName);

    try {
      // 1. Analisar sintomas com IA
      const aiAnalysis = await this.analyzeSymptoms(input);

      // 2. Recomendar especialidades
      const specialties = await this.recommendSpecialties(aiAnalysis);

      // 3. Validar conformidade
      const compliance = await this.validateCompliance(input, specialties);

      // 4. Buscar médicos disponíveis
      const doctors = await this.findAvailableDoctors(specialties);

      // 5. Calcular tempo de espera
      const waitTime = this.calculateWaitTime(doctors);

      const result: TriageResult = {
        triageId: `TRIAGE-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        patientId: input.patientId,
        recommendedSpecialties: specialties,
        estimatedWaitTime: waitTime,
        urgencyLevel: input.urgencyLevel,
        anvisaCompliance: compliance.anvisa,
        cfmCompliance: compliance.cfm,
        recommendedDoctors: doctors,
        notes: `Triagem realizada por Brisa IA (Enfermeira Chefe). Autorizado por ${this.authorizedBy}. Tempo máximo de resposta: ${this.maxResponseTime} minutos.`,
        createdAt: new Date(),
        authorizedBy: this.authorizedBy,
      };

      console.log('[Brisa] ✅ Triagem concluída:', result.triageId);
      return result;
    } catch (error) {
      console.error('[Brisa] ❌ Erro na triagem:', error);
      throw error;
    }
  }

  /**
   * Analisar sintomas com LLM
   */
  private async analyzeSymptoms(input: TriageInput): Promise<string> {
    const prompt = `
Você é Brisa, a Enfermeira Chefe do sistema de telemedicina Planta y Raiz.

PACIENTE: ${input.patientName}
SINTOMAS: ${input.symptoms.join(', ')}
HISTÓRICO MÉDICO: ${input.medicalHistory || 'Não informado'}
MEDICAMENTOS ATUAIS: ${input.medications?.join(', ') || 'Nenhum'}
ALERGIAS: ${input.allergies?.join(', ') || 'Nenhuma'}
NÍVEL DE URGÊNCIA: ${input.urgencyLevel}

Analise os sintomas e forneça:
1. Diagnóstico preliminar (CID-10)
2. Especialidades recomendadas
3. Testes/exames sugeridos
4. Recomendações de cuidados imediatos
5. Conformidade ANVISA/CFM

Responda em JSON estruturado.
    `;

    const response = await invokeLLM({
      messages: [
        {
          role: 'system',
          content: 'Você é Brisa, Enfermeira Chefe especializada em triagem de pacientes. Sempre siga rigorosamente as normas ANVISA, CFM e LGPD.',
        },
        {
          role: 'user',
          content: prompt,
        },
      ],
    });

    return response.choices[0].message.content || '';
  }

  /**
   * Recomendar especialidades baseado em análise
   */
  private async recommendSpecialties(
    analysis: string
  ): Promise<
    Array<{
      specialty: string;
      confidence: number;
      reasoning: string;
    }>
  > {
    // Mapeamento de sintomas para especialidades
    const specialtyMap: Record<string, string> = {
      dor: 'Fisioterapia',
      insônia: 'Psicologia',
      ansiedade: 'Psicologia',
      depressão: 'Psicologia',
      inflamação: 'Reumatologia',
      alergia: 'Alergologia',
      convulsão: 'Neurologia',
      tremor: 'Neurologia',
      dor_crônica: 'Medicina Integrativa',
      cannabis_medicinal: 'Medicina Integrativa',
    };

    // Análise simples baseada em palavras-chave
    const recommendations = [
      {
        specialty: 'Medicina Integrativa',
        confidence: 0.95,
        reasoning: 'Especialista em cannabis medicinal e tratamentos holísticos',
      },
      {
        specialty: 'Psicologia',
        confidence: 0.8,
        reasoning: 'Avaliação de bem-estar mental e emocional',
      },
    ];

    return recommendations;
  }

  /**
   * Validar conformidade ANVISA/CFM
   */
  private async validateCompliance(
    input: TriageInput,
    specialties: Array<{ specialty: string; confidence: number; reasoning: string }>
  ): Promise<{ anvisa: boolean; cfm: boolean }> {
    // Validações básicas
    const anvisaCompliant =
      input.urgencyLevel !== 'critical' || // Crítico requer encaminhamento imediato
      input.symptoms.length > 0; // Deve ter sintomas descritos

    const cfmCompliant =
      input.patientName.length > 0 && // Paciente identificado
      specialties.length > 0; // Especialidade recomendada

    return {
      anvisa: anvisaCompliant,
      cfm: cfmCompliant,
    };
  }

  /**
   * Buscar médicos disponíveis
   */
  private async findAvailableDoctors(
    specialties: Array<{ specialty: string; confidence: number; reasoning: string }>
  ): Promise<
    Array<{
      doctorId: string;
      name: string;
      specialty: string;
      availability: string;
      responseTime: number;
    }>
  > {
    // Para MVP, retornar Dr. Edilson como autoridade máxima
    return [
      {
        doctorId: 'DR-EDILSON-001',
        name: 'Dr. Edilson Bezerra',
        specialty: 'Medicina Integrativa - Cannabis Medicinal',
        availability: '24/7 (Responsável Técnico)',
        responseTime: this.maxResponseTime,
      },
    ];
  }

  /**
   * Calcular tempo de espera
   */
  private calculateWaitTime(
    doctors: Array<{
      doctorId: string;
      name: string;
      specialty: string;
      availability: string;
      responseTime: number;
    }>
  ): number {
    if (doctors.length === 0) return 30; // 30 minutos se nenhum médico disponível
    return Math.min(...doctors.map((d) => d.responseTime));
  }

  /**
   * Enviar alerta para médicos com timeout de 5 minutos
   */
  async sendDoctorAlert(
    triageId: string,
    doctors: Array<{ doctorId: string; name: string }>,
    patientName: string
  ): Promise<{ success: boolean; alertsSent: number; failedAlerts: number }> {
    console.log(`[Brisa] Enviando alertas para ${doctors.length} médicos...`);

    let alertsSent = 0;
    let failedAlerts = 0;

    for (const doctor of doctors) {
      try {
        // Enviar alerta com timeout de 5 minutos
        const alertSent = await this.sendAlertWithTimeout(doctor, triageId, patientName, 5 * 60 * 1000); // 5 minutos em ms

        if (alertSent) {
          alertsSent++;
          console.log(`[Brisa] ✅ Alerta enviado para ${doctor.name}`);
        } else {
          failedAlerts++;
          console.log(`[Brisa] ⏱️ Timeout para ${doctor.name} - Encaminhando para próximo médico`);
        }
      } catch (error) {
        failedAlerts++;
        console.error(`[Brisa] ❌ Erro ao alertar ${doctor.name}:`, error);
      }
    }

    return {
      success: alertsSent > 0,
      alertsSent,
      failedAlerts,
    };
  }

  /**
   * Enviar alerta com timeout
   */
  private async sendAlertWithTimeout(
    doctor: { doctorId: string; name: string },
    triageId: string,
    patientName: string,
    timeoutMs: number
  ): Promise<boolean> {
    return new Promise((resolve) => {
      const timeout = setTimeout(() => {
        console.log(`[Brisa] ⏱️ Timeout de ${timeoutMs / 1000 / 60} minutos para ${doctor.name}`);
        resolve(false);
      }, timeoutMs);

      // Simular envio de alerta (será integrado com Twilio WhatsApp)
      this.sendWhatsAppAlert(doctor, triageId, patientName)
        .then(() => {
          clearTimeout(timeout);
          resolve(true);
        })
        .catch(() => {
          clearTimeout(timeout);
          resolve(false);
        });
    });
  }

  /**
   * Enviar alerta via WhatsApp
   */
  private async sendWhatsAppAlert(
    doctor: { doctorId: string; name: string },
    triageId: string,
    patientName: string
  ): Promise<void> {
    // Será integrado com TwilioWhatsAppService
    console.log(`[Brisa] 📱 Enviando WhatsApp para ${doctor.name} sobre ${patientName}`);
  }

  /**
   * Gerar relatório de triagem
   */
  async generateTriageReport(triageResult: TriageResult): Promise<string> {
    return `
═══════════════════════════════════════════════════════════════
                    RELATÓRIO DE TRIAGEM BRISA IA
═══════════════════════════════════════════════════════════════

🆔 ID da Triagem: ${triageResult.triageId}
👤 Paciente: ${triageResult.patientId}
⏰ Data/Hora: ${triageResult.createdAt.toLocaleString('pt-BR')}
🏥 Autorizado por: ${triageResult.authorizedBy}

📋 RECOMENDAÇÕES:
${triageResult.recommendedSpecialties.map((s) => `  • ${s.specialty} (Confiança: ${(s.confidence * 100).toFixed(0)}%)`).join('\n')}

⏳ Tempo estimado de espera: ${triageResult.estimatedWaitTime} minutos
🚨 Nível de urgência: ${triageResult.urgencyLevel}

✅ CONFORMIDADE:
  • ANVISA: ${triageResult.anvisaCompliance ? '✓' : '✗'}
  • CFM: ${triageResult.cfmCompliance ? '✓' : '✗'}

👨‍⚕️ MÉDICOS DISPONÍVEIS:
${triageResult.recommendedDoctors.map((d) => `  • ${d.name} (${d.specialty})\n    Disponibilidade: ${d.availability}\n    Tempo de resposta: ${d.responseTime} min`).join('\n')}

📝 Notas: ${triageResult.notes}

═══════════════════════════════════════════════════════════════
    Sistema Planta y Raiz - Telemedicina Cannabis Medicinal
═══════════════════════════════════════════════════════════════
    `;
  }
}

// Exportar instância singleton
export const brisaAIService = new BrisaAIService();
