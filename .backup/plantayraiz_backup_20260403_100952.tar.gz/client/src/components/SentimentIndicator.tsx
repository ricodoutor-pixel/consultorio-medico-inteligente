/**
 * 🎭 SENTIMENT INDICATOR — Indicador Visual de Sentimento
 * 
 * Componente que mostra:
 * - Ícone de emoção
 * - Score de sentimento (-100 a 100)
 * - Barra de progresso colorida
 * - Sugestão de resposta personalizada
 */

import React from 'react';
import { AlertCircle, Heart, Frown, Smile } from 'lucide-react';

interface SentimentIndicatorProps {
  sentiment: 'very_positive' | 'positive' | 'neutral' | 'negative' | 'very_negative';
  emotion: 'happy' | 'satisfied' | 'neutral' | 'confused' | 'frustrated' | 'angry' | 'sad';
  score: number; // -100 to 100
  suggestion: string;
  icon: string;
  showDetails?: boolean;
}

const SentimentIndicator: React.FC<SentimentIndicatorProps> = ({
  sentiment,
  emotion,
  score,
  suggestion,
  icon,
  showDetails = true
}) => {
  // Determinar cor baseada no score
  const getColor = () => {
    if (score >= 50) return 'text-green-500';
    if (score >= 20) return 'text-emerald-500';
    if (score >= -20) return 'text-yellow-500';
    if (score >= -50) return 'text-orange-500';
    return 'text-red-500';
  };

  const getBgColor = () => {
    if (score >= 50) return 'bg-green-500/20';
    if (score >= 20) return 'bg-emerald-500/20';
    if (score >= -20) return 'bg-yellow-500/20';
    if (score >= -50) return 'bg-orange-500/20';
    return 'bg-red-500/20';
  };

  const getBarColor = () => {
    if (score >= 50) return 'bg-green-500';
    if (score >= 20) return 'bg-emerald-500';
    if (score >= -20) return 'bg-yellow-500';
    if (score >= -50) return 'bg-orange-500';
    return 'bg-red-500';
  };

  // Normalizar score para porcentagem (0-100)
  const percentage = ((score + 100) / 200) * 100;

  // Ícone de emoção
  const getEmotionIcon = () => {
    switch (emotion) {
      case 'happy':
        return <Smile className="w-5 h-5 text-green-500" />;
      case 'satisfied':
        return <Heart className="w-5 h-5 text-emerald-500" />;
      case 'neutral':
        return <div className="w-5 h-5 text-yellow-500">😐</div>;
      case 'confused':
        return <AlertCircle className="w-5 h-5 text-yellow-500" />;
      case 'frustrated':
        return <Frown className="w-5 h-5 text-orange-500" />;
      case 'angry':
        return <Frown className="w-5 h-5 text-red-500" />;
      case 'sad':
        return <Frown className="w-5 h-5 text-red-500" />;
      default:
        return <div className="w-5 h-5">😐</div>;
    }
  };

  return (
    <div className={`p-3 rounded-lg border border-border ${getBgColor()}`}>
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <span className="text-2xl">{icon}</span>
          <div>
            <p className="text-sm font-medium capitalize">{emotion}</p>
            <p className="text-xs text-muted-foreground capitalize">{sentiment}</p>
          </div>
        </div>
        <div className={`text-2xl font-bold ${getColor()}`}>
          {score > 0 ? '+' : ''}{score}
        </div>
      </div>

      {/* Barra de progresso */}
      <div className="mb-2 h-2 bg-background rounded-full overflow-hidden">
        <div
          className={`h-full ${getBarColor()} transition-all duration-300`}
          style={{ width: `${percentage}%` }}
        />
      </div>

      {/* Sugestão */}
      {showDetails && (
        <div className="text-xs text-muted-foreground italic">
          💡 {suggestion}
        </div>
      )}

      {/* Indicador de ação se necessário */}
      {(emotion === 'frustrated' || emotion === 'angry') && (
        <div className="mt-2 p-2 bg-red-500/20 border border-red-500/30 rounded text-xs text-red-600">
          ⚠️ Usuário pode precisar de suporte adicional
        </div>
      )}

      {emotion === 'confused' && (
        <div className="mt-2 p-2 bg-yellow-500/20 border border-yellow-500/30 rounded text-xs text-yellow-600">
          ℹ️ Considere fornecer mais detalhes
        </div>
      )}
    </div>
  );
};

export default SentimentIndicator;
