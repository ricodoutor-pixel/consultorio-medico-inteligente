/**
 * Download App Page
 * Display app download links for iOS and Android
 */

import React, { useState, useEffect } from "react";
import {
  Download,
  Apple,
  Smartphone,
  Star,
  Users,
  Zap,
  Shield,
  Check,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

interface AppStats {
  downloads: number;
  rating: number;
  reviews: number;
  activeUsers: number;
}

const APP_LINKS = {
  ios: "https://apps.apple.com/br/app/planta-raiz/id1234567890",
  android:
    "https://play.google.com/store/apps/details?id=com.plantaraiz.app",
  testflight: "https://testflight.apple.com/join/XXXXX",
  googlePlay: "https://play.google.com/store/apps/details?id=com.plantaraiz.app",
};

const mockStats: AppStats = {
  downloads: 125000,
  rating: 4.9,
  reviews: 8500,
  activeUsers: 45000,
};

export default function DownloadApp() {
  const [stats, setStats] = useState<AppStats>(mockStats);
  const [platform, setPlatform] = useState<"ios" | "android" | null>(null);

  // Detect platform
  useEffect(() => {
    const userAgent = navigator.userAgent.toLowerCase();
    if (/iphone|ipad|ipod/.test(userAgent)) {
      setPlatform("ios");
    } else if (/android/.test(userAgent)) {
      setPlatform("android");
    }
  }, []);

  const handleDownload = (os: "ios" | "android") => {
    const link = os === "ios" ? APP_LINKS.ios : APP_LINKS.android;
    window.open(link, "_blank");
  };

  const features = [
    {
      icon: Zap,
      title: "Consultas em Tempo Real",
      description: "Chat e vídeo com especialistas 24/7",
    },
    {
      icon: Shield,
      title: "100% Seguro",
      description: "Criptografia end-to-end e conformidade ANVISA",
    },
    {
      icon: Smartphone,
      title: "Offline-First",
      description: "Use o app mesmo sem internet",
    },
    {
      icon: Users,
      title: "Comunidade Ativa",
      description: "45K+ usuários ativos compartilhando experiências",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl font-bold mb-4">Baixe o App Planta & Raiz</h1>
          <p className="text-xl opacity-90">
            Acesso completo à telemedicina + marketplace na palma da sua mão
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        {/* Download Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {/* iOS */}
          <Card className="p-8 text-center hover:shadow-lg transition">
            <Apple className="w-16 h-16 mx-auto mb-4 text-primary" />
            <h2 className="text-2xl font-bold mb-2">iPhone & iPad</h2>
            <p className="text-muted-foreground mb-6">
              Disponível na App Store para iOS 14+
            </p>
            <Button
              size="lg"
              onClick={() => handleDownload("ios")}
              className="w-full mb-3"
            >
              <Download className="mr-2" size={20} />
              Baixar na App Store
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.open(APP_LINKS.testflight, "_blank")}
              className="w-full"
            >
              TestFlight (Beta)
            </Button>
          </Card>

          {/* Android */}
          <Card className="p-8 text-center hover:shadow-lg transition">
            <Smartphone className="w-16 h-16 mx-auto mb-4 text-primary" />
            <h2 className="text-2xl font-bold mb-2">Android</h2>
            <p className="text-muted-foreground mb-6">
              Disponível no Google Play para Android 8+
            </p>
            <Button
              size="lg"
              onClick={() => handleDownload("android")}
              className="w-full"
            >
              <Download className="mr-2" size={20} />
              Baixar no Google Play
            </Button>
          </Card>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-16">
          <Card className="p-6 text-center">
            <div className="text-3xl font-bold text-primary mb-2">
              {(stats.downloads / 1000).toFixed(0)}K+
            </div>
            <p className="text-muted-foreground">Downloads</p>
          </Card>
          <Card className="p-6 text-center">
            <div className="flex items-center justify-center gap-1 mb-2">
              <span className="text-3xl font-bold text-primary">
                {stats.rating}
              </span>
              <Star size={24} className="fill-yellow-400 text-yellow-400" />
            </div>
            <p className="text-muted-foreground">Avaliação</p>
          </Card>
          <Card className="p-6 text-center">
            <div className="text-3xl font-bold text-primary mb-2">
              {(stats.reviews / 1000).toFixed(1)}K
            </div>
            <p className="text-muted-foreground">Avaliações</p>
          </Card>
          <Card className="p-6 text-center">
            <div className="text-3xl font-bold text-primary mb-2">
              {(stats.activeUsers / 1000).toFixed(0)}K+
            </div>
            <p className="text-muted-foreground">Usuários Ativos</p>
          </Card>
        </div>

        {/* Features */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-12">
            Por que usar nosso app?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="p-6 flex gap-4">
                  <Icon className="w-12 h-12 text-primary flex-shrink-0" />
                  <div>
                    <h3 className="font-bold text-lg mb-2">{feature.title}</h3>
                    <p className="text-muted-foreground">{feature.description}</p>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Requirements */}
        <Card className="p-8 mb-16 bg-muted/50">
          <h3 className="text-2xl font-bold mb-6">Requisitos</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h4 className="font-bold mb-4 flex items-center gap-2">
                <Apple size={20} />
                iOS
              </h4>
              <ul className="space-y-2 text-muted-foreground">
                <li className="flex items-center gap-2">
                  <Check size={16} className="text-green-600" />
                  iOS 14 ou superior
                </li>
                <li className="flex items-center gap-2">
                  <Check size={16} className="text-green-600" />
                  100 MB de espaço
                </li>
                <li className="flex items-center gap-2">
                  <Check size={16} className="text-green-600" />
                  Conexão com internet
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4 flex items-center gap-2">
                <Smartphone size={20} />
                Android
              </h4>
              <ul className="space-y-2 text-muted-foreground">
                <li className="flex items-center gap-2">
                  <Check size={16} className="text-green-600" />
                  Android 8 ou superior
                </li>
                <li className="flex items-center gap-2">
                  <Check size={16} className="text-green-600" />
                  120 MB de espaço
                </li>
                <li className="flex items-center gap-2">
                  <Check size={16} className="text-green-600" />
                  Conexão com internet
                </li>
              </ul>
            </div>
          </div>
        </Card>

        {/* FAQ */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold mb-8">Perguntas Frequentes</h3>
          <div className="space-y-4">
            <Card className="p-6">
              <h4 className="font-bold mb-2">O app é gratuito?</h4>
              <p className="text-muted-foreground">
                Sim! O download e instalação são 100% gratuitos. Você só paga
                pelas consultas com especialistas.
              </p>
            </Card>
            <Card className="p-6">
              <h4 className="font-bold mb-2">Meus dados são seguros?</h4>
              <p className="text-muted-foreground">
                Sim! Usamos criptografia end-to-end, conformidade ANVISA/LGPD e
                backup automático.
              </p>
            </Card>
            <Card className="p-6">
              <h4 className="font-bold mb-2">
                Posso usar sem internet?
              </h4>
              <p className="text-muted-foreground">
                Sim! O app é offline-first. Você pode navegar, ler conteúdo e
                consultar histórico sem internet.
              </p>
            </Card>
            <Card className="p-6">
              <h4 className="font-bold mb-2">Como faço para cancelar?</h4>
              <p className="text-muted-foreground">
                Você pode desinstalar o app a qualquer momento. Suas consultas
                continuam acessíveis via web.
              </p>
            </Card>
          </div>
        </div>

        {/* CTA */}
        <div className="bg-gradient-to-r from-primary/10 to-primary/5 rounded-lg p-12 text-center">
          <h2 className="text-3xl font-bold mb-4">Pronto para começar?</h2>
          <p className="text-lg text-muted-foreground mb-8">
            Baixe agora e tenha acesso a especialistas 24/7
          </p>
          <div className="flex flex-col md:flex-row gap-4 justify-center">
            <Button
              size="lg"
              onClick={() => handleDownload("ios")}
              className="md:w-auto"
            >
              <Apple className="mr-2" size={20} />
              App Store
            </Button>
            <Button
              size="lg"
              onClick={() => handleDownload("android")}
              className="md:w-auto"
            >
              <Smartphone className="mr-2" size={20} />
              Google Play
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
