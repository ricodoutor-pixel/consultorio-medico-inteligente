import { TRPCError } from '@trpc/server';
import { validateAuthHeader, TokenPayload } from './auth-enhanced';

export type UserRole = 'user' | 'admin' | 'doctor';

/**
 * Check if user has required role
 */
export function hasRole(userRole: UserRole, requiredRoles: UserRole[]): boolean {
  return requiredRoles.includes(userRole);
}

/**
 * Check if user is admin
 */
export function isAdmin(userRole: UserRole): boolean {
  return userRole === 'admin';
}

/**
 * Check if user is doctor
 */
export function isDoctor(userRole: UserRole): boolean {
  return userRole === 'doctor';
}

/**
 * Check if user is regular user
 */
export function isRegularUser(userRole: UserRole): boolean {
  return userRole === 'user';
}

/**
 * Validate user has required role
 */
export function validateRole(userRole: UserRole, requiredRoles: UserRole[]): void {
  if (!hasRole(userRole, requiredRoles)) {
    throw new TRPCError({
      code: 'FORBIDDEN',
      message: `User role "${userRole}" does not have access to this resource. Required roles: ${requiredRoles.join(', ')}`,
    });
  }
}

/**
 * Validate user is admin
 */
export function validateAdmin(userRole: UserRole): void {
  if (!isAdmin(userRole)) {
    throw new TRPCError({
      code: 'FORBIDDEN',
      message: 'Admin access required',
    });
  }
}

/**
 * Validate user is doctor
 */
export function validateDoctor(userRole: UserRole): void {
  if (!isDoctor(userRole)) {
    throw new TRPCError({
      code: 'FORBIDDEN',
      message: 'Doctor access required',
    });
  }
}

/**
 * Validate user owns resource
 */
export function validateOwnership(userId: string, resourceOwnerId: string): void {
  if (userId !== resourceOwnerId) {
    throw new TRPCError({
      code: 'FORBIDDEN',
      message: 'You do not have permission to access this resource',
    });
  }
}

/**
 * Validate user is admin or owner
 */
export function validateAdminOrOwner(
  userRole: UserRole,
  userId: string,
  resourceOwnerId: string
): void {
  if (!isAdmin(userRole) && userId !== resourceOwnerId) {
    throw new TRPCError({
      code: 'FORBIDDEN',
      message: 'You do not have permission to access this resource',
    });
  }
}

/**
 * Permission matrix for resources
 */
export const PERMISSIONS = {
  // User management
  'users:read': ['admin', 'user'],
  'users:create': ['admin'],
  'users:update': ['admin'],
  'users:delete': ['admin'],

  // Doctor management
  'doctors:read': ['admin', 'user', 'doctor'],
  'doctors:create': ['admin'],
  'doctors:update': ['admin', 'doctor'],
  'doctors:delete': ['admin'],

  // Consultation management
  'consultations:read': ['admin', 'user', 'doctor'],
  'consultations:create': ['admin', 'user', 'doctor'],
  'consultations:update': ['admin', 'user', 'doctor'],
  'consultations:delete': ['admin'],

  // Payment management
  'payments:read': ['admin', 'user'],
  'payments:create': ['admin', 'user'],
  'payments:update': ['admin'],
  'payments:delete': ['admin'],

  // Product management
  'products:read': ['admin', 'user'],
  'products:create': ['admin'],
  'products:update': ['admin'],
  'products:delete': ['admin'],

  // Admin dashboard
  'admin:dashboard': ['admin'],
  'admin:analytics': ['admin'],
  'admin:settings': ['admin'],
} as const;

export type Permission = keyof typeof PERMISSIONS;

/**
 * Check if user has permission
 */
export function hasPermission(userRole: UserRole, permission: Permission): boolean {
  const allowedRoles = PERMISSIONS[permission];
  return allowedRoles.includes(userRole);
}

/**
 * Validate user has permission
 */
export function validatePermission(userRole: UserRole, permission: Permission): void {
  if (!hasPermission(userRole, permission)) {
    throw new TRPCError({
      code: 'FORBIDDEN',
      message: `Permission denied: ${permission}`,
    });
  }
}

/**
 * Get user permissions
 */
export function getUserPermissions(userRole: UserRole): Permission[] {
  return Object.entries(PERMISSIONS)
    .filter(([_, roles]) => roles.includes(userRole))
    .map(([permission]) => permission as Permission);
}
