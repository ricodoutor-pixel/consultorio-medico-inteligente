#!/bin/bash

# PLANTA & RAIZ - PRODUCTION DEPLOYMENT SCRIPT
# Deploy em produção com Docker + SSL + Monitoramento

set -e

echo "🚀 INICIANDO DEPLOY EM PRODUÇÃO..."

# 1. Build Docker image
echo "📦 Building Docker image..."
docker build -t planta-raiz:latest .

# 2. Pull latest code
echo "📥 Pulling latest code from repository..."
git pull origin main

# 3. Stop running containers
echo "🛑 Stopping running containers..."
docker-compose down || true

# 4. Start production environment
echo "🚀 Starting production environment..."
docker-compose -f docker-compose.yml up -d

# 5. Run database migrations
echo "🗄️ Running database migrations..."
docker-compose exec -T app pnpm db:push

# 6. Run tests
echo "🧪 Running tests..."
docker-compose exec -T app pnpm test

# 7. Health check
echo "🏥 Running health checks..."
for i in {1..30}; do
  if curl -f http://localhost:3000/health > /dev/null 2>&1; then
    echo "✅ Health check passed!"
    break
  fi
  if [ $i -eq 30 ]; then
    echo "❌ Health check failed!"
    exit 1
  fi
  sleep 1
done

# 8. Configure SSL with Let's Encrypt
echo "🔒 Configuring SSL with Let's Encrypt..."
docker-compose exec -T nginx certbot certonly --webroot -w /var/www/certbot \
  -d planta-raiz.com \
  -d www.planta-raiz.com \
  --email admin@planta-raiz.com \
  --agree-tos \
  --non-interactive || true

# 9. Restart Nginx with SSL
echo "🔄 Restarting Nginx with SSL..."
docker-compose exec -T nginx nginx -s reload

# 10. Setup monitoring (Sentry)
echo "📊 Setting up monitoring with Sentry..."
docker-compose exec -T app npm install @sentry/node @sentry/tracing

# 11. Verify deployment
echo "✅ Verifying deployment..."
curl -s http://localhost:3000/health | jq .

echo "🎉 DEPLOY CONCLUÍDO COM SUCESSO!"
echo "🌐 Acesse: https://planta-raiz.com"
echo "📊 Monitoramento: https://sentry.io/organizations/planta-raiz"
echo "📱 Mobile App: App Store + Google Play"
