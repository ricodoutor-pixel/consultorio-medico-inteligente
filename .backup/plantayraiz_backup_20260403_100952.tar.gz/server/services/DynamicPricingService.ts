// import { db } from "../db"; // Não usar db diretamente, usar getDb()
import { doctorPricing, payments } from "../../drizzle/schema-ceo-autonomous";
import { desc, eq, and, gte } from "drizzle-orm";

/**
 * DynamicPricingService
 * Implementa preços dinâmicos que variam de R$ 49-130 baseado em demanda
 * Análise a cada 60 minutos
 */

const PRICE_RANGE = {
  MIN: 4900, // R$ 49 em centavos
  MAX: 13000, // R$ 130 em centavos
  BASE: 8900, // R$ 89 em centavos (preço base)
};

const DEMAND_LEVELS = {
  LOW: { multiplier: 0.7, threshold: 0.2 }, // 70% do preço base
  MEDIUM: { multiplier: 1.0, threshold: 0.5 }, // 100% do preço base
  HIGH: { multiplier: 1.3, threshold: 0.8 }, // 130% do preço base
  CRITICAL: { multiplier: 1.5, threshold: 1.0 }, // 150% do preço base
};

interface DemandAnalysis {
  consultationsLast24h: number;
  consultationsLast7d: number;
  averagePrice: number;
  conversionRate: number;
  demandLevel: "low" | "medium" | "high" | "critical";
}

interface PricingRecommendation {
  doctorId: number;
  currentPrice: number;
  recommendedPrice: number;
  demandLevel: "low" | "medium" | "high" | "critical";
  roiEstimate: number;
  rationale: string;
}

/**
 * Analisa demanda de consultas para um médico
 */
async function analyzeDemand(doctorId: number): Promise<DemandAnalysis> {
  const now = new Date();
  const last24h = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  const last7d = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

  // Buscar pagamentos dos últimos 7 dias
  const recentPayments = await db
    .select()
    .from(payments)
    .where(
      and(
        eq(payments.doctorId, doctorId),
        gte(payments.timestamp, last7d),
        eq(payments.status, "completed")
      )
    );

  const consultationsLast24h = recentPayments.filter(
    (p) => p.timestamp > last24h
  ).length;
  const consultationsLast7d = recentPayments.length;

  // Calcular preço médio
  const totalAmount = recentPayments.reduce((sum, p) => sum + p.amount, 0);
  const averagePrice =
    consultationsLast7d > 0 ? Math.round(totalAmount / consultationsLast7d) : 0;

  // Calcular taxa de conversão (consultas completadas vs tentadas)
  // Simplificado: assumir 15% de taxa de conversão base
  const conversionRate = consultationsLast7d > 0 ? 0.15 : 0;

  // Determinar nível de demanda baseado em consultas/dia
  const consultationsPerDay = consultationsLast24h;
  let demandLevel: "low" | "medium" | "high" | "critical";

  if (consultationsPerDay === 0) {
    demandLevel = "low";
  } else if (consultationsPerDay < 3) {
    demandLevel = "medium";
  } else if (consultationsPerDay < 6) {
    demandLevel = "high";
  } else {
    demandLevel = "critical";
  }

  return {
    consultationsLast24h,
    consultationsLast7d,
    averagePrice,
    conversionRate,
    demandLevel,
  };
}

/**
 * Recomenda preço ótimo baseado em demanda
 */
async function recommendPrice(
  doctorId: number
): Promise<PricingRecommendation> {
  const demand = await analyzeDemand(doctorId);

  // Buscar último preço registrado
  const lastPricing = await db
    .select()
    .from(doctorPricing)
    .where(eq(doctorPricing.doctorId, doctorId))
    .orderBy(desc(doctorPricing.timestamp))
    .limit(1);

  const currentPrice = lastPricing[0]?.recommendedPrice || PRICE_RANGE.BASE;

  // Calcular preço recomendado
  const demandConfig = DEMAND_LEVELS[demand.demandLevel.toUpperCase()];
  let recommendedPrice = Math.round(PRICE_RANGE.BASE * demandConfig.multiplier);

  // Aplicar limites
  recommendedPrice = Math.max(
    PRICE_RANGE.MIN,
    Math.min(PRICE_RANGE.MAX, recommendedPrice)
  );

  // Calcular ROI estimado
  // ROI = (preço recomendado - preço atual) / preço atual * 100
  const roiEstimate =
    currentPrice > 0
      ? ((recommendedPrice - currentPrice) / currentPrice) * 100
      : 0;

  // Gerar rationale
  const rationale = generateRationale(demand, currentPrice, recommendedPrice);

  return {
    doctorId,
    currentPrice,
    recommendedPrice,
    demandLevel: demand.demandLevel,
    roiEstimate,
    rationale,
  };
}

/**
 * Gera explicação da recomendação
 */
function generateRationale(
  demand: DemandAnalysis,
  currentPrice: number,
  recommendedPrice: number
): string {
  const priceDiff = recommendedPrice - currentPrice;
  const priceDiffPercent = ((priceDiff / currentPrice) * 100).toFixed(1);

  const reasons: string[] = [];

  if (demand.demandLevel === "critical") {
    reasons.push(
      `Demanda crítica detectada (${demand.consultationsLast24h} consultas/dia)`
    );
    reasons.push("Aumento de preço recomendado para maximizar receita");
  } else if (demand.demandLevel === "high") {
    reasons.push(
      `Alta demanda (${demand.consultationsLast24h} consultas/dia)`
    );
    reasons.push("Preço aumentado para otimizar margem");
  } else if (demand.demandLevel === "medium") {
    reasons.push(
      `Demanda média (${demand.consultationsLast24h} consultas/dia)`
    );
    reasons.push("Preço mantido no nível ótimo");
  } else {
    reasons.push(`Baixa demanda (${demand.consultationsLast24h} consultas/dia)`);
    reasons.push("Preço reduzido para aumentar conversão");
  }

  if (priceDiff > 0) {
    reasons.push(
      `Aumento sugerido: +R$ ${(priceDiff / 100).toFixed(2)} (+${priceDiffPercent}%)`
    );
  } else if (priceDiff < 0) {
    reasons.push(
      `Redução sugerida: -R$ ${(Math.abs(priceDiff) / 100).toFixed(2)} (${priceDiffPercent}%)`
    );
  }

  return reasons.join(" | ");
}

/**
 * Salva recomendação de preço no banco de dados
 */
async function savePricingRecommendation(
  recommendation: PricingRecommendation
): Promise<void> {
  await db.insert(doctorPricing).values({
    doctorId: recommendation.doctorId,
    basePrice: PRICE_RANGE.BASE,
    demandLevel: recommendation.demandLevel,
    recommendedPrice: recommendation.recommendedPrice,
    roiEstimate: recommendation.roiEstimate,
    timestamp: new Date(),
  });
}

/**
 * Executa análise de preços para todos os médicos
 * Chamado a cada 60 minutos
 */
async function runPricingAnalysis(): Promise<PricingRecommendation[]> {
  try {
    // Buscar todos os médicos ativos
    // TODO: Implementar query para buscar médicos com role "doctor"
    // Por enquanto, retornar array vazio
    const recommendations: PricingRecommendation[] = [];

    // Para cada médico, gerar recomendação
    // for (const doctor of doctors) {
    //   const recommendation = await recommendPrice(doctor.id);
    //   await savePricingRecommendation(recommendation);
    //   recommendations.push(recommendation);
    // }

    console.log(
      `[DynamicPricingService] Análise concluída: ${recommendations.length} recomendações geradas`
    );
    return recommendations;
  } catch (error) {
    console.error("[DynamicPricingService] Erro na análise:", error);
    throw error;
  }
}

/**
 * Retorna métricas de preços dinâmicos
 */
async function getMetrics(): Promise<{
  averagePrice: number;
  minPrice: number;
  maxPrice: number;
  totalRecommendations: number;
  avgROI: number;
}> {
  const allPricings = await db.select().from(doctorPricing);

  if (allPricings.length === 0) {
    return {
      averagePrice: 0,
      minPrice: 0,
      maxPrice: 0,
      totalRecommendations: 0,
      avgROI: 0,
    };
  }

  const prices = allPricings.map((p) => p.recommendedPrice);
  const rois = allPricings.map((p) => p.roiEstimate);

  return {
    averagePrice: Math.round(prices.reduce((a, b) => a + b, 0) / prices.length),
    minPrice: Math.min(...prices),
    maxPrice: Math.max(...prices),
    totalRecommendations: allPricings.length,
    avgROI: rois.reduce((a, b) => a + b, 0) / rois.length,
  };
}

export const DynamicPricingService = {
  analyzeDemand,
  recommendPrice,
  savePricingRecommendation,
  runPricingAnalysis,
  getMetrics,
};
