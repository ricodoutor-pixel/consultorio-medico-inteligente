import { onCLS, onFCP, onLCP, onTTFB } from "web-vitals";

/**
 * Web Vitals metrics for Core Web Vitals monitoring
 */
export interface WebVitalsMetrics {
  LCP: number; // Largest Contentful Paint (target: < 2.5s)
  FID: number; // First Input Delay (target: < 100ms)
  CLS: number; // Cumulative Layout Shift (target: < 0.1)
  FCP: number; // First Contentful Paint (target: < 1.8s)
  TTFB: number; // Time to First Byte (target: < 600ms)
}

/**
 * Initialize Google Analytics with Web Vitals tracking
 */
export function initGoogleAnalytics() {
  const gaId = import.meta.env.VITE_GOOGLE_ANALYTICS_ID;
  
  if (!gaId) {
    console.warn("⚠️  VITE_GOOGLE_ANALYTICS_ID not configured. Analytics disabled.");
    return;
  }

  // Load Google Analytics script
  const script = document.createElement("script");
  script.async = true;
  script.src = `https://www.googletagmanager.com/gtag/js?id=${gaId}`;
  document.head.appendChild(script);

  // Initialize gtag
  window.dataLayer = window.dataLayer || [];
  function gtag(...args: any[]) {
    window.dataLayer.push(arguments);
  }
  gtag("js", new Date());
  gtag("config", gaId, {
    page_path: window.location.pathname,
    send_page_view: true,
  });

  // Store gtag globally
  (window as any).gtag = gtag;

  console.log("✅ Google Analytics initialized");
}

/**
 * Send Web Vitals to Google Analytics
 */
export function trackWebVitals() {
  // Track LCP (Largest Contentful Paint)
  onLCP((metric) => {
    sendMetricToAnalytics("LCP", metric.value, {
      rating: metric.rating,
      delta: metric.delta,
      id: metric.id,
    });
  });



  // Track CLS (Cumulative Layout Shift)
  onCLS((metric) => {
    sendMetricToAnalytics("CLS", metric.value, {
      rating: metric.rating,
      delta: metric.delta,
      id: metric.id,
    });
  });

  // Track FCP (First Contentful Paint)
  onFCP((metric) => {
    sendMetricToAnalytics("FCP", metric.value, {
      rating: metric.rating,
      delta: metric.delta,
      id: metric.id,
    });
  });

  // Track TTFB (Time to First Byte)
  onTTFB((metric) => {
    sendMetricToAnalytics("TTFB", metric.value, {
      rating: metric.rating,
      delta: metric.delta,
      id: metric.id,
    });
  });

  console.log("✅ Web Vitals tracking initialized");
}

/**
 * Send metric to Google Analytics
 */
function sendMetricToAnalytics(
  metricName: string,
  value: number,
  metadata?: Record<string, any>
) {
  const gtag = (window as any).gtag;
  
  if (!gtag) {
    console.warn("⚠️  gtag not available");
    return;
  }

  // Send as event to Google Analytics
  gtag("event", `web_vitals_${metricName.toLowerCase()}`, {
    value: Math.round(value),
    event_category: "web_vitals",
    event_label: metricName,
    non_interaction: true,
    ...metadata,
  });

  // Log to console for debugging
  console.log(`📊 ${metricName}: ${Math.round(value)}ms`, metadata);
}

/**
 * Track page view
 */
export function trackPageView(path: string, title?: string) {
  const gtag = (window as any).gtag;
  
  if (!gtag) {
    console.warn("⚠️  gtag not available");
    return;
  }

  gtag("config", (window as any).GA_ID, {
    page_path: path,
    page_title: title || document.title,
  });
}

/**
 * Track custom event
 */
export function trackEvent(
  eventName: string,
  eventData?: Record<string, any>
) {
  const gtag = (window as any).gtag;
  
  if (!gtag) {
    console.warn("⚠️  gtag not available");
    return;
  }

  gtag("event", eventName, eventData);
}

/**
 * Track conversion (e.g., purchase, signup)
 */
export function trackConversion(
  conversionType: "purchase" | "signup" | "consultation" | "payment",
  value?: number,
  currency?: string
) {
  const gtag = (window as any).gtag;
  
  if (!gtag) {
    console.warn("⚠️  gtag not available");
    return;
  }

  gtag("event", "conversion", {
    conversion_type: conversionType,
    value: value || 0,
    currency: currency || "BRL",
  });
}

/**
 * Set user ID for tracking
 */
export function setAnalyticsUserId(userId: string) {
  const gtag = (window as any).gtag;
  
  if (!gtag) {
    console.warn("⚠️  gtag not available");
    return;
  }

  gtag("config", (window as any).GA_ID, {
    user_id: userId,
  });
}



/**
 * Type declaration for window.gtag
 */
declare global {
  interface Window {
    dataLayer: any[];
    gtag: (...args: any[]) => void;
    GA_ID: string;
  }
}
