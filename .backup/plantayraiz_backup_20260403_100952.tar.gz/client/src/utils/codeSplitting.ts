import React, { lazy, Suspense } from 'react';

// Lazy load rotas
export const lazyRoutes = {
  Home: lazy(() => import('../pages/Home')),
  Profissionais: lazy(() => import('../pages/Profissionais')),
  Marketplace: lazy(() => import('../pages/Marketplace')),
  Biblioteca: lazy(() => import('../pages/Biblioteca')),
  Telemedicina: lazy(() => import('../pages/Telemedicina')),
  Comunidade: lazy(() => import('../pages/Comunidade')),
  Admin: lazy(() => import('../pages/Admin')),
  Planos: lazy(() => import('../pages/Planos')),
  Perfil: lazy(() => import('../pages/Perfil')),
  Configuracoes: lazy(() => import('../pages/Configuracoes')),
  NotFound: lazy(() => import('../pages/NotFound')),
};

// Lazy load componentes pesados
export const lazyComponents = {
  CEOExecutiveDashboard: lazy(() => import('../components/CEOExecutiveDashboard')),
  AdminWorldMap: lazy(() => import('../components/AdminWorldMap')),
  MarketingCampaignDashboard: lazy(() => import('../components/MarketingCampaignDashboard')),
  CommunityThreads: lazy(() => import('../components/CommunityThreads')),
  PredictiveAnalytics: lazy(() => import('../components/PredictiveAnalytics')),
  AIChatBox: lazy(() => import('../components/AIChatBox')),
  Map: lazy(() => import('../components/Map')),
};

// Preload componentes críticos
export const preloadComponent = (
  importFunc: () => Promise<{ default: React.ComponentType<any> }>
) => {
  importFunc();
};

// Preload rotas críticas
export const preloadCriticalRoutes = () => {
  preloadComponent(() => import('../pages/Home'));
  preloadComponent(() => import('../pages/Profissionais'));
  preloadComponent(() => import('../pages/Marketplace'));
};

// Obter tamanho estimado de bundle
export const getBundleSizeEstimate = (): { [route: string]: string } => {
  return {
    Home: '~45KB',
    Profissionais: '~52KB',
    Marketplace: '~68KB',
    Biblioteca: '~71KB',
    Telemedicina: '~84KB',
    Comunidade: '~61KB',
    Admin: '~95KB',
    Planos: '~38KB',
    Perfil: '~42KB',
    Configuracoes: '~35KB',
  };
};

// Monitorar performance
export const monitorLazyLoadPerformance = (componentName: string, duration: number) => {
  if (duration > 1000) {
    console.warn(`⚠️ Componente ${componentName} levou ${duration}ms para carregar`);
  } else {
    console.log(`✅ Componente ${componentName} carregou em ${duration}ms`);
  }
};

export default {
  lazyRoutes,
  lazyComponents,
  preloadComponent,
  preloadCriticalRoutes,
  getBundleSizeEstimate,
  monitorLazyLoadPerformance,
};
