import { cacheGet, cacheSet, cacheDel } from './cache';

export interface WebhookEvent {
  id: string;
  type: string;
  data: Record<string, unknown>;
  timestamp: Date;
  retries: number;
  maxRetries: number;
  nextRetryAt?: Date;
  lastError?: string;
}

export interface WebhookHandler {
  (event: WebhookEvent): Promise<boolean>;
}

const WEBHOOK_HANDLERS: Map<string, WebhookHandler> = new Map();
const MAX_RETRIES = 5;
const INITIAL_RETRY_DELAY = 60 * 1000; // 1 minute
const MAX_RETRY_DELAY = 24 * 60 * 60 * 1000; // 24 hours

/**
 * Register webhook handler
 */
export function registerWebhookHandler(eventType: string, handler: WebhookHandler): void {
  WEBHOOK_HANDLERS.set(eventType, handler);
  console.log(`Webhook handler registered for: ${eventType}`);
}

/**
 * Get webhook handler
 */
export function getWebhookHandler(eventType: string): WebhookHandler | undefined {
  return WEBHOOK_HANDLERS.get(eventType);
}

/**
 * Calculate exponential backoff delay
 */
export function calculateRetryDelay(retryCount: number): number {
  const delay = INITIAL_RETRY_DELAY * Math.pow(2, retryCount);
  return Math.min(delay, MAX_RETRY_DELAY);
}

/**
 * Process webhook event
 */
export async function processWebhookEvent(event: WebhookEvent): Promise<boolean> {
  const handler = getWebhookHandler(event.type);

  if (!handler) {
    console.warn(`No handler registered for webhook type: ${event.type}`);
    return false;
  }

  try {
    const success = await handler(event);

    if (success) {
      // Remove from retry queue
      await cacheDel(`webhook:${event.id}`);
      console.log(`Webhook processed successfully: ${event.id}`);
      return true;
    }

    // Schedule retry
    await scheduleWebhookRetry(event);
    return false;
  } catch (error) {
    console.error(`Error processing webhook ${event.id}:`, error);
    event.lastError = error instanceof Error ? error.message : String(error);
    await scheduleWebhookRetry(event);
    return false;
  }
}

/**
 * Schedule webhook retry
 */
export async function scheduleWebhookRetry(event: WebhookEvent): Promise<void> {
  if (event.retries >= event.maxRetries) {
    console.error(`Max retries reached for webhook: ${event.id}`);
    // Store failed webhook for manual review
    await cacheSet(`webhook:failed:${event.id}`, event, 7 * 24 * 60 * 60);
    return;
  }

  const nextRetryCount = event.retries + 1;
  const delay = calculateRetryDelay(nextRetryCount);
  const nextRetryAt = new Date(Date.now() + delay);

  event.retries = nextRetryCount;
  event.nextRetryAt = nextRetryAt;

  // Store in cache with TTL
  const ttl = Math.ceil(delay / 1000);
  await cacheSet(`webhook:${event.id}`, event, ttl);

  console.log(
    `Webhook retry scheduled for ${event.id} at ${nextRetryAt.toISOString()} (attempt ${nextRetryCount}/${event.maxRetries})`
  );
}

/**
 * Retry pending webhooks
 */
export async function retryPendingWebhooks(): Promise<void> {
  console.log('Checking for pending webhooks to retry...');

  // This would typically be called by a cron job or background task
  // In a real implementation, you'd query the database for pending webhooks
  // For now, this is a placeholder for the retry logic
}

/**
 * Create webhook event
 */
export function createWebhookEvent(
  type: string,
  data: Record<string, unknown>,
  maxRetries: number = MAX_RETRIES
): WebhookEvent {
  return {
    id: `webhook-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    type,
    data,
    timestamp: new Date(),
    retries: 0,
    maxRetries,
  };
}

/**
 * Handle Mercado Pago webhook
 */
export async function handleMercadoPagoWebhook(event: WebhookEvent): Promise<boolean> {
  const { id, type, data } = event.data;

  if (type !== 'payment') {
    console.log(`Ignoring non-payment webhook: ${type}`);
    return true;
  }

  try {
    // TODO: Fetch payment details from Mercado Pago API
    // const paymentDetails = await getPaymentDetails(data.id);

    // Process payment
    console.log(`Processing Mercado Pago payment: ${data.id}`);

    // TODO: Update database with payment status
    // TODO: Send notifications
    // TODO: Update user balance

    return true;
  } catch (error) {
    console.error(`Error handling Mercado Pago webhook:`, error);
    return false;
  }
}

/**
 * Handle Stripe webhook
 */
export async function handleStripeWebhook(event: WebhookEvent): Promise<boolean> {
  const { type, data } = event.data;

  try {
    console.log(`Processing Stripe event: ${type}`);

    // TODO: Handle different Stripe event types
    // - charge.succeeded
    // - charge.failed
    // - customer.subscription.updated
    // - etc.

    return true;
  } catch (error) {
    console.error(`Error handling Stripe webhook:`, error);
    return false;
  }
}

// Register default handlers
registerWebhookHandler('mercadopago', handleMercadoPagoWebhook);
registerWebhookHandler('stripe', handleStripeWebhook);
