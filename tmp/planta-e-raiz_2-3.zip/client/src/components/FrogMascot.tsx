import React, { useState, useEffect, useRef } from 'react';
import FrogChatModal from './FrogChatModal';

interface MousePosition {
  x: number;
  y: number;
}

const FrogMascot: React.FC = () => {
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [mousePos, setMousePos] = useState<MousePosition>({ x: 0, y: 0 });
  const [headRotation, setHeadRotation] = useState({ x: 0, y: 0 });
  const frogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });

      if (frogRef.current) {
        const frogRect = frogRef.current.getBoundingClientRect();
        const frogCenterX = frogRect.left + frogRect.width / 2;
        const frogCenterY = frogRect.top + frogRect.height / 2;

        const deltaX = e.clientX - frogCenterX;
        const deltaY = e.clientY - frogCenterY;

        const angle = Math.atan2(deltaY, deltaX);
        const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);

        // Limitar rotação para não virar muito
        const maxRotation = Math.min(distance / 100, 0.3);

        setHeadRotation({
          x: Math.sin(angle) * maxRotation * 20,
          y: Math.cos(angle) * maxRotation * 20,
        });
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <>
      <div
        ref={frogRef}
        className="fixed top-20 left-4 z-40 w-16 h-20 cursor-pointer group"
        title="Sapo Verde - Assistente de IA"
        onClick={() => setIsChatOpen(true)}
      >
      {/* Corpo do Sapo */}
      <div className="relative w-full h-full">
        {/* Perna traseira esquerda */}
        <div className="absolute bottom-2 left-1 w-4 h-3 bg-green-500 rounded-full opacity-80 group-hover:opacity-100 transition-opacity"></div>

        {/* Perna traseira direita */}
        <div className="absolute bottom-2 right-1 w-4 h-3 bg-green-500 rounded-full opacity-80 group-hover:opacity-100 transition-opacity"></div>

        {/* Corpo principal */}
        <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-12 h-14 bg-gradient-to-b from-green-400 to-green-600 rounded-full shadow-lg">
          {/* Barriga */}
          <div className="absolute top-4 left-1/2 transform -translate-x-1/2 w-8 h-8 bg-green-300 rounded-full opacity-70"></div>

          {/* Perna dianteira esquerda */}
          <div className="absolute bottom-1 left-0 w-3 h-2 bg-green-500 rounded-full opacity-80"></div>

          {/* Perna dianteira direita */}
          <div className="absolute bottom-1 right-0 w-3 h-2 bg-green-500 rounded-full opacity-80"></div>
        </div>

        {/* Cabeça (acompanha mouse) */}
        <div
          className="absolute top-0 left-1/2 transform -translate-x-1/2 w-10 h-10 bg-gradient-to-b from-green-300 to-green-500 rounded-full shadow-lg transition-transform duration-100"
          style={{
            transform: `translate(calc(-50% + ${headRotation.y}px), ${headRotation.x}px)`,
          }}
        >
          {/* Olho esquerdo */}
          <div className="absolute top-2 left-2 w-3 h-3 bg-white rounded-full shadow-md">
            <div className="absolute top-0.5 left-0.5 w-1.5 h-1.5 bg-black rounded-full"></div>
          </div>

          {/* Olho direito */}
          <div className="absolute top-2 right-2 w-3 h-3 bg-white rounded-full shadow-md">
            <div className="absolute top-0.5 right-0.5 w-1.5 h-1.5 bg-black rounded-full"></div>
          </div>

          {/* Boca */}
          <div className="absolute bottom-1 left-1/2 transform -translate-x-1/2 w-4 h-2 border-b-2 border-green-700 rounded-b-full"></div>
        </div>

        {/* Tooltip ao hover */}
        <div className="absolute top-20 left-0 bg-slate-900 text-green-400 px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
          Posso ajudar? 🐸
        </div>
      </div>
      </div>

      {/* Chat Modal */}
      <FrogChatModal isOpen={isChatOpen} onClose={() => setIsChatOpen(false)} />
    </>
  );
};

export default FrogMascot;
